'use strict';

const fs = require('node:fs');
const path = require('node:path');
const zlib = require('node:zlib');
const { spawnSync } = require('node:child_process');

const isElectronMain = Boolean(process.versions.electron) && process.type === 'browser';

if (!isElectronMain) {
  const executable = process.versions.electron ? process.execPath : require('electron');
  const env = { ...process.env };
  delete env.ELECTRON_RUN_AS_NODE;
  const result = spawnSync(executable, [__filename, ...process.argv.slice(2)], {
    stdio: 'inherit',
    env,
  });
  if (result.error) throw result.error;
  process.exit(result.status == null ? 1 : result.status);
}

const { app, nativeImage } = require('electron');

const ROOT = path.join(__dirname, '..');
const SOURCE = path.join(__dirname, 'assets', 'perfillab-logo.png');
const MAIN_ASSETS = path.join(ROOT, 'assets');
const ADMIN_ASSETS = path.join(ROOT, 'license-admin', 'assets');
const ICO_SIZES = [16, 24, 32, 48, 64, 128, 256];
const PNG_ICO_FROM = 256;

function decodePng(buffer) {
  if (buffer.length < 8 || buffer.readUInt32BE(0) !== 0x89504e47) throw new Error('PNG no válido.');
  let pos = 8;
  let width = 0;
  let height = 0;
  let bitDepth = 0;
  let colorType = 0;
  let interlace = 0;
  const chunks = [];
  while (pos + 8 <= buffer.length) {
    const length = buffer.readUInt32BE(pos);
    const type = buffer.toString('ascii', pos + 4, pos + 8);
    const data = buffer.subarray(pos + 8, pos + 8 + length);
    pos += length + 12;
    if (type === 'IHDR') {
      width = data.readUInt32BE(0);
      height = data.readUInt32BE(4);
      bitDepth = data[8];
      colorType = data[9];
      interlace = data[12];
    } else if (type === 'IDAT') {
      chunks.push(data);
    } else if (type === 'IEND') {
      break;
    }
  }
  if (!width || !height) throw new Error('PNG sin dimensiones.');
  if (bitDepth !== 8 || (colorType !== 6 && colorType !== 2) || interlace !== 0) {
    throw new Error(`Formato PNG no soportado (${bitDepth} bits, color ${colorType}, entrelazado ${interlace}).`);
  }
  const channels = colorType === 6 ? 4 : 3;
  const stride = width * channels;
  const raw = zlib.inflateSync(Buffer.concat(chunks));
  const rgba = Buffer.alloc(width * height * 4);
  let previous = Buffer.alloc(stride);
  for (let y = 0; y < height; y += 1) {
    const filter = raw[y * (stride + 1)];
    const line = Buffer.from(raw.subarray(y * (stride + 1) + 1, (y + 1) * (stride + 1)));
    for (let x = 0; x < stride; x += 1) {
      const left = x >= channels ? line[x - channels] : 0;
      const up = previous[x];
      const upLeft = x >= channels ? previous[x - channels] : 0;
      let value = line[x];
      if (filter === 1) value += left;
      else if (filter === 2) value += up;
      else if (filter === 3) value += (left + up) >> 1;
      else if (filter === 4) {
        const estimate = left + up - upLeft;
        const pa = Math.abs(estimate - left);
        const pb = Math.abs(estimate - up);
        const pc = Math.abs(estimate - upLeft);
        value += pa <= pb && pa <= pc ? left : pb <= pc ? up : upLeft;
      }
      line[x] = value & 0xff;
    }
    for (let x = 0; x < width; x += 1) {
      const target = (y * width + x) * 4;
      rgba[target] = line[x * channels];
      rgba[target + 1] = line[x * channels + 1];
      rgba[target + 2] = line[x * channels + 2];
      rgba[target + 3] = channels === 4 ? line[x * channels + 3] : 255;
    }
    previous = line;
  }
  return { width, height, rgba };
}

function crc32(buffer) {
  return zlib.crc32(buffer) >>> 0;
}

function pngChunk(type, data) {
  const name = Buffer.from(type, 'ascii');
  const length = Buffer.alloc(4);
  length.writeUInt32BE(data.length, 0);
  const crc = Buffer.alloc(4);
  crc.writeUInt32BE(crc32(Buffer.concat([name, data])), 0);
  return Buffer.concat([length, name, data, crc]);
}

function encodePng(size, rgba) {
  const stride = size * 4;
  const raw = Buffer.alloc((stride + 1) * size);
  for (let y = 0; y < size; y += 1) {
    raw[y * (stride + 1)] = 0;
    rgba.copy(raw, y * (stride + 1) + 1, y * stride, (y + 1) * stride);
  }
  const header = Buffer.alloc(13);
  header.writeUInt32BE(size, 0);
  header.writeUInt32BE(size, 4);
  header[8] = 8;
  header[9] = 6;
  return Buffer.concat([
    Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]),
    pngChunk('IHDR', header),
    pngChunk('IDAT', zlib.deflateSync(raw, { level: 9 })),
    pngChunk('IEND', Buffer.alloc(0)),
  ]);
}

function bmpFrame(size, rgba) {
  const rowBytes = size * 4;
  const pixels = Buffer.alloc(rowBytes * size);
  const maskStride = ((size + 31) >> 5) * 4;
  const mask = Buffer.alloc(maskStride * size);
  for (let y = 0; y < size; y += 1) {
    const source = (size - 1 - y) * rowBytes;
    const target = y * rowBytes;
    for (let x = 0; x < size; x += 1) {
      const from = source + x * 4;
      const to = target + x * 4;
      pixels[to] = rgba[from + 2];
      pixels[to + 1] = rgba[from + 1];
      pixels[to + 2] = rgba[from];
      pixels[to + 3] = rgba[from + 3];
      if (rgba[from + 3] === 0) mask[y * maskStride + (x >> 3)] |= 0x80 >> (x & 7);
    }
  }
  const header = Buffer.alloc(40);
  header.writeUInt32LE(40, 0);
  header.writeInt32LE(size, 4);
  header.writeInt32LE(size * 2, 8);
  header.writeUInt16LE(1, 12);
  header.writeUInt16LE(32, 14);
  header.writeUInt32LE(0, 16);
  header.writeUInt32LE(pixels.length + mask.length, 20);
  return Buffer.concat([header, pixels, mask]);
}

function buildIco(frames) {
  const directory = Buffer.alloc(6 + frames.length * 16);
  directory.writeUInt16LE(0, 0);
  directory.writeUInt16LE(1, 2);
  directory.writeUInt16LE(frames.length, 4);
  let offset = directory.length;
  frames.forEach((frame, index) => {
    const entry = 6 + index * 16;
    directory[entry] = frame.size >= 256 ? 0 : frame.size;
    directory[entry + 1] = frame.size >= 256 ? 0 : frame.size;
    directory[entry + 2] = 0;
    directory[entry + 3] = 0;
    directory.writeUInt16LE(1, entry + 4);
    directory.writeUInt16LE(32, entry + 6);
    directory.writeUInt32LE(frame.data.length, entry + 8);
    directory.writeUInt32LE(offset, entry + 12);
    offset += frame.data.length;
  });
  return Buffer.concat([directory, ...frames.map((frame) => frame.data)]);
}

function write(file, data) {
  fs.mkdirSync(path.dirname(file), { recursive: true });
  fs.writeFileSync(file, data);
  process.stdout.write(`  ${path.relative(ROOT, file)}  ${data.length} B\n`);
}

function run() {
  if (!fs.existsSync(SOURCE)) throw new Error(`No se encontró el logo de origen: ${SOURCE}`);
  const logo = nativeImage.createFromPath(SOURCE);
  if (logo.isEmpty()) throw new Error(`Electron no pudo leer el logo: ${SOURCE}`);
  const { width, height } = logo.getSize();
  if (width !== height) throw new Error(`El logo debe ser cuadrado; recibido ${width}x${height}.`);

  const pngBySize = new Map();
  for (const size of ICO_SIZES) {
    const image = size === width ? logo : logo.resize({ width: size, height: size, quality: 'best' });
    const png = image.toPNG();
    if (!png.length) throw new Error(`No se pudo generar el icono de ${size}px.`);
    pngBySize.set(size, png);
  }

  const frames = ICO_SIZES.map((size) => ({
    size,
    data: size >= PNG_ICO_FROM ? pngBySize.get(size) : bmpFrame(size, decodePng(pngBySize.get(size)).rgba),
  }));
  const ico = buildIco(frames);
  const icon256 = pngBySize.get(256);
  const tray32 = pngBySize.get(32);

  process.stdout.write('Generando iconos de PerfilLab:\n');
  write(path.join(MAIN_ASSETS, 'icon.png'), icon256);
  write(path.join(MAIN_ASSETS, 'logo.png'), icon256);
  write(path.join(MAIN_ASSETS, 'tray.png'), tray32);
  write(path.join(MAIN_ASSETS, 'icon.ico'), ico);
  write(path.join(ADMIN_ASSETS, 'icon.png'), icon256);
  write(path.join(ADMIN_ASSETS, 'logo.png'), icon256);
  write(path.join(ADMIN_ASSETS, 'icon.ico'), ico);
}

app.whenReady().then(() => {
  try {
    run();
  } catch (error) {
    process.stderr.write(`Error generando los iconos: ${error.message}\n`);
    app.exit(1);
    return;
  }
  app.exit(0);
}).catch((error) => {
  process.stderr.write(`Error iniciando Electron: ${error.message}\n`);
  app.exit(1);
});
