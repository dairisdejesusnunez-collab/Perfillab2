'use strict';

const crypto = require('node:crypto');
const fs = require('node:fs');
const path = require('node:path');
const core = require('../license-admin/lib/core');
const { HISTORICAL_LICENSE_LIMIT, keyIdFor } = require('../shared/license-format');

const root = path.join(__dirname, '..');
const seedDir = path.join(root, 'license-admin', 'seed');
const seedFile = path.join(seedDir, 'vault.json');
const publicModule = path.join(root, 'electron', 'license-public.js');
const passwordFile = path.join(root, '..', 'perfillab-admin-password.txt');
const force = process.argv.includes('--force');

if (!force && (fs.existsSync(seedFile) || fs.existsSync(publicModule))) {
  console.error('Ya existe una bóveda o clave pública. Usa --force solo si quieres invalidar todas las licencias emitidas.');
  process.exit(1);
}

const alphabet = '0123456789ABCDEFGHJKMNPQRSTVWXYZ';
function group(value, size = 4) {
  return value.match(new RegExp(`.{1,${size}}`, 'g')).join('-');
}
function randomPassword() {
  let value = '';
  while (value.length < 16) {
    const byte = crypto.randomBytes(1)[0];
    if (byte < 248) value += alphabet[byte % 32];
  }
  return group(value);
}

const password = randomPassword();
const keys = core.generateKeyPair();
const seats = core.createSeats(core.SEAT_LIMIT);
const { file } = core.createVault({
  password,
  privateKey: keys.privateKey,
  publicKey: keys.publicKey,
  seats,
});

fs.mkdirSync(seedDir, { recursive: true });
const tempSeed = `${seedFile}.tmp`;
fs.writeFileSync(tempSeed, `${JSON.stringify(file, null, 2)}\n`, 'utf8');
fs.renameSync(tempSeed, seedFile);

const serverArg = process.argv.find((arg) => arg.startsWith('--server-url='));
let serverUrl = serverArg ? serverArg.slice('--server-url='.length).trim() : '';
if (serverUrl) {
  let parsed;
  try {
    parsed = new URL(serverUrl);
  } catch {
    console.error('La dirección del servidor no es válida.');
    process.exit(1);
  }
  if (parsed.protocol !== 'http:' && parsed.protocol !== 'https:') {
    console.error('El servidor debe usar http:// o https://.');
    process.exit(1);
  }
  const hostname = parsed.hostname.toLowerCase().replace(/^\[|\]$/g, '');
  const loopback = hostname === 'localhost' || hostname === '::1' || /^127(?:\.\d{1,3}){3}$/.test(hostname);
  if (parsed.protocol === 'http:' && !loopback) {
    console.error('Para un servidor remoto usa HTTPS. HTTP solo se permite en localhost o 127.0.0.1.');
    process.exit(1);
  }
  serverUrl = parsed.origin;
}

const moduleSource = `'use strict';

// Generada por scripts/provision-license.js. Cambiar esta clave invalida las licencias emitidas.
module.exports = {
  publicKey: ${JSON.stringify(keys.publicKey)},
  keyId: ${JSON.stringify(keyIdFor(keys.publicKey))},
  seatLimit: ${HISTORICAL_LICENSE_LIMIT},
  serverUrl: ${JSON.stringify(serverUrl)},
  generatedAt: ${JSON.stringify(new Date().toISOString())},
};
`;
fs.writeFileSync(publicModule, moduleSource, 'utf8');

const passwordText = [
  'PerfilLab · contraseña inicial de la bóveda de licencias',
  '',
  password,
  '',
  'Úsala al abrir PerfilLab Licencias. Cambia la contraseña desde Herramientas.',
  'No compartas este archivo ni la aplicación de administración.',
  '',
].join('\r\n');
fs.writeFileSync(passwordFile, passwordText, 'utf8');

console.log(`Bóveda inicial: ${path.relative(root, seedFile)} (${seats.length} asientos heredados; el servidor migra a ${HISTORICAL_LICENSE_LIMIT})`);
console.log(`Clave pública: ${path.relative(root, publicModule)}`);
console.log(`Contraseña inicial guardada en: ${passwordFile}`);
console.log('No compartas ese archivo ni lo incluyas en el instalador o el repositorio.');
