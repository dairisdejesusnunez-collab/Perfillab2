'use strict';

const assert = require('node:assert/strict');
const { spawn } = require('node:child_process');
const fs = require('node:fs');
const http = require('node:http');
const net = require('node:net');
const os = require('node:os');
const path = require('node:path');

const electronPath = require('electron');
const root = path.join(__dirname, '..');
const buildDir = path.join(root, 'build');

function delay(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function freePort() {
  return new Promise((resolve, reject) => {
    const server = net.createServer();
    server.once('error', reject);
    server.listen(0, '127.0.0.1', () => {
      const { port } = server.address();
      server.close(() => resolve(port));
    });
  });
}

function startTestServer() {
  const pages = {
    '/page-a': `<!doctype html><html><head><meta charset="utf-8"><title>Página A</title></head>
      <body><h1>Página A</h1><p>Contenido del perfil A: aguja uno.</p>
      <p>Segunda aguja del documento.</p><p>Tercera aguja.</p>
      <a id="to-b" href="/page-b">Ir a la página B</a></body></html>`,
    '/page-b': `<!doctype html><html><head><meta charset="utf-8"><title>Página B</title></head>
      <body><h1>Página B</h1><p>Navegación verificada: aguja uno.</p>
      <p>Otra aguja para la búsqueda.</p><p>Tercera aguja.</p>
      <a id="popup" href="/page-c" target="_blank">Abrir página C</a></body></html>`,
    '/page-c': `<!doctype html><html><head><meta charset="utf-8"><title>Página C</title></head>
      <body><h1>Página C</h1><p>Pestaña nueva del navegador integrado.</p></body></html>`,
  };
  const server = http.createServer((req, res) => {
    const url = new URL(req.url, 'http://127.0.0.1');
    if (url.pathname === '/download') {
      const body = 'descarga de prueba PerfilLab\n';
      res.writeHead(200, {
        'Content-Type': 'text/plain; charset=utf-8',
        'Content-Disposition': 'attachment; filename="perfilab-prueba.txt"',
        'Content-Length': Buffer.byteLength(body),
      });
      res.end(body);
      return;
    }
    const html = pages[url.pathname];
    if (!html) {
      res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
      res.end('no encontrado');
      return;
    }
    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
    res.end(html);
  });
  return new Promise((resolve, reject) => {
    server.once('error', reject);
    server.listen(0, '127.0.0.1', () => {
      const { port } = server.address();
      resolve({ server, base: `http://127.0.0.1:${port}`, port });
    });
  });
}

async function waitForPage(port, predicate, label, timeout = 30000) {
  const deadline = Date.now() + timeout;
  let lastError = null;
  while (Date.now() < deadline) {
    try {
      const response = await fetch(`http://127.0.0.1:${port}/json/list`);
      if (response.ok) {
        const pages = await response.json();
        const page = pages.find((item) => item.type === 'page' && predicate(item));
        if (page) return page;
      }
    } catch (error) {
      lastError = error;
    }
    await delay(200);
  }
  throw new Error(`No apareció ${label}. ${lastError ? lastError.message : ''}`);
}

function connectCdp(wsUrl) {
  return new Promise((resolve, reject) => {
    const ws = new WebSocket(wsUrl);
    ws.onerror = () => reject(new Error('No se pudo conectar al depurador.'));
    ws.onopen = () => {
      let nextId = 1;
      const pending = new Map();
      ws.onmessage = (event) => {
        const message = JSON.parse(String(event.data));
        if (!message.id) return;
        const handler = pending.get(message.id);
        if (!handler) return;
        pending.delete(message.id);
        if (message.error) handler.reject(new Error(message.error.message));
        else handler.resolve(message.result);
      };
      const send = (method, params = {}) => {
        const id = nextId++;
        return new Promise((res, rej) => {
          pending.set(id, { resolve: res, reject: rej });
          ws.send(JSON.stringify({ id, method, params }));
        });
      };
      const evaluate = async (expression, options = {}) => {
        const result = await send('Runtime.evaluate', {
          expression,
          awaitPromise: true,
          returnByValue: true,
          userGesture: options.userGesture === true,
        });
        if (result.exceptionDetails) {
          throw new Error(result.exceptionDetails.exception
            ? result.exceptionDetails.exception.description
            : result.exceptionDetails.text);
        }
        return result.result.value;
      };
      const screenshot = async (name) => {
        const shot = await send('Page.captureScreenshot', { format: 'png' });
        const file = path.join(buildDir, name);
        fs.writeFileSync(file, Buffer.from(shot.data, 'base64'));
        return file;
      };
      resolve({ ws, send, evaluate, screenshot, close: () => ws.close() });
    };
  });
}

async function launchBrowser({ debugPort, profileId, profileName, profileDir, dataDir, startUrl = '', requireLicense = false }) {
  fs.mkdirSync(profileDir, { recursive: true });
  fs.mkdirSync(dataDir, { recursive: true });
  const browserData = path.join(profileDir, 'browser');
  const downloads = path.join(profileDir, 'downloads');
  const args = [
    root,
    '--perfillab-browser',
    `--perfillab-profile-id=${profileId}`,
    `--perfillab-profile-name=${encodeURIComponent(profileName)}`,
    `--perfillab-browser-data=${browserData}`,
    `--perfillab-downloads=${downloads}`,
    `--perfillab-app-data=${dataDir}`,
    '--perfillab-proxy-label=Sin%20proxy',
  ];
  if (startUrl) args.push(startUrl);
  const env = { ...process.env, PERFILLAB_DEBUG_PORT: String(debugPort) };
  delete env.ELECTRON_RUN_AS_NODE;
  if (requireLicense) env.PERFILLAB_REQUIRE_LICENSE = '1';
  else delete env.PERFILLAB_REQUIRE_LICENSE;
  const child = spawn(electronPath, args, {
    cwd: root,
    env,
    windowsHide: false,
    stdio: ['ignore', 'pipe', 'pipe'],
  });
  let stderr = '';
  child.stderr.on('data', (chunk) => {
    stderr += String(chunk);
  });
  return { child, stderr: () => stderr, downloads, browserData };
}

async function stopBrowser(child, target) {
  if (!child || child.exitCode !== null) return;
  try {
    if (target) await target.send('Page.close');
  } catch {
    // La ventana pudo cerrarse antes.
  }
  await new Promise((resolve) => {
    const timer = setTimeout(() => {
      try {
        child.kill();
      } catch {
        // El proceso ya no existe.
      }
      resolve();
    }, 6000);
    child.once('exit', () => {
      clearTimeout(timer);
      resolve();
    });
  });
}

async function waitState(shell, predicate, label, timeout = 15000) {
  const deadline = Date.now() + timeout;
  let state = null;
  while (Date.now() < deadline) {
    state = await shell.evaluate('window.perfilabBrowser.getState()');
    if (predicate(state)) return state;
    await delay(150);
  }
  throw new Error(`Tiempo de espera agotado: ${label}. Estado: ${JSON.stringify(state)}`);
}

async function runProfileChecks({ base, tempRoot, port, startUrl }) {
  const profileDir = path.join(tempRoot, 'profiles', 'perfil-a');
  const dataDir = path.join(tempRoot, 'data-a');
  const app = await launchBrowser({
    debugPort: port,
    profileId: 'perfil-ui-a',
    profileName: 'Perfil UI A',
    profileDir,
    dataDir,
    startUrl,
  });
  let shell = null;
  let tab = null;
  try {
    const shellPage = await waitForPage(port, (page) => page.url.includes('renderer/browser.html'), 'la interfaz del navegador');
    shell = await connectCdp(shellPage.webSocketDebuggerUrl);
    await shell.send('Runtime.enable');
    await shell.send('Page.enable');
    const tabPage = await waitForPage(port, (page) => page.url.startsWith(base), 'la pestaña del perfil A');
    tab = await connectCdp(tabPage.webSocketDebuggerUrl);
    await tab.send('Runtime.enable');

    const chromeHeight = await shell.evaluate(`document.getElementById('chrome').getBoundingClientRect().height`);
    assert.equal(Math.round(chromeHeight), 96, `El cromo debe medir 96 px y mide ${chromeHeight}`);
    const profileChip = await shell.evaluate(`document.getElementById('profile-chip').title`);
    assert.match(profileChip, /Perfil UI A/);
    assert.match(profileChip, /Chromium/);
    const initial = await waitState(shell, (state) => state.tabs.length === 1 && state.tabs[0].title === 'Página A', 'pestaña A cargada');
    assert.equal(initial.profile.id, 'perfil-ui-a');
    assert.equal(initial.tabs[0].secure, false);
    assert.equal(initial.tabs[0].home, false);
    assert.match(initial.tabs[0].url, /\/page-a$/);
    const security = await shell.evaluate(`document.getElementById('security').title`);
    assert.match(security, /no segura \(HTTP\)/i);
    const userAgent = await tab.evaluate('navigator.userAgent');
    assert.match(userAgent, /PerfilLab\//);
    assert.match(userAgent, /Chrome\//);
    const content = await tab.evaluate('document.body.innerText');
    assert.match(content, /Contenido del perfil A/);
    await shell.screenshot('browser-shell-a.png');
    await tab.screenshot('browser-page-a.png');

    await shell.evaluate(`window.perfilabBrowser.navigate('${base}/page-b')`);
    await waitState(shell, (state) => state.tabs[0].url.endsWith('/page-b') && state.tabs[0].canGoBack, 'navegación a B');
    await shell.evaluate('window.perfilabBrowser.back()');
    const back = await waitState(shell, (state) => state.tabs[0].url.endsWith('/page-a') && state.tabs[0].canGoForward, 'atrás a A');
    assert.equal(back.tabs[0].canGoBack, false);
    await shell.evaluate('window.perfilabBrowser.forward()');
    await waitState(shell, (state) => state.tabs[0].url.endsWith('/page-b')
      && state.tabs[0].title === 'Página B'
      && state.tabs[0].loading === false, 'adelante a B');
    await delay(400);

    await shell.evaluate(`document.dispatchEvent(new KeyboardEvent('keydown', { key: 'f', ctrlKey: true, bubbles: true }))`);
    const findVisible = await shell.evaluate(`!document.getElementById('findbar').hidden`);
    assert.equal(findVisible, true, 'La barra de búsqueda debe abrirse con Ctrl+F');
    await shell.evaluate(`(() => {
      const input = document.getElementById('find-input');
      input.value = 'aguja';
      input.dispatchEvent(new Event('input', { bubbles: true }));
    })()`);
    const deadline = Date.now() + 10000;
    let count = '0/0';
    while (Date.now() < deadline) {
      count = await shell.evaluate(`document.getElementById('find-count').textContent`);
      const match = /^(\d+)\/(\d+)$/.exec(count);
      if (match && Number(match[2]) >= 2) break;
      await delay(120);
    }
    assert.match(count, /^\d+\/\d+$/);
    assert.ok(Number(count.split('/')[1]) >= 2, `Se esperaban coincidencias y se obtuvo ${count}`);
    assert.match(count, /^[1-9]\//, `La coincidencia activa debe ser válida y se obtuvo ${count}`);
    await shell.evaluate(`document.getElementById('find-close').click()`);
    await delay(300);
    assert.equal(await shell.evaluate(`document.getElementById('find-count').textContent`), '0/0');

    await shell.evaluate(`document.dispatchEvent(new KeyboardEvent('keydown', { key: '=', ctrlKey: true, bubbles: true }))`);
    await delay(500);
    const zoomNotice = await shell.evaluate(`document.getElementById('notice-text').textContent`);
    assert.match(zoomNotice, /Zoom: 120%/);
    await shell.evaluate('window.perfilabBrowser.zoom(0)');
    await delay(300);

    const downloadPath = path.join(profileDir, 'downloads', 'perfilab-prueba.txt');
    assert.equal(fs.existsSync(downloadPath), false);
    await tab.evaluate(`document.createElement('a'); const link = document.createElement('a'); link.href = '/download'; link.download = 'perfilab-prueba.txt'; document.body.append(link); link.click();`, { userGesture: true });
    const downloaded = await waitState(shell, (state) => state.downloads.some((item) => item.state === 'completed'), 'descarga completada', 20000);
    const record = downloaded.downloads.find((item) => item.state === 'completed');
    assert.equal(record.filename, 'perfilab-prueba.txt');
    assert.equal(fs.existsSync(downloadPath), true, 'La descarga debe quedar en la carpeta del perfil');
    assert.match(fs.readFileSync(downloadPath, 'utf8'), /descarga de prueba PerfilLab/);

    await tab.evaluate(`document.getElementById('popup').click()`, { userGesture: true });
    const twoTabs = await waitState(
      shell,
      (state) => state.tabs.length === 2 && state.tabs.some((item) => item.url.endsWith('/page-c')),
      'pestaña emergente',
    );
    assert.equal(twoTabs.tabs.filter((item) => item.url.endsWith('/page-c')).length, 1);
    const popupTab = twoTabs.tabs.find((item) => item.url.endsWith('/page-c'));
    await shell.evaluate(`window.perfilabBrowser.closeTab('${popupTab.id}')`);
    await waitState(shell, (state) => state.tabs.length === 1, 'cierre de la pestaña emergente');

    const deadPort = await freePort();
    await shell.evaluate(`window.perfilabBrowser.navigate('http://127.0.0.1:${deadPort}/sin-servidor')`);
    const failed = await waitState(shell, (state) => state.tabs[0].error === true, 'página de error', 20000);
    assert.match(failed.tabs[0].url, new RegExp(`127\\.0\\.0\\.1:${deadPort}`));
    const errorPage = await waitForPage(port, (page) => page.url.includes('browser-error.html'), 'la página de error');
    const errorClient = await connectCdp(errorPage.webSocketDebuggerUrl);
    await errorClient.send('Runtime.enable');
    const errorText = await errorClient.evaluate('document.body.innerText');
    assert.match(errorText, /No se pudo cargar|sin-servidor/i);
    await errorClient.close();

    await shell.evaluate(`window.perfilabBrowser.navigate('${base}/page-a')`);
    await waitState(shell, (state) => state.tabs[0].url.endsWith('/page-a') && !state.tabs[0].error, 'vuelta a A');
    const tabForFullscreen = await waitForPage(port, (page) => page.url.endsWith('/page-a'), 'la pestaña A para pantalla completa');
    const tabFs = await connectCdp(tabForFullscreen.webSocketDebuggerUrl);
    await tabFs.send('Runtime.enable');
    await tabFs.evaluate('document.documentElement.requestFullscreen()', { userGesture: true });
    await waitState(shell, (state) => state.fullscreen === true, 'pantalla completa', 15000);
    await tabFs.evaluate('document.exitFullscreen()', { userGesture: true });
    await waitState(shell, (state) => state.fullscreen === false, 'salida de pantalla completa', 15000);
    await tabFs.close();

    await tab.evaluate(`document.cookie = 'pl_iso=perfil-a; path=/; max-age=86400'; localStorage.setItem('pl_iso', 'perfil-a');`);
    const marked = await tab.evaluate(`document.cookie.includes('pl_iso=perfil-a') && localStorage.getItem('pl_iso') === 'perfil-a'`);
    assert.equal(marked, true);

    await stopBrowser(app.child, shell);
    assert.equal(fs.existsSync(downloadPath), true);
    return { downloadPath, browserData: path.join(profileDir, 'browser') };
  } finally {
    await stopBrowser(app.child, shell);
    if (tab) tab.close();
    if (shell) shell.close();
  }
}

async function runIsolationCheck({ base, tempRoot, port }) {
  const profileDir = path.join(tempRoot, 'profiles', 'perfil-b');
  const dataDir = path.join(tempRoot, 'data-b');
  const app = await launchBrowser({
    debugPort: port,
    profileId: 'perfil-ui-b',
    profileName: 'Perfil UI B',
    profileDir,
    dataDir,
    startUrl: `${base}/page-a`,
  });
  let shell = null;
  let tab = null;
  try {
    const shellPage = await waitForPage(port, (page) => page.url.includes('renderer/browser.html'), 'la interfaz del perfil B');
    shell = await connectCdp(shellPage.webSocketDebuggerUrl);
    await shell.send('Runtime.enable');
    const tabPage = await waitForPage(port, (page) => page.url.startsWith(base), 'la pestaña del perfil B');
    tab = await connectCdp(tabPage.webSocketDebuggerUrl);
    await tab.send('Runtime.enable');
    const isolated = await tab.evaluate(`document.cookie.includes('pl_iso=perfil-a') || localStorage.getItem('pl_iso') !== null`);
    assert.equal(isolated, false, 'El perfil B no debe heredar cookies ni almacenamiento del perfil A');
    const downloads = path.join(profileDir, 'downloads');
    assert.equal(fs.existsSync(path.join(downloads, 'perfilab-prueba.txt')), false);
  } finally {
    await stopBrowser(app.child, shell);
    if (tab) tab.close();
    if (shell) shell.close();
  }
}

async function runPersistenceCheck({ base, tempRoot, port }) {
  const profileDir = path.join(tempRoot, 'profiles', 'perfil-a');
  const dataDir = path.join(tempRoot, 'data-a');
  const app = await launchBrowser({
    debugPort: port,
    profileId: 'perfil-ui-a',
    profileName: 'Perfil UI A',
    profileDir,
    dataDir,
    startUrl: `${base}/page-a`,
  });
  let shell = null;
  let tab = null;
  try {
    const shellPage = await waitForPage(port, (page) => page.url.includes('renderer/browser.html'), 'la interfaz persistida');
    shell = await connectCdp(shellPage.webSocketDebuggerUrl);
    await shell.send('Runtime.enable');
    const tabPage = await waitForPage(port, (page) => page.url.startsWith(base), 'la pestaña persistida');
    tab = await connectCdp(tabPage.webSocketDebuggerUrl);
    await tab.send('Runtime.enable');
    const persisted = await tab.evaluate(`document.cookie.includes('pl_iso=perfil-a') && localStorage.getItem('pl_iso') === 'perfil-a'`);
    assert.equal(persisted, true, 'El perfil A debe conservar sus datos entre sesiones');
  } finally {
    await stopBrowser(app.child, shell);
    if (tab) tab.close();
    if (shell) shell.close();
  }
}

async function runLicenseGate({ tempRoot, port }) {
  const profileDir = path.join(tempRoot, 'profiles', 'perfil-bloqueado');
  const dataDir = path.join(tempRoot, 'data-bloqueado');
  const app = await launchBrowser({
    debugPort: port,
    profileId: 'perfil-bloqueado',
    profileName: 'Perfil bloqueado',
    profileDir,
    dataDir,
    requireLicense: true,
  });
  let blocked = null;
  try {
    const page = await waitForPage(port, (item) => item.url.includes('browser-blocked.html'), 'la pantalla de licencia', 30000);
    blocked = await connectCdp(page.webSocketDebuggerUrl);
    await blocked.send('Runtime.enable');
    let text = '';
    const deadline = Date.now() + 15000;
    while (Date.now() < deadline) {
      text = await blocked.evaluate('document.body ? document.body.innerText : ""');
      if (/Activa PerfilLab para usar este navegador/i.test(text)) break;
      await delay(150);
    }
    assert.match(text, /Activa PerfilLab para usar este navegador/i);
    const pages = await (await fetch(`http://127.0.0.1:${port}/json/list`)).json();
    assert.equal(pages.some((item) => item.type === 'page' && item.url.includes('renderer/browser.html')), false);
  } finally {
    await stopBrowser(app.child, blocked);
    if (blocked) blocked.close();
  }
}

async function main() {
  fs.mkdirSync(buildDir, { recursive: true });
  const tempRoot = fs.mkdtempSync(path.join(os.tmpdir(), 'perfillab-browser-ui-'));
  const { server, base } = await startTestServer();
  const port = await freePort();
  try {
    const profile = await runProfileChecks({ base, tempRoot, port, startUrl: `${base}/page-a` });
    await runIsolationCheck({ base, tempRoot, port: await freePort() });
    await runPersistenceCheck({ base, tempRoot, port: await freePort() });
    await runLicenseGate({ tempRoot, port: await freePort() });
    console.log('ok  PerfilLab Browser abre con su propio cromo y datos aislados');
    console.log('ok  Navegación, atrás/adelante, búsqueda, zoom y descarga verificados');
    console.log('ok  Pestaña emergente, página de error y pantalla completa verificadas');
    console.log('ok  Cada perfil conserva sus datos y no hereda cookies de otro perfil');
    console.log('ok  Sin licencia, el navegador muestra la pantalla de bloqueo');
    console.log(`Capturas: ${path.join(buildDir, 'browser-shell-a.png')}, ${path.join(buildDir, 'browser-page-a.png')}`);
    console.log(`Datos del perfil: ${profile.browserData}`);
  } finally {
    server.closeAllConnections();
    await new Promise((resolve) => server.close(resolve));
    try {
      fs.rmSync(tempRoot, { recursive: true, force: true });
    } catch {
      // Windows puede retener archivos de Chromium unos instantes.
    }
  }
}

main().catch((error) => {
  console.error(error.stack || error.message);
  process.exit(1);
});
