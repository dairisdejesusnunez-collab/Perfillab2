'use strict';

const assert = require('node:assert/strict');
const crypto = require('node:crypto');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');

const {
  canonicalPayloadV1,
  canonicalPayloadV2,
  canonicalRevocationList,
  keyIdFor,
  normalizeLicenseKey,
} = require('../shared/license-format');

const keys = crypto.generateKeyPairSync('ed25519');
const publicKey = keys.publicKey.export({ format: 'der', type: 'spki' }).toString('base64');
process.env.PERFILLAB_DEV = '1';
process.env.PERFILLAB_LICENSE_PUBLIC_KEY = publicKey;

const { LicenseService, machineInfo, normalizeMachineCode, normalizeServerUrl } = require('../electron/license');

const results = [];
const tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), 'perfillab-license-test-'));

function pass(name) {
  results.push(name);
  console.log(`  ok  ${name}`);
}

function expectThrow(fn, pattern, label, code) {
  let thrown = null;
  try {
    fn();
  } catch (error) {
    thrown = error;
  }
  assert(thrown, `${label}: se esperaba un error`);
  if (pattern) assert.match(String(thrown.message), pattern);
  if (code) assert.equal(thrown.code, code);
  pass(label);
  return thrown;
}

function futureIso(ms = 30 * 24 * 60 * 60 * 1000) {
  return new Date(Date.now() + ms).toISOString();
}

function sign(payload, version = 2) {
  const canonical = version === 1 ? canonicalPayloadV1(payload) : canonicalPayloadV2(payload);
  return crypto.sign(null, Buffer.from(canonical, 'utf8'), keys.privateKey).toString('base64');
}

function v2License(overrides = {}) {
  const machine = machineInfo();
  const payload = {
    keyId: keyIdFor(publicKey),
    licenseId: 'PL-0001',
    licenseKey: '47P0-9Z8K-793A-2VK9',
    seat: 1,
    machineCode: machine.code,
    customer: 'Equipo de prueba',
    product: 'perfillab',
    plan: 'annual',
    transactionId: 'TEST-0001',
    issuedAt: new Date().toISOString(),
    startsAt: new Date(Date.now() - 1000).toISOString(),
    expiresAt: futureIso(30 * 24 * 60 * 60 * 1000),
    ...overrides,
  };
  return { format: 'perfillab-license', version: 2, payload, signature: sign(payload, 2) };
}

function v1License(overrides = {}) {
  const machine = machineInfo();
  const payload = {
    licenseId: 'PL-LEGACY',
    licenseKey: '47P0-9Z8K-793A-2VK9',
    seat: 2,
    machineCode: machine.code,
    customer: 'Licencia heredada',
    issuedAt: new Date().toISOString(),
    expiresAt: futureIso(10 * 24 * 60 * 60 * 1000),
    ...overrides,
  };
  return { format: 'perfillab-license', version: 1, payload, signature: sign(payload, 1) };
}

function serviceFor(name, enforced = true) {
  return new LicenseService({
    filePath: path.join(tmpDir, name, 'license.json'),
    enforced,
  });
}

function testMachineAndNormalization() {
  const machine = machineInfo();
  assert.ok(machine.code, machine.error || 'sin código de equipo');
  assert.match(machine.code, /^[0-9A-HJKMNP-TV-Z]{4}(-[0-9A-HJKMNP-TV-Z]{4}){3}$/);
  pass('El código de equipo tiene el formato esperado');

  assert.equal(normalizeMachineCode(machine.code), machine.code);
  assert.equal(normalizeMachineCode(machine.code.replace(/-/g, '').toLowerCase()), machine.code);
  assert.equal(normalizeMachineCode('corto'), '');
  pass('Normalización de códigos de equipo');

  assert.equal(normalizeLicenseKey('47p0-9z8k-793a-2vk9'), '47P0-9Z8K-793A-2VK9');
  assert.equal(normalizeLicenseKey('47P0-9Z8K-793A'), '');
  pass('Normalización de claves de licencia');

  assert.equal(normalizeServerUrl('https://licencias.example.com'), 'https://licencias.example.com');
  assert.equal(normalizeServerUrl('http://127.0.0.1:45900'), 'http://127.0.0.1:45900');
  assert.equal(normalizeServerUrl('http://localhost:45900'), 'http://localhost:45900');
  assert.throws(() => normalizeServerUrl('http://licencias.example.com'), /HTTPS/);
  assert.throws(() => normalizeServerUrl('http://192.168.1.10:45900'), /HTTPS/);
  pass('El endpoint remoto exige HTTPS y HTTP queda solo en local');
}

function testServiceStates() {
  const empty = serviceFor('empty');
  const status = empty.publicStatus();
  assert.equal(status.required, true);
  assert.equal(status.licensed, false);
  assert.equal(status.active, false);
  pass('Sin licencia: requerida e inactiva');

  const dev = serviceFor('dev', false);
  assert.equal(dev.publicStatus().active, true);
  assert.equal(dev.publicStatus().licensed, false);
  pass('Modo desarrollo sin licencia sigue activo');

  const active = serviceFor('active');
  const activated = active.activateFile(v2License());
  assert.equal(activated.licensed, true);
  assert.equal(activated.active, true);
  assert.equal(activated.status, 'active');
  assert.equal(activated.licenseId, 'PL-0001');
  assert.equal(activated.customer, 'Equipo de prueba');
  assert.equal(activated.seat, 1);
  assert.equal(activated.plan, 'annual');
  assert.ok(fs.existsSync(path.join(tmpDir, 'active', 'license.json')));
  const saved = fs.readFileSync(path.join(tmpDir, 'active', 'license.json'), 'utf8');
  assert.ok(!/privateKey|private_key|seed/i.test(saved));
  pass('Licencia v2 vigente: activa, firmada y persistida');
}

function testRejections() {
  const service = serviceFor('rejections');
  const other = serviceFor('other-machine');

  expectThrow(() => other.activateFile(v2License({ machineCode: 'AAAA-BBBB-CCCC-DDDD' })), /otro equipo/i, 'Licencia de otro equipo rechazada', 'license_other_machine');

  const tampered = v2License();
  tampered.payload.customer = 'Cliente alterado';
  expectThrow(() => service.activateFile(tampered), /firma/i, 'Firma manipulada rechazada', 'invalid_license');

  const wrongKeyId = v2License();
  wrongKeyId.payload.keyId = '0000000000000000';
  wrongKeyId.signature = sign(wrongKeyId.payload, 2);
  expectThrow(() => service.activateFile(wrongKeyId), /otra clave|clave de firma/i, 'Licencia firmada con otra clave rechazada', 'invalid_license');

  expectThrow(() => service.activateFile(v2License({ seat: 50001 })), /asiento/i, 'Asiento fuera del límite rechazado', 'invalid_license');
  expectThrow(
    () => service.activateFile(v2License({
      startsAt: new Date(Date.now() - 120_000).toISOString(),
      expiresAt: new Date(Date.now() - 60_000).toISOString(),
    })),
    /caducado/i,
    'Licencia ya caducada rechazada',
    'license_expired',
  );
  expectThrow(() => service.activateFile(v2License({ startsAt: futureIso(3_600_000) })), /comenzado/i, 'Licencia futura rechazada', 'license_not_started');
  expectThrow(() => service.activateFile('{no es json'), /JSON/i, 'Texto de licencia inválido rechazado', 'invalid_license');
}

function testExpiry() {
  const service = serviceFor('expiry');
  service.activateFile(v2License({ expiresAt: futureIso(150) }));
  assert.equal(service.publicStatus().status, 'active');
  return new Promise((resolve) => {
    setTimeout(() => {
      const status = service.publicStatus();
      assert.equal(status.status, 'expired');
      assert.equal(status.active, false);
      assert.match(String(status.error), /caducado/i);
      pass('La licencia caducada se desactiva al evaluarla');
      resolve();
    }, 260);
  });
}

function testV1Compatibility() {
  const service = serviceFor('v1');
  const status = service.activateFile(v1License());
  assert.equal(status.active, true);
  assert.equal(status.licenseId, 'PL-LEGACY');
  pass('Compatibilidad con licencias v1 firmadas');
}

function testRevocations() {
  const service = serviceFor('revocations');
  service.activateFile(v2License({ licenseId: 'PL-REVOKED' }));
  assert.equal(service.publicStatus().status, 'active');

  const keyId = keyIdFor(publicKey);
  const list = {
    format: 'perfillab-revocation-list',
    version: 1,
    keyId,
    issuedAt: new Date().toISOString(),
    revoked: [{ licenseId: 'PL-REVOKED', revokedAt: new Date().toISOString(), reason: 'Prueba de revocación' }],
    signature: '',
  };
  list.signature = crypto.sign(null, Buffer.from(canonicalRevocationList(list), 'utf8'), keys.privateKey).toString('base64');
  fs.writeFileSync(path.join(tmpDir, 'revocations', 'license-revocations.json'), JSON.stringify({
    version: 1,
    fetchedAt: new Date().toISOString(),
    etag: '"test"',
    list,
  }), 'utf8');

  const reloaded = serviceFor('revocations');
  const status = reloaded.publicStatus();
  assert.equal(status.status, 'revoked');
  assert.equal(status.active, false);
  assert.match(String(status.error), /revocada/i);
  assert.equal(status.revokedCount, 1);
  pass('Lista de revocación firmada desactiva la licencia');
}

function testCorruptCache() {
  const dir = path.join(tmpDir, 'corrupt');
  fs.mkdirSync(dir, { recursive: true });
  fs.writeFileSync(path.join(dir, 'license.json'), '{"format":"perfillab-license","version":2}', 'utf8');
  const service = serviceFor('corrupt');
  assert.equal(service.publicStatus().status, 'invalid');
  assert.ok(service.publicStatus().error);
  pass('Archivo de licencia corrupto rechazado al cargar');
}

async function main() {
  console.log('Pruebas del sistema de licencias de PerfilLab\n');
  try {
    testMachineAndNormalization();
    testServiceStates();
    testRejections();
    await testExpiry();
    testV1Compatibility();
    testRevocations();
    testCorruptCache();
    console.log(`\n${results.length} pruebas de licencias superadas.`);
  } finally {
    fs.rmSync(tmpDir, { recursive: true, force: true });
  }
}

main().catch((error) => {
  console.error(error.stack || error.message);
  process.exit(1);
});
