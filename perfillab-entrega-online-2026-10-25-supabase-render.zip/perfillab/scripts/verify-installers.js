'use strict';

const crypto = require('node:crypto');
const fs = require('node:fs');
const net = require('node:net');
const os = require('node:os');
const path = require('node:path');
const { execFileSync, spawn } = require('node:child_process');
const pkg = require('../package.json');
const adminPkg = require('../license-admin/package.json');
const { assertInstalledApp } = require('./pack-audit');

const root = path.join(__dirname, '..');
const buildDir = path.join(root, 'build');
const distDir = process.env.PERFILLAB_DIST_DIR
  ? path.resolve(process.env.PERFILLAB_DIST_DIR)
  : path.join(root, 'dist');
const artifactsDir = path.join(buildDir, 'installer-check');
const checkRoot = path.join(os.tmpdir(), `perfillab-installer-check-${process.pid}-${Date.now()}`);
const logsDir = path.join(checkRoot, 'logs');
const clientInstaller = path.join(distDir, `PerfilLab-Setup-${pkg.version}.exe`);
const adminInstaller = path.join(distDir, `PerfilLab-Licencias-Setup-${adminPkg.version}.exe`);

function fail(message) {
  throw new Error(message);
}

function check(condition, message) {
  if (!condition) fail(message);
}

function delay(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function sha256(file) {
  return crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex');
}

function run(command, args, options = {}) {
  execFileSync(command, args, { stdio: 'inherit', windowsHide: true, timeout: 300000, ...options });
}

function walk(root, base = root, result = []) {
  if (!fs.existsSync(root)) return result;
  for (const entry of fs.readdirSync(root, { withFileTypes: true })) {
    const full = path.join(root, entry.name);
    if (entry.isDirectory()) walk(full, base, result);
    else if (entry.isFile()) result.push(path.relative(base, full).replace(/\\/g, '/'));
  }
  return result;
}

function verifyManifest() {
  const manifestPath = path.join(distDir, 'installers.json');
  if (!fs.existsSync(manifestPath)) {
    console.warn('Aviso: no existe dist/installers.json; se verifican los tamaños y hashes calculados ahora.');
    return;
  }
  const manifest = JSON.parse(fs.readFileSync(manifestPath, 'utf8'));
  for (const [kind, expected] of Object.entries(manifest.installers || {})) {
    const file = path.join(distDir, expected.file);
    check(fs.existsSync(file), `El manifiesto menciona un instalador ausente: ${expected.file}`);
    const size = fs.statSync(file).size;
    const hash = sha256(file);
    check(size === expected.size, `Tamaño distinto al manifiesto para ${kind}.`);
    check(hash === expected.sha256, `SHA-256 distinto al manifiesto para ${kind}.`);
  }
}

function install(installer, label, appDir, logFile, expectedExe) {
  check(fs.existsSync(installer), `Falta el instalador ${label}: ${installer}`);
  check(!fs.existsSync(appDir), `La carpeta de prueba ya existe: ${appDir}`);
  check(!fs.existsSync(path.join(appDir, expectedExe)), `La aplicación ${label} ya está instalada en la carpeta de prueba.`);
  console.log(`Instalando ${label} en ${path.relative(root, appDir)}…`);
  run(installer, [
    '/VERYSILENT',
    '/SUPPRESSMSGBOXES',
    '/NORESTART',
    '/NOCANCEL',
    `/LOG=${logFile}`,
    `/DIR=${appDir}`,
  ]);
  check(fs.existsSync(path.join(appDir, expectedExe)), `La instalación de ${label} no creó ${expectedExe}.`);
  check(fs.existsSync(path.join(appDir, 'unins000.exe')), `La instalación de ${label} no creó el desinstalador.`);
}

function launch(exe, extraEnv) {
  const env = { ...process.env, ...extraEnv };
  delete env.ELECTRON_RUN_AS_NODE;
  for (const key of Object.keys(env)) {
    if (env[key] === undefined) delete env[key];
  }
  const child = spawn(exe, [], { stdio: ['ignore', 'pipe', 'pipe'], windowsHide: false, env });
  let stderr = '';
  let stdout = '';
  child.stderr.on('data', (chunk) => { stderr += chunk.toString(); });
  child.stdout.on('data', (chunk) => { stdout += chunk.toString(); });
  return {
    child,
    stderr: () => stderr,
    output: () => `${stderr}\n${stdout}`.trim().slice(-1200),
  };
}

function stopApp(pid) {
  try {
    execFileSync('taskkill', ['/PID', String(pid), '/T', '/F'], {
      stdio: 'ignore',
      windowsHide: true,
      timeout: 20000,
    });
  } catch {
    // El proceso ya terminó.
  }
}

function windowTitle(pid) {
  try {
    return execFileSync('powershell.exe', [
      '-NoProfile',
      '-NonInteractive',
      '-Command',
      `(Get-Process -Id ${pid} -ErrorAction SilentlyContinue).MainWindowTitle`,
    ], { encoding: 'utf8', windowsHide: true, timeout: 10000 }).trim();
  } catch {
    return '';
  }
}

async function verifyClientLaunch(exePath, appDir) {
  const dataDir = path.join(checkRoot, 'client-data');
  fs.rmSync(dataDir, { recursive: true, force: true });
  const app = launch(exePath, {
    PERFILLAB_DATA_DIR: dataDir,
    PERFILLAB_REQUIRE_LICENSE: '1',
    PERFILLAB_LICENSE_SERVER: undefined,
    PERFILLAB_DEBUG_PORT: undefined,
  });
  try {
    const deadline = Date.now() + 25000;
    let title = '';
    while (Date.now() < deadline) {
      if (app.child.exitCode !== null) break;
      title = windowTitle(app.child.pid);
      if (/PerfilLab/i.test(title)) break;
      await delay(500);
    }
    check(app.child.exitCode === null, `El cliente instalado terminó al arrancar. ${app.output()}`);
    check(/PerfilLab/i.test(title), `No se abrió la ventana del cliente instalado (título: ${title || 'vacío'}).`);
    check(fs.existsSync(dataDir), 'El cliente instalado no creó su carpeta de datos temporal.');
    console.log(`Cliente instalado abierto: "${title}"`);
    return { title, dataDir };
  } finally {
    stopApp(app.child.pid);
    await delay(1500);
  }
}

function freePort() {
  return new Promise((resolve, reject) => {
    const server = net.createServer();
    server.once('error', reject);
    server.listen(0, '127.0.0.1', () => {
      const { port } = server.address();
      server.close(() => resolve(port));
    });
  });
}

async function waitForAdminPage(port, timeoutMs = 25000) {
  const deadline = Date.now() + timeoutMs;
  let lastError = null;
  while (Date.now() < deadline) {
    try {
      const response = await fetch(`http://127.0.0.1:${port}/json/list`, { signal: AbortSignal.timeout(1500) });
      if (response.ok) {
        const pages = await response.json();
        const page = pages.find((item) => item.type === 'page' && item.url.includes('renderer/index.html'))
          || pages.find((item) => item.type === 'page');
        if (page) return page;
      }
    } catch (error) {
      lastError = error;
    }
    await delay(300);
  }
  throw new Error(`La consola instalada no abrió su página CDP: ${lastError ? lastError.message : 'sin página'}`);
}

function connectCdp(wsUrl) {
  return new Promise((resolve, reject) => {
    const ws = new WebSocket(wsUrl);
    const pending = new Map();
    let seq = 0;
    const timer = setTimeout(() => {
      try { ws.close(); } catch { /* cerrada */ }
      reject(new Error('Tiempo de espera agotado al conectar con CDP.'));
    }, 15000);

    function send(method, params = {}) {
      const id = ++seq;
      return new Promise((resolveCall, rejectCall) => {
        pending.set(id, { resolve: resolveCall, reject: rejectCall });
        ws.send(JSON.stringify({ id, method, params }));
      });
    }

    ws.addEventListener('open', () => {
      clearTimeout(timer);
      resolve({
        send,
        close() {
          try { ws.close(); } catch { /* cerrada */ }
        },
      });
    });
    ws.addEventListener('error', () => {
      clearTimeout(timer);
      reject(new Error('No se pudo abrir la conexión CDP.'));
    });
    ws.addEventListener('close', () => {
      for (const entry of pending.values()) entry.reject(new Error('CDP se cerró.'));
      pending.clear();
    });
    ws.addEventListener('message', (event) => {
      let message;
      try {
        message = JSON.parse(String(event.data));
      } catch {
        return;
      }
      if (!message.id || !pending.has(message.id)) return;
      const entry = pending.get(message.id);
      pending.delete(message.id);
      if (message.error) entry.reject(new Error(message.error.message || 'Error CDP.'));
      else entry.resolve(message.result);
    });
  });
}

async function evaluate(client, expression) {
  const result = await client.send('Runtime.evaluate', {
    expression,
    returnByValue: true,
    awaitPromise: true,
  });
  if (result.exceptionDetails) {
    throw new Error(result.exceptionDetails.text || 'Error al evaluar la consola instalada.');
  }
  return result.result ? result.result.value : undefined;
}

async function verifyAdminLaunch(exePath) {
  const dataDir = path.join(checkRoot, 'admin-data');
  fs.rmSync(dataDir, { recursive: true, force: true });
  const port = await freePort();
  const env = {
    PERFILLAB_ADMIN_DATA_DIR: dataDir,
    PERFILLAB_DEBUG_PORT: String(port),
    PERFILLAB_LICENSE_SERVER: undefined,
  };
  const app = launch(exePath, env);
  let client = null;
  try {
    const page = await waitForAdminPage(port);
    client = await connectCdp(page.webSocketDebuggerUrl);
    await client.send('Runtime.enable');
    const deadline = Date.now() + 15000;
    let view = null;
    while (Date.now() < deadline) {
      view = await evaluate(client, `(() => ({
        title: document.title,
        heading: (document.querySelector('#login-screen h1') || {}).innerText || '',
        hasLogin: Boolean(document.querySelector('#login-form')),
        server: (document.querySelector('#login-server') || {}).value || '',
        placeholder: (document.querySelector('#login-server') || {}).placeholder || ''
      }))()`);
      if (view && view.hasLogin && view.title) break;
      await delay(300);
    }
    check(view && view.hasLogin, 'La consola instalada no mostró el formulario de acceso.');
    check(view.title === 'PerfilLab Licencias', `Título inesperado en la consola: ${view.title}`);
    check(/Acceso administrativo/i.test(view.heading), `Cabecera inesperada en la consola: ${view.heading}`);
    check(/127\.0\.0\.1:45900/.test(`${view.server} ${view.placeholder}`), `La consola no apunta al puerto local 45900: ${view.server} ${view.placeholder}`);
    const shot = await client.send('Page.captureScreenshot', { format: 'png' });
    const screenshot = path.join(checkRoot, 'admin-installed.png');
    fs.writeFileSync(screenshot, Buffer.from(shot.data, 'base64'));
    console.log(`Consola instalada abierta con el servidor predeterminado: ${view.server || view.placeholder}`);
    return { dataDir, screenshot, view };
  } finally {
    if (client) client.close();
    stopApp(app.child.pid);
    await delay(1500);
  }
}

async function uninstall(appDir, label, logFile) {
  const uninstaller = path.join(appDir, 'unins000.exe');
  check(fs.existsSync(uninstaller), `No existe el desinstalador de ${label}.`);
  console.log(`Desinstalando ${label}…`);
  run(uninstaller, [
    '/VERYSILENT',
    '/SUPPRESSMSGBOXES',
    '/NORESTART',
    `/LOG=${logFile}`,
  ], { timeout: 120000 });
  const deadline = Date.now() + 30000;
  while (Date.now() < deadline && fs.existsSync(appDir)) {
    const remaining = walk(appDir);
    if (remaining.length === 0) break;
    await delay(500);
  }
  const remaining = walk(appDir);
  check(remaining.length === 0, `Quedaron archivos tras desinstalar ${label}: ${remaining.slice(0, 8).join(', ')}`);
  fs.rmSync(appDir, { recursive: true, force: true });
}

function copyArtifacts() {
  if (!fs.existsSync(checkRoot)) return null;
  fs.mkdirSync(artifactsDir, { recursive: true });
  const targetLogs = path.join(artifactsDir, 'logs');
  fs.mkdirSync(targetLogs, { recursive: true });
  if (fs.existsSync(logsDir)) {
    for (const name of fs.readdirSync(logsDir)) {
      const source = path.join(logsDir, name);
      if (!fs.statSync(source).isFile()) continue;
      fs.copyFileSync(source, path.join(targetLogs, name));
    }
  }
  const sourceShot = path.join(checkRoot, 'admin-installed.png');
  const targetShot = path.join(artifactsDir, 'admin-installed.png');
  if (fs.existsSync(sourceShot)) fs.copyFileSync(sourceShot, targetShot);
  return { logs: targetLogs, screenshot: targetShot };
}

async function main() {
  if (process.platform !== 'win32') fail('La verificación de instaladores solo se ejecuta en Windows.');
  check(fs.existsSync(clientInstaller), `Falta ${path.relative(root, clientInstaller)}. Ejecuta npm run installers.`);
  check(fs.existsSync(adminInstaller), `Falta ${path.relative(root, adminInstaller)}. Ejecuta npm run installers.`);
  verifyManifest();

  fs.mkdirSync(logsDir, { recursive: true });

  const clientApp = path.join(checkRoot, 'Cliente PerfilLab');
  const adminApp = path.join(checkRoot, 'Consola PerfilLab');
  const clientExe = path.join(clientApp, 'PerfilLab.exe');
  const adminExe = path.join(adminApp, 'PerfilLab Licencias.exe');

  install(clientInstaller, 'el cliente PerfilLab', clientApp, path.join(logsDir, 'client-install.log'), 'PerfilLab.exe');
  assertInstalledApp(clientApp, 'client');
  check(!fs.existsSync(path.join(clientApp, 'PerfilLab Licencias.exe')), 'El instalador del cliente incluyó la consola administrativa.');
  console.log(`Contenido del cliente verificado: ${walk(clientApp).length} archivos, sin servidor, bóveda ni secretos.`);
  await verifyClientLaunch(clientExe, clientApp);

  install(adminInstaller, 'la consola PerfilLab Licencias', adminApp, path.join(logsDir, 'admin-install.log'), 'PerfilLab Licencias.exe');
  assertInstalledApp(adminApp, 'admin');
  check(!fs.existsSync(path.join(adminApp, 'PerfilLab.exe')), 'El instalador de la consola incluyó el cliente PerfilLab.');
  console.log(`Contenido de la consola verificado: ${walk(adminApp).length} archivos, sin servidor, bóveda ni secretos.`);
  await verifyAdminLaunch(adminExe);

  await uninstall(clientApp, 'el cliente PerfilLab', path.join(logsDir, 'client-uninstall.log'));
  await uninstall(adminApp, 'la consola PerfilLab Licencias', path.join(logsDir, 'admin-uninstall.log'));

  for (const dir of ['client-data', 'admin-data']) {
    fs.rmSync(path.join(checkRoot, dir), { recursive: true, force: true });
  }

  const artifacts = copyArtifacts();
  try {
    fs.rmSync(checkRoot, { recursive: true, force: true });
  } catch (error) {
    console.warn(`Aviso: no se pudo limpiar el directorio temporal ${checkRoot}: ${error.message}`);
  }

  console.log('\nVerificación completada:');
  console.log('- Los dos instaladores se instalaron y desinstalaron en silencio.');
  console.log('- El cliente y la consola arrancaron y mostraron su interfaz.');
  console.log('- El contenido instalado no incluye servidor, .env, bóveda, keystore, pruebas ni secretos.');
  console.log(`- Registros: ${path.relative(root, artifacts.logs)}`);
  console.log(`- Captura de la consola: ${path.relative(root, artifacts.screenshot)}`);
}

main().catch((error) => {
  try {
    const artifacts = copyArtifacts();
    if (artifacts) console.error(`Registros conservados en: ${path.relative(root, artifacts.logs)}`);
  } catch {
    // Los artefactos son auxiliares; el error original es el relevante.
  }
  console.error(`\n${error && error.message ? error.message : error}\n`);
  if (fs.existsSync(checkRoot)) console.error(`Directorio temporal: ${checkRoot}`);
  process.exit(1);
});
