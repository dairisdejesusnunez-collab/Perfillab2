#!/usr/bin/env node
'use strict';

const crypto = require('node:crypto');
const fs = require('node:fs');
const path = require('node:path');
const { execFileSync } = require('node:child_process');

const pkg = require('../package.json');

const root = path.join(__dirname, '..');
const sourceDir = process.env.PERFILLAB_PACK_DIR
  ? path.resolve(process.env.PERFILLAB_PACK_DIR)
  : path.join(root, 'build', `${pkg.productName}-win32-x64`);
const distDir = process.env.PERFILLAB_DIST_DIR
  ? path.resolve(process.env.PERFILLAB_DIST_DIR)
  : path.join(root, 'dist');
const fileName = `${pkg.productName}-${pkg.version}-win64.zip`;
const target = path.join(distDir, fileName);

if (!fs.existsSync(sourceDir)) {
  console.error(`No existe ${path.relative(root, sourceDir)}. Ejecuta primero: npm run pack`);
  process.exit(1);
}

fs.mkdirSync(distDir, { recursive: true });
if (fs.existsSync(target)) fs.rmSync(target);

if (process.platform === 'win32') {
  const tar = path.join(process.env.SystemRoot || 'C:\\Windows', 'System32', 'tar.exe');
  execFileSync(tar, ['-a', '-c', '-f', target, '-C', path.dirname(sourceDir), path.basename(sourceDir)], {
    stdio: 'inherit',
    windowsHide: true,
  });
} else {
  execFileSync('zip', ['-q', '-r', target, path.basename(sourceDir)], {
    cwd: path.dirname(sourceDir),
    stdio: 'inherit',
  });
}

const sha256 = crypto.createHash('sha256').update(fs.readFileSync(target)).digest('hex');
const size = fs.statSync(target).size;

console.log('');
console.log(`Artefacto: ${path.relative(root, target)}`);
console.log(`Tamaño: ${size} bytes`);
console.log(`SHA-256: ${sha256}`);
console.log('');
console.log('Configura el servidor de licencias con estos valores:');
console.log(`PERFILLAB_INSTALLER_FILENAME=${fileName}`);
console.log(`PERFILLAB_INSTALLER_VERSION=${pkg.version}`);
console.log(`PERFILLAB_INSTALLER_SHA256=${sha256}`);
console.log(`PERFILLAB_INSTALLER_SIZE=${size}`);
console.log('');
console.log('Sube el ZIP a un almacenamiento HTTPS público y define PERFILLAB_INSTALLER_URL,');
console.log('o cópialo a un volumen persistente y define PERFILLAB_INSTALLER_PATH con su ruta.');
