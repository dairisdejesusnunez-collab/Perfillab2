'use strict';

const fs = require('node:fs');
const path = require('node:path');

const root = path.join(__dirname, '..');
const publicModule = path.join(root, 'electron', 'license-public.js');
const rawArg = process.argv.find((arg) => arg.startsWith('--server-url='));
const clear = process.argv.includes('--clear');

function fail(message) {
  console.error(message);
  console.error('Uso: npm run license:endpoint -- --server-url=https://licencias.tu-dominio.com');
  console.error('     npm run license:endpoint -- --clear');
  process.exit(1);
}

function isLoopbackHostname(hostname) {
  const raw = String(hostname || '').trim().toLowerCase()
    .replace(/^\[/, '')
    .replace(/\]$/, '')
    .replace(/\.$/, '');
  if (!raw) return false;
  if (raw === 'localhost' || raw === '::1') return true;
  const match = /^127\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/.exec(raw);
  return Boolean(match) && match.slice(1).every((part) => Number(part) <= 255);
}

if (!rawArg && !clear) fail('Indica --server-url=https://... o --clear.');
if (rawArg && clear) fail('Usa --server-url o --clear, no ambos.');

let serverUrl = '';
if (rawArg) {
  const value = rawArg.slice('--server-url='.length).trim();
  let parsed;
  try {
    parsed = new URL(value);
  } catch {
    fail('La dirección del servidor no es válida.');
  }
  if (parsed.protocol !== 'http:' && parsed.protocol !== 'https:') {
    fail('El servidor debe usar http:// o https://.');
  }
  if (parsed.protocol === 'http:' && !isLoopbackHostname(parsed.hostname)) {
    fail('Para un servidor remoto usa HTTPS. HTTP solo se permite en localhost o 127.0.0.1.');
  }
  if (parsed.username || parsed.password) fail('No incluyas credenciales en la dirección.');
  if (parsed.search || parsed.hash || (parsed.pathname !== '/' && parsed.pathname !== '')) {
    fail('La dirección debe ser la raíz del servidor, sin rutas ni parámetros.');
  }
  serverUrl = parsed.origin;
}

const current = require(publicModule);
if (!current || typeof current.publicKey !== 'string' || !current.publicKey) {
  fail('electron/license-public.js no contiene una clave pública válida.');
}

const moduleSource = `'use strict';

// Generada por scripts/provision-license.js. Cambiar esta clave invalida las licencias emitidas.
module.exports = {
  publicKey: ${JSON.stringify(current.publicKey)},
  keyId: ${JSON.stringify(current.keyId)},
  seatLimit: ${Number(current.seatLimit) || 50000},
  serverUrl: ${JSON.stringify(serverUrl)},
  generatedAt: ${JSON.stringify(current.generatedAt || new Date().toISOString())},
};
`;

const temp = `${publicModule}.tmp`;
fs.writeFileSync(temp, moduleSource, { encoding: 'utf8', mode: 0o600 });
fs.renameSync(temp, publicModule);

console.log(serverUrl
  ? `Endpoint de licencias configurado en ${path.relative(root, publicModule)}: ${serverUrl}`
  : 'Endpoint de licencias borrado; se usará el valor local o el que introduzca el cliente.');
console.log('La clave pública y los asientos no cambiaron.');
