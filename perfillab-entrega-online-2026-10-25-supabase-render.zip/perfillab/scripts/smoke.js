'use strict';

const assert = require('node:assert/strict');
const fs = require('node:fs');
const net = require('node:net');
const os = require('node:os');
const path = require('node:path');
const { app } = require('electron');

const dataDir = fs.mkdtempSync(path.join(os.tmpdir(), 'perfillab-smoke-'));
process.env.PERFILLAB_DATA_DIR = dataDir;

const { Store } = require('../electron/store');
const { ProfileLauncher } = require('../electron/launcher');
const { AppService } = require('../electron/app-service');
const { LocalApiServer } = require('../electron/api-server');

const results = [];

function pass(name) {
  results.push(name);
  console.log(`  ok  ${name}`);
}

function expectError(fn, label) {
  let thrown = null;
  try {
    fn();
  } catch (error) {
    thrown = error;
  }
  assert(thrown, `${label}: se esperaba un error`);
  pass(label);
  return thrown;
}

async function freePort() {
  return new Promise((resolve, reject) => {
    const server = net.createServer();
    server.once('error', reject);
    server.listen(0, '127.0.0.1', () => {
      const { port } = server.address();
      server.close(() => resolve(port));
    });
  });
}

async function request(base, pathname, { method = 'GET', token, body, origin } = {}) {
  const headers = {};
  if (token) headers.Authorization = `Bearer ${token}`;
  if (origin) headers.Origin = origin;
  if (body !== undefined) headers['Content-Type'] = 'application/json';
  const response = await fetch(`${base}${pathname}`, {
    method,
    headers,
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  const text = await response.text();
  let payload = null;
  try {
    payload = JSON.parse(text);
  } catch {
    payload = text;
  }
  return { status: response.status, payload };
}

async function main() {
  await app.whenReady();

  const store = new Store();
  store.load();
  const state = store.getState();
  assert.equal(state.workspaces.length, 1, 'debe existir el espacio General');
  assert.equal(state.workspaces[0].name, 'General');
  pass('store inicial y migración');

  const launcher = new ProfileLauncher(store);
  const service = new AppService({ store, launcher });
  service.setApiStatusProvider(() => ({ enabled: false, running: false, port: null, error: null }));

  const token = service.getApiToken();
  assert.equal(typeof token, 'string');
  assert(token.length >= 32, 'el token de la API debe tener longitud suficiente');
  pass('token de API generado');

  const workspace = service.createWorkspace({ name: 'QA Smoke', color: '#22c55e' });
  assert.equal(workspace.name, 'QA Smoke');
  expectError(() => service.createWorkspace({ name: 'qa smoke' }), 'espacio duplicado rechazado');

  const proxy = service.createProxy({
    name: 'Proxy smoke',
    protocol: 'http',
    host: '127.0.0.1',
    port: 9,
    username: 'user',
    password: 'secreto',
    notes: 'temporal',
  });
  const rawProxy = service.state.proxies.find((item) => item.id === proxy.id);
  const publicProxy = service.publicProxy(rawProxy);
  assert.equal(publicProxy.hasPassword, true);
  assert.equal(publicProxy.passwordEnc, undefined);
  assert.equal(publicProxy.password, undefined);
  pass('proxy con credenciales sin filtrar secretos');

  const browsers = service.getPublicState().browsers;
  if (!browsers.length) {
    console.log('  --  el navegador integrado no está disponible; se omiten las pruebas de perfiles');
    await service.deleteProxy(proxy.id);
    await service.deleteWorkspace(workspace.id);
    await finish();
    return;
  }
  const browserId = browsers[0].id;

  const profile = service.createProfile({
    name: 'Perfil smoke',
    workspaceId: workspace.id,
    browserId,
    proxyId: proxy.id,
    startUrls: ['example.com', 'https://example.org'],
    tags: ['qa', ' smoke ', 'qa'],
    notes: 'prueba',
    color: '#5b6cff',
  });
  assert.equal(profile.name, 'Perfil smoke');
  assert.equal(profile.startUrls.length, 2);
  assert.equal(profile.startUrls[0], 'https://example.com/');
  assert.deepEqual(profile.tags, ['qa', 'smoke']);
  pass('crear perfil y normalizar URLs/etiquetas');

  const copy = service.duplicateProfile(profile.id);
  assert.notEqual(copy.id, profile.id);
  assert.equal(copy.name, 'Copia de Perfil smoke');
  pass('duplicar perfil');

  const updated = service.updateProfile(profile.id, { name: 'Perfil smoke editado' });
  assert.equal(updated.name, 'Perfil smoke editado');
  expectError(() => service.createProfile({ browserId }), 'perfil sin nombre rechazado');
  pass('actualizar perfil');

  const exported = service.buildExport();
  assert.equal(exported.format, 'perfillab-export');
  assert.equal(exported.version, 1);
  assert.equal(exported.profiles.length, 2);
  assert.equal(exported.proxies.length, 1);
  assert.equal(exported.proxies[0].password, undefined);
  assert.equal(exported.proxies[0].passwordEnc, undefined);
  assert.equal(exported.proxies[0].requiresPassword, true);
  assert.equal(exported.profiles[0].workspace, 'QA Smoke');
  pass('exportar sin contraseñas');

  const before = service.state.profiles.length;
  const imported = service.importData(exported);
  assert.equal(imported.profiles, 2);
  assert.equal(imported.workspaces, 0);
  assert.equal(imported.proxies, 0);
  assert.equal(service.state.profiles.length, before + 2);
  assert(service.state.profiles.slice(-2).every((item) => !item.proxyId || service.state.proxies.some((p) => p.id === item.proxyId)));
  pass('importar exportación');

  expectError(() => service.importData({ format: 'otro', version: 1, profiles: [] }), 'formato de importación inválido');
  expectError(() => service.updateProfile(profile.id, { startUrls: ['ftp://example.com'] }), 'URL no http rechazada');
  expectError(() => service.updateProxy(proxy.id, { port: 70000 }), 'puerto inválido rechazado');

  const csvText = '\uFEFFNombre,Espacio,Navegador,Proxy,URLs,Etiquetas,Notas,Color\r\nPerfil CSV,CSV Smoke,,Proxy smoke,https://example.net,uno;dos,nota,#123456\r\n';
  const csvResult = service.importCsv(csvText);
  assert.equal(csvResult.profiles, 1);
  assert.equal(csvResult.workspaces, 1);
  assert.equal(csvResult.errors.length, 0);
  const csvProfile = service.state.profiles.find((item) => item.name === 'Perfil CSV');
  assert(csvProfile);
  assert.equal(service.state.proxies.length, 1, 'el CSV no debe crear proxies');
  const csvExport = service.buildCsv([csvProfile.id]);
  assert(csvExport.startsWith('\uFEFFNombre,'));
  assert(csvExport.includes('Proxy smoke'));
  assert.equal(csvExport.includes('secreto'), false);
  assert.equal(csvExport.includes('passwordEnc'), false);
  pass('importar y exportar CSV sin credenciales');

  const generalWorkspace = service.state.workspaces.find((item) => item.name === 'General');
  const bulkMove = await service.batchProfiles({
    action: 'move',
    profileIds: [csvProfile.id, copy.id],
    workspaceId: generalWorkspace.id,
  });
  assert.equal(bulkMove.succeeded, 2);
  assert.equal(bulkMove.failed, 0);
  assert(service.state.profiles.filter((item) => item.id === csvProfile.id || item.id === copy.id)
    .every((item) => item.workspaceId === generalWorkspace.id));
  pass('mover perfiles en lote');

  const bulkProxy = await service.testProxies({ ids: [proxy.id] });
  assert.equal(bulkProxy.total, 1);
  assert.equal(bulkProxy.results[0].proxyId, proxy.id);
  assert.equal(bulkProxy.results[0].password, undefined);
  pass('probar proxies en lote sin exponer credenciales');

  const port = await freePort();
  const api = new LocalApiServer({ service });
  service.setApiStatusProvider(() => api.status());
  service.updateSettings({ api: { enabled: true, port } });
  await api.apply();
  assert.equal(api.status().running, true);
  const base = `http://127.0.0.1:${port}/v1`;
  pass('API local iniciada en 127.0.0.1');

  const health = await request(base, '/health', { token });
  assert.equal(health.status, 200);
  assert.equal(health.payload.ok, true);
  const healthWithoutToken = await request(base, '/health');
  assert.equal(healthWithoutToken.status, 401);
  const healthBadToken = await request(base, '/health', { token: 'incorrecto' });
  assert.equal(healthBadToken.status, 401);
  const healthOrigin = await request(base, '/health', { token, origin: 'https://ejemplo.test' });
  assert.equal(healthOrigin.status, 403);
  pass('API exige Bearer y rechaza Origin');

  const stateResponse = await request(base, '/state', { token });
  assert.equal(stateResponse.status, 200);
  assert.equal(stateResponse.payload.settings.api.token, undefined);
  assert.equal(stateResponse.payload.settings.api.tokenEnc, undefined);
  const proxiesResponse = await request(base, '/proxies', { token });
  assert.equal(proxiesResponse.payload.proxies[0].passwordEnc, undefined);
  assert.equal(proxiesResponse.payload.proxies[0].password, undefined);
  pass('API no expone token ni contraseñas');

  const viaApi = await request(base, '/profiles', {
    method: 'POST',
    token,
    body: { name: 'Perfil API', workspaceId: workspace.id, browserId, startUrls: ['https://example.com'] },
  });
  assert.equal(viaApi.status, 201, JSON.stringify(viaApi.payload));
  const list = await request(base, '/profiles', { token });
  assert(list.payload.profiles.some((item) => item.id === viaApi.payload.id));
  pass('API crea y lista perfiles');

  const apiBatch = await request(base, '/profiles/batch', {
    method: 'POST',
    token,
    body: { action: 'move', profileIds: [viaApi.payload.id, copy.id], workspaceId: generalWorkspace.id },
  });
  assert.equal(apiBatch.status, 200, JSON.stringify(apiBatch.payload));
  assert.equal(apiBatch.payload.succeeded, 1);
  assert.equal(apiBatch.payload.skipped, 1);
  assert.equal(apiBatch.payload.failed, 0);
  pass('API mueve perfiles en lote');

  const statusCreated = await request(base, '/statuses', {
    method: 'POST',
    token,
    body: { name: 'API revisión', color: '#f59e0b' },
  });
  assert.equal(statusCreated.status, 201, JSON.stringify(statusCreated.payload));
  const statusList = await request(base, '/statuses', { token });
  assert(statusList.payload.statuses.some((item) => item.id === statusCreated.payload.id));
  const statusBatch = await request(base, '/profiles/batch', {
    method: 'POST',
    token,
    body: { action: 'set-status', profileIds: [viaApi.payload.id], statusId: statusCreated.payload.id },
  });
  assert.equal(statusBatch.status, 200, JSON.stringify(statusBatch.payload));
  assert.equal(statusBatch.payload.succeeded, 1);
  assert.equal(statusBatch.payload.failed, 0);
  const statusProfile = await request(base, `/profiles/${viaApi.payload.id}`, { token });
  assert.equal(statusProfile.payload.profile.statusId, statusCreated.payload.id);
  const statusDeleted = await request(base, `/statuses/${statusCreated.payload.id}`, { method: 'DELETE', token });
  assert.equal(statusDeleted.status, 200, JSON.stringify(statusDeleted.payload));
  assert.equal(statusDeleted.payload.updatedProfiles, 1);
  pass('API administra estados y los asigna en lote');

  const originalTestProxy = service.testProxyConnection.bind(service);
  let apiProxyTest;
  try {
    service.testProxyConnection = async () => ({ ok: true, ip: '203.0.113.7', latencyMs: 4 });
    apiProxyTest = await request(base, '/proxies/test', {
      method: 'POST',
      token,
      body: { ids: [proxy.id] },
    });
  } finally {
    service.testProxyConnection = originalTestProxy;
  }
  assert.equal(apiProxyTest.status, 200, JSON.stringify(apiProxyTest.payload));
  assert.equal(apiProxyTest.payload.ok, 1);
  assert.equal(apiProxyTest.payload.results[0].proxyId, proxy.id);
  assert.equal(apiProxyTest.payload.results[0].ip, '203.0.113.7');
  pass('API prueba proxies en lote');

  const badBody = await fetch(`${base}/profiles`, {
    method: 'POST',
    headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'text/plain' },
    body: '{}',
  });
  assert.equal(badBody.status, 415);
  pass('API valida Content-Type');

  if (process.argv.includes('--browser')) {
    const started = await request(base, `/profiles/${viaApi.payload.id}/start`, {
      method: 'POST',
      token,
      body: {},
    });
    assert.equal(started.status, 200, JSON.stringify(started.payload));
    assert.equal(started.payload.proxyMode, 'none');
    await new Promise((resolve) => setTimeout(resolve, 1200));
    const running = await request(base, '/status', { token });
    assert(running.payload.running.some((item) => item.profileId === viaApi.payload.id));
    const stopped = await request(base, `/profiles/${viaApi.payload.id}/stop`, {
      method: 'POST',
      token,
      body: {},
    });
    assert.equal(stopped.status, 200);
    pass('API inicia y detiene el navegador');
  } else {
    console.log('  --  lanzamiento de navegador omitido (usa --browser para probarlo)');
  }

  await request(base, `/profiles/${viaApi.payload.id}`, { method: 'DELETE', token });
  const deleted = await request(base, `/profiles/${profile.id}`, { method: 'DELETE', token });
  assert.equal(deleted.status, 200);
  pass('API elimina perfiles');

  service.updateSettings({ api: { enabled: false } });
  await api.apply();
  assert.equal(api.status().running, false);
  pass('API se detiene al desactivarla');

  await finish();

  async function finish() {
    launcher.stopAllSync();
    await api.close().catch(() => {});
    fs.rmSync(dataDir, { recursive: true, force: true });
  }
}

main()
  .then(() => {
    console.log(`\n${results.length} comprobaciones correctas.`);
    app.exit(0);
  })
  .catch((error) => {
    console.error('\nFallo en la prueba:', error && error.stack ? error.stack : error);
    app.exit(1);
  });
