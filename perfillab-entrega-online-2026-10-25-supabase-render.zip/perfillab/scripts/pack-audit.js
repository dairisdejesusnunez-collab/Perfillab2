'use strict';

const fs = require('node:fs');
const path = require('node:path');
const asar = require('@electron/asar');

const FORBIDDEN_SEGMENTS = /(^|\/)(license-server|license-admin|seed|test|scripts|\.git)(\/|$)/i;
const FORBIDDEN_FILES = /(^|\/)(?:\.env[^/]*|vault[^/]*|keystore[^/]*|[^/]*password[^/]*|\.npmrc|\.netrc|\.pgpass|id_rsa|id_ed25519|[^/]*\.(?:pem|key|p12|pfx|jks|kdbx))$/i;
const SECRET_MARKERS = [
  'BEGIN PRIVATE KEY',
  'BEGIN RSA PRIVATE KEY',
  'BEGIN EC PRIVATE KEY',
  'BEGIN OPENSSH PRIVATE KEY',
  'PERFILLAB_KEYSTORE_',
  'PERFILLAB_VAULT_PASSWORD',
  'perfillab-admin-password',
  'license-server/',
];

const REQUIRED = {
  client: [
    'electron/main.js',
    'electron/preload.js',
    'electron/license.js',
    'electron/license-public.js',
    'electron/secrets.js',
    'electron/browser-mode.js',
    'electron/browser-preload.js',
    'renderer/index.html',
    'renderer/browser.html',
    'shared/license-format.js',
    'package.json',
  ],
  admin: [
    'electron/main.js',
    'electron/preload.js',
    'electron/server-client.js',
    'renderer/index.html',
    'renderer/app.js',
    'renderer/styles.css',
    'package.json',
  ],
};

function normalize(entry) {
  return String(entry || '').replace(/^[\\/]+/, '').replace(/\\/g, '/');
}

function walk(root, base = root, result = []) {
  for (const entry of fs.readdirSync(root, { withFileTypes: true })) {
    const full = path.join(root, entry.name);
    if (entry.isDirectory()) walk(full, base, result);
    else if (entry.isFile()) result.push(path.relative(base, full).replace(/\\/g, '/'));
  }
  return result;
}

function auditAsar(appDir, kind) {
  const asarPath = path.join(appDir, 'resources', 'app.asar');
  const problems = [];
  if (!fs.existsSync(asarPath)) {
    return { asarPath, files: [], problems: [`No existe ${asarPath}`] };
  }
  const files = asar.listPackage(asarPath)
    .map(normalize)
    .filter((entry) => entry && !entry.endsWith('/'));
  for (const file of files) {
    if (FORBIDDEN_SEGMENTS.test(file) || FORBIDDEN_FILES.test(file)) {
      problems.push(`Archivo prohibido en el paquete: ${file}`);
    }
  }
  for (const required of REQUIRED[kind] || []) {
    if (!files.includes(required)) problems.push(`Falta un archivo obligatorio: ${required}`);
  }
  if (kind === 'admin') {
    const allowedTop = new Set(['assets', 'electron', 'package.json', 'renderer']);
    for (const file of files) {
      const top = file.split('/')[0];
      if (!allowedTop.has(top)) problems.push(`Contenido ajeno en la consola: ${file}`);
    }
    const electronFiles = files
      .filter((file) => file.startsWith('electron/'))
      .map((file) => file.slice('electron/'.length))
      .sort();
    const expected = ['main.js', 'preload.js', 'server-client.js'];
    if (electronFiles.join(',') !== expected.join(',')) {
      problems.push(`Archivos de electron inesperados en la consola: ${electronFiles.join(', ')}`);
    }
  }
  if (kind === 'client') {
    for (const file of files) {
      if (file.startsWith('electron/server-client.js') || file.startsWith('renderer/admin')) {
        problems.push(`Código administrativo en el cliente: ${file}`);
      }
    }
  }
  const bytes = fs.readFileSync(asarPath);
  for (const marker of SECRET_MARKERS) {
    if (bytes.includes(Buffer.from(marker))) {
      problems.push(`Marcador sensible dentro de app.asar: ${marker}`);
    }
  }
  return { asarPath, files, problems };
}

function auditInstalled(appDir, kind) {
  const problems = [];
  const files = walk(appDir);
  for (const file of files) {
    if (FORBIDDEN_SEGMENTS.test(file) || FORBIDDEN_FILES.test(file)) {
      problems.push(`Archivo prohibido instalado: ${file}`);
    }
  }
  const packed = auditAsar(appDir, kind);
  problems.push(...packed.problems);
  return { files, asarPath: packed.asarPath, asarFiles: packed.files, problems };
}

function assertPackedApp(appDir, kind) {
  const result = auditAsar(appDir, kind);
  if (result.problems.length) {
    throw new Error(`Paquete ${kind} no válido:\n- ${result.problems.join('\n- ')}`);
  }
  return result;
}

function assertInstalledApp(appDir, kind) {
  const result = auditInstalled(appDir, kind);
  if (result.problems.length) {
    throw new Error(`Instalación ${kind} no válida:\n- ${result.problems.join('\n- ')}`);
  }
  return result;
}

module.exports = {
  REQUIRED,
  SECRET_MARKERS,
  assertInstalledApp,
  assertPackedApp,
  auditAsar,
  auditInstalled,
};
