'use strict';

const assert = require('node:assert/strict');
const { spawn, spawnSync } = require('node:child_process');
const fs = require('node:fs');
const net = require('node:net');
const os = require('node:os');
const path = require('node:path');

const electronPath = require('electron');
const root = path.join(__dirname, '..');
const appDir = process.env.PERFILLAB_UI_APP_DIR ? path.resolve(process.env.PERFILLAB_UI_APP_DIR) : root;
const buildDir = path.join(root, 'build');
const { accountName, accountDescription } = require(path.join(appDir, 'electron', 'native-clone'));

function delay(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function waitExit(child, timeout = 8000) {
  return new Promise((resolve) => {
    if (child.exitCode !== null) return resolve();
    const timer = setTimeout(resolve, timeout);
    child.once('exit', () => {
      clearTimeout(timer);
      resolve();
    });
  });
}

function freePort() {
  return new Promise((resolve, reject) => {
    const server = net.createServer();
    server.once('error', reject);
    server.listen(0, '127.0.0.1', () => {
      const { port } = server.address();
      server.close(() => resolve(port));
    });
  });
}

async function waitForTarget(port, timeout = 30000) {
  const deadline = Date.now() + timeout;
  let lastError = null;
  while (Date.now() < deadline) {
    try {
      const response = await fetch(`http://127.0.0.1:${port}/json/list`);
      if (response.ok) {
        const pages = await response.json();
        const page = pages.find((item) => item.type === 'page' && item.url.includes('renderer/index.html'));
        if (page) return page;
      }
    } catch (error) {
      lastError = error;
    }
    await delay(200);
  }
  throw new Error(`No apareció la ventana de PerfilLab con depuración remota. ${lastError ? lastError.message : ''}`);
}

function createCdpClient(ws) {
  let nextId = 1;
  const pending = new Map();
  const exceptions = [];
  const consoleErrors = [];
  ws.onmessage = (event) => {
    const message = JSON.parse(String(event.data));
    if (message.id) {
      const handler = pending.get(message.id);
      if (!handler) return;
      pending.delete(message.id);
      if (message.error) handler.reject(new Error(message.error.message));
      else handler.resolve(message.result);
      return;
    }
    if (message.method === 'Runtime.exceptionThrown') {
      const details = message.params.exceptionDetails;
      exceptions.push(details.exception ? details.exception.description : details.text);
    }
    if (message.method === 'Runtime.consoleAPICalled' && message.params.type === 'error') {
      consoleErrors.push((message.params.args || []).map((arg) => arg.value || arg.description || '').join(' '));
    }
  };
  return {
    exceptions,
    consoleErrors,
    send(method, params = {}) {
      const id = nextId++;
      return new Promise((resolve, reject) => {
        pending.set(id, { resolve, reject });
        ws.send(JSON.stringify({ id, method, params }));
      });
    },
  };
}

async function main() {
  const tempRoot = fs.mkdtempSync(path.join(os.tmpdir(), 'perfillab-ui-clone-'));
  fs.mkdirSync(buildDir, { recursive: true });
  const dataDir = path.join(tempRoot, 'data');
  const profilesDir = path.join(tempRoot, 'profiles');
  fs.mkdirSync(dataDir, { recursive: true });
  fs.mkdirSync(profilesDir, { recursive: true });

  const cmd = path.join(process.env.SystemRoot || 'C:\\Windows', 'System32', 'cmd.exe');
  const notepad = path.join(process.env.SystemRoot || 'C:\\Windows', 'System32', 'notepad.exe');
  assert.equal(fs.existsSync(cmd), true, 'cmd.exe debe existir para la prueba de interfaz');
  assert.equal(fs.existsSync(notepad), true, 'notepad.exe debe existir para la prueba de interfaz');
  const now = new Date().toISOString();
  const profileId = 'profile-ui';
  const username = accountName(profileId);
  const cloneData = path.join(profilesDir, profileId, 'applications', 'app-data-ui');
  const dataArgs = `/d /c "echo %APPDATA%>%LOCALAPPDATA%\\env-check.txt & ping -n 60 127.0.0.1 >nul"`;

  const data = {
    schemaVersion: 7,
    settings: {
      theme: 'dark',
      closeToTray: true,
      profilesDir,
      api: { enabled: false, port: 45800 },
    },
    workspaces: [{ id: 'ws-ui', name: 'General', color: '#5b6cff', createdAt: now, updatedAt: now }],
    profileStatuses: [
      { id: 'status-ui-nuevo', name: 'Nuevo', color: '#5b6cff', createdAt: now, updatedAt: now },
      { id: 'status-ui-revision', name: 'En revisión', color: '#f59e0b', createdAt: now, updatedAt: now },
    ],
    proxies: [{
      id: 'proxy-ui',
      name: 'Proxy UI',
      protocol: 'http',
      host: '127.0.0.1',
      port: 9,
      username: '',
      passwordEnc: '',
      notes: '',
      createdAt: now,
      updatedAt: now,
    }],
    profiles: [{
      id: profileId,
      name: 'Perfil de prueba',
      workspaceId: 'ws-ui',
      browserId: 'perfillab',
      proxyId: null,
      statusId: 'status-ui-revision',
      startUrls: [],
      tags: [],
      notes: '',
      color: '#5b6cff',
      createdAt: now,
      updatedAt: now,
      lastStartedAt: null,
      lastStoppedAt: null,
    }, {
      id: 'profile-ui-2',
      name: 'Perfil sin cuenta',
      workspaceId: 'ws-ui',
      browserId: 'perfillab',
      proxyId: null,
      startUrls: [],
      tags: [],
      notes: '',
      color: '#22a06b',
      createdAt: now,
      updatedAt: now,
      lastStartedAt: null,
      lastStoppedAt: null,
    }],
    apps: [
      {
        id: 'app-account-ui',
        name: 'Bloc de notas',
        kind: 'executable',
        target: notepad,
        args: '',
        cwd: '',
        cloneMode: 'account',
        favorite: false,
        source: 'manual',
        createdAt: now,
        updatedAt: now,
      },
      {
        id: 'app-data-ui',
        name: 'Consola aislada',
        kind: 'executable',
        target: cmd,
        args: dataArgs,
        cwd: '',
        cloneMode: 'data',
        favorite: false,
        source: 'manual',
        createdAt: now,
        updatedAt: now,
      },
    ],
    cloneAccounts: [{
      profileId,
      username,
      description: accountDescription(profileId),
      sid: 'S-1-5-21-111111111-222222222-333333333-1001',
      passwordEnc: `plain1:${Buffer.from('Pl1!ui-check-password-000000', 'utf8').toString('base64')}`,
      preparedAt: now,
      verifiedAt: now,
      updatedAt: now,
    }],
    appProfileConfigs: [],
    activity: [],
  };
  fs.writeFileSync(path.join(dataDir, 'data.json'), `${JSON.stringify(data, null, 2)}\n`);

  const port = await freePort();
  const env = { ...process.env, PERFILLAB_DATA_DIR: dataDir, PERFILLAB_DEBUG_PORT: String(port) };
  delete env.ELECTRON_RUN_AS_NODE;
  const child = spawn(electronPath, [appDir], {
    cwd: appDir,
    env,
    windowsHide: false,
    stdio: ['ignore', 'pipe', 'pipe'],
  });
  let stderr = '';
  child.stderr.on('data', (chunk) => {
    stderr += String(chunk);
  });

  let ws = null;
  let cdp = null;
  try {
    const page = await waitForTarget(port);
    ws = new WebSocket(page.webSocketDebuggerUrl);
    await new Promise((resolve, reject) => {
      ws.onopen = resolve;
      ws.onerror = () => reject(new Error('No se pudo conectar al depurador de la ventana.'));
    });
    cdp = createCdpClient(ws);
    await cdp.send('Runtime.enable');
    await cdp.send('Page.enable');
    await cdp.send('Page.bringToFront');

    const evaluate = async (expression) => {
      const result = await cdp.send('Runtime.evaluate', {
        expression,
        awaitPromise: true,
        returnByValue: true,
      });
      if (result.exceptionDetails) {
        throw new Error(result.exceptionDetails.exception
          ? result.exceptionDetails.exception.description
          : result.exceptionDetails.text);
      }
      return result.result.value;
    };
    const waitFor = async (expression, label, timeout = 15000) => {
      const deadline = Date.now() + timeout;
      while (Date.now() < deadline) {
        try {
          if (await evaluate(expression)) return;
        } catch {
          // El DOM todavía se está cargando.
        }
        await delay(120);
      }
      throw new Error(`Tiempo de espera agotado: ${label}`);
    };
    const screenshot = async (name) => {
      const shot = await cdp.send('Page.captureScreenshot', { format: 'png' });
      const file = path.join(buildDir, name);
      fs.writeFileSync(file, Buffer.from(shot.data, 'base64'));
      return file;
    };
    const gotoView = async (view, label = view, timeout = 20000) => {
      const deadline = Date.now() + timeout;
      while (Date.now() < deadline) {
        await evaluate(`document.querySelector('[data-nav="${view}"]')?.click()`);
        await delay(200);
        const visible = await evaluate(`Boolean(document.querySelector('#view-${view}')) && !document.querySelector('#view-${view}').hidden`);
        if (visible) return;
      }
      throw new Error(`Tiempo de espera agotado: ${label}`);
    };

    await waitFor(`Boolean(document.querySelector('[data-nav="apps"]'))`, 'ventana principal', 30000);
    await gotoView('apps', 'vista de aplicaciones');
    await waitFor(
      `document.querySelectorAll('#view-apps .app-card').length === 2`,
      'aplicaciones renderizadas',
      30000,
    );
    await waitFor(
      `document.querySelector('.app-isolation-note')?.innerText.includes('Clonador disponible')`,
      'diagnóstico del clonador',
      30000,
    );

    const appsView = await evaluate(`(() => ({
      note: document.querySelector('#view-apps .app-isolation-note').innerText,
      chips: [...document.querySelectorAll('#view-apps .app-isolation-note .chip')].map((chip) => chip.innerText),
      cards: [...document.querySelectorAll('#view-apps .app-card')].map((card) => ({
        name: card.querySelector('.app-card-title strong').innerText,
        chips: [...card.querySelectorAll('.chip')].map((chip) => chip.innerText)
      }))
    }))()`);
    assert.match(appsView.note, /Clones nativos de Windows, sin instalar nada más/);
    assert.match(appsView.note, /no es una barrera de seguridad/);
    assert.ok(appsView.chips.includes('Clonador disponible'), `chips: ${appsView.chips.join(', ')}`);
    assert.ok(appsView.chips.includes('Credenciales cifradas'), `chips: ${appsView.chips.join(', ')}`);
    assert.ok(appsView.chips.includes('1 cuenta preparada'), `chips: ${appsView.chips.join(', ')}`);
    assert.ok(appsView.chips.includes('1 aplicación usa cuenta'), `chips: ${appsView.chips.join(', ')}`);
    const accountCard = appsView.cards.find((card) => card.name === 'Bloc de notas');
    const dataCard = appsView.cards.find((card) => card.name === 'Consola aislada');
    assert.ok(accountCard.chips.includes('Cuenta Windows'), `chips: ${accountCard.chips.join(', ')}`);
    assert.ok(dataCard.chips.includes('Datos aislados (limitado)'), `chips: ${dataCard.chips.join(', ')}`);
    await screenshot('ui-apps-clone.png');

    await evaluate(`document.querySelector('[data-action="app-edit"][data-id="app-account-ui"]').click()`);
    await waitFor(`Boolean(document.querySelector('#app-edit-form'))`, 'modal de edición');
    const editView = await evaluate(`(() => {
      const form = document.querySelector('#app-edit-form');
      return {
        cards: form.querySelectorAll('.clone-mode-card').length,
        selected: form.querySelector('input[name="cloneMode"]:checked')?.value || '',
        text: form.innerText
      };
    })()`);
    assert.equal(editView.cards, 4);
    assert.equal(editView.selected, 'account');
    assert.match(editView.text, /HKCU, AppData y TEMP/);
    assert.match(editView.text, /prepara una vez con UAC/);
    assert.match(editView.text, /Máquina virtual Hyper-V/);
    assert.match(editView.text, /imagen base \.vhdx/);
    await screenshot('ui-edit-clone.png');
    await evaluate(`document.querySelector('.modal [data-close-modal]').click()`);
    await waitFor(`!document.querySelector('.modal')`, 'cierre del modal de edición');

    await evaluate(`document.querySelector('[data-action="app-launch"][data-id="app-account-ui"]').click()`);
    await waitFor(`Boolean(document.querySelector('#app-launch-form'))`, 'modal de apertura de cuenta');
    const launchView = await evaluate(`(() => ({
      status: document.querySelector('#al-clone-status').innerText,
      prepareButton: Boolean(document.querySelector('#al-clone-status [data-action="clone-prepare"]'))
    }))()`);
    assert.match(launchView.status, new RegExp(`Se abrirá en la cuenta ${username}`));
    assert.match(launchView.status, /HKCU, AppData y TEMP/);
    assert.equal(launchView.prepareButton, false);
    await screenshot('ui-launch-account-clone.png');
    await evaluate(`document.querySelector('.modal button[type="submit"][form="app-launch-form"]').click()`);
    await waitFor(
      `document.querySelector('#app-launch-error')?.classList.contains('is-visible')`,
      'error controlado al abrir con una cuenta inexistente',
      60000,
    );
    const launchError = await evaluate(`document.querySelector('#app-launch-error').innerText`);
    assert.match(launchError, /1326|iniciar sesión/);
    await evaluate(`document.querySelector('.modal [data-close-modal]').click()`);
    await waitFor(`!document.querySelector('.modal')`, 'cierre del modal de apertura');

    await evaluate(`document.querySelector('[data-action="app-launch"][data-id="app-account-ui"]').click()`);
    await waitFor(`Boolean(document.querySelector('#app-launch-form'))`, 'modal de apertura sin cuenta');
    await evaluate(`(() => {
      const select = document.querySelector('#al-profile');
      select.value = 'profile-ui-2';
      select.dispatchEvent(new Event('change', { bubbles: true }));
    })()`);
    await waitFor(
      `document.querySelector('#al-clone-status')?.innerText.includes('Preparar cuenta')`,
      'aviso de cuenta sin preparar',
    );
    const unpreparedView = await evaluate(`(() => ({
      status: document.querySelector('#al-clone-status').innerText,
      prepareButton: Boolean(document.querySelector('#al-clone-status [data-action="clone-prepare"]'))
    }))()`);
    assert.match(unpreparedView.status, /Este perfil todavía no tiene su cuenta de Windows/);
    assert.match(unpreparedView.status, /permisos de administrador una sola vez/);
    assert.equal(unpreparedView.prepareButton, true);
    await screenshot('ui-launch-unprepared-clone.png');
    await evaluate(`document.querySelector('.modal [data-close-modal]').click()`);
    await waitFor(`!document.querySelector('.modal')`, 'cierre del modal sin cuenta');

    await evaluate(`document.querySelector('[data-action="app-launch"][data-id="app-data-ui"]').click()`);
    await waitFor(`Boolean(document.querySelector('#app-launch-form'))`, 'modal de apertura de datos');
    const dataLaunchView = await evaluate(`(() => ({
      status: document.querySelector('#al-clone-status').innerText,
      args: document.querySelector('#al-args').value,
      cwd: document.querySelector('#al-cwd').value
    }))()`);
    assert.match(dataLaunchView.status, /Datos aislados no duplica/);
    assert.equal(dataLaunchView.args, dataArgs);
    await evaluate(`document.querySelector('.modal button[type="submit"][form="app-launch-form"]').click()`);
    await waitFor(
      `[...document.querySelectorAll('#view-apps .app-running-row')].some((row) => row.innerText.includes('Consola aislada') && row.innerText.includes('datos aislados'))`,
      'aplicación aislada en ejecución',
      30000,
    );

    const envFile = path.join(cloneData, 'Local', 'env-check.txt');
    const deadline = Date.now() + 15000;
    while (!fs.existsSync(envFile) && Date.now() < deadline) await delay(150);
    assert.equal(fs.existsSync(envFile), true, 'La aplicación debe escribir dentro de LOCALAPPDATA redirigido');
    const appDataSeen = fs.readFileSync(envFile, 'utf8').trim();
    assert.equal(path.resolve(appDataSeen).toLowerCase(), path.resolve(path.join(cloneData, 'Roaming')).toLowerCase());
    assert.equal(fs.existsSync(path.join(cloneData, 'Temp')), true);
    await screenshot('ui-data-running-clone.png');

    await evaluate(`document.querySelector('#view-apps [data-action="app-stop"]').click()`);
    await waitFor(
      `document.querySelectorAll('#view-apps .app-running-row').length === 0`,
      'detención de la aplicación aislada',
      30000,
    );

    await gotoView('settings', 'vista de ajustes');
    await waitFor(
      `[...document.querySelectorAll('#view-settings .settings-card')].some((card) => card.innerText.includes('Clonador nativo') && [...card.querySelectorAll('.clone-account-row')].some((row) => row.innerText.includes('${username}')))`,
      'tarjeta del clonador nativo',
    );
    const settingsView = await evaluate(`(() => {
      const card = [...document.querySelectorAll('#view-settings .settings-card')].find((item) => item.innerText.includes('Clonador nativo'));
      const rows = [...card.querySelectorAll('.clone-account-row')];
      const row = rows.find((item) => item.innerText.includes('${username}')) || rows[0];
      const unprepared = rows.find((item) => item.innerText.includes('Perfil sin cuenta')) || null;
      return {
        text: card.innerText,
        chips: [...card.querySelectorAll('.chip')].map((chip) => chip.innerText),
        row: row ? row.innerText : '',
        actions: row ? [...row.querySelectorAll('[data-action]')].map((button) => button.dataset.action) : [],
        unpreparedActions: unprepared ? [...unprepared.querySelectorAll('[data-action]')].map((button) => button.dataset.action) : []
      };
    })()`);
    assert.match(settingsView.text, /Sin software de terceros/);
    assert.match(settingsView.text, /No es una barrera de seguridad/);
    assert.match(settingsView.text, /1 de 2 perfiles con cuenta preparada/);
    assert.ok(settingsView.chips.includes('Disponible'), `chips: ${settingsView.chips.join(', ')}`);
    assert.ok(settingsView.chips.includes('Cifradas'), `chips: ${settingsView.chips.join(', ')}`);
    assert.match(settingsView.row, new RegExp(username));
    assert.deepEqual(settingsView.actions.sort(), ['clone-release', 'clone-verify']);
    assert.deepEqual(settingsView.unpreparedActions, ['clone-prepare']);
    await screenshot('ui-settings-clone.png');

    const statusSettings = await evaluate(`(() => {
      const card = [...document.querySelectorAll('#view-settings .settings-card')].find((item) => item.innerText.includes('Estados de perfil'));
      if (!card) return null;
      return {
        text: card.innerText,
        rows: [...card.querySelectorAll('.status-manage-row')].map((row) => row.innerText),
        actions: [...card.querySelectorAll('[data-action]')].map((button) => button.dataset.action),
        pills: card.querySelectorAll('.status-pill').length
      };
    })()`);
    assert.ok(statusSettings, 'tarjeta de estados de perfil');
    assert.equal(statusSettings.pills, 2);
    assert.ok(statusSettings.rows.some((row) => /En revisión/.test(row)), statusSettings.rows.join(' | '));
    assert.ok(statusSettings.rows.some((row) => /Nuevo/.test(row)), statusSettings.rows.join(' | '));
    for (const action of ['status-new', 'status-edit', 'status-delete']) {
      assert.ok(statusSettings.actions.includes(action), `acciones de estado: ${statusSettings.actions.join(', ')}`);
    }
    await screenshot('ui-settings-statuses.png');
    await evaluate(`document.querySelector('.clone-account-row [data-action="clone-verify"]').click()`);
    await waitFor(
      `[...document.querySelectorAll('.toast-copy')].some((toast) => /iniciar sesión|cuenta del clon/i.test(toast.innerText))`,
      'verificación real de la cuenta simulada',
      60000,
    );
    const verifyToast = await evaluate(`[...document.querySelectorAll('.toast-copy')].map((toast) => toast.innerText).find((text) => /iniciar sesión|cuenta del clon/i.test(text)) || ''`);
    assert.match(verifyToast, /1326|iniciar sesión/);
    await evaluate(`document.querySelector('[data-action="clone-refresh"]').click()`);
    await waitFor(
      `[...document.querySelectorAll('.toast-copy')].some((toast) => toast.innerText.includes('Clonador nativo listo'))`,
      'diagnóstico del clonador actualizado',
    );

    const vmSettings = await evaluate(`(() => {
      const card = [...document.querySelectorAll('#view-settings .settings-card')].find((item) => item.innerText.includes('Máquinas virtuales'));
      if (!card) return null;
      return {
        text: card.innerText,
        hasPick: Boolean(card.querySelector('[data-action="vm-pick-base"]')),
        hasSave: Boolean(card.querySelector('[data-action="vm-save-config"]')),
        hasSwitch: Boolean(card.querySelector('#vm-switch')),
        hasMemory: Boolean(card.querySelector('#vm-memory')),
        hasProfileRows: card.querySelectorAll('.clone-account-row').length > 0
      };
    })()`);
    assert.ok(vmSettings, 'tarjeta de máquinas virtuales');
    assert.equal(vmSettings.hasPick, true);
    assert.equal(vmSettings.hasSave, true);
    assert.equal(vmSettings.hasSwitch, true);
    assert.equal(vmSettings.hasMemory, true);
    assert.equal(vmSettings.hasProfileRows, true);
    assert.match(vmSettings.text, /Hyper-V nativo/);
    assert.match(vmSettings.text, /Límites reales del modo máquina virtual/);
    assert.match(vmSettings.text, /licencia de Windows válida/);
    await screenshot('ui-settings-vm.png');

    await gotoView('profiles', 'vista de perfiles');
    await waitFor(`Boolean(document.querySelector('[data-menu-profile="${profileId}"]'))`, 'tarjeta del perfil');

    const profileStatusView = await evaluate(`(() => ({
      pill: document.querySelector('#view-profiles .profile-card .status-pill')?.innerText || '',
      statusSelect: Boolean(document.querySelector('#filter-status')),
      filterOptions: [...document.querySelectorAll('#filter-status option')].map((option) => option.innerText)
    }))()`);
    assert.equal(profileStatusView.statusSelect, true);
    assert.match(profileStatusView.pill, /En revisión/);
    assert.deepEqual(profileStatusView.filterOptions, ['Todos los estados', 'Nuevo', 'En revisión', 'Sin estado']);

    await evaluate(`(() => {
      const select = document.querySelector('#filter-status');
      select.value = 'none';
      select.dispatchEvent(new Event('change', { bubbles: true }));
    })()`);
    await waitFor(`document.querySelectorAll('#view-profiles .profile-card').length === 1`, 'filtro por perfiles sin estado');
    const filteredName = await evaluate(`document.querySelector('#view-profiles .profile-card strong')?.innerText || ''`);
    assert.match(filteredName, /Perfil sin cuenta/);
    await evaluate(`(() => {
      const select = document.querySelector('#filter-status');
      select.value = 'all';
      select.dispatchEvent(new Event('change', { bubbles: true }));
    })()`);
    await waitFor(`document.querySelectorAll('#view-profiles .profile-card').length === 2`, 'quitar filtro de estado');

    const selectionView = await evaluate(`(() => ({
      checkboxes: document.querySelectorAll('#view-profiles .profile-select input[type="checkbox"]').length,
      bulkBar: Boolean(document.querySelector('#view-profiles .bulk-bar'))
    }))()`);
    assert.equal(selectionView.checkboxes, 2);
    assert.equal(selectionView.bulkBar, false);

    await evaluate(`document.querySelector('#view-profiles .profile-select input[type="checkbox"]').click()`);
    await waitFor(`Boolean(document.querySelector('#view-profiles .bulk-bar'))`, 'barra de acciones masivas');
    const bulkView = await evaluate(`(() => ({
      text: document.querySelector('#view-profiles .bulk-bar').innerText,
      actions: [...document.querySelectorAll('#view-profiles .bulk-bar [data-action]')].map((button) => button.dataset.action)
    }))()`);
    assert.match(bulkView.text, /1 perfil seleccionado/);
    for (const action of ['bulk-start', 'bulk-stop', 'bulk-move', 'bulk-tags', 'bulk-status', 'bulk-proxy', 'bulk-duplicate', 'bulk-delete', 'bulk-test-proxies', 'bulk-export', 'bulk-clear']) {
      assert.ok(bulkView.actions.includes(action), `acciones masivas: ${bulkView.actions.join(', ')}`);
    }
    await screenshot('ui-profiles-bulk.png');

    await evaluate(`document.querySelector('#view-profiles [data-action="profiles-select-visible"]').click()`);
    await waitFor(
      `document.querySelector('#view-profiles .bulk-count')?.innerText.includes('2 perfiles seleccionados')`,
      'selección de todos los perfiles visibles',
    );

    await evaluate(`document.querySelector('#view-profiles [data-action="bulk-export"]').click()`);
    await waitFor(`Boolean(document.querySelector('.modal [data-export-format="csv"]'))`, 'selector de exportación');
    const exportChoices = await evaluate(`[...document.querySelectorAll('.modal .choice-card')].map((card) => card.innerText)`);
    assert.equal(exportChoices.length, 2);
    assert.ok(exportChoices.some((text) => text.includes('CSV')));
    assert.ok(exportChoices.some((text) => text.includes('JSON')));
    await screenshot('ui-export-choices.png');
    await evaluate(`document.querySelector('.modal [data-close-modal]').click()`);
    await waitFor(`!document.querySelector('.modal')`, 'cierre del selector de exportación');

    await evaluate(`document.querySelector('#view-profiles [data-action="bulk-move"]').click()`);
    await waitFor(`Boolean(document.querySelector('#bulk-workspace'))`, 'modal para mover perfiles');
    const moveOptions = await evaluate(`document.querySelectorAll('#bulk-workspace option').length`);
    assert.equal(moveOptions, 1);
    await evaluate(`document.querySelector('.modal [data-close-modal]').click()`);
    await waitFor(`!document.querySelector('.modal')`, 'cierre del modal para mover perfiles');

    await evaluate(`document.querySelector('#view-profiles [data-action="bulk-tags"]').click()`);
    await waitFor(`Boolean(document.querySelector('#bulk-tags-input'))`, 'modal de etiquetas masivas');
    const tagsModes = await evaluate(`document.querySelectorAll('#bulk-tags-mode option').length`);
    assert.equal(tagsModes, 3);
    await screenshot('ui-bulk-tags.png');
    await evaluate(`document.querySelector('.modal [data-close-modal]').click()`);
    await waitFor(`!document.querySelector('.modal')`, 'cierre del modal de etiquetas');

    await evaluate(`document.querySelector('#view-profiles [data-action="bulk-status"]').click()`);
    await waitFor(`Boolean(document.querySelector('#bulk-status'))`, 'modal de estado masivo');
    const statusChoices = await evaluate(`[...document.querySelectorAll('#bulk-status option')].map((option) => option.innerText)`);
    assert.deepEqual(statusChoices, ['Sin estado', 'Nuevo', 'En revisión']);
    await screenshot('ui-bulk-status.png');
    await evaluate(`document.querySelector('.modal [data-close-modal]').click()`);
    await waitFor(`!document.querySelector('.modal')`, 'cierre del modal de estado');

    await evaluate(`document.querySelector('#view-profiles [data-action="bulk-proxy"]').click()`);
    await waitFor(`Boolean(document.querySelector('#bulk-proxy'))`, 'modal de proxy masivo');
    const proxyChoices = await evaluate(`document.querySelectorAll('#bulk-proxy option').length`);
    assert.equal(proxyChoices, 2);
    await evaluate(`document.querySelector('.modal [data-close-modal]').click()`);
    await waitFor(`!document.querySelector('.modal')`, 'cierre del modal de proxy');

    await evaluate(`document.querySelector('#view-profiles [data-action="bulk-duplicate"]').click()`);
    await waitFor(`Boolean(document.querySelector('#confirm-button'))`, 'confirmación de duplicado masivo');
    const duplicateText = await evaluate(`document.querySelector('.modal').innerText`);
    assert.match(duplicateText, /Se creará una copia de cada perfil/);
    await evaluate(`document.querySelector('.modal [data-close-modal]').click()`);
    await waitFor(`!document.querySelector('.modal')`, 'cierre del modal de duplicado');

    await evaluate(`document.querySelector('#view-profiles [data-action="bulk-delete"]').click()`);
    await waitFor(`Boolean(document.querySelector('#bulk-delete-clone'))`, 'confirmación de eliminación masiva');
    const bulkDeleteView = await evaluate(`(() => ({
      text: document.querySelector('.modal').innerText,
      hasDataOption: Boolean(document.querySelector('#bulk-delete-data')),
      cloneChecked: document.querySelector('#bulk-delete-clone').checked,
      hasVmOption: Boolean(document.querySelector('#bulk-delete-vm'))
    }))()`);
    assert.match(bulkDeleteView.text, /Se eliminarán 2 perfiles/);
    assert.equal(bulkDeleteView.hasDataOption, true);
    assert.equal(bulkDeleteView.cloneChecked, true);
    assert.equal(bulkDeleteView.hasVmOption, false);
    await screenshot('ui-bulk-delete.png');
    await evaluate(`document.querySelector('.modal [data-close-modal]').click()`);
    await waitFor(`!document.querySelector('.modal')`, 'cierre del modal de eliminación');

    await evaluate(`document.querySelector('#view-profiles [data-action="bulk-clear"]').click()`);
    await waitFor(`!document.querySelector('#view-profiles .bulk-bar')`, 'limpiar la selección');

    await evaluate(`document.querySelector('#view-profiles [data-action="import-profiles"]').click()`);
    await waitFor(`Boolean(document.querySelector('.modal [data-import-format="csv"]'))`, 'selector de importación');
    const importText = await evaluate(`document.querySelector('.modal').innerText`);
    assert.match(importText, /credenciales nunca se leen del CSV/);
    await evaluate(`document.querySelector('.modal [data-close-modal]').click()`);
    await waitFor(`!document.querySelector('.modal')`, 'cierre del selector de importación');

    await evaluate(`document.querySelector('#view-profiles [data-action="export-profiles"]').click()`);
    await waitFor(`Boolean(document.querySelector('.modal [data-export-format="json"]'))`, 'selector de exportación general');
    await evaluate(`document.querySelector('.modal [data-close-modal]').click()`);
    await waitFor(`!document.querySelector('.modal')`, 'cierre del selector de exportación general');

    await gotoView('proxies', 'vista de proxies');
    await waitFor(`Boolean(document.querySelector('#view-proxies [data-action="proxy-test-all"]'))`, 'prueba masiva de proxies');
    await screenshot('ui-proxies-bulk.png');

    await gotoView('api', 'vista de API');
    await waitFor(
      `document.querySelector('#view-api .endpoint-list')?.innerText.includes('/v1/profiles/batch')`,
      'endpoints de lote documentados',
    );
    const apiEndpoints = await evaluate(`document.querySelector('#view-api .endpoint-list').innerText`);
    assert.match(apiEndpoints, /\/v1\/proxies\/test/);
    assert.match(apiEndpoints, /\/v1\/statuses/);
    assert.match(apiEndpoints, /set-status|estado o proxy/);

    await gotoView('profiles', 'vista de perfiles');
    await waitFor(`Boolean(document.querySelector('[data-menu-profile="${profileId}"]'))`, 'tarjeta del perfil');

    await evaluate(`document.querySelector('[data-menu-profile="${profileId}"]').click()`);
    await waitFor(`Boolean(document.querySelector('.popover [data-action="profile-delete"]'))`, 'menú del perfil');
    await evaluate(`document.querySelector('.popover [data-action="profile-delete"]').click()`);
    await waitFor(`Boolean(document.querySelector('#delete-profile-confirm'))`, 'modal de eliminación');
    const deleteView = await evaluate(`(() => ({
      text: document.querySelector('.modal').innerText,
      checked: document.querySelector('#delete-profile-clone').checked
    }))()`);
    assert.match(deleteView.text, /Este perfil tiene una cuenta de Windows clon/);
    assert.equal(deleteView.checked, true);
    await screenshot('ui-delete-profile-clone.png');
    await evaluate(`document.querySelector('#delete-profile-clone').click()`);
    await evaluate(`document.querySelector('#delete-profile-confirm').click()`);
    await waitFor(`document.querySelector('#delete-profile-error')?.classList.contains('is-visible')`, 'bloqueo de eliminación sin liberar la cuenta');
    const deleteError = await evaluate(`document.querySelector('#delete-profile-error').innerText`);
    assert.match(deleteError, /Confirma que también quieres eliminarla/);
    const profileStillThere = await evaluate(`document.querySelectorAll('#view-profiles .profile-card').length === 2`);
    assert.equal(profileStillThere, true);
    await evaluate(`document.querySelector('.modal [data-close-modal]').click()`);

    assert.deepEqual(cdp.exceptions, [], `La interfaz lanzó excepciones: ${cdp.exceptions.join('\n')}`);
    const relevantErrors = cdp.consoleErrors.filter((message) => /clone|uncaught|typeerror|referenceerror/i.test(message));
    assert.deepEqual(relevantErrors, [], `Errores de consola: ${relevantErrors.join('\n')}`);

    console.log('Interfaz de clones nativos verificada:');
    console.log('  - Bibliotecas, chips y editor de modos (cuenta, datos, sin aislamiento, VM)');
    console.log('  - Estado de la cuenta preparada en el lanzador');
    console.log('  - Error controlado al abrir con una cuenta no disponible');
    console.log('  - Aviso y botón de preparación UAC para un perfil sin cuenta');
    console.log('  - Verificación nativa de la cuenta desde Ajustes con error de Windows controlado');
    console.log(`  - Aislamiento real de datos: ${cloneData}`);
    console.log('  - Ajustes, diagnóstico y bloqueo al eliminar un perfil con cuenta');
    console.log('  - Tarjeta de Hyper-V con límites y configuración sin crear máquinas');
    console.log('  - Selección múltiple con barra de acciones masivas y modal de movimiento');
    console.log('  - Estados de perfil: tarjeta en Ajustes, chip en la tarjeta y filtro por estado');
    console.log('  - Modales masivos de etiquetas, estado, proxy, duplicado y eliminación con salvaguardas');
    console.log('  - Selector de formato para importar y exportar (JSON o CSV sin credenciales)');
    console.log('  - Prueba masiva de proxies y endpoints /v1/profiles/batch, /v1/statuses y /v1/proxies/test');
  } catch (error) {
    console.error(`Interfaz de clones nativos falló: ${error.message}`);
    if (stderr.trim()) console.error('Electron stderr:', stderr.trim().split('\n').slice(-20).join('\n'));
    if (cdp && typeof cdp.send === 'function') {
      try {
        const shot = await cdp.send('Page.captureScreenshot', { format: 'png' });
        const file = path.join(buildDir, 'ui-failure-clone.png');
        fs.writeFileSync(file, Buffer.from(shot.data, 'base64'));
        console.error('Captura del fallo:', file);
      } catch {
        // La ventana ya no responde.
      }
    }
    process.exitCode = 1;
  } finally {
    try { ws?.close(); } catch {
      // la conexión ya está cerrada
    }
    if (child.exitCode === null) {
      if (process.platform === 'win32' && child.pid) {
        spawnSync('taskkill', ['/PID', String(child.pid), '/T', '/F'], { windowsHide: true, stdio: 'ignore' });
      } else {
        child.kill();
      }
      await waitExit(child, 5000);
    }
    try {
      fs.rmSync(tempRoot, { recursive: true, force: true, maxRetries: 10, retryDelay: 250 });
    } catch {
      // Windows puede retener archivos del proceso recién cerrado.
    }
  }
}

main().catch((error) => {
  console.error(error.stack || error.message);
  process.exit(1);
});
