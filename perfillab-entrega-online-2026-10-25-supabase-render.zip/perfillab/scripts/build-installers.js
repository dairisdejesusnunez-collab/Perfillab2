'use strict';

const crypto = require('node:crypto');
const fs = require('node:fs');
const path = require('node:path');
const { execFileSync } = require('node:child_process');
const pkg = require('../package.json');
const adminPkg = require('../license-admin/package.json');
const { assertPackedApp } = require('./pack-audit');

const root = path.join(__dirname, '..');
const buildDir = path.join(root, 'build');
const stageClientRoot = path.join(buildDir, 'pack-client');
const stageAdminRoot = path.join(buildDir, 'pack-admin');
const distDir = process.env.PERFILLAB_DIST_DIR
  ? path.resolve(process.env.PERFILLAB_DIST_DIR)
  : path.join(root, 'dist');
const isccCandidates = [
  process.env.PERFILLAB_ISCC,
  path.join(process.env.ProgramFiles || 'C:\\Program Files', 'Inno Setup 6', 'ISCC.exe'),
  path.join(process.env['ProgramFiles(x86)'] || 'C:\\Program Files (x86)', 'Inno Setup 6', 'ISCC.exe'),
].filter(Boolean).map((candidate) => path.resolve(candidate));
const iscc = isccCandidates.find((candidate) => fs.existsSync(candidate)) || isccCandidates[0];
const skipPack = process.argv.includes('--skip-pack');

const clientSource = path.join(stageClientRoot, `${pkg.productName}-win32-x64`);
const adminSource = path.join(stageAdminRoot, `${adminPkg.productName}-win32-x64`);

function fail(message) {
  console.error(`\n${message}\n`);
  process.exit(1);
}

function sha256(file) {
  return crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex');
}

function run(command, args, options = {}) {
  execFileSync(command, args, { stdio: 'inherit', windowsHide: true, ...options });
}

function packClient() {
  fs.rmSync(stageClientRoot, { recursive: true, force: true });
  console.log('Empaquetando el cliente…');
  run(process.execPath, [path.join(root, 'scripts', 'pack.js')], {
    env: { ...process.env, PERFILLAB_PACK_OUT: stageClientRoot },
  });
}

function packAdmin() {
  fs.rmSync(stageAdminRoot, { recursive: true, force: true });
  console.log('Empaquetando la consola de licencias…');
  run(process.execPath, [path.join(root, 'scripts', 'pack-admin.js')], {
    env: { ...process.env, PERFILLAB_ADMIN_PACK_OUT: stageAdminRoot },
  });
}

function compile({ label, script, version, source, fileName }) {
  const target = path.join(distDir, fileName);
  if (!fs.existsSync(source)) fail(`No existe el contenido empaquetado de ${label}: ${source}`);
  fs.rmSync(target, { force: true });
  console.log(`Compilando ${label}…`);
  run(iscc, [
    `/DAppVersion=${version}`,
    `/DAppSource=${source}`,
    `/DOutputDir=${distDir}`,
    path.join(root, script),
  ]);
  if (!fs.existsSync(target)) fail(`Inno Setup no generó ${path.relative(root, target)}.`);
  const size = fs.statSync(target).size;
  if (size < 40 * 1024 * 1024) fail(`El instalador ${fileName} es demasiado pequeño (${size} bytes).`);
  return { version, file: fileName, size, sha256: sha256(target) };
}

function main() {
  if (process.platform !== 'win32') fail('Los instaladores solo se compilan en Windows.');
  if (!fs.existsSync(iscc)) {
    fail(`No se encontró Inno Setup 6 en ${iscc}. Instálalo o define PERFILLAB_ISCC.`);
  }
  fs.mkdirSync(buildDir, { recursive: true });
  fs.mkdirSync(distDir, { recursive: true });

  if (skipPack) {
    console.log('Se reutiliza el contenido empaquetado existente (--skip-pack).');
  } else {
    packClient();
    packAdmin();
  }

  const clientAudit = assertPackedApp(clientSource, 'client');
  console.log(`Cliente auditado: ${clientAudit.files.length} archivos dentro de app.asar, sin contenido prohibido.`);
  const adminAudit = assertPackedApp(adminSource, 'admin');
  console.log(`Consola auditada: ${adminAudit.files.length} archivos dentro de app.asar, sin contenido prohibido.`);

  const client = compile({
    label: 'el cliente PerfilLab',
    script: 'installer/client.iss',
    version: pkg.version,
    source: clientSource,
    fileName: `PerfilLab-Setup-${pkg.version}.exe`,
  });
  const admin = compile({
    label: 'la consola PerfilLab Licencias',
    script: 'installer/admin.iss',
    version: adminPkg.version,
    source: adminSource,
    fileName: `PerfilLab-Licencias-Setup-${adminPkg.version}.exe`,
  });

  const manifest = {
    product: 'PerfilLab',
    generatedAt: new Date().toISOString(),
    contents: 'Cliente y consola independientes; sin servidor, .env, bóveda, keystore, pruebas ni secretos.',
    installers: { client, admin },
  };
  fs.writeFileSync(path.join(distDir, 'installers.json'), `${JSON.stringify(manifest, null, 2)}\n`);
  fs.writeFileSync(
    path.join(distDir, 'SHA256SUMS.txt'),
    `${client.sha256} *${client.file}\n${admin.sha256} *${admin.file}\n`,
  );

  console.log('\nInstaladores listos:');
  for (const item of [client, admin]) {
    console.log(`- ${path.relative(root, path.join(distDir, item.file))}`);
    console.log(`  ${item.size} bytes`);
    console.log(`  SHA-256: ${item.sha256}`);
  }
  console.log('\nNo se publicó ningún archivo ni se configuró un dominio.');
}

try {
  main();
} catch (error) {
  console.error(error && error.message ? error.message : error);
  process.exit(1);
}
