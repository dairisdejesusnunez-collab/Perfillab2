'use strict';

const { execFile } = require('node:child_process');
const path = require('node:path');
const pkg = require('../package.json');

// extract-zip se queda bloqueado con el archivo de Electron en este entorno;
// el tar incluido en Windows extrae el mismo ZIP de forma fiable.
if (process.platform === 'win32') {
  const modulePath = require.resolve('extract-zip');
  require(modulePath);
  const tar = path.join(process.env.SystemRoot || 'C:\\Windows', 'System32', 'tar.exe');
  require.cache[modulePath].exports = function extractWithTar(zipPath, options) {
    return new Promise((resolve, reject) => {
      execFile(tar, ['-xf', zipPath, '-C', options.dir], { windowsHide: true }, (error) => {
        if (error) reject(error);
        else resolve();
      });
    });
  };
}

const packager = require('@electron/packager');

const root = path.join(__dirname, '..');
const outDir = process.env.PERFILLAB_PACK_OUT
  ? path.resolve(process.env.PERFILLAB_PACK_OUT)
  : path.join(root, 'build');

packager({
  dir: root,
  out: outDir,
  name: pkg.productName,
  executableName: pkg.productName,
  appVersion: pkg.version,
  platform: 'win32',
  arch: 'x64',
  icon: path.join(root, 'assets', 'icon.ico'),
  asar: true,
  overwrite: true,
  prune: true,
  ignore: [
    /^\/build($|\/)/,
    /^\/dist($|\/)/,
    /^\/\.tmp[^/]*($|\/)/,
    /^\/license-admin($|\/)/,
    /^\/license-server($|\/)/,
    /^\/test($|\/)/,
    /^\/scripts($|\/)/,
    /^\/\.git($|\/)/,
    /^\/index\.html$/,
    /^\/README\.md$/i,
    /^\/package-lock\.json$/,
    /^\/\.gitignore$/,
    /(^|\/)\.env(?:\.|$)/i,
    /(^|\/)vault\.json$/i,
    /(^|\/)keystore[^/]*$/i,
    /(^|\/)seed($|\/)/i,
    /(^|\/)[^/]*password[^/]*$/i,
    /(^|\/)(?:\.npmrc|\.netrc|\.pgpass|id_rsa|id_ed25519)$/i,
    /(^|\/)[^/]*\.(?:pem|key|p12|pfx|jks|kdbx)$/i,
  ],
})
  .then((paths) => {
    for (const output of paths) console.log(`Empaquetado en ${path.relative(root, output) || output}`);
  })
  .catch((error) => {
    console.error(error);
    process.exit(1);
  });
