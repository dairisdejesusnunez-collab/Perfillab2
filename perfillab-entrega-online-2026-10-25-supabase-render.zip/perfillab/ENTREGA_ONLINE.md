# PerfilLab: entrega para publicación online

Este paquete contiene el código fuente del cliente, la consola administrativa, el servidor de licencias, la tienda y las pruebas. No contiene secretos ni artefactos compilados.

## Lo que no incluye (a propósito)

- `node_modules`, `build`, `dist` ni instaladores.
- `license-admin/seed/vault.json` (bóveda cifrada con la clave privada de firma).
- `license-server/data` (keystore, SQLite, WAL y copias).
- `.env`, contraseñas, bases de datos, registros ni copias de seguridad.
- Ningún keystore ni frase de paso.

## Ruta recomendada: Supabase + Render

La guía completa está en [`license-server/docs/DESPLIEGUE_SUPABASE_RENDER.md`](license-server/docs/DESPLIEGUE_SUPABASE_RENDER.md). El blueprint [`render.yaml`](render.yaml) crea el servicio Docker con health check en `/api/health`; Supabase aporta PostgreSQL gestionado.

El orden importa:

1. Crear el proyecto de Supabase y obtener la URL del **Session pooler** (puerto 5432).
2. Crear la base remota con **uno** de estos caminos:
   - `scripts/clone-to-postgres.js`: copia la base local completa (50.000 asientos, ajustes, administrador, licencias y pedidos). No necesita la bóveda.
   - `scripts/init.js --vault ...`: base nueva desde la bóveda; solo migra las licencias heredadas emitidas.

   En ambos casos deben quedar 50.000 asientos y el `keyId` que espera el cliente.
3. Exportar el keystore cifrado a base64. Si clonaste la base, el administrador local ya existe; si inicializaste desde la bóveda, créalo con `scripts/admin.js`.
4. Subir el contenido de esta carpeta, no la carpeta padre, a un repositorio privado.
5. Crear el Blueprint en Render y cargar los secretos.
6. Añadir `PERFILLAB_PUBLIC_BASE_URL` con la URL real de Render y configurar PayPal.
7. Fijar el endpoint del cliente antes de compilar:

   ```powershell
   npm run license:endpoint -- --server-url=https://<tu-servicio>
   npm run installers
   npm run verify:installers
   ```

8. Publicar solo el instalador del cliente en una URL HTTPS pública (GitHub Releases de un repositorio público o un bucket público de Supabase Storage) y configurar `PERFILLAB_INSTALLER_URL`, versión, tamaño y SHA-256.

## Sobre la pantalla de activación

- El campo «Servidor de licencias» aparece porque este código no tiene un endpoint compilado: `electron/license-public.js` tiene `serverUrl` vacío y el cliente usa `http://127.0.0.1:45900`.
- El cliente final solo debe introducir su clave. El endpoint se fija con el comando del paso 7 antes de compilar.
- Sin endpoint remoto, la activación online no puede funcionar; la carga de un archivo de licencia firmado sí funciona.
- Si un cliente ya guardó una dirección local, `%LOCALAPPDATA%\PerfilLab\license-config.json` tiene prioridad sobre la URL compilada. Borra ese archivo o corrige la configuración antes de distribuir.
- No se incluye ningún dominio real porque no se proporcionó.

## Advertencias

- La bóveda y el keystore son necesarios para emitir licencias: consérvalos fuera del repositorio y de este ZIP.
- No publiques `perfillab-admin-password.txt`, la frase de paso del keystore ni ningún archivo `.env`.
- No uses las claves `anon` o `service_role` de Supabase como contraseña de PostgreSQL.
- El servidor activa RLS automáticamente en Supabase para que la Data API no pueda leer asientos, licencias, clientes ni administradores. No lo desactives.
- El plan gratuito de Supabase puede pausar el proyecto tras unos 7 días sin actividad; el de Render duerme el servicio tras unos 15 minutos. Despierta el servicio antes de una activación o usa un plan de pago.
- El servicio no está desplegado: esta entrega incluye el código y la configuración, no credenciales ni recursos externos.
