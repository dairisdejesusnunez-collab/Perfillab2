; Instalador del cliente PerfilLab.
; El contenido se genera con scripts/pack.js; este script no compila el servidor
; ni incorpora bóvedas, keystores, .env, pruebas o secretos.

#ifndef AppVersion
  #define AppVersion "1.1.1"
#endif
#ifndef AppSource
  #define AppSource "..\build\pack-client\PerfilLab-win32-x64"
#endif
#ifndef OutputDir
  #define OutputDir "..\dist"
#endif

[Setup]
AppId={{51D86413-73E2-4501-A5B0-2FAA4CA055AA}
AppName=PerfilLab
AppVersion={#AppVersion}
AppVerName=PerfilLab {#AppVersion}
AppPublisher=PerfilLab
DefaultDirName={localappdata}\Programs\PerfilLab
DefaultGroupName=PerfilLab
DisableProgramGroupPage=yes
PrivilegesRequired=lowest
OutputDir={#OutputDir}
OutputBaseFilename=PerfilLab-Setup-{#AppVersion}
SetupIconFile=..\assets\icon.ico
UninstallDisplayIcon={app}\PerfilLab.exe
Compression=lzma2/max
SolidCompression=yes
WizardStyle=modern
CloseApplications=yes
RestartApplications=no
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
MinVersion=10.0
UsePreviousAppDir=yes
AllowNoIcons=yes

[Languages]
Name: "spanish"; MessagesFile: "compiler:Languages\Spanish.isl"

[Tasks]
Name: "desktopicon"; Description: "Crear un acceso directo en el escritorio"; GroupDescription: "Accesos directos:"

[Files]
Source: "{#AppSource}\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs

[Icons]
Name: "{group}\PerfilLab"; Filename: "{app}\PerfilLab.exe"
Name: "{group}\Desinstalar PerfilLab"; Filename: "{uninstallexe}"
Name: "{autodesktop}\PerfilLab"; Filename: "{app}\PerfilLab.exe"; Tasks: desktopicon

[Run]
Filename: "{app}\PerfilLab.exe"; Description: "Abrir PerfilLab"; Flags: nowait postinstall skipifsilent
