; Instalador de la consola PerfilLab Licencias.
; Solo contiene la interfaz administrativa. El servidor, PostgreSQL, .env,
; bóvedas, keystores y secretos quedan fuera de este instalador.

#ifndef AppVersion
  #define AppVersion "1.0.0"
#endif
#ifndef AppSource
  #define AppSource "..\build\pack-admin\PerfilLab Licencias-win32-x64"
#endif
#ifndef OutputDir
  #define OutputDir "..\dist"
#endif

[Setup]
AppId={{0A7EFDEF-D728-49EC-9550-047EB74C4F3A}
AppName=PerfilLab Licencias
AppVersion={#AppVersion}
AppVerName=PerfilLab Licencias {#AppVersion}
AppPublisher=PerfilLab
DefaultDirName={localappdata}\Programs\PerfilLab Licencias
DefaultGroupName=PerfilLab Licencias
DisableProgramGroupPage=yes
PrivilegesRequired=lowest
OutputDir={#OutputDir}
OutputBaseFilename=PerfilLab-Licencias-Setup-{#AppVersion}
SetupIconFile=..\assets\icon.ico
UninstallDisplayIcon={app}\PerfilLab Licencias.exe
Compression=lzma2/max
SolidCompression=yes
WizardStyle=modern
CloseApplications=yes
RestartApplications=no
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
MinVersion=10.0
UsePreviousAppDir=yes
AllowNoIcons=yes

[Languages]
Name: "spanish"; MessagesFile: "compiler:Languages\Spanish.isl"

[Tasks]
Name: "desktopicon"; Description: "Crear un acceso directo en el escritorio"; GroupDescription: "Accesos directos:"

[Files]
Source: "{#AppSource}\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs

[Icons]
Name: "{group}\PerfilLab Licencias"; Filename: "{app}\PerfilLab Licencias.exe"
Name: "{group}\Desinstalar PerfilLab Licencias"; Filename: "{uninstallexe}"
Name: "{autodesktop}\PerfilLab Licencias"; Filename: "{app}\PerfilLab Licencias.exe"; Tasks: desktopicon

[Run]
Filename: "{app}\PerfilLab Licencias.exe"; Description: "Abrir PerfilLab Licencias"; Flags: nowait postinstall skipifsilent
