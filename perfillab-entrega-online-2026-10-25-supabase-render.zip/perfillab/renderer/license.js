'use strict';

(() => {
  const bridge = window.perfillab;
  const $ = (selector) => document.querySelector(selector);
  const machineCodeEl = $('#machine-code');
  const machineHintEl = $('#machine-hint');
  const errorBox = $('#error-box');
  const keyInput = $('#license-key');
  const serverInput = $('#server-url');
  const serverNote = $('#server-note');
  const serverDot = $('#server-dot');
  const testButton = $('#test-server');
  const textArea = $('#license-text');
  const activateButton = $('#activate-license');
  const activateTextButton = $('#activate-text');
  const importButton = $('#import-license');
  const copyButton = $('#copy-machine');
  const panel = $('#panel');
  const successPanel = $('#success-panel');
  const detailsEl = $('#license-details');
  const statusEl = $('#license-status');
  const openButton = $('#open-app');
  const refreshButton = $('#refresh-license');
  const advanced = $('#advanced');
  const toastEl = $('#toast');
  let machineCode = '';
  let busy = false;
  let toastTimer = null;
  let lastStatus = null;
  const activateButtonHTML = activateButton.innerHTML;
  const refreshButtonHTML = refreshButton.innerHTML;

  function esc(value) {
    return String(value === undefined || value === null ? '' : value)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  }

  async function action(name, payload) {
    const result = await bridge.action(name, payload);
    if (!result || !result.ok) {
      const error = new Error(result && result.error && result.error.message
        ? result.error.message
        : 'No se pudo completar la acción.');
      error.code = result && result.error ? result.error.code : 'error';
      throw error;
    }
    return result.data;
  }

  function showError(message) {
    errorBox.textContent = message;
    errorBox.hidden = false;
  }

  function clearError() {
    errorBox.textContent = '';
    errorBox.hidden = true;
  }

  function toast(message) {
    toastEl.textContent = message;
    toastEl.classList.add('is-visible');
    if (toastTimer) clearTimeout(toastTimer);
    toastTimer = setTimeout(() => toastEl.classList.remove('is-visible'), 2200);
  }

  function formatDate(value) {
    if (!value) return 'Permanente';
    const date = new Date(value);
    if (!Number.isFinite(date.getTime())) return '—';
    return date.toLocaleDateString('es-ES', { day: '2-digit', month: 'short', year: 'numeric' });
  }

  function formatDateTime(value) {
    if (!value) return '';
    const date = new Date(value);
    if (!Number.isFinite(date.getTime())) return '';
    return date.toLocaleString('es-ES', {
      day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit',
    });
  }

  function planLabel(plan) {
    if (!plan) return '—';
    const labels = { monthly: 'Mensual', semiannual: 'Semestral', annual: 'Anual' };
    return labels[plan] || plan;
  }

  function maskKey(value) {
    const normalized = normalizeKey(value);
    if (!normalized) return '—';
    return `••••-••••-••••-${normalized.slice(-4)}`;
  }

  function normalizeKey(value) {
    const cleaned = String(value || '')
      .toUpperCase()
      .replace(/[^0-9A-Z]/g, '')
      .slice(0, 16);
    return cleaned.length === 16
      ? cleaned.replace(/(.{4})/g, '$1-').replace(/-$/, '')
      : '';
  }

  function formatKeyInput(value) {
    const cleaned = String(value || '').toUpperCase().replace(/[^0-9A-Z]/g, '').slice(0, 16);
    return cleaned.replace(/(.{4})(?=.)/g, '$1-');
  }

  function setServerState(state, message) {
    serverDot.classList.remove('is-ok', 'is-error');
    serverNote.classList.remove('is-ok', 'is-error');
    if (state) {
      serverDot.classList.add(`is-${state}`);
      serverNote.classList.add(`is-${state}`);
    }
    serverNote.textContent = message;
  }

  function setBusy(next, mode) {
    busy = next;
    activateButton.disabled = next;
    importButton.disabled = next;
    activateTextButton.disabled = next;
    keyInput.disabled = next;
    serverInput.disabled = next;
    testButton.disabled = next;
    refreshButton.disabled = next;
    activateButton.innerHTML = next && mode === 'activate'
      ? '<span>Verificando…</span>'
      : activateButtonHTML;
    refreshButton.innerHTML = next && mode === 'refresh'
      ? '<span>Comprobando…</span>'
      : refreshButtonHTML;
  }

  function showSuccess(status) {
    lastStatus = status;
    panel.hidden = true;
    successPanel.hidden = false;
    const offline = Boolean(status.offline);
    detailsEl.innerHTML = `
      <div><small>Cliente</small><strong>${esc(status.customer || '—')}</strong></div>
      <div><small>Licencia</small><strong>${esc(status.licenseId || '—')}</strong></div>
      <div><small>Equipo</small><strong>${esc(status.machineCode || '—')}</strong></div>
      <div><small>Asiento</small><strong>${esc(status.seat ? `#${status.seat}` : '—')}</strong></div>
      <div><small>Plan</small><strong>${esc(planLabel(status.plan))}</strong></div>
      <div><small>Válida hasta</small><strong>${esc(formatDate(status.expiresAt))}</strong></div>
      <div class="span-2"><small>Clave</small><strong>${esc(maskKey(status.licenseKey))}</strong></div>
    `;
    const checked = formatDateTime(status.lastCheckedAt);
    const revoked = Number.isFinite(status.revokedCount) ? status.revokedCount : null;
    statusEl.classList.toggle('is-warning', offline);
    if (offline) {
      statusEl.innerHTML = '<span class="status-dot"></span>Sin conexión con el servidor. La licencia guardada sigue vigente en este equipo.';
    } else if (checked) {
      const revocationText = revoked === null ? '' : ` · ${revoked} revocación(es) descargada(s)`;
      statusEl.innerHTML = `<span class="status-dot is-ok"></span>Comprobada con el servidor el ${esc(checked)}${esc(revocationText)}.`;
    } else {
      statusEl.classList.remove('is-warning');
      statusEl.innerHTML = '<span class="status-dot"></span>Licencia guardada en este equipo. Aún no se ha comprobado en línea.';
    }
    openButton.focus();
  }

  function showActivation(status, message) {
    successPanel.hidden = true;
    panel.hidden = false;
    if (status) {
      lastStatus = status;
      if (status.serverUrl) serverInput.value = status.serverUrl;
      if (status.licenseKey) keyInput.value = normalizeKey(status.licenseKey);
    }
    if (message) showError(message);
    if (machineCode) keyInput.focus();
  }

  async function copyMachine() {
    if (!machineCode) return;
    try {
      await action('app:copy', { text: machineCode });
      copyButton.classList.add('is-copied');
      copyButton.querySelector('span').textContent = 'Copiado';
      toast('Código de equipo copiado');
      setTimeout(() => {
        copyButton.classList.remove('is-copied');
        copyButton.querySelector('span').textContent = 'Copiar';
      }, 1800);
    } catch (error) {
      toast(error.message);
    }
  }

  async function testServer() {
    if (busy) return;
    clearError();
    const serverUrl = serverInput.value.trim();
    if (!serverUrl) {
      setServerState('error', 'Escribe la dirección del servidor.');
      serverInput.focus();
      return;
    }
    testButton.disabled = true;
    setServerState('', 'Conectando con el servidor…');
    try {
      const info = await action('license:ping', { serverUrl });
      setServerState('ok', `Servidor disponible: ${info.service || 'PerfilLab Licencias'}${info.version ? ` v${info.version}` : ''}.`);
    } catch (error) {
      setServerState('error', error.message);
    } finally {
      testButton.disabled = busy;
    }
  }

  async function activate() {
    if (busy) return;
    clearError();
    if (!machineCode) {
      showError('No se pudo identificar este equipo. Cierra y vuelve a abrir PerfilLab.');
      return;
    }
    const key = normalizeKey(keyInput.value);
    if (!key) {
      showError('Escribe la clave completa: 16 caracteres en cuatro bloques.');
      keyInput.focus();
      return;
    }
    keyInput.value = key;
    setBusy(true, 'activate');
    try {
      const status = await action('license:activate-key', {
        licenseKey: key,
        serverUrl: serverInput.value.trim(),
      });
      setServerState('ok', 'Servidor disponible.');
      showSuccess(status);
      toast('Licencia activada correctamente');
    } catch (error) {
      if (error.code === 'license_server_unreachable' || error.code === 'license_server_timeout') {
        showError(`${error.message} Si ya tienes el archivo de licencia, usa «Cargar archivo» o el texto de licencia.`);
      } else {
        showError(error.message);
      }
    } finally {
      setBusy(false);
    }
  }

  async function importLicense() {
    if (busy) return;
    clearError();
    setBusy(true, 'import');
    try {
      const result = await action('license:import');
      if (result && result.canceled) return;
      showSuccess(result);
      toast('Licencia cargada correctamente');
    } catch (error) {
      showError(error.message);
    } finally {
      setBusy(false);
    }
  }

  async function activateFromText() {
    if (busy) return;
    clearError();
    const value = textArea.value.trim();
    if (!value) {
      showError('Pega el contenido de la licencia o cárgala desde un archivo.');
      textArea.focus();
      return;
    }
    setBusy(true, 'text');
    try {
      const status = await action('license:activate', { text: value });
      showSuccess(status);
      toast('Licencia verificada correctamente');
    } catch (error) {
      showError(error.message);
    } finally {
      setBusy(false);
    }
  }

  async function refreshStatus({ silent = false } = {}) {
    if (busy) return;
    if (!silent) clearError();
    setBusy(true, 'refresh');
    try {
      const status = await action('license:refresh');
      if (status && (status.licensed || status.active)) {
        showSuccess(status);
        if (!silent) toast('Licencia comprobada con el servidor');
      } else if (status) {
        showActivation(status, status.statusMessage || 'La licencia ya no es válida.');
      }
    } catch (error) {
      if (!silent) toast(error.message);
    } finally {
      setBusy(false);
    }
  }

  async function openApp() {
    if (busy) return;
    setBusy(true, 'launch');
    openButton.disabled = true;
    const original = openButton.innerHTML;
    openButton.innerHTML = '<span>Abriendo…</span>';
    try {
      await action('license:launch');
    } catch (error) {
      showActivation(lastStatus, error.message);
      openButton.disabled = false;
      openButton.innerHTML = original;
      setBusy(false);
    }
  }

  async function init() {
    if (!bridge) {
      showError('El puente de la aplicación no está disponible. Cierra y vuelve a abrir PerfilLab.');
      activateButton.disabled = true;
      importButton.disabled = true;
      activateTextButton.disabled = true;
      testButton.disabled = true;
      return;
    }

    copyButton.addEventListener('click', copyMachine);
    activateButton.addEventListener('click', activate);
    importButton.addEventListener('click', importLicense);
    activateTextButton.addEventListener('click', activateFromText);
    testButton.addEventListener('click', testServer);
    openButton.addEventListener('click', openApp);
    refreshButton.addEventListener('click', () => refreshStatus());
    keyInput.addEventListener('input', () => {
      keyInput.value = formatKeyInput(keyInput.value);
    });
    serverInput.addEventListener('input', () => {
      setServerState('', 'Pulsa «Probar conexión» para verificar la dirección.');
    });
    for (const element of [keyInput, serverInput]) {
      element.addEventListener('keydown', (event) => {
        if (event.key === 'Enter') {
          event.preventDefault();
          if (element === keyInput) activate();
          else testServer();
        }
      });
    }
    textArea.addEventListener('keydown', (event) => {
      if ((event.ctrlKey || event.metaKey) && event.key === 'Enter') {
        event.preventDefault();
        activateFromText();
      }
    });

    try {
      const info = await action('license:info');
      machineCode = info.machineCode || '';
      machineCodeEl.textContent = machineCode || 'No disponible';
      if (info.serverUrl) serverInput.value = info.serverUrl;
      if (!machineCode) {
        machineHintEl.textContent = info.machineError || 'No se pudo identificar este equipo.';
        machineHintEl.classList.add('is-error');
        copyButton.disabled = true;
        activateButton.disabled = true;
        importButton.disabled = true;
        activateTextButton.disabled = true;
        showError(info.machineError || 'No se pudo identificar este equipo.');
        return;
      }
      if (info.licenseKey) keyInput.value = normalizeKey(info.licenseKey);
      if (info.active && info.licensed) {
        showSuccess(info);
        const checked = info.lastCheckedAt ? Date.parse(info.lastCheckedAt) : 0;
        if (!checked || Date.now() - checked > 15 * 60 * 1000) {
          setTimeout(() => refreshStatus({ silent: true }), 1800);
        }
        return;
      }
      if (info.licenseId) {
        showActivation(info, info.statusMessage || 'La licencia guardada ya no es válida.');
        return;
      }
      if (info.error) showError(info.error);
      keyInput.focus();
    } catch (error) {
      machineCodeEl.textContent = 'No disponible';
      showError(error.message);
      activateButton.disabled = true;
      importButton.disabled = true;
      activateTextButton.disabled = true;
      testButton.disabled = true;
      copyButton.disabled = true;
    }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
