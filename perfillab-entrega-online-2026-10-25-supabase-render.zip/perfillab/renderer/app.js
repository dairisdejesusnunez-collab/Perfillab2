'use strict';

(() => {
  const bridge = window.perfillab;
  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => Array.from(root.querySelectorAll(selector));

  const PALETTE = ['#5b6cff', '#8b5cf6', '#0ea5e9', '#14b8a6', '#f59e0b', '#ef4444', '#ec4899', '#22c55e'];

  const VIEW_META = {
    dashboard: {
      title: 'Panel',
      subtitle: 'Resumen de tu entorno local',
    },
    profiles: {
      title: 'Perfiles',
      subtitle: 'Cada identidad con su propia carpeta de navegador',
    },
    apps: {
      title: 'Aplicaciones',
      subtitle: 'Abre programas de Windows desde tus perfiles',
    },
    workspaces: {
      title: 'Espacios',
      subtitle: 'Agrupa tus perfiles por proyecto o cliente',
    },
    proxies: {
      title: 'Proxies',
      subtitle: 'Conexiones reutilizables para tus perfiles',
    },
    activity: {
      title: 'Actividad',
      subtitle: 'Historial local de lo que ocurre en la app',
    },
    api: {
      title: 'API local',
      subtitle: 'Automatiza PerfilLab sin salir de tu equipo',
    },
    settings: {
      title: 'Ajustes',
      subtitle: 'Apariencia, navegadores y almacenamiento',
    },
  };

  const ICONS = {
    plus: '<path d="M12 5v14M5 12h14"></path>',
    play: '<path d="M8 5.5v13l10-6.5-10-6.5Z"></path>',
    stop: '<rect x="7" y="7" width="10" height="10" rx="2"></rect>',
    edit: '<path d="M4 20h4l10.5-10.5a2.12 2.12 0 0 0-3-3L5 17v3Z"></path><path d="m13.5 6.5 3 3"></path>',
    copy: '<rect x="9" y="9" width="11" height="11" rx="2"></rect><path d="M5 15V5a2 2 0 0 1 2-2h8"></path>',
    trash: '<path d="M4 7h16M9 7V5h6v2M7 7l1 12a2 2 0 0 0 2 2h4a2 2 0 0 0 2-2l1-12M10 11v6M14 11v6"></path>',
    folder: '<path d="M3.5 7.5a2 2 0 0 1 2-2h3.7l2 2.5h7.3a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2h-13a2 2 0 0 1-2-2v-10Z"></path>',
    dots: '<circle cx="5" cy="12" r="1.1"></circle><circle cx="12" cy="12" r="1.1"></circle><circle cx="19" cy="12" r="1.1"></circle>',
    search: '<circle cx="11" cy="11" r="6.5"></circle><path d="m16 16 4 4"></path>',
    x: '<path d="M6 6l12 12M18 6 6 18"></path>',
    check: '<path d="m5 12.5 4.5 4.5L19 7.5"></path>',
    alert: '<path d="M12 3.5 22 20H2L12 3.5Z"></path><path d="M12 9v5M12 17.2v.1"></path>',
    info: '<circle cx="12" cy="12" r="8.5"></circle><path d="M12 11v5M12 7.8v.1"></path>',
    lock: '<rect x="4.5" y="10" width="15" height="10.5" rx="2"></rect><path d="M8 10V7.5a4 4 0 0 1 8 0V10"></path>',
    globe: '<circle cx="12" cy="12" r="8.5"></circle><path d="M3.8 9.5h16.4M3.8 14.5h16.4"></path><path d="M12 3.5c2.4 2.3 3.6 5.2 3.6 8.5s-1.2 6.2-3.6 8.5c-2.4-2.3-3.6-5.2-3.6-8.5s1.2-6.2 3.6-8.5Z"></path>',
    monitor: '<rect x="3" y="4.5" width="18" height="12" rx="2"></rect><path d="M9 20h6M12 16.5V20"></path>',
    clock: '<circle cx="12" cy="12" r="8.5"></circle><path d="M12 7.5V12l3 2"></path>',
    link: '<path d="M10 13.5a4 4 0 0 0 5.7.2l2.6-2.6a4 4 0 0 0-5.6-5.6l-1.5 1.4"></path><path d="M14 10.5a4 4 0 0 0-5.7-.2l-2.6 2.6a4 4 0 0 0 5.6 5.6l1.5-1.4"></path>',
    key: '<circle cx="8" cy="12" r="4"></circle><path d="M12 12h8M17 12v3M20 12v2"></path>',
    refresh: '<path d="M20 11a8 8 0 1 0-2 5.5"></path><path d="M20 5v6h-6"></path>',
    upload: '<path d="M12 16V4M7.5 8.5 12 4l4.5 4.5"></path><path d="M4 16v3a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-3"></path>',
    download: '<path d="M12 4v12M7.5 11.5 12 16l4.5-4.5"></path><path d="M4 17v2a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-2"></path>',
    terminal: '<rect x="3" y="4.5" width="18" height="15" rx="3"></rect><path d="m7.5 9 3 3-3 3M13 15h4"></path>',
    shield: '<path d="M12 3.5 19.5 6v6c0 4.4-3.2 7.5-7.5 9-4.3-1.5-7.5-4.6-7.5-9V6L12 3.5Z"></path><path d="m9 12 2 2 4-4"></path>',
    layers: '<path d="M12 3.5 21 8l-9 4.5L3 8l9-4.5Z"></path><path d="m3 12 9 4.5 9-4.5"></path><path d="m3 16 9 4.5 9-4.5"></path>',
    sparkle: '<path d="m12 3 1.7 5.3L19 10l-5.3 1.7L12 17l-1.7-5.3L5 10l5.3-1.7L12 3Z"></path>',
    server: '<rect x="3" y="4" width="18" height="6.5" rx="2"></rect><rect x="3" y="13.5" width="18" height="6.5" rx="2"></rect><path d="M7 7.2h.1M7 16.7h.1"></path>',
    eye: '<path d="M2.5 12S6 5.5 12 5.5 21.5 12 21.5 12 18 18.5 12 18.5 2.5 12 2.5 12Z"></path><circle cx="12" cy="12" r="3"></circle>',
    eyeoff: '<path d="M4 4l16 16"></path><path d="M9.5 5.9A9.6 9.6 0 0 1 12 5.5c6 0 9.5 6.5 9.5 6.5a17 17 0 0 1-3.2 4.1M6.2 8.2A16.7 16.7 0 0 0 2.5 12S6 18.5 12 18.5c1 0 1.9-.2 2.8-.5"></path><path d="M10 10a3 3 0 0 0 4 4"></path>',
    star: '<path d="m12 3.8 2.5 5.1 5.6.8-4.1 4 1 5.6-5-2.7-5 2.7 1-5.6-4.1-4 5.6-.8L12 3.8Z"></path>',
    appgrid: '<rect x="3.5" y="3.5" width="7" height="7" rx="2"></rect><rect x="13.5" y="3.5" width="7" height="7" rx="2"></rect><rect x="3.5" y="13.5" width="7" height="7" rx="2"></rect><rect x="13.5" y="13.5" width="7" height="7" rx="2"></rect>',
    tag: '<path d="M3.5 12.2V4.5a1 1 0 0 1 1-1h7.7a2 2 0 0 1 1.4.6l7 7a2 2 0 0 1 0 2.8l-6.8 6.8a2 2 0 0 1-2.8 0l-7-7a2 2 0 0 1-.5-1.5Z"></path><circle cx="8" cy="8" r="1.2"></circle>',
    windows: '<path d="M4 5.5 11 4v7H4V5.5ZM13 3.7 20.5 2.5V11H13V3.7ZM4 13h7v7L4 18.5V13ZM13 13h7.5v8.5L13 20.3V13Z"></path>',
    external: '<path d="M14 4h6v6M20 4l-8.5 8.5"></path><path d="M18 13v5a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h5"></path>',
  };

  function icon(name, className = '') {
    return `<svg${className ? ` class="${className}"` : ''} viewBox="0 0 24 24" aria-hidden="true">${ICONS[name] || ''}</svg>`;
  }

  const app = {
    state: null,
    view: 'dashboard',
    busy: new Set(),
    query: '',
    appQuery: '',
    workspaceFilter: 'all',
    statusFilter: 'all',
    sort: 'recent',
    discoveredApps: null,
    discoveryBusy: false,
    discoveryError: '',
    discoveryForce: false,
    activityFilter: 'all',
    testResults: new Map(),
    selection: new Set(),
    batchBusy: false,
    proxyBulkBusy: false,
    apiRevealed: false,
    dataDir: '',
    modalStack: [],
    renderQueued: false,
    initialized: false,
  };

  let popoverEl = null;

  // ===== Utilities =====

  function esc(value) {
    return String(value === undefined || value === null ? '' : value)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  }

  function safeColor(value) {
    return /^#[0-9a-fA-F]{6}$/.test(value || '') ? value : '#6b7cff';
  }

  function initials(name) {
    const words = String(name || '').trim().split(/\s+/).filter(Boolean);
    if (!words.length) return 'PL';
    return words.slice(0, 2).map((word) => word.charAt(0).toUpperCase()).join('');
  }

  const RELATIVE = typeof Intl.RelativeTimeFormat === 'function'
    ? new Intl.RelativeTimeFormat('es', { numeric: 'auto' })
    : null;

  function relativeTime(iso) {
    if (!iso) return 'nunca';
    const ts = Date.parse(iso);
    if (!Number.isFinite(ts)) return '—';
    const diff = ts - Date.now();
    const abs = Math.abs(diff);
    const units = [
      ['year', 31536000000],
      ['month', 2592000000],
      ['week', 604800000],
      ['day', 86400000],
      ['hour', 3600000],
      ['minute', 60000],
    ];
    for (const [unit, ms] of units) {
      if (abs >= ms) {
        const amount = Math.round(diff / ms);
        return RELATIVE ? RELATIVE.format(amount, unit) : new Date(ts).toLocaleString('es');
      }
    }
    return 'hace un momento';
  }

  function exactTime(iso) {
    if (!iso) return '—';
    const ts = Date.parse(iso);
    if (!Number.isFinite(ts)) return '—';
    return new Intl.DateTimeFormat('es', { dateStyle: 'medium', timeStyle: 'short' }).format(ts);
  }

  function elapsedSince(iso) {
    const ts = Date.parse(iso);
    if (!Number.isFinite(ts)) return '';
    const minutes = Math.max(0, Math.floor((Date.now() - ts) / 60000));
    if (minutes < 1) return 'menos de 1 min';
    if (minutes < 60) return `${minutes} min`;
    const hours = Math.floor(minutes / 60);
    const rest = minutes % 60;
    if (hours < 24) return rest ? `${hours} h ${rest} min` : `${hours} h`;
    const days = Math.floor(hours / 24);
    return `${days} d ${hours % 24} h`;
  }

  function plural(count, singular, pluralForm) {
    return `${count} ${count === 1 ? singular : pluralForm}`;
  }

  function hostOf(url) {
    try {
      return new URL(url).hostname || url;
    } catch {
      return url;
    }
  }

  function fileName(filePath) {
    return String(filePath || '').split(/[\\/]/).pop() || filePath;
  }

  function maskToken(token) {
    if (!token) return '';
    return `${'•'.repeat(30)}${token.slice(-4)}`;
  }

  function systemTheme() {
    return window.matchMedia('(prefers-color-scheme: light)').matches ? 'light' : 'dark';
  }

  function resolveTheme(setting) {
    return setting === 'light' || setting === 'dark' ? setting : systemTheme();
  }

  function profileById(id) {
    return app.state.profiles.find((profile) => profile.id === id) || null;
  }

  function proxyById(id) {
    if (!id) return null;
    return app.state.proxies.find((proxy) => proxy.id === id) || null;
  }

  function workspaceById(id) {
    return app.state.workspaces.find((workspace) => workspace.id === id) || null;
  }

  function profileStatusById(id) {
    if (!id) return null;
    return profileStatuses().find((status) => status.id === id) || null;
  }

  function profileStatuses() {
    return app.state.profileStatuses || [];
  }

  function browserById() {
    return app.state.browsers[0] || null;
  }

  function runningFor(profileId) {
    return app.state.statuses.find((status) => status.profileId === profileId) || null;
  }

  function appById(id) {
    return app.state.apps.find((item) => item.id === id) || null;
  }

  function appStatusFor(appId) {
    return app.state.appStatuses.filter((status) => status.appId === appId);
  }

  function appProfileConfig(profileId, appId) {
    return app.state.appProfileConfigs.find((item) => item.profileId === profileId && item.appId === appId) || null;
  }

  function browserLabel() {
    return 'PerfilLab Browser';
  }

  // ===== Bridge helpers =====

  async function callAction(name, payload) {
    if (!bridge) throw new Error('El puente de la aplicación no está disponible.');
    const result = await bridge.action(name, payload);
    if (!result || !result.ok) {
      const message = result && result.error && result.error.message
        ? result.error.message
        : 'No se pudo completar la acción.';
      throw new Error(message);
    }
    return result.data;
  }

  function captureFocus() {
    const active = document.activeElement;
    if (!active || !active.id) return null;
    const content = document.getElementById('content');
    if (!content || !content.contains(active)) return null;
    const state = { id: active.id };
    if (typeof active.selectionStart === 'number' && typeof active.selectionEnd === 'number') {
      state.start = active.selectionStart;
      state.end = active.selectionEnd;
    }
    return state;
  }

  function restoreFocus(saved) {
    if (!saved) return;
    const element = document.getElementById(saved.id);
    if (!element) return;
    element.focus({ preventScroll: true });
    if (typeof saved.start === 'number' && typeof element.setSelectionRange === 'function') {
      try {
        element.setSelectionRange(saved.start, saved.end);
      } catch {
        // some input types do not support selection
      }
    }
  }

  // ===== Toasts =====

  function toast(message, level = 'info') {
    const root = document.getElementById('toast-root');
    if (!root) return;
    const icons = { success: 'check', error: 'alert', warn: 'alert', info: 'info' };
    const element = document.createElement('div');
    element.className = `toast is-${level}`;
    element.innerHTML = `
      <div class="toast-icon">${icon(icons[level] || 'info')}</div>
      <div class="toast-copy"><p>${esc(message)}</p></div>
      <button class="toast-close" type="button" aria-label="Cerrar aviso">${icon('x')}</button>
    `;
    root.appendChild(element);
    while (root.children.length > 4) root.firstElementChild.remove();
    const remove = () => {
      if (element.classList.contains('is-leaving') || !element.isConnected) return;
      element.classList.add('is-leaving');
      setTimeout(() => element.remove(), 190);
    };
    element.querySelector('.toast-close').addEventListener('click', remove);
    setTimeout(remove, level === 'error' ? 6500 : 4200);
  }

  // ===== Modals =====

  let modalSequence = 0;

  function openModal(options) {
    const {
      title,
      subtitle = '',
      body = '',
      footer = '',
      size = '',
      onMount = null,
    } = options;
    const titleId = `modal-title-${++modalSequence}`;
    const backdrop = document.createElement('div');
    backdrop.className = 'modal-backdrop';
    backdrop.innerHTML = `
      <div class="modal ${size}" role="dialog" aria-modal="true" aria-labelledby="${titleId}">
        <div class="modal-head">
          <div class="modal-head-copy">
            <h2 id="${titleId}">${esc(title)}</h2>
            ${subtitle ? `<p>${esc(subtitle)}</p>` : ''}
          </div>
          <button class="modal-close" type="button" data-close-modal aria-label="Cerrar">${icon('x')}</button>
        </div>
        <div class="modal-body">${body}</div>
        ${footer ? `<div class="modal-foot">${footer}</div>` : ''}
      </div>
    `;
    const entry = {
      backdrop,
      onClose: options.onClose || null,
      close: () => closeModal(entry),
      closed: false,
    };
    document.getElementById('modal-root').appendChild(backdrop);
    app.modalStack.push(entry);
    backdrop.addEventListener('mousedown', (event) => {
      if (event.target === backdrop) entry.close();
    });
    updateModalStack();
    if (typeof onMount === 'function') onMount(backdrop, entry);
    const autofocus = backdrop.querySelector('[data-autofocus]');
    if (autofocus) {
      setTimeout(() => {
        autofocus.focus();
        if (typeof autofocus.select === 'function' && autofocus.type !== 'checkbox') autofocus.select();
      }, 30);
    }
    return entry;
  }

  function closeModal(entry) {
    if (!entry || entry.closed) return;
    entry.closed = true;
    const index = app.modalStack.indexOf(entry);
    if (index >= 0) app.modalStack.splice(index, 1);
    if (typeof entry.onClose === 'function') entry.onClose();
    entry.backdrop.remove();
    updateModalStack();
  }

  function updateModalStack() {
    app.modalStack.forEach((entry, index) => {
      entry.backdrop.classList.toggle('is-top', index === app.modalStack.length - 1);
    });
  }

  function closeTopModal() {
    const entry = app.modalStack[app.modalStack.length - 1];
    if (entry) closeModal(entry);
  }

  function closeAllModals() {
    [...app.modalStack].forEach((entry) => closeModal(entry));
  }

  function closeModalFor(element) {
    const entry = app.modalStack.find((item) => item.backdrop.contains(element));
    if (entry) closeModal(entry);
  }

  function trapFocus(event) {
    const top = app.modalStack[app.modalStack.length - 1];
    if (!top) return;
    const nodes = $$('button:not([disabled]), input:not([disabled]):not([type="hidden"]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])', top.backdrop)
      .filter((element) => element.offsetParent !== null);
    if (!nodes.length) return;
    const first = nodes[0];
    const last = nodes[nodes.length - 1];
    if (event.shiftKey && document.activeElement === first) {
      event.preventDefault();
      last.focus();
    } else if (!event.shiftKey && document.activeElement === last) {
      event.preventDefault();
      first.focus();
    }
  }

  function openConfirmModal(options) {
    const {
      title,
      subtitle = '',
      message,
      extra = '',
      confirmLabel = 'Confirmar',
      danger = true,
      onConfirm,
    } = options;
    const entry = openModal({
      title,
      subtitle,
      size: 'is-narrow',
      body: `
        <p class="confirm-copy">${message}</p>
        ${extra}
        <div class="form-error" id="confirm-error"></div>
      `,
      footer: `
        <button class="btn btn-ghost" type="button" data-close-modal>Cancelar</button>
        <button class="btn ${danger ? 'btn-danger' : 'btn-primary'}" type="button" id="confirm-button">${esc(confirmLabel)}</button>
      `,
      onMount(root) {
        const button = root.querySelector('#confirm-button');
        const errorBox = root.querySelector('#confirm-error');
        button.addEventListener('click', async () => {
          if (button.dataset.busy === '1') return;
          button.dataset.busy = '1';
          const original = button.innerHTML;
          button.disabled = true;
          button.innerHTML = '<span class="spinner-xs"></span> Procesando…';
          try {
            await onConfirm();
            entry.close();
          } catch (error) {
            errorBox.textContent = error.message;
            errorBox.classList.add('is-visible');
            button.disabled = false;
            button.innerHTML = original;
            button.dataset.busy = '';
          }
        });
      },
    });
    return entry;
  }

  // ===== State / chrome =====

  function applyState(state) {
    if (!state || typeof state !== 'object') return;
    app.state = state;
    const validIds = new Set(state.profiles.map((profile) => profile.id));
    for (const id of [...app.selection]) {
      if (!validIds.has(id)) app.selection.delete(id);
    }
    const statusIds = new Set((state.profileStatuses || []).map((status) => status.id));
    if (app.statusFilter !== 'all' && app.statusFilter !== 'none' && !statusIds.has(app.statusFilter)) {
      app.statusFilter = 'all';
    }
    applyTheme();
    updateChrome();
    if (!app.initialized) {
      app.initialized = true;
      hideSplash();
    }
    scheduleRender();
  }

  function applyTheme() {
    if (!app.state) return;
    document.documentElement.dataset.theme = resolveTheme(app.state.settings.theme);
    const toggle = document.getElementById('theme-toggle');
    if (toggle) {
      const next = resolveTheme(app.state.settings.theme) === 'dark' ? 'claro' : 'oscuro';
      toggle.title = `Cambiar a tema ${next}`;
      toggle.setAttribute('aria-label', `Cambiar a tema ${next}`);
    }
  }

  function apiPresentation(api) {
    if (api.running) {
      return {
        className: 'on',
        label: `API :${api.port}`,
        sidebarTitle: `API activa · :${api.port}`,
        sidebarSub: '127.0.0.1 · solo local',
        dotClass: 'is-on',
      };
    }
    if (api.error) {
      return {
        className: 'error',
        label: 'API error',
        sidebarTitle: 'API con error',
        sidebarSub: api.error,
        dotClass: 'is-error',
      };
    }
    if (api.enabled) {
      return {
        className: 'off',
        label: 'API iniciando',
        sidebarTitle: 'API iniciando',
        sidebarSub: `Puerto ${api.port}`,
        dotClass: '',
      };
    }
    return {
      className: 'off',
      label: 'API off',
      sidebarTitle: 'API detenida',
      sidebarSub: 'Actívala en API local',
      dotClass: '',
    };
  }

  function updateChrome() {
    if (!app.state) return;
    const state = app.state;
    const meta = VIEW_META[app.view];
    const pageTitle = document.getElementById('page-title');
    const pageSubtitle = document.getElementById('page-subtitle');
    if (pageTitle) pageTitle.textContent = meta.title;
    if (pageSubtitle) pageSubtitle.textContent = meta.subtitle;
    document.title = `PerfilLab · ${meta.title}`;

    const version = document.getElementById('app-version');
    if (version) version.textContent = state.app.version;

    const profileCount = document.getElementById('nav-profile-count');
    if (profileCount) profileCount.textContent = String(state.profiles.length);
    const appCount = document.getElementById('nav-app-count');
    if (appCount) {
      appCount.textContent = String(state.apps.length);
      appCount.title = `${state.apps.length} aplicaciones · ${state.appStatuses.length} en ejecución`;
    }
    const proxyCount = document.getElementById('nav-proxy-count');
    if (proxyCount) proxyCount.textContent = String(state.proxies.length);
    const runningCount = state.statuses.length;
    if (profileCount) profileCount.title = `${state.profiles.length} perfiles · ${runningCount} en ejecución`;

    $$('.nav-item').forEach((button) => {
      button.classList.toggle('is-active', button.dataset.nav === app.view);
    });

    const api = state.settings.api;
    const presentation = apiPresentation(api);
    const topbarApi = document.getElementById('topbar-api');
    if (topbarApi) {
      const dot = topbarApi.querySelector('.status-dot');
      if (dot) {
        dot.classList.toggle('is-on', Boolean(api.running));
        dot.classList.toggle('is-error', Boolean(api.error) && !api.running);
      }
      const label = document.getElementById('topbar-api-label');
      if (label) label.textContent = presentation.label;
      topbarApi.title = api.running
        ? `API escuchando en http://127.0.0.1:${api.port}/v1`
        : api.error || 'API local desactivada';
    }
    const navApiDot = document.getElementById('nav-api-dot');
    if (navApiDot) {
      navApiDot.classList.toggle('is-on', Boolean(api.running));
      navApiDot.title = api.running ? `API activa en el puerto ${api.port}` : 'API detenida';
    }
    const sidebarTitle = document.getElementById('sidebar-api-title');
    if (sidebarTitle) sidebarTitle.textContent = presentation.sidebarTitle;
    const sidebarSub = document.getElementById('sidebar-api-sub');
    if (sidebarSub) sidebarSub.textContent = presentation.sidebarSub;
    const sidebarButton = document.getElementById('sidebar-api');
    if (sidebarButton) {
      const dot = sidebarButton.querySelector('.status-dot');
      if (dot) {
        dot.classList.toggle('is-on', Boolean(api.running));
        dot.classList.toggle('is-error', Boolean(api.error) && !api.running);
      }
    }
  }

  function hideSplash() {
    const splash = document.getElementById('splash');
    if (!splash) return;
    setTimeout(() => splash.classList.add('is-hidden'), 250);
  }

  function showFatal(message) {
    const splash = document.getElementById('splash');
    if (!splash) return;
    const inner = splash.querySelector('.splash-inner');
    if (!inner) return;
    inner.innerHTML = `
      <div class="empty-icon">${icon('alert')}</div>
      <div class="splash-text">
        <strong>No se pudo iniciar la interfaz</strong>
        <span>${esc(message)}</span>
      </div>
    `;
  }

  // ===== Rendering helpers =====

  function scheduleRender() {
    if (app.renderQueued) return;
    app.renderQueued = true;
    requestAnimationFrame(() => {
      app.renderQueued = false;
      renderView();
    });
  }

  function setView(view) {
    if (!VIEW_META[view]) return;
    app.view = view;
    closePopover();
    const content = document.getElementById('content');
    if (content) content.scrollTop = 0;
    updateChrome();
    renderView();
  }

  function renderView() {
    if (!app.state) return;
    const focus = captureFocus();
    closePopover();
    $$('.view').forEach((section) => {
      section.hidden = section.dataset.view !== app.view;
    });
    const target = document.getElementById(`view-${app.view}`);
    if (!target) return;
    const renderers = {
      dashboard: renderDashboard,
      profiles: renderProfiles,
      apps: renderApps,
      workspaces: renderWorkspaces,
      proxies: renderProxies,
      activity: renderActivity,
      api: renderApi,
      settings: renderSettings,
    };
    target.innerHTML = renderers[app.view]();
    restoreFocus(focus);
    updateClocks();
  }

  function updateClocks() {
    $$('.js-elapsed').forEach((element) => {
      element.textContent = elapsedSince(element.dataset.started);
    });
  }

  function statCard(iconName, value, label, tone = '') {
    return `
      <div class="stat-card">
        <div class="stat-icon ${tone}">${icon(iconName)}</div>
        <div class="stat-copy">
          <div class="stat-value">${value}</div>
          <div class="stat-label">${esc(label)}</div>
        </div>
      </div>
    `;
  }

  function emptyBlock(iconName, title, text, extra = '') {
    return `
      <div class="empty">
        <div class="empty-icon">${icon(iconName)}</div>
        <strong>${esc(title)}</strong>
        <p>${esc(text)}</p>
        ${extra}
      </div>
    `;
  }

  function activityDot(level) {
    return `<span class="activity-mini-dot is-${esc(level)}"></span>`;
  }

  // ===== Dashboard =====

  function renderDashboard() {
    const state = app.state;
    const api = state.settings.api;
    const builtin = state.browsers[0];
    const running = state.statuses
      .map((status) => ({ status, profile: profileById(status.profileId) }))
      .filter((item) => item.profile);
    const recent = [...state.profiles]
      .sort((a, b) => Date.parse(b.updatedAt || 0) - Date.parse(a.updatedAt || 0))
      .slice(0, 4);
    const activity = state.activity.slice(0, 5);
    const firstProfile = state.profiles[0];
    const apiInfo = apiPresentation(api);

    const heroTitle = state.profiles.length
      ? 'Tus perfiles, <span>separados y bajo control</span>.'
      : 'Tu primer <span>perfil aislado</span>, en un minuto.';
    const heroText = state.profiles.length
      ? 'Abre cada perfil con su propia carpeta de navegador y su proxy. Las sesiones no se mezclan y todo se queda en este equipo.'
      : 'PerfilLab Browser viene incluido: abre cada perfil con su propia carpeta de datos y, si quieres, su propio proxy. Así organizas cuentas y proyectos sin compartir sesiones.';

    const heroActions = state.profiles.length
      ? `
        <button class="btn btn-primary" type="button" data-action="new-profile">${icon('plus')} Nuevo perfil</button>
        <button class="btn btn-ghost" type="button" data-go-view="profiles">${icon('layers')} Ver perfiles</button>
        <button class="btn btn-ghost" type="button" data-action="export-profiles">${icon('download')} Exportar</button>
      `
      : `
        <button class="btn btn-primary" type="button" data-action="new-profile">${icon('plus')} Crear mi primer perfil</button>
        <button class="btn btn-ghost" type="button" data-action="import-profiles">${icon('upload')} Importar JSON</button>
      `;

    const heroSide = `
      <div class="hero-side-item">
        <div class="hero-side-icon">${icon('monitor')}</div>
        <div>
          <strong>PerfilLab Browser</strong>
          <small>${builtin ? `Chromium ${esc(builtin.engineVersion || '—')} · integrado en la aplicación` : 'Navegador integrado no disponible'}</small>
        </div>
      </div>
      <div class="hero-side-item">
        <div class="hero-side-icon">${icon('server')}</div>
        <div>
          <strong>${api.running ? 'API local activa' : 'API local inactiva'}</strong>
          <small>${api.running ? `127.0.0.1:${api.port} · solo tu equipo` : 'Actívala si usas scripts propios'}</small>
        </div>
      </div>
      <div class="hero-side-item">
        <div class="hero-side-icon">${icon('shield')}</div>
        <div>
          <strong>Datos locales</strong>
          <small>${plural(state.profiles.length, 'perfil guardado', 'perfiles guardados')} en este equipo</small>
        </div>
      </div>
    `;

    const runningBody = running.length
      ? running.map(({ status, profile }) => `
          <div class="running-row">
            <div class="pulse"></div>
            <div class="avatar" style="--avatar:${safeColor(profile.color)}">${esc(initials(profile.name))}</div>
            <div class="running-copy">
              <strong>${esc(profile.name)}</strong>
              <small>${esc(status.browserName)} · ${esc(status.proxyMode === 'relay' ? 'proxy con autenticación' : status.proxyMode === 'direct' ? 'proxy directo' : 'sin proxy')} · <span class="js-elapsed" data-started="${esc(status.startedAt)}">${esc(elapsedSince(status.startedAt))}</span></small>
            </div>
            <button class="btn btn-ghost btn-sm" type="button" data-action="profile-stop" data-id="${esc(profile.id)}">${icon('stop')} Detener</button>
            <button class="btn-icon-sm" type="button" data-action="profile-start" data-id="${esc(profile.id)}" title="Abrir otra ventana" aria-label="Abrir otra ventana">${icon('play')}</button>
          </div>
        `).join('')
      : emptyBlock(
        'play',
        'Nada en ejecución',
        'Cuando inicies un perfil, verás aquí el navegador y el tiempo de sesión.',
        state.profiles.length ? '<button class="btn btn-ghost btn-sm" type="button" data-go-view="profiles">Elegir un perfil</button>' : '',
      );

    const recentBody = recent.length
      ? recent.map((profile) => {
        const workspace = workspaceById(profile.workspaceId);
        const isRunning = Boolean(runningFor(profile.id));
        return `
          <div class="recent-row">
            <div class="avatar" style="--avatar:${safeColor(profile.color)}">${esc(initials(profile.name))}</div>
            <div class="recent-main">
              <strong>${esc(profile.name)}</strong>
              <small>${esc(workspace ? workspace.name : 'Sin espacio')} · ${esc(browserLabel(profile))} · ${esc(relativeTime(profile.updatedAt))}</small>
            </div>
            ${isRunning
              ? '<span class="chip is-success"><span class="pulse"></span>En ejecución</span>'
              : `<button class="btn btn-ghost btn-sm" type="button" data-action="profile-start" data-id="${esc(profile.id)}">${icon('play')} Abrir</button>`}
          </div>
        `;
      }).join('')
      : emptyBlock('layers', 'Sin perfiles todavía', 'Crea tu primer perfil para verlo aquí.');

    const activityBody = activity.length
      ? activity.map((entry) => `
          <div class="activity-mini">
            ${activityDot(entry.level)}
            <div>
              ${esc(entry.message)}
              <time>${esc(relativeTime(entry.ts))}</time>
            </div>
          </div>
        `).join('')
      : emptyBlock('info', 'Sin actividad', 'Los inicios, cambios y errores aparecerán en este lugar.');

    const apiBody = `
      <p class="settings-note">
        ${api.running
          ? `La API responde en <span class="mono">http://127.0.0.1:${api.port}/v1</span> y requiere el token que puedes copiar en su página.`
          : api.enabled
            ? 'La API está activada pero todavía no está escuchando. Revisa el puerto en su página.'
            : 'Activa la API si quieres abrir perfiles o consultar su estado desde tus propios scripts locales.'}
      </p>
      <div class="browser-chips">
        <span class="chip ${api.running ? 'is-success' : api.error ? 'is-danger' : ''}"><span class="status-dot ${apiInfo.dotClass}"></span>${esc(api.running ? 'Escuchando' : api.error ? 'Con error' : 'Detenida')}</span>
        <span class="chip">Solo 127.0.0.1</span>
        <span class="chip">Token obligatorio</span>
      </div>
      <div class="panel-actions">
        <button class="btn btn-ghost btn-sm" type="button" data-go-view="api">${icon('terminal')} Configurar API</button>
      </div>
    `;

    const onboarding = state.profiles.length ? '' : `
      <div class="onboarding">
        <div class="step-card">
          <div class="step-num">01</div>
          <strong>Navegador incluido</strong>
          <p>PerfilLab Browser ya viene incluido y es el único navegador. No necesitas instalar Chrome ni ningún otro programa.</p>
        </div>
        <div class="step-card">
          <div class="step-num">02</div>
          <strong>Crea un perfil</strong>
          <p>Elige espacio, proxy y estado. Cada perfil recibe una carpeta de datos independiente.</p>
        </div>
        <div class="step-card">
          <div class="step-num">03</div>
          <strong>Abre y organiza</strong>
          <p>Inicia el perfil cuando lo necesites. Puedes detenerlo, duplicarlo o exportar tu configuración.</p>
        </div>
      </div>
    `;

    return `
      <div class="hero">
        <div>
          <span class="hero-eyebrow">${icon('sparkle')} Entorno local</span>
          <h2>${heroTitle}</h2>
          <p>${esc(heroText)}</p>
          <div class="hero-actions">${heroActions}</div>
        </div>
        <div class="hero-side">${heroSide}</div>
      </div>

      <div class="stat-grid">
        ${statCard('layers', state.profiles.length, 'Perfiles', '')}
        ${statCard('play', running.length, 'En ejecución', 'is-success')}
        ${statCard('globe', state.proxies.length, 'Proxies', 'is-warn')}
        ${statCard('folder', state.workspaces.length, 'Espacios', 'is-pink')}
      </div>

      ${onboarding}

      <div class="dash-grid">
        <div class="dash-side">
          <div class="panel">
            <div class="panel-head">
              <div>
                <h2>En ejecución</h2>
                <p>${running.length ? plural(running.length, 'sesión activa', 'sesiones activas') : 'Sesiones abiertas desde PerfilLab'}</p>
              </div>
              ${state.profiles.length ? '<button class="link-btn" type="button" data-go-view="profiles">Ver todos</button>' : ''}
            </div>
            <div class="panel-body">${runningBody}</div>
          </div>
          <div class="panel">
            <div class="panel-head">
              <div>
                <h2>Perfiles recientes</h2>
                <p>Últimos perfiles que actualizaste</p>
              </div>
              ${firstProfile ? '<button class="link-btn" type="button" data-action="new-profile">Crear otro</button>' : ''}
            </div>
            <div class="panel-body">${recentBody}</div>
          </div>
        </div>
        <div class="dash-side">
          <div class="panel">
            <div class="panel-head">
              <div>
                <h2>Actividad reciente</h2>
                <p>Registro local de la aplicación</p>
              </div>
              ${state.activity.length ? '<button class="link-btn" type="button" data-go-view="activity">Historial</button>' : ''}
            </div>
            <div class="panel-body">${activityBody}</div>
          </div>
          <div class="panel">
            <div class="panel-head">
              <div>
                <h2>API local</h2>
                <p>Automatización desde tus scripts</p>
              </div>
              <span class="chip ${api.running ? 'is-success' : api.error ? 'is-danger' : ''}"><span class="status-dot ${apiInfo.dotClass}"></span>${esc(api.running ? 'Activa' : api.error ? 'Error' : 'Inactiva')}</span>
            </div>
            <div class="panel-body">${apiBody}</div>
          </div>
        </div>
      </div>
    `;
  }

  // ===== Profiles =====

  function filteredProfiles() {
    const state = app.state;
    const query = app.query.trim().toLowerCase();
    let list = state.profiles.filter((profile) => {
      if (app.workspaceFilter !== 'all' && profile.workspaceId !== app.workspaceFilter) return false;
      if (app.statusFilter !== 'all') {
        if (app.statusFilter === 'none' ? Boolean(profile.statusId) : profile.statusId !== app.statusFilter) return false;
      }
      if (!query) return true;
      const workspace = workspaceById(profile.workspaceId);
      const proxy = proxyById(profile.proxyId);
      const status = profileStatusById(profile.statusId);
      const haystack = [
        profile.name,
        profile.notes,
        workspace ? workspace.name : '',
        status ? status.name : '',
        proxy ? proxy.name : '',
        proxy ? proxy.host : '',
        ...(profile.tags || []),
      ].join(' ').toLowerCase();
      return haystack.includes(query);
    });
    if (app.sort === 'name') list = list.sort((a, b) => a.name.localeCompare(b.name, 'es'));
    else if (app.sort === 'created') list = list.sort((a, b) => Date.parse(b.createdAt || 0) - Date.parse(a.createdAt || 0));
    else list = list.sort((a, b) => Date.parse(b.updatedAt || 0) - Date.parse(a.updatedAt || 0));
    return list;
  }

  function profileCard(profile) {
    const running = runningFor(profile.id);
    const workspace = workspaceById(profile.workspaceId);
    const proxy = proxyById(profile.proxyId);
    const status = profileStatusById(profile.statusId);
    const browser = browserById(profile.browserId);
    const selected = app.selection.has(profile.id);
    const startBusy = app.busy.has(`start:${profile.id}`);
    const stopBusy = app.busy.has(`stop:${profile.id}`);
    const tags = (profile.tags || []).slice(0, 4);
    const extraTags = (profile.tags || []).length - tags.length;
    const urls = profile.startUrls || [];
    const urlLabel = urls.length
      ? `${hostOf(urls[0])}${urls.length > 1 ? ` +${urls.length - 1}` : ''}`
      : 'Sin URLs de inicio';
    const last = profile.lastStartedAt
      ? `Abierto ${relativeTime(profile.lastStartedAt)}`
      : 'Aún sin abrir';

    return `
      <article class="profile-card ${running ? 'is-running' : ''} ${selected ? 'is-selected' : ''}" style="--avatar:${safeColor(profile.color)}">
        <div class="pc-head">
          <label class="profile-select" title="Seleccionar ${esc(profile.name)}">
            <input type="checkbox" data-select-profile="${esc(profile.id)}" ${selected ? 'checked' : ''} aria-label="Seleccionar ${esc(profile.name)}">
          </label>
          <div class="pc-avatar">${esc(initials(profile.name))}</div>
          <div class="pc-title">
            <strong title="${esc(profile.name)}">${esc(profile.name)}</strong>
            <small>
              <i class="ws-dot" style="--ws-color:${safeColor(workspace ? workspace.color : '#5b6cff')}"></i>
              <span>${esc(workspace ? workspace.name : 'Sin espacio')}</span>
              ${status ? `<span class="status-pill" style="--status-color:${safeColor(status.color)}" title="Estado: ${esc(status.name)}"><i></i>${esc(status.name)}</span>` : ''}
            </small>
          </div>
          <button class="btn-icon-sm pc-menu" type="button" data-menu-profile="${esc(profile.id)}" title="Más acciones" aria-label="Más acciones para ${esc(profile.name)}">${icon('dots')}</button>
        </div>
        ${running ? `<span class="pc-status"><span class="pulse"></span> En ejecución · <span class="js-elapsed" data-started="${esc(running.startedAt)}">${esc(elapsedSince(running.startedAt))}</span></span>` : ''}
        <div class="pc-meta">
          <div class="pc-meta-row">
            ${icon('monitor')}
            <span>${esc(browser ? browser.name : 'Navegador no disponible')}</span>
            ${browser ? '' : '<span class="chip is-warn">Revisar</span>'}
          </div>
          <div class="pc-meta-row">
            ${icon('globe')}
            <span>${proxy ? esc(`${proxy.name} · ${proxy.protocol}://${proxy.host}:${proxy.port}`) : 'Sin proxy'}</span>
            ${proxy && proxy.hasPassword ? `<span title="Proxy con autenticación">${icon('lock')}</span>` : ''}
          </div>
          ${cloneAccountFor(profile.id) ? `<div class="pc-meta-row">
            ${icon('shield')}
            <span>Cuenta clon <span class="mono">${esc(cloneAccountFor(profile.id).username)}</span></span>
            <span class="chip is-success">Lista</span>
          </div>` : ''}
          <div class="pc-meta-row">
            ${icon('link')}
            <span>${esc(urlLabel)}</span>
          </div>
          <div class="pc-meta-row">
            ${icon('clock')}
            <span>${esc(last)}</span>
          </div>
        </div>
        ${tags.length ? `
          <div class="tag-row">
            ${tags.map((tag) => `<span class="tag">${esc(tag)}</span>`).join('')}
            ${extraTags > 0 ? `<span class="tag">+${extraTags}</span>` : ''}
          </div>
        ` : ''}
        <div class="pc-foot">
          <button class="btn btn-sm btn-start ${running ? 'is-running' : 'btn-soft'}" type="button"
            data-action="${running ? 'profile-stop' : 'profile-start'}" data-id="${esc(profile.id)}"
            ${startBusy || stopBusy ? 'disabled' : ''}>
            ${startBusy || stopBusy ? '<span class="spinner-xs"></span>' : icon(running ? 'stop' : 'play')}
            ${running ? 'Detener' : 'Iniciar'}
          </button>
          <button class="btn-icon-sm" type="button" data-action="profile-apps" data-id="${esc(profile.id)}" title="Abrir aplicación con este perfil" aria-label="Abrir aplicación con este perfil">${icon('appgrid')}</button>
          <button class="btn-icon-sm" type="button" data-action="profile-folder" data-id="${esc(profile.id)}" title="Abrir carpeta de datos" aria-label="Abrir carpeta de datos">${icon('folder')}</button>
          <button class="btn-icon-sm" type="button" data-action="profile-edit" data-id="${esc(profile.id)}" title="Editar perfil" aria-label="Editar perfil">${icon('edit')}</button>
        </div>
      </article>
    `;
  }

  function renderProfiles() {
    const state = app.state;
    const list = filteredProfiles();
    const total = state.profiles.length;
    const statuses = profileStatuses();
    const hasFilters = Boolean(app.query.trim()) || app.workspaceFilter !== 'all' || app.statusFilter !== 'all';

    const workspaceOptions = [
      '<option value="all">Todos los espacios</option>',
      ...state.workspaces.map((workspace) => `<option value="${esc(workspace.id)}" ${app.workspaceFilter === workspace.id ? 'selected' : ''}>${esc(workspace.name)}</option>`),
    ].join('');

    const statusOptions = statuses.length ? [
      '<option value="all">Todos los estados</option>',
      ...statuses.map((status) => `<option value="${esc(status.id)}" ${app.statusFilter === status.id ? 'selected' : ''}>${esc(status.name)}</option>`),
      `<option value="none" ${app.statusFilter === 'none' ? 'selected' : ''}>Sin estado</option>`,
    ].join('') : '';

    const toolbar = `
      <div class="toolbar">
        <div class="search-box ${app.query ? 'has-value' : ''}">
          ${icon('search')}
          <input id="profile-search" type="search" placeholder="Buscar perfiles…" value="${esc(app.query)}" autocomplete="off" spellcheck="false" aria-label="Buscar perfiles">
          <button class="search-clear" type="button" data-action="profile-search-clear" aria-label="Limpiar búsqueda">${icon('x')}</button>
        </div>
        <select class="select" id="filter-workspace" aria-label="Filtrar por espacio">${workspaceOptions}</select>
        ${statuses.length ? `<select class="select" id="filter-status" aria-label="Filtrar por estado">${statusOptions}</select>` : ''}
        <select class="select" id="sort-profiles" aria-label="Ordenar perfiles">
          <option value="recent" ${app.sort === 'recent' ? 'selected' : ''}>Actualizados</option>
          <option value="name" ${app.sort === 'name' ? 'selected' : ''}>Nombre A–Z</option>
          <option value="created" ${app.sort === 'created' ? 'selected' : ''}>Más nuevos</option>
        </select>
        <span class="toolbar-spacer"></span>
        <button class="btn btn-ghost" type="button" data-action="import-profiles">${icon('upload')} Importar</button>
        <button class="btn btn-ghost" type="button" data-action="export-profiles" ${total ? '' : 'disabled'}>${icon('download')} Exportar</button>
        <button class="btn btn-primary" type="button" data-action="new-profile">${icon('plus')} Nuevo perfil</button>
      </div>
    `;

    if (!total) {
      return `
        ${toolbar}
        <div class="panel">
          ${emptyBlock(
            'layers',
            'Todavía no hay perfiles',
            'Crea un perfil para abrir un navegador con su propia carpeta de datos y, si quieres, su propio proxy.',
            `<div class="hero-actions" style="justify-content:center">
              <button class="btn btn-primary" type="button" data-action="new-profile">${icon('plus')} Crear perfil</button>
              <button class="btn btn-ghost" type="button" data-action="import-profiles">${icon('upload')} Importar</button>
            </div>`,
          )}
        </div>
      `;
    }

    const selectedCount = app.selection.size;
    const allVisibleSelected = list.length > 0 && list.every((profile) => app.selection.has(profile.id));
    const bulkBar = selectedCount ? `
      <div class="bulk-bar">
        <span class="bulk-count">${icon('check')} ${plural(selectedCount, 'perfil seleccionado', 'perfiles seleccionados')}</span>
        <div class="bulk-actions">
          <button class="btn btn-soft btn-sm" type="button" data-action="bulk-start" ${app.batchBusy ? 'disabled' : ''}>${icon('play')} Iniciar</button>
          <button class="btn btn-soft btn-sm" type="button" data-action="bulk-stop" ${app.batchBusy ? 'disabled' : ''}>${icon('stop')} Detener</button>
          <button class="btn btn-soft btn-sm" type="button" data-action="bulk-move" ${app.batchBusy ? 'disabled' : ''}>${icon('layers')} Mover</button>
          <button class="btn btn-soft btn-sm" type="button" data-action="bulk-tags" ${app.batchBusy ? 'disabled' : ''}>${icon('tag')} Etiquetas</button>
          <button class="btn btn-soft btn-sm" type="button" data-action="bulk-status" ${app.batchBusy ? 'disabled' : ''}>${icon('sparkle')} Estado</button>
          <button class="btn btn-soft btn-sm" type="button" data-action="bulk-proxy" ${app.batchBusy ? 'disabled' : ''}>${icon('globe')} Proxy</button>
          <button class="btn btn-soft btn-sm" type="button" data-action="bulk-duplicate" ${app.batchBusy ? 'disabled' : ''}>${icon('copy')} Duplicar</button>
          <button class="btn btn-soft btn-sm" type="button" data-action="bulk-test-proxies" ${app.proxyBulkBusy ? 'disabled' : ''}>${icon('refresh')} Probar proxies</button>
          <button class="btn btn-soft btn-sm" type="button" data-action="bulk-export" ${app.batchBusy ? 'disabled' : ''}>${icon('download')} Exportar</button>
          <button class="btn btn-danger btn-sm" type="button" data-action="bulk-delete" ${app.batchBusy ? 'disabled' : ''}>${icon('trash')} Eliminar</button>
        </div>
        <span class="toolbar-spacer"></span>
        <button class="btn btn-ghost btn-sm" type="button" data-action="profiles-select-visible">${allVisibleSelected ? 'Quitar visibles' : 'Añadir visibles'}</button>
        <button class="btn btn-ghost btn-sm" type="button" data-action="bulk-clear">${icon('x')} Cancelar</button>
      </div>
    ` : '';

    const grid = list.length
      ? `<div class="profile-grid">${list.map(profileCard).join('')}</div>`
      : `<div class="panel">${emptyBlock(
        'search',
        'Sin coincidencias',
        'No encontramos perfiles con esos filtros. Prueba con otras palabras o limpia la búsqueda.',
        `<button class="btn btn-ghost" type="button" data-action="reset-filters">${icon('refresh')} Limpiar filtros</button>`,
      )}</div>`;

    return `
      ${toolbar}
      <div class="section-head">
        <div>
          <h2>${hasFilters ? `${plural(list.length, 'resultado', 'resultados')}` : plural(total, 'perfil', 'perfiles')}</h2>
          <p>${hasFilters ? 'Filtrados según tu búsqueda' : 'Inicia, edita o duplica tus perfiles'}</p>
        </div>
        <span class="chip">Navegador integrado</span>
      </div>
      ${bulkBar}
      ${grid}
    `;
  }

  // ===== Applications =====

  function appIcon(app, className = '') {
    const name = app ? app.name : 'Aplicación';
    return `<span class="app-icon ${className}" aria-hidden="true">${esc(initials(name))}</span>`;
  }

  function appKindLabel(app) {
    return app.kind === 'startapp' ? 'Menú Inicio' : 'Ejecutable';
  }

  function loadDiscoveredApps(force = false) {
    if (app.discoveryBusy) return;
    if (!force && app.discoveredApps !== null) return;
    app.discoveryBusy = true;
    app.discoveryError = '';
    scheduleRender();
    callAction('apps:discover', { force })
      .then((list) => {
        app.discoveredApps = Array.isArray(list) ? list : [];
        app.discoveryError = '';
      })
      .catch((error) => {
        app.discoveredApps = [];
        app.discoveryError = error.message;
      })
      .finally(() => {
        app.discoveryBusy = false;
        scheduleRender();
      });
  }

  function appLaunchButton(app, profile = null, className = 'btn btn-primary btn-sm') {
    return `<button class="${className}" type="button" data-action="app-launch" data-id="${esc(app.id)}"${profile ? ` data-profile="${esc(profile.id)}"` : ''}>${icon('play')} Abrir</button>`;
  }

  function appCard(app) {
    const running = appStatusFor(app.id);
    const isRunning = running.length > 0;
    const profilesAvailable = appProfileConfigsFor(app.id).length;
    return `
      <article class="app-card ${isRunning ? 'is-running' : ''}">
        <div class="app-card-head">
          ${appIcon(app)}
          <div class="app-card-title">
            <strong title="${esc(app.name)}">${esc(app.name)}</strong>
            <small>${esc(appKindLabel(app))} · ${profilesAvailable ? plural(profilesAvailable, 'perfil configurado', 'perfiles configurados') : 'Sin configurar'}</small>
          </div>
          <button class="app-star ${app.favorite ? 'is-active' : ''}" type="button" data-action="app-favorite" data-id="${esc(app.id)}" title="${app.favorite ? 'Quitar de favoritos' : 'Añadir a favoritos'}" aria-label="${app.favorite ? 'Quitar de favoritos' : 'Añadir a favoritos'}">${icon('star')}</button>
        </div>
        <div class="app-card-meta">
          <span class="chip">${icon(app.kind === 'startapp' ? 'windows' : 'monitor')} ${esc(appKindLabel(app))}</span>
          ${app.kind === 'executable' ? cloneModeChip(app.cloneMode) : ''}
          ${isRunning ? `<span class="chip is-success"><span class="pulse"></span>${plural(running.length, 'instancia', 'instancias')}</span>` : ''}
          ${app.favorite ? '<span class="chip is-warn">Favorita</span>' : ''}
        </div>
        <p class="app-path mono" title="${esc(app.target)}">${esc(app.target)}</p>
        <div class="app-card-foot">
          ${appLaunchButton(app)}
          <button class="btn-icon-sm" type="button" data-action="app-edit" data-id="${esc(app.id)}" title="Editar aplicación" aria-label="Editar aplicación">${icon('edit')}</button>
          ${app.kind === 'executable' ? `<button class="btn-icon-sm" type="button" data-action="app-delete" data-id="${esc(app.id)}" title="Eliminar de la biblioteca" aria-label="Eliminar aplicación">${icon('trash')}</button>` : `<button class="btn-icon-sm" type="button" data-action="app-delete" data-id="${esc(app.id)}" title="Quitar de la biblioteca" aria-label="Quitar aplicación">${icon('x')}</button>`}
        </div>
      </article>
    `;
  }

  function appProfileConfigsFor(appId) {
    return app.state.appProfileConfigs.filter((item) => item.appId === appId);
  }

  function cloneInfo() {
    if (app.state && app.state.clone) return app.state.clone;
    return {
      available: false,
      checked: true,
      encryption: false,
      accounts: [],
      error: 'El clonador nativo no está disponible.',
    };
  }

  function cloneAccountFor(profileId) {
    return (cloneInfo().accounts || []).find((item) => item.profileId === profileId) || null;
  }

  function vmInfo() {
    if (app.state && app.state.vm) return app.state.vm;
    return {
      available: false,
      checked: true,
      settings: {},
      machines: [],
      error: 'El motor de máquinas virtuales no está disponible.',
    };
  }

  function vmMachineFor(profileId) {
    return (vmInfo().machines || []).find((item) => item.profileId === profileId) || null;
  }

  function cloneModeOf(currentApp) {
    if (!currentApp || currentApp.kind !== 'executable') return 'none';
    return ['none', 'data', 'account', 'vm'].includes(currentApp.cloneMode) ? currentApp.cloneMode : 'account';
  }

  function cloneModeChip(mode) {
    if (mode === 'vm') {
      return `<span class="chip is-accent" title="Cada perfil se abre dentro de su propia máquina virtual Hyper-V: es una sesión de Windows completa y verdaderamente independiente, incluso para aplicaciones de instancia única">${icon('monitor')} Máquina virtual</span>`;
    }
    if (mode === 'account') {
      return `<span class="chip is-success" title="Cada perfil usa una cuenta local estándar de Windows con su propio HKCU, AppData y TEMP: la aplicación se duplica de verdad">${icon('shield')} Cuenta Windows</span>`;
    }
    if (mode === 'data') {
      return `<span class="chip is-accent" title="Solo redirige APPDATA, LOCALAPPDATA y TEMP. La mayoría de aplicaciones leen sus datos del registro y no se duplican: usa Cuenta de Windows">${icon('lock')} Datos aislados (limitado)</span>`;
    }
    return '<span class="chip" title="Se abre con el usuario de Windows actual, sin aislamiento adicional">Sin aislamiento</span>';
  }

  function cloneModeLabel(mode) {
    if (mode === 'vm') return 'Máquina virtual Hyper-V';
    if (mode === 'account') return 'Cuenta de Windows';
    if (mode === 'data') return 'Datos aislados (limitado)';
    return 'Sin aislamiento';
  }

  function renderApps() {
    const state = app.state;
    const clone = cloneInfo();
    const vm = vmInfo();
    const preparedAccounts = clone.accounts.length;
    const accountApps = state.apps.filter((item) => item.cloneMode === 'account').length;
    const vmApps = state.apps.filter((item) => item.cloneMode === 'vm').length;
    const vmMachines = (vm.machines || []).length;
    if (state.apps.length && app.discoveredApps === null && !app.discoveryBusy) {
      loadDiscoveredApps(false);
    }
    const query = app.appQuery.trim().toLowerCase();
    const saved = state.apps.filter((item) => !query || `${item.name} ${item.target}`.toLowerCase().includes(query));
    const favorites = saved.filter((item) => item.favorite);
    const regular = saved.filter((item) => !item.favorite);
    const running = state.appStatuses;
    const runningRows = running.length ? running.map((item) => {
      const currentApp = appById(item.appId);
      const profile = profileById(item.profileId);
      const cloneDetail = item.isolation === 'account'
        ? ` · cuenta ${esc(item.accountName || 'Windows')}`
        : item.isolation === 'data'
          ? ' · datos aislados'
          : item.isolation === 'vm'
            ? ` · máquina virtual${item.vmName ? ` ${esc(item.vmName)}` : ''}`
            : '';
      return `
        <div class="running-row app-running-row">
          <div class="pulse"></div>
          ${appIcon(currentApp || { name: item.appName })}
          <div class="running-copy">
            <strong>${esc(item.appName)}</strong>
            <small>${esc(profile ? profile.name : item.profileName)} · PID ${Number(item.pid) || '—'} · <span class="js-elapsed" data-started="${esc(item.startedAt)}">${esc(elapsedSince(item.startedAt))}</span>${cloneDetail}</small>
          </div>
          <button class="btn btn-ghost btn-sm" type="button" data-action="app-stop" data-instance="${esc(item.instanceId)}">${icon('stop')} Detener</button>
        </div>
      `;
    }).join('') : emptyBlock('appgrid', 'Ninguna aplicación abierta', 'Las aplicaciones .exe abiertas desde PerfilLab aparecerán aquí y podrás cerrarlas.');

    const discoverySaved = new Set(state.apps.map((item) => `${item.kind}:${item.target.toLowerCase()}`));
    const discovered = (app.discoveredApps || [])
      .filter((item) => !discoverySaved.has(`${item.kind}:${item.target.toLowerCase()}`))
      .filter((item) => !query || `${item.name} ${item.target}`.toLowerCase().includes(query))
      .slice(0, 150);
    const detectionPanel = app.discoveryBusy
      ? `<div class="app-discovery"><span class="spinner"></span><span>Buscando aplicaciones del menú Inicio…</span></div>`
      : app.discoveryError
        ? `<div class="app-discovery is-error">${icon('alert')}<span>${esc(app.discoveryError)}</span><button class="btn btn-ghost btn-sm" type="button" data-action="apps-refresh">${icon('refresh')} Reintentar</button></div>`
        : discovered.length
          ? `<div class="discovered-list">${discovered.map((item) => `
              <div class="discovered-row">
                ${appIcon(item)}
                <div class="discovered-copy"><strong>${esc(item.name)}</strong><small class="mono">${esc(item.target)}</small></div>
                <button class="btn btn-ghost btn-sm" type="button" data-action="app-add-discovered" data-target="${esc(item.target)}">${icon('plus')} Agregar</button>
              </div>
            `).join('')}</div>`
          : `<div class="app-discovery">${icon('check')}<span>${app.discoveredApps ? (query ? 'No hay aplicaciones detectadas que coincidan.' : 'Todas las aplicaciones detectadas ya están en tu biblioteca.') : 'La detección está disponible en Windows.'}</span></div>`;

    const libraryGrid = regular.length
      ? `<div class="app-grid">${regular.map(appCard).join('')}</div>`
      : '';
    const favoritesGrid = favorites.length
      ? `<div class="app-grid app-grid-favorites">${favorites.map(appCard).join('')}</div>`
      : '';

    const emptyLibrary = !state.apps.length
      ? `<div class="panel">${emptyBlock(
        'appgrid',
        'Tu biblioteca de aplicaciones está vacía',
        'Agrega un programa del menú Inicio de Windows o selecciona un archivo .exe. Después podrás abrirlo con los datos de cualquier perfil.',
        `<div class="hero-actions" style="justify-content:center">
          <button class="btn btn-primary" type="button" data-action="apps-refresh">${icon('refresh')} Detectar aplicaciones</button>
          <button class="btn btn-ghost" type="button" data-action="app-add-exe">${icon('plus')} Añadir .exe</button>
        </div>`,
      )}</div>`
      : '';

    return `
      <div class="view-head">
        <div>
          <h2>Aplicaciones de Windows</h2>
          <p>Programas del menú Inicio y ejecutables supervisados por PerfilLab.</p>
        </div>
        <div class="view-actions">
          <button class="btn btn-ghost" type="button" data-action="apps-refresh">${icon('refresh')} Actualizar detección</button>
          <button class="btn btn-primary" type="button" data-action="app-add-exe">${icon('plus')} Añadir .exe</button>
        </div>
      </div>

      <div class="callout app-isolation-note">
        ${icon('shield')}
        <div>
          <strong>Un perfil, un dispositivo. Clones nativos de Windows, sin instalar nada más.</strong>
          La misma aplicación .exe abierta en dos perfiles distintos son dos instancias independientes: cada perfil usa su propia cuenta local estándar con su propio HKCU, AppData y TEMP, así que la app actúa como un dispositivo nuevo. Windows pide UAC una vez por perfil. Si la aplicación usa una instancia única por sesión de Windows (por ejemplo Spotify), el modo <strong>Máquina virtual Hyper-V</strong> da a cada perfil una sesión de Windows completa. El modo <strong>Datos aislados</strong> solo sirve para apps que respetan las variables de entorno y no duplica a la mayoría.
          <div style="margin-top:6px;display:flex;gap:8px;align-items:center;flex-wrap:wrap">
            <span class="chip ${clone.available ? 'is-success' : clone.checked ? 'is-danger' : ''}">${clone.checked ? (clone.available ? 'Clonador disponible' : 'Clonador no disponible') : 'Comprobando clonador…'}</span>
            <span class="chip ${clone.encryption ? 'is-success' : 'is-warn'}">${clone.encryption ? 'Credenciales cifradas' : 'Cifrado no disponible'}</span>
            <span class="chip ${vm.available ? 'is-success' : vm.checked ? 'is-danger' : ''}">${!vm.checked ? 'Comprobando Hyper-V…' : vm.available ? 'Hyper-V disponible' : 'Hyper-V no disponible'}</span>
            <span class="chip">${plural(preparedAccounts, 'cuenta preparada', 'cuentas preparadas')}</span>
            ${vmMachines ? `<span class="chip is-accent">${plural(vmMachines, 'máquina virtual', 'máquinas virtuales')}</span>` : ''}
            ${accountApps ? `<span class="chip is-accent">${plural(accountApps, 'aplicación usa cuenta', 'aplicaciones usan cuenta')}</span>` : ''}
            ${vmApps ? `<span class="chip is-accent">${plural(vmApps, 'aplicación usa VM', 'aplicaciones usan VM')}</span>` : ''}
          </div>
          ${clone.error && clone.checked ? `<div class="field-hint" style="margin-top:6px">${esc(clone.error)}</div>` : ''}
          ${vm.error && vm.checked ? `<div class="field-hint" style="margin-top:6px">Máquinas virtuales: ${esc(vm.error)}</div>` : ''}
          <div class="field-hint" style="margin-top:6px">Aísla datos y configuración de Windows; no es una barrera de seguridad frente a código malicioso ni eleva aplicaciones que requieren administrador. Las aplicaciones del menú Inicio no admiten cuenta clon.</div>
        </div>
      </div>

      <div class="toolbar">
        <div class="search-box ${app.appQuery ? 'has-value' : ''}">
          ${icon('search')}
          <input id="apps-search" type="search" placeholder="Buscar aplicaciones…" value="${esc(app.appQuery)}" autocomplete="off" spellcheck="false" aria-label="Buscar aplicaciones">
          <button class="search-clear" type="button" data-action="apps-search-clear" aria-label="Limpiar búsqueda">${icon('x')}</button>
        </div>
        <span class="toolbar-spacer"></span>
        <span class="chip">${plural(state.apps.length, 'aplicación guardada', 'aplicaciones guardadas')}</span>
        <span class="chip">${plural(running.length, 'sesión activa', 'sesiones activas')}</span>
      </div>

      <div class="panel">
        <div class="panel-head">
          <div><h2>En ejecución</h2><p>Procesos .exe iniciados por PerfilLab</p></div>
          <span class="chip">${plural(running.length, 'proceso', 'procesos')}</span>
        </div>
        <div class="panel-body">${runningRows}</div>
      </div>

      ${emptyLibrary}
      ${favorites.length ? `<div class="section-head"><div><h2>Favoritas</h2><p>Acceso rápido a tus aplicaciones habituales</p></div></div>${favoritesGrid}` : ''}
      ${regular.length ? `<div class="section-head"><div><h2>Biblioteca</h2><p>${plural(regular.length, 'aplicación', 'aplicaciones')} guardadas</p></div></div>${libraryGrid}` : ''}

      <div class="panel app-discovery-panel">
        <div class="panel-head">
          <div><h2>Aplicaciones detectadas</h2><p>Programas instalados y registrados en el menú Inicio de Windows</p></div>
          <button class="btn btn-ghost btn-sm" type="button" data-action="apps-refresh">${icon('refresh')} Escanear</button>
        </div>
        <div class="panel-body">${detectionPanel}</div>
      </div>
    `;
  }

  function launchCloneStatus(currentApp, profileId) {
    const mode = cloneModeOf(currentApp);
    const clone = cloneInfo();
    if (mode === 'data') {
      return {
        tone: 'is-warn',
        html: `${icon('alert')}<div><strong>Datos aislados no duplica la mayoría de aplicaciones.</strong> Solo cambia APPDATA, LOCALAPPDATA y TEMP, pero muchos programas leen sus datos del registro de Windows y vuelven a abrir la ventana que ya estaba abierta. Para que cada perfil sea un dispositivo nuevo, cambia esta aplicación a <strong>Cuenta de Windows</strong>.</div>`,
      };
    }
    if (mode === 'none') {
      return {
        tone: 'is-warn',
        html: `${icon('alert')}<div><strong>Sin aislamiento.</strong> La aplicación se abre con tu usuario de Windows y comparte su configuración y datos. Útil solo para programas de confianza que deben conservar sus datos normales.</div>`,
      };
    }
    if (mode === 'vm') {
      const vm = vmInfo();
      const settings = vm.settings || {};
      if (!vm.checked) {
        return { tone: '', html: `${icon('monitor')}<div><strong>Comprobando Hyper-V…</strong> Espera un momento o abre Ajustes &gt; Máquinas virtuales.</div>` };
      }
      if (!vm.available) {
        return {
          tone: 'is-warn',
          html: `${icon('alert')}<div><strong>Hyper-V no está disponible.</strong> ${esc(vm.error || 'Este equipo no puede crear máquinas virtuales.')} Puedes cambiar esta aplicación a <strong>Cuenta de Windows</strong>.</div>`,
        };
      }
      if (!settings.baseImagePath) {
        return {
          tone: 'is-warn',
          html: `${icon('alert')}<div><strong>Falta la imagen base de Hyper-V.</strong> Elige un archivo <span class="mono">.vhdx</span> con Windows ya instalado en Ajustes &gt; Máquinas virtuales antes de abrir esta aplicación.</div>`,
        };
      }
      const machine = vmMachineFor(profileId);
      const ram = settings.memoryMb || 4096;
      if (machine) {
        if (machine.running) {
          return {
            tone: 'is-warn',
            html: `${icon('monitor')}<div><strong>La máquina virtual ${esc(machine.vmName)} ya está encendida.</strong> Abre la aplicación dentro de su ventana de conexión. Si cerraste esa ventana, la máquina seguirá encendida: vuelve a pulsar «Encender» para reconectarte.</div>`,
          };
        }
        return {
          tone: '',
          html: `${icon('monitor')}<div><strong>Se usará la máquina virtual ${esc(machine.vmName)}.</strong> Windows pedirá permisos de administrador para encenderla. La aplicación debe abrirse manualmente dentro de la ventana de la máquina virtual.</div>`,
        };
      }
      return {
        tone: 'is-warn',
        html: `${icon('monitor')}<div><strong>Se creará la máquina virtual de este perfil.</strong> Usa ${ram} MB de RAM y un disco diferencial sobre la imagen base. Windows pedirá permisos de administrador. Después, abre la aplicación manualmente dentro de la ventana de la máquina virtual.</div>`,
      };
    }
    if (!clone.checked) {
      return { tone: '', html: `${icon('shield')}<div><strong>Comprobando el clonador nativo…</strong> Espera un momento o abre Ajustes &gt; Clonador nativo.</div>` };
    }
    if (!clone.available) {
      return {
        tone: 'is-warn',
        html: `${icon('alert')}<div><strong>El clonador nativo no está disponible.</strong> ${esc(clone.error || 'Este equipo no puede crear cuentas locales de Windows.')} Puedes cambiar el modo de la aplicación a Datos aislados.</div>`,
      };
    }
    const account = cloneAccountFor(profileId);
    if (account) {
      const verified = account.verifiedAt
        ? `Verificada ${esc(relativeTime(account.verifiedAt))}.`
        : 'Pendiente de verificación; puedes probarla desde Ajustes.';
      return {
        tone: '',
        html: `${icon('shield')}<div><strong>Se abrirá en la cuenta ${esc(account.username)}.</strong> Esta cuenta local estándar tiene su propio HKCU, AppData y TEMP. ${verified}</div>`,
      };
    }
    const disabled = clone.encryption ? '' : 'disabled';
    const reason = clone.encryption ? '' : '<div class="field-hint" style="margin-top:4px">El cifrado del sistema no está disponible; no se pueden guardar credenciales de clon.</div>';
    return {
      tone: 'is-warn',
      html: `${icon('alert')}<div><strong>Este perfil todavía no tiene su cuenta de Windows.</strong> Al pulsar «Abrir aplicación» se creará una cuenta local estándar (PL_…) con contraseña aleatoria cifrada y Windows pedirá permisos de administrador una sola vez. Después, cada perfil será un dispositivo nuevo e independiente.<div style="margin-top:8px"><button class="btn btn-ghost btn-sm" type="button" data-action="clone-prepare" data-profile="${esc(profileId)}" data-context="launch" ${disabled}>${icon('shield')} Preparar cuenta ahora (UAC)</button></div>${reason}</div>`,
    };
  }

  function paintLaunchCloneStatus(root) {
    const form = root.querySelector('#app-launch-form');
    const select = root.querySelector('#al-profile');
    const container = root.querySelector('#al-clone-status');
    if (!form || !select || !container) return;
    const currentApp = appById(form.dataset.app);
    if (!currentApp) return;
    const status = launchCloneStatus(currentApp, select.value);
    container.className = `callout ${status.tone}`.trim();
    container.innerHTML = status.html;
  }

  function openAppLaunchModal(appId, preselectedProfileId = '') {
    const currentApp = appById(appId);
    if (!currentApp) {
      toast('La aplicación ya no está en la biblioteca.', 'warn');
      return;
    }
    if (!app.state.profiles.length) {
      toast('Crea un perfil antes de abrir una aplicación.', 'warn');
      setView('profiles');
      return;
    }
    const defaultProfile = app.state.profiles.find((profile) => profile.id === preselectedProfileId) || app.state.profiles[0];
    const options = app.state.profiles.map((profile) => `<option value="${esc(profile.id)}" ${profile.id === defaultProfile.id ? 'selected' : ''}>${esc(profile.name)}${profile.workspaceId ? ` · ${esc((workspaceById(profile.workspaceId) || {}).name || '')}` : ''}</option>`).join('');
    const config = appProfileConfig(appId, defaultProfile.id);
    const args = config ? config.args : currentApp.args;
    const cwd = config ? config.cwd : currentApp.cwd;
    const isStart = currentApp.kind === 'startapp';
    const mode = cloneModeOf(currentApp);
    const vmMode = mode === 'vm';
    const locked = isStart || vmMode;
    const status = launchCloneStatus(currentApp, defaultProfile.id);
    openModal({
      title: `Abrir ${currentApp.name}`,
      subtitle: 'Elige el perfil y ajusta cómo se inicia esta aplicación.',
      body: `
        ${isStart ? `<div class="callout is-warn">${icon('alert')}<div><strong>Aplicación del menú Inicio.</strong> Windows controla el proceso, por lo que no se aplica aislamiento ni se puede detener desde PerfilLab.</div></div>` : ''}
        ${isStart ? '' : `<div class="callout ${status.tone}" id="al-clone-status">${status.html}</div>`}
        <form class="modal-form" id="app-launch-form" data-app="${esc(appId)}" novalidate>
          <div class="form-error" id="app-launch-error"></div>
          <div class="field">
            <label for="al-profile">Perfil</label>
            <select class="select" id="al-profile" name="profileId">${options}</select>
            <span class="field-hint">${vmMode ? `Cada perfil tiene su propia máquina virtual Hyper-V. Modo: ${esc(cloneModeLabel(mode))}.` : `Cada perfil conserva sus propios argumentos y su aislamiento: ${esc(cloneModeLabel(mode))}.`}</span>
          </div>
          <div class="field">
            <label for="al-args">Argumentos ${locked ? '(no disponible)' : ''}</label>
            <input class="input is-mono" id="al-args" name="args" maxlength="4000" value="${esc(args)}" placeholder="${vmMode ? 'No se aplican dentro de la máquina virtual' : '--ejemplo &quot;valor con espacios&quot;'}" autocomplete="off" ${locked ? 'disabled' : ''}>
          </div>
          <div class="field">
            <label for="al-cwd">Carpeta de trabajo ${locked ? '(no disponible)' : ''}</label>
            <input class="input is-mono" id="al-cwd" name="cwd" maxlength="1000" value="${esc(cwd)}" placeholder="${vmMode ? 'No se aplica dentro de la máquina virtual' : mode === 'account' ? 'Vacío = carpeta del ejecutable' : 'Vacío = carpeta del perfil'}" autocomplete="off" ${locked ? 'disabled' : ''}>
          </div>
        </form>
      `,
      footer: `
        <button class="btn btn-ghost" type="button" data-close-modal>Cancelar</button>
        <button class="btn btn-primary" type="submit" form="app-launch-form" id="al-submit">${icon('play')} ${vmMode ? 'Encender máquina virtual' : 'Abrir aplicación'}</button>
      `,
      onMount(root) {
        const form = root.querySelector('#app-launch-form');
        const profileSelect = root.querySelector('#al-profile');
        const applyProfile = () => {
          const selected = appProfileConfig(appId, profileSelect.value);
          if (!isStart) {
            form.querySelector('#al-args').value = selected ? selected.args : currentApp.args;
            form.querySelector('#al-cwd').value = selected ? selected.cwd : currentApp.cwd;
          }
          paintLaunchCloneStatus(root);
        };
        profileSelect.addEventListener('change', applyProfile);
        const submitButton = root.querySelector('#al-submit');
        const syncVmLaunch = () => {
          if (!vmMode || !submitButton) return;
          const machine = vmMachineFor(profileSelect.value);
          const running = Boolean(machine && machine.running);
          submitButton.disabled = running;
          submitButton.title = running ? 'La máquina virtual ya está encendida; usa su ventana de conexión.' : '';
          submitButton.innerHTML = `${icon('play')} ${running ? 'Máquina encendida' : 'Encender máquina virtual'}`;
        };
        if (vmMode) {
          syncVmLaunch();
          profileSelect.addEventListener('change', syncVmLaunch);
        }
      },
    });
  }

  function openAppEditModal(currentApp) {
    const isStart = currentApp.kind === 'startapp';
    const mode = cloneModeOf(currentApp);
    const clone = cloneInfo();
    const vm = vmInfo();
    const modeCard = (value, title, description, iconName) => `
      <label class="clone-mode-card">
        <input type="radio" name="cloneMode" value="${value}" ${mode === value ? 'checked' : ''}>
        <span class="clone-mode-icon">${icon(iconName)}</span>
        <span class="clone-mode-copy"><strong>${esc(title)}</strong><small>${esc(description)}</small></span>
      </label>
    `;
    openModal({
      title: 'Editar aplicación',
      subtitle: currentApp.name,
      size: 'is-wide',
      body: `
        <form class="modal-form" id="app-edit-form" data-id="${esc(currentApp.id)}" novalidate>
          <div class="form-error" id="app-edit-error"></div>
          <div class="field">
            <label for="ae-name">Nombre</label>
            <input class="input" id="ae-name" name="name" maxlength="100" value="${esc(currentApp.name)}" autocomplete="off" data-autofocus>
          </div>
          <div class="field">
            <label for="ae-args">Argumentos predeterminados</label>
            <input class="input is-mono" id="ae-args" name="args" maxlength="4000" value="${esc(currentApp.args)}" placeholder="Opcional" autocomplete="off">
          </div>
          <div class="field">
            <label for="ae-cwd">Carpeta de trabajo predeterminada</label>
            <input class="input is-mono" id="ae-cwd" name="cwd" maxlength="1000" value="${esc(currentApp.cwd)}" placeholder="Vacío = carpeta del perfil" autocomplete="off">
          </div>
          ${isStart ? `
            <div class="callout is-warn">
              ${icon('alert')}
              <div><strong>Aplicación del menú Inicio.</strong> Windows controla el proceso y no permite elegir cuenta ni aislar sus datos desde PerfilLab.</div>
            </div>
          ` : `
            <div class="field">
              <label>Modo de clonación</label>
              <div class="clone-mode-grid">
                ${modeCard(
                  'account',
                  'Cuenta de Windows (recomendado)',
                  'Duplica de verdad la aplicación: cada perfil usa una cuenta local estándar con su propio HKCU, AppData y TEMP, así que la misma app abierta en dos perfiles son dos instancias independientes a la vez. Se prepara una vez con UAC.',
                  'shield',
                )}
                ${modeCard(
                  'data',
                  'Datos aislados (limitado)',
                  'Sin UAC ni cuentas. Solo redirige APPDATA, LOCALAPPDATA y TEMP: muchos programas leen sus datos del registro y no se duplican, por lo que vuelven a abrir la ventana existente. Úsalo solo si la app respeta esas variables.',
                  'lock',
                )}
                ${modeCard(
                  'vm',
                  'Máquina virtual Hyper-V',
                  'Cada perfil se abre en su propia máquina virtual: una sesión de Windows completa, así que incluso las aplicaciones de instancia única (Spotify, por ejemplo) pueden ejecutarse a la vez en varios perfiles. Necesita Hyper-V, una imagen base .vhdx y unos 4 GB de RAM por máquina encendida; la aplicación se abre manualmente dentro de la ventana de la VM.',
                  'monitor',
                )}
                ${modeCard(
                  'none',
                  'Sin aislamiento',
                  'Se abre con tu usuario de Windows y comparte configuración y datos. Solo para programas de confianza.',
                  'monitor',
                )}
              </div>
              ${!clone.available && clone.checked ? `<div class="callout is-warn" style="margin-top:8px">${icon('alert')}<div>${esc(clone.error || 'El clonador nativo no está disponible en este equipo.')} El modo Cuenta de Windows no podrá abrirse hasta que se resuelva.</div></div>` : ''}
              ${!vm.available && vm.checked ? `<div class="callout is-warn" style="margin-top:8px">${icon('alert')}<div>${esc(vm.error || 'Hyper-V no está disponible en este equipo.')} El modo Máquina virtual no podrá abrirse hasta que se resuelva.</div></div>` : ''}
              <span class="field-hint" style="margin-top:6px">La cuenta de Windows y la máquina virtual se preparan por perfil, no por aplicación: se reutilizan en todas las aplicaciones .exe abiertas con ese perfil.</span>
            </div>
          `}
          <p class="app-path mono" style="margin-top:4px">${esc(currentApp.target)}</p>
        </form>
      `,
      footer: `
        <button class="btn btn-ghost" type="button" data-close-modal>Cancelar</button>
        <button class="btn btn-primary" type="submit" form="app-edit-form">Guardar aplicación</button>
      `,
    });
  }

  function openAppDeleteModal(currentApp) {
    const running = appStatusFor(currentApp.id).length;
    openConfirmModal({
      title: 'Quitar aplicación',
      subtitle: currentApp.name,
      message: `Se quitará <strong>${esc(currentApp.name)}</strong> de la biblioteca.${running ? ` Se cerrarán ${plural(running, 'instancia abierta', 'instancias abiertas')}.` : ''} No se elimina el programa ni sus datos.`,
      confirmLabel: 'Quitar de la biblioteca',
      onConfirm: async () => {
        await callAction('apps:delete', { id: currentApp.id });
        toast('Aplicación quitada de la biblioteca.', 'success');
      },
    });
  }

  function openProfileAppsModal(profileId) {
    const profile = profileById(profileId);
    if (!profile) return;
    const apps = app.state.apps;
    openModal({
      title: 'Abrir aplicación',
      subtitle: `Perfil: ${profile.name}`,
      body: apps.length
        ? `<div class="app-picker">${apps.map((item) => `
            <button class="app-picker-row" type="button" data-action="app-launch" data-id="${esc(item.id)}" data-profile="${esc(profileId)}">
              ${appIcon(item)}
              <span><strong>${esc(item.name)}</strong><small>${esc(appKindLabel(item))}</small></span>
              ${icon('play')}
            </button>
          `).join('')}</div>`
        : `<p class="confirm-copy">Tu biblioteca está vacía. Agrega un programa desde la sección Aplicaciones.</p>`,
      size: 'is-narrow',
      footer: `<button class="btn btn-ghost" type="button" data-close-modal>Cerrar</button>${apps.length ? `<button class="btn btn-primary" type="button" data-go-view="apps">${icon('appgrid')} Ver biblioteca</button>` : `<button class="btn btn-primary" type="button" data-go-view="apps">${icon('plus')} Agregar aplicaciones</button>`}`,
    });
  }

  // ===== Workspaces =====

  function renderWorkspaces() {
    const state = app.state;
    const cards = state.workspaces.map((workspace) => {
      const profiles = state.profiles.filter((profile) => profile.workspaceId === workspace.id);
      const running = profiles.filter((profile) => runningFor(profile.id)).length;
      return `
        <article class="workspace-card" style="--ws-color:${safeColor(workspace.color)}">
          <div class="ws-head">
            <div class="ws-icon">${icon('folder')}</div>
            <div class="ws-name">
              <strong>${esc(workspace.name)}</strong>
              <small>Creado ${esc(relativeTime(workspace.createdAt))}</small>
            </div>
            <div class="ws-actions">
              <button class="btn-icon-sm" type="button" data-action="workspace-edit" data-id="${esc(workspace.id)}" title="Editar espacio" aria-label="Editar espacio">${icon('edit')}</button>
              <button class="btn-icon-sm is-danger" type="button" data-action="workspace-delete" data-id="${esc(workspace.id)}" title="Eliminar espacio" aria-label="Eliminar espacio">${icon('trash')}</button>
            </div>
          </div>
          <div class="ws-stats">
            <div><strong>${profiles.length}</strong><span>Perfiles</span></div>
            <div><strong>${running}</strong><span>En ejecución</span></div>
            <button class="link-btn" type="button" data-action="filter-workspace" data-id="${esc(workspace.id)}">Ver perfiles →</button>
          </div>
        </article>
      `;
    }).join('');

    return `
      <div class="section-head">
        <div>
          <h2>${plural(state.workspaces.length, 'espacio de trabajo', 'espacios de trabajo')}</h2>
          <p>Organiza tus perfiles por cliente, proyecto o campaña</p>
        </div>
        <button class="btn btn-primary" type="button" data-action="workspace-new">${icon('plus')} Nuevo espacio</button>
      </div>
      <div class="workspace-grid">${cards}</div>
    `;
  }

  // ===== Proxies =====

  function proxyResultHtml(proxy) {
    const result = app.testResults.get(proxy.id);
    if (!result) return '<div class="proxy-result"><small>Sin probar</small></div>';
    if (result.status === 'pending') {
      return '<div class="proxy-result"><small><span class="spinner-xs"></span>Probando conexión…</small></div>';
    }
    if (result.status === 'ok') {
      return `<div class="proxy-result is-ok"><strong>${esc(result.ip)}</strong><small>${Number(result.latencyMs) || 0} ms · conexión correcta</small></div>`;
    }
    return `<div class="proxy-result is-error"><strong>Sin conexión</strong><small title="${esc(result.error || '')}">${esc(result.error || 'Error desconocido')}</small></div>`;
  }

  function renderProxies() {
    const state = app.state;
    if (!state.proxies.length) {
      return `
        <div class="section-head">
          <div><h2>Proxies</h2><p>Configura conexiones y reutilízalas en tus perfiles</p></div>
          <button class="btn btn-primary" type="button" data-action="proxy-new">${icon('plus')} Nuevo proxy</button>
        </div>
        <div class="panel">
          ${emptyBlock(
            'globe',
            'Sin proxies guardados',
            'Añade un proxy HTTP, HTTPS o SOCKS5 y asígnalo a los perfiles que lo necesiten. Las contraseñas se cifran en este equipo.',
            `<button class="btn btn-primary" type="button" data-action="proxy-new">${icon('plus')} Añadir proxy</button>`,
          )}
        </div>
      `;
    }

    const rows = state.proxies.map((proxy) => {
      const usage = state.profiles.filter((profile) => profile.proxyId === proxy.id).length;
      const result = app.testResults.get(proxy.id);
      const pending = result && result.status === 'pending';
      return `
        <div class="proxy-card">
          <div class="proxy-ident">
            <div class="proxy-icon">${icon('globe')}</div>
            <div>
              <strong title="${esc(proxy.name)}">${esc(proxy.name)}</strong>
              <small>${usage ? plural(usage, 'perfil lo usa', 'perfiles lo usan') : 'Sin asignar'}</small>
            </div>
          </div>
          <div class="proxy-address">
            <span class="mono">${esc(`${proxy.protocol}://${proxy.host}:${proxy.port}`)}</span>
            <small>
              <span class="chip">${esc(proxy.protocol.toUpperCase())}</span>
              <span class="proxy-auth">${proxy.hasPassword ? `${icon('lock')} Con autenticación` : 'Sin autenticación'}</span>
              ${proxy.notes ? `· ${esc(proxy.notes)}` : ''}
            </small>
          </div>
          ${proxyResultHtml(proxy)}
          <div class="proxy-actions">
            <button class="btn btn-ghost btn-sm" type="button" data-action="proxy-test" data-id="${esc(proxy.id)}" ${pending ? 'disabled' : ''}>
              ${pending ? '<span class="spinner-xs"></span>' : icon('refresh')} Probar
            </button>
            <button class="btn-icon-sm" type="button" data-action="proxy-edit" data-id="${esc(proxy.id)}" title="Editar proxy" aria-label="Editar proxy">${icon('edit')}</button>
            <button class="btn-icon-sm is-danger" type="button" data-action="proxy-delete" data-id="${esc(proxy.id)}" title="Eliminar proxy" aria-label="Eliminar proxy">${icon('trash')}</button>
          </div>
        </div>
      `;
    }).join('');

    return `
      <div class="section-head">
        <div><h2>${plural(state.proxies.length, 'proxy guardado', 'proxies guardados')}</h2><p>Las credenciales se cifran en este equipo y no se exportan</p></div>
        <div class="section-actions">
          <button class="btn btn-ghost" type="button" data-action="proxy-test-all" ${app.proxyBulkBusy ? 'disabled' : ''}>
            ${app.proxyBulkBusy ? '<span class="spinner-xs"></span> Probando…' : `${icon('refresh')} Probar todos`}
          </button>
          <button class="btn btn-primary" type="button" data-action="proxy-new">${icon('plus')} Nuevo proxy</button>
        </div>
      </div>
      <div class="proxy-list">${rows}</div>
    `;
  }

  // ===== Activity =====

  function activityIcon(level) {
    if (level === 'success') return 'check';
    if (level === 'warn' || level === 'error') return 'alert';
    return 'info';
  }

  function renderActivity() {
    const state = app.state;
    const filters = [
      ['all', 'Todo'],
      ['info', 'Información'],
      ['success', 'Correcto'],
      ['warn', 'Avisos'],
      ['error', 'Errores'],
    ];
    const list = app.activityFilter === 'all'
      ? state.activity
      : state.activity.filter((entry) => entry.level === app.activityFilter);

    const filterBar = `
      <div class="activity-toolbar">
        ${filters.map(([value, label]) => `<button class="filter-chip ${app.activityFilter === value ? 'is-active' : ''}" type="button" data-action="activity-filter" data-level="${value}">${label}</button>`).join('')}
        <span class="toolbar-spacer"></span>
        <button class="btn btn-ghost btn-sm" type="button" data-action="activity-clear" ${state.activity.length ? '' : 'disabled'}>${icon('trash')} Vaciar historial</button>
      </div>
    `;

    if (!state.activity.length) {
      return `${filterBar}<div class="panel">${emptyBlock('info', 'Sin actividad todavía', 'Aquí se registran los inicios de perfiles, los cambios de configuración y los errores.')}</div>`;
    }

    if (!list.length) {
      return `${filterBar}<div class="panel">${emptyBlock('search', 'Sin eventos de este tipo', 'Prueba con otro filtro para ver el resto del historial.')}</div>`;
    }

    const rows = list.map((entry) => `
      <div class="activity-item">
        <div class="act-icon is-${esc(entry.level)}">${icon(activityIcon(entry.level))}</div>
        <div class="act-body">
          <p>${esc(entry.message)}</p>
          <time datetime="${esc(entry.ts)}">${esc(exactTime(entry.ts))} · ${esc(relativeTime(entry.ts))}</time>
        </div>
        <span class="act-level">${esc(entry.level === 'success' ? 'ok' : entry.level)}</span>
      </div>
    `).join('');

    return `${filterBar}<div class="activity-list">${rows}</div>`;
  }

  // ===== API =====

  function curlExample(port) {
    return [
      'export PERFILLAB_TOKEN="tu-token"',
      '',
      `curl -s "http://127.0.0.1:${port}/v1/profiles" \\`,
      '  -H "Authorization: Bearer $PERFILLAB_TOKEN"',
    ].join('\n');
  }

  function renderApi() {
    const state = app.state;
    const api = state.settings.api;
    const stateClass = api.running ? 'is-on' : api.error ? 'is-error' : 'is-off';
    const stateText = api.running
      ? `Activa en 127.0.0.1:${api.port}`
      : api.error
        ? 'Error al iniciar'
        : api.enabled
          ? 'Iniciando…'
          : 'Detenida';
    const token = api.token || '';
    const tokenDisplay = app.apiRevealed ? token : maskToken(token);
    const busy = app.busy.has('api');
    const endpointBase = `http://127.0.0.1:${api.port}/v1`;

    const endpoints = [
      ['GET', '/v1/health', 'Comprobar que la API responde'],
      ['GET', '/v1/profiles', 'Listar perfiles y sesiones activas'],
      ['POST', '/v1/profiles', 'Crear un perfil'],
      ['POST', '/v1/profiles/batch', 'Iniciar, detener, mover, etiquetar, asignar estado o proxy, duplicar o eliminar varios perfiles'],
      ['POST', '/v1/profiles/:id/start', 'Iniciar el navegador de un perfil'],
      ['POST', '/v1/profiles/:id/stop', 'Detener un perfil'],
      ['PATCH', '/v1/profiles/:id', 'Editar un perfil'],
      ['DELETE', '/v1/profiles/:id', 'Eliminar un perfil'],
      ['GET', '/v1/statuses', 'Listar estados de perfil'],
      ['POST', '/v1/statuses', 'Crear un estado de perfil'],
      ['PATCH', '/v1/statuses/:id', 'Editar un estado'],
      ['DELETE', '/v1/statuses/:id', 'Eliminar un estado (los perfiles quedan sin estado)'],
      ['GET', '/v1/proxies', 'Listar proxies sin contraseñas'],
      ['POST', '/v1/proxies/test', 'Probar uno o varios proxies'],
      ['GET', '/v1/workspaces', 'Listar espacios de trabajo'],
      ['GET', '/v1/status', 'Estado de sesiones y de la API'],
      ['GET', '/v1/activity', 'Historial de actividad'],
    ];

    return `
      <div class="api-hero">
        <div>
          <h2>Conecta tus herramientas</h2>
          <p>Una API HTTP local para crear perfiles, abrirlos y consultar su estado. Escucha únicamente en 127.0.0.1 y exige un token Bearer en cada petición.</p>
        </div>
        <div class="api-state ${stateClass}">
          <span class="status-dot ${api.running ? 'is-on' : api.error ? 'is-error' : ''}"></span>
          ${esc(stateText)}
        </div>
      </div>

      <div class="api-grid">
        <div class="settings-col">
          <section class="settings-card">
            <div class="settings-card-head">
              <h2>${icon('server')} Servidor</h2>
              <p>Activa el servidor y elige su puerto. Se reinicia solo al guardar.</p>
            </div>
            <div class="settings-rows">
              <div class="setting-row">
                <div class="setting-info">
                  <strong>Activar API local</strong>
                  <p>Disponible solo mientras PerfilLab esté abierto.</p>
                </div>
                <div class="setting-control">
                  <label class="switch" title="Activar API local">
                    <input type="checkbox" id="api-enabled" ${api.enabled ? 'checked' : ''} ${busy ? 'disabled' : ''} aria-label="Activar API local">
                    <span class="switch-track"></span>
                  </label>
                </div>
              </div>
              <div class="setting-row">
                <div class="setting-info">
                  <strong>Puerto</strong>
                  <p>Entre 1024 y 65535. Debe estar libre en este equipo.</p>
                </div>
                <div class="setting-control">
                  <input class="input" id="api-port" type="number" min="1024" max="65535" value="${api.port}" aria-label="Puerto de la API" style="width:112px;height:34px">
                  <button class="btn btn-ghost btn-sm" type="button" data-action="api-port-save" ${busy ? 'disabled' : ''}>Guardar</button>
                </div>
              </div>
              <div class="setting-row">
                <div class="setting-info">
                  <strong>Dirección base</strong>
                  <p class="mono">${esc(endpointBase)}</p>
                </div>
                <div class="setting-control">
                  <button class="btn-icon-sm" type="button" data-copy-source="api-base" title="Copiar dirección" aria-label="Copiar dirección">${icon('copy')}</button>
                </div>
              </div>
            </div>
            ${api.error ? `<div class="card-pad"><div class="callout is-danger">${icon('alert')}<div>${esc(api.error)}</div></div></div>` : ''}
          </section>

          <section class="settings-card">
            <div class="settings-card-head">
              <h2>${icon('key')} Token de acceso</h2>
              <p>Las peticiones necesitan la cabecera Authorization: Bearer.</p>
            </div>
            <div class="settings-pad">
              <div class="token-control">
                <input class="input is-mono" id="api-token-display" type="text" readonly value="${esc(tokenDisplay)}" aria-label="Token de la API">
                <button class="btn-icon-sm" type="button" data-action="api-token-reveal" title="${app.apiRevealed ? 'Ocultar token' : 'Mostrar token'}" aria-label="${app.apiRevealed ? 'Ocultar token' : 'Mostrar token'}">${icon(app.apiRevealed ? 'eyeoff' : 'eye')}</button>
                <button class="btn-icon-sm" type="button" data-copy-source="api-token" title="Copiar token" aria-label="Copiar token">${icon('copy')}</button>
              </div>
              <div class="callout is-warn">
                ${icon('alert')}
                <div>El token controla PerfilLab. No lo compartas ni lo incluyas en capturas o repositorios. Puedes regenerarlo cuando quieras; los scripts anteriores dejarán de funcionar.</div>
              </div>
              <div>
                <button class="btn btn-danger btn-sm" type="button" data-action="api-token-regenerate">${icon('refresh')} Regenerar token</button>
              </div>
            </div>
          </section>
        </div>

        <div class="settings-col">
          <section class="settings-card">
            <div class="settings-card-head">
              <h2>${icon('terminal')} Endpoints disponibles</h2>
              <p>Respuestas JSON. Los identificadores son UUID de cada recurso.</p>
            </div>
            <div class="settings-pad">
              <div class="endpoint-list">
                ${endpoints.map(([method, path, desc]) => `
                  <div class="endpoint">
                    <span class="method ${method.toLowerCase()}">${method}</span>
                    <div>
                      <code>${esc(path)}</code>
                      <small>${esc(desc)}</small>
                    </div>
                  </div>
                `).join('')}
              </div>
            </div>
          </section>

          <section class="settings-card">
            <div class="settings-card-head">
              <h2>${icon('copy')} Ejemplo rápido</h2>
              <p>Primero guarda el token en una variable de entorno.</p>
            </div>
            <div class="settings-pad">
              <div class="code-block">
                <code>${esc(curlExample(api.port))}</code>
                <button class="copy-code" type="button" data-copy-source="curl" title="Copiar ejemplo" aria-label="Copiar ejemplo">${icon('copy')}</button>
              </div>
              <p class="settings-note">Sustituye <span class="mono">tu-token</span> por el token real. No pegues el token en servicios externos.</p>
            </div>
          </section>
        </div>
      </div>
    `;
  }

  // ===== Settings =====

  function themeOption(value, label, previewClass) {
    const active = app.state.settings.theme === value;
    return `
      <button class="theme-option ${active ? 'is-active' : ''}" type="button" data-theme-choice="${value}">
        <span class="theme-preview ${previewClass}"><span></span><span></span><span></span></span>
        <strong>${esc(label)}</strong>
      </button>
    `;
  }

  function renderSettings() {
    const state = app.state;
    const settings = state.settings;
    const builtin = state.browsers[0];
    const clone = cloneInfo();
    const vm = vmInfo();
    const vmSettings = vm.settings || {};
    const preparedAccounts = clone.accounts.length;
    const vmMachineRows = state.profiles.length
      ? state.profiles.map((profile) => {
        const machine = vmMachineFor(profile.id);
        const running = Boolean(machine && machine.running);
        const status = machine
          ? running
            ? '<span class="chip is-success"><span class="pulse"></span>Encendida</span>'
            : '<span class="chip">Apagada</span>'
          : '<span class="chip is-warn">Sin preparar</span>';
        const actions = machine
          ? `${status}
             <button class="btn btn-ghost btn-sm" type="button" data-action="vm-start" data-profile="${esc(profile.id)}" title="Windows pedirá UAC para encender la máquina virtual" ${vm.available && vmSettings.baseImagePath && !running ? '' : 'disabled'}>${icon('play')} Encender (UAC)</button>
             <button class="btn btn-ghost btn-sm" type="button" data-action="vm-stop" data-profile="${esc(profile.id)}" title="Guarda el estado de la máquina virtual" ${running ? '' : 'disabled'}>${icon('stop')} Detener</button>
             <button class="btn btn-ghost btn-sm" type="button" data-action="vm-remove" data-profile="${esc(profile.id)}" title="Elimina la máquina virtual y su disco diferencial">${icon('trash')} Eliminar</button>`
          : `<button class="btn btn-primary btn-sm" type="button" data-action="vm-prepare" data-profile="${esc(profile.id)}" ${vm.available && vmSettings.baseImagePath ? '' : 'disabled'}>${icon('monitor')} Preparar (UAC)</button>`;
        return `
          <div class="clone-account-row">
            <div class="clone-account-copy">
              <strong>${esc(profile.name)}</strong>
              <small>${machine ? `VM <span class="mono">${esc(machine.vmName)}</span>` : 'Sin máquina virtual preparada'}</small>
            </div>
            <div class="inline-buttons">${actions}</div>
          </div>
        `;
      }).join('')
      : '<div class="field-hint">Crea un perfil para preparar su máquina virtual.</div>';
    const cloneRows = state.profiles.length
      ? state.profiles.map((profile) => {
        const account = cloneAccountFor(profile.id);
        const status = account
          ? account.verifiedAt
            ? `<span class="chip is-success">Verificada ${esc(relativeTime(account.verifiedAt))}</span>`
            : '<span class="chip is-warn">Sin verificar</span>'
          : '';
        const actions = account
          ? `${status}
             <button class="btn btn-ghost btn-sm" type="button" data-action="clone-verify" data-profile="${esc(profile.id)}">${icon('check')} Probar</button>
             <button class="btn btn-ghost btn-sm" type="button" data-action="clone-release" data-profile="${esc(profile.id)}">${icon('trash')} Liberar</button>`
          : `<button class="btn btn-primary btn-sm" type="button" data-action="clone-prepare" data-profile="${esc(profile.id)}" ${clone.available && clone.encryption ? '' : 'disabled'}>${icon('shield')} Preparar (UAC)</button>`;
        return `
          <div class="clone-account-row">
            <div class="clone-account-copy">
              <strong>${esc(profile.name)}</strong>
              <small>${account ? `Cuenta <span class="mono">${esc(account.username)}</span>` : 'Sin cuenta de Windows preparada'}</small>
            </div>
            <div class="inline-buttons">${actions}</div>
          </div>
        `;
      }).join('')
      : '<div class="field-hint">Crea un perfil para preparar su cuenta de Windows.</div>';
    const license = state.license || {};
    const licenseExpiry = license.expiresAt
      ? new Date(license.expiresAt).toLocaleDateString('es-ES', { day: '2-digit', month: 'short', year: 'numeric' })
      : 'Permanente';
    const statusList = profileStatuses();
    const statusRows = statusList.length
      ? statusList.map((status) => {
        const usage = state.profiles.filter((profile) => profile.statusId === status.id).length;
        return `
          <div class="status-manage-row">
            <span class="status-pill" style="--status-color:${safeColor(status.color)}"><i></i>${esc(status.name)}</span>
            <span class="field-hint">${usage ? plural(usage, 'perfil', 'perfiles') : 'Sin usar'}</span>
            <span class="toolbar-spacer"></span>
            <button class="btn-icon-sm" type="button" data-action="status-edit" data-id="${esc(status.id)}" title="Editar estado" aria-label="Editar estado ${esc(status.name)}">${icon('edit')}</button>
            <button class="btn-icon-sm is-danger" type="button" data-action="status-delete" data-id="${esc(status.id)}" title="Eliminar estado" aria-label="Eliminar estado ${esc(status.name)}">${icon('trash')}</button>
          </div>
        `;
      }).join('')
      : '<div class="field-hint">Todavía no hay estados. Crea el primero para clasificar tus perfiles.</div>';

    return `
      <div class="settings-layout">
        <div class="settings-col">
          <section class="settings-card">
            <div class="settings-card-head">
              <h2>${icon('sparkle')} Apariencia</h2>
              <p>Elige cómo se ve PerfilLab. El tema del sistema se adapta automáticamente.</p>
            </div>
            <div class="theme-options">
              ${themeOption('system', 'Sistema', 'pv-system')}
              ${themeOption('light', 'Claro', 'pv-light')}
              ${themeOption('dark', 'Oscuro', 'pv-dark')}
            </div>
            <div class="settings-rows">
              <div class="setting-row">
                <div class="setting-info">
                  <strong>Cerrar a la bandeja</strong>
                  <p>Al cerrar la ventana, PerfilLab sigue activo en la bandeja del sistema.</p>
                </div>
                <div class="setting-control">
                  <label class="switch" title="Cerrar a la bandeja">
                    <input type="checkbox" id="setting-close-tray" ${settings.closeToTray ? 'checked' : ''} aria-label="Cerrar a la bandeja">
                    <span class="switch-track"></span>
                  </label>
                </div>
              </div>
            </div>
          </section>

          <section class="settings-card">
            <div class="settings-card-head">
              <h2>${icon('tag')} Estados de perfil</h2>
              <p>Etiquetas con color para seguir el estado de cada perfil. Se asignan al editarlo o en masa.</p>
            </div>
            <div class="settings-rows">
              <div class="status-manage-list">${statusRows}</div>
            </div>
            <div class="settings-inline-actions">
              <button class="btn btn-ghost btn-sm" type="button" data-action="status-new" ${statusList.length >= 30 ? 'disabled' : ''}>${icon('plus')} Nuevo estado</button>
              <span class="field-hint">${statusList.length} de 30 estados.</span>
            </div>
          </section>

          <section class="settings-card">
            <div class="settings-card-head">
              <h2>${icon('monitor')} Navegador integrado</h2>
              <p>PerfilLab Browser es el único navegador. No hace falta instalar Chrome, Edge ni ningún otro programa.</p>
            </div>
            <div class="settings-rows">
              <div class="browser-row">
                <div class="browser-row-icon">${icon('monitor')}</div>
                <div class="browser-row-copy">
                  <strong>PerfilLab Browser <span class="chip is-accent">Incluido</span></strong>
                  <small>${builtin ? `Chromium ${esc(builtin.engineVersion || '—')} · datos aislados por perfil` : 'Navegador integrado no disponible'}</small>
                </div>
                <span class="chip is-success">Único</span>
              </div>
              <div class="setting-row">
                <div class="setting-info">
                  <strong>Sin navegadores externos</strong>
                  <p>Todos los perfiles se abren en PerfilLab Browser. Los navegadores del sistema y los ejecutables personalizados ya no se usan.</p>
                </div>
              </div>
            </div>
          </section>
        </div>

        <div class="settings-col">
          <section class="settings-card">
            <div class="settings-card-head">
              <h2>${icon('shield')} Clonador nativo</h2>
              <p>Cuentas locales de Windows por perfil para abrir aplicaciones .exe con datos separados.</p>
            </div>
            <div class="settings-rows">
              <div class="setting-row">
                <div class="setting-info">
                  <strong>Estado del motor</strong>
                  <p>${!clone.checked
                    ? 'Consultando Windows PowerShell…'
                    : clone.available
                      ? `${esc(clone.os || 'Windows')} · PowerShell ${esc(clone.powershell || '—')} · ${clone.uac ? 'UAC activo' : 'UAC desactivado'}`
                      : esc(clone.error || 'El clonador nativo no está disponible.')}</p>
                </div>
                <div class="setting-control">
                  <span class="chip ${clone.available ? 'is-success' : clone.checked ? 'is-danger' : ''}">${!clone.checked ? 'Comprobando' : clone.available ? 'Disponible' : 'No disponible'}</span>
                </div>
              </div>
              <div class="setting-row">
                <div class="setting-info">
                  <strong>Credenciales</strong>
                  <p>${clone.encryption ? 'Las contraseñas de las cuentas clon se guardan cifradas con el almacén seguro de Windows.' : 'El cifrado del sistema no está disponible; no se pueden preparar cuentas hasta que Windows lo habilite.'}</p>
                </div>
                <div class="setting-control">
                  <span class="chip ${clone.encryption ? 'is-success' : 'is-warn'}">${clone.encryption ? 'Cifradas' : 'Sin cifrado'}</span>
                </div>
              </div>
            </div>
            <div class="settings-inline-actions">
              <button class="btn btn-ghost btn-sm" type="button" data-action="clone-refresh">${icon('refresh')} Volver a diagnosticar</button>
              <span class="field-hint">${preparedAccounts} de ${state.profiles.length} perfiles con cuenta preparada.</span>
            </div>
            <div class="clone-account-list">
              <div class="clone-account-head">
                <strong>Cuentas por perfil</strong>
                <span class="field-hint">El modo Cuenta de Windows se elige al editar cada aplicación.</span>
              </div>
              ${cloneRows}
            </div>
            <div class="card-pad">
              <div class="callout ${clone.available && clone.encryption ? '' : 'is-warn'}">
                ${icon('shield')}
                <div>
                  <strong>Sin software de terceros.</strong> PerfilLab crea una cuenta local estándar por perfil con contraseña aleatoria cifrada. Windows solicitará UAC al preparar, reparar o liberar la cuenta; nunca verás la contraseña en la interfaz ni en los registros.
                  <div class="field-hint" style="margin-top:6px">Aísla HKCU, AppData, TEMP y el perfil de usuario de Windows. No es una barrera de seguridad frente a código malicioso y no eleva aplicaciones que requieran administrador. Los programas del menú Inicio no admiten cuenta clon.</div>
                </div>
              </div>
            </div>
          </section>

          <section class="settings-card">
            <div class="settings-card-head">
              <h2>${icon('monitor')} Máquinas virtuales</h2>
              <p>Hyper-V nativo: una máquina virtual por perfil para aplicaciones que no se pueden duplicar con cuentas.</p>
            </div>
            <div class="settings-rows">
              <div class="setting-row">
                <div class="setting-info">
                  <strong>Estado de Hyper-V</strong>
                  <p>${!vm.checked
                    ? 'Consultando Windows PowerShell…'
                    : vm.available
                      ? `${esc(vm.os || 'Windows')} ${esc(vm.version || '')} · ${vm.ramGb ? `${vm.ramGb} GB de RAM` : 'RAM no detectada'}`
                      : esc(vm.error || 'Hyper-V no está disponible en este equipo.')}</p>
                </div>
                <div class="setting-control">
                  <span class="chip ${vm.available ? 'is-success' : vm.checked ? 'is-danger' : ''}">${!vm.checked ? 'Comprobando' : vm.available ? 'Disponible' : 'No disponible'}</span>
                </div>
              </div>
              <div class="setting-row">
                <div class="setting-info">
                  <strong>Imagen base (.vhdx)</strong>
                  <p>Cada perfil recibe un disco diferencial sobre esta imagen. Debe tener Windows instalado y estar apagada; PerfilLab no la modifica.</p>
                </div>
              </div>
              <div class="settings-inline-actions column">
                <input class="input is-mono" type="text" readonly value="${esc(vmSettings.baseImagePath || '')}" placeholder="Ninguna imagen seleccionada" title="${esc(vmSettings.baseImagePath || '')}" aria-label="Imagen base de Hyper-V">
                <div class="inline-buttons">
                  <button class="btn btn-ghost btn-sm" type="button" data-action="vm-pick-base">${icon('folder')} Elegir .vhdx</button>
                  <button class="btn btn-ghost btn-sm" type="button" data-action="vm-refresh">${icon('refresh')} Volver a diagnosticar</button>
                </div>
              </div>
              <div class="setting-row">
                <div class="setting-info">
                  <strong>Conmutador virtual</strong>
                  <p>Nombre del conmutador de Hyper-V. «Default Switch» usa NAT y suele funcionar sin configuración extra.</p>
                </div>
                <div class="setting-control wide">
                  <input class="input" id="vm-switch" list="vm-switch-list" maxlength="100" value="${esc(vmSettings.switchName || 'Default Switch')}" aria-label="Conmutador virtual">
                  <datalist id="vm-switch-list"></datalist>
                  <button class="btn btn-ghost btn-sm" type="button" data-action="vm-switches" title="Windows pedirá UAC para consultar los conmutadores">Detectar</button>
                </div>
              </div>
              <div class="setting-row">
                <div class="setting-info">
                  <strong>Memoria y procesadores</strong>
                  <p>Memoria dinámica por máquina encendida (1024–32768 MB) y hasta 16 procesadores virtuales.</p>
                </div>
                <div class="setting-control wide">
                  <input class="input" id="vm-memory" type="number" min="1024" max="32768" step="512" value="${Number(vmSettings.memoryMb) || 4096}" aria-label="Memoria en MB">
                  <input class="input" id="vm-cpu" type="number" min="1" max="16" step="1" value="${Number(vmSettings.cpuCount) || 2}" aria-label="Procesadores virtuales">
                  <select class="select" id="vm-generation" aria-label="Generación de la máquina virtual">
                    <option value="2" ${Number(vmSettings.generation) === 2 ? 'selected' : ''}>Generación 2</option>
                    <option value="1" ${Number(vmSettings.generation) === 1 ? 'selected' : ''}>Generación 1</option>
                  </select>
                </div>
              </div>
              <div class="setting-row">
                <div class="setting-info">
                  <strong>Carpeta de discos</strong>
                  <p>Vacío = carpeta de datos de PerfilLab. Los discos diferenciales pueden crecer hasta el tamaño de la imagen base.</p>
                </div>
                <div class="setting-control wide">
                  <input class="input is-mono" id="vm-disks-dir" type="text" maxlength="1000" value="${esc(vmSettings.disksDir || '')}" placeholder="Predeterminada" aria-label="Carpeta de discos">
                </div>
              </div>
            </div>
            <div class="settings-inline-actions">
              <button class="btn btn-primary btn-sm" type="button" data-action="vm-save-config">Guardar configuración</button>
              <span class="field-hint">La configuración se aplica a las máquinas nuevas; las existentes conservan su memoria y CPU hasta que las recrees.</span>
            </div>
            <div class="clone-account-list">
              <div class="clone-account-head">
                <strong>Máquinas por perfil</strong>
                <span class="field-hint">El modo Máquina virtual se elige al editar cada aplicación.</span>
              </div>
              ${vmMachineRows}
            </div>
            <div class="card-pad">
              <div class="callout ${vm.available && vmSettings.baseImagePath ? '' : 'is-warn'}">
                ${icon('monitor')}
                <div>
                  <strong>Límites reales del modo máquina virtual.</strong> Una máquina por perfil, unos 4 GB de RAM por máquina encendida y una licencia de Windows válida para cada VM. PerfilLab no inicia la aplicación dentro del invitado: abre la ventana de la máquina y tú ejecutas el programa allí. Sin aceleración de GPU y con el rendimiento de la virtualización; algunas aplicaciones antifraude detectan Hyper-V.
                  <div class="field-hint" style="margin-top:6px">Windows pedirá UAC para crear, encender, detener o eliminar cada máquina. Al detenerla se guarda su estado para la próxima sesión.</div>
                </div>
              </div>
            </div>
          </section>

          <section class="settings-card">
            <div class="settings-card-head">
              <h2>${icon('folder')} Datos y almacenamiento</h2>
              <p>Las carpetas de los perfiles y la base local viven en este equipo.</p>
            </div>
            <div class="settings-rows">
              <div class="setting-row">
                <div class="setting-info">
                  <strong>Carpeta de perfiles</strong>
                  <p>Los perfiles nuevos se crean aquí. Los existentes conservan su carpeta anterior.</p>
                </div>
              </div>
              <div class="settings-inline-actions column">
                <input class="input is-mono" id="profiles-dir" type="text" value="${esc(settings.profilesDir || '')}" placeholder="Carpeta predeterminada de la aplicación" aria-label="Carpeta de perfiles">
                <div class="inline-buttons">
                  <button class="btn btn-ghost btn-sm" type="button" data-action="settings-save-profiles-dir">Aplicar</button>
                  <button class="btn btn-ghost btn-sm" type="button" data-action="settings-open-profiles">${icon('folder')} Abrir carpeta</button>
                </div>
              </div>
              <div class="setting-row">
                <div class="setting-info">
                  <strong>Base de datos local</strong>
                  <p class="mono path-text" title="${esc(app.dataDir)}">${esc(app.dataDir || 'Calculando…')}</p>
                </div>
                <div class="setting-control">
                  <button class="btn-icon-sm" type="button" data-copy-source="data-dir" title="Copiar ruta" aria-label="Copiar ruta">${icon('copy')}</button>
                </div>
              </div>
            </div>
            <div class="card-pad">
              <div class="callout">
                ${icon('shield')}
                <div>Las contraseñas de proxy y el token de la API se guardan cifrados con el almacén seguro del sistema cuando está disponible. Las exportaciones nunca incluyen contraseñas ni tokens.</div>
              </div>
            </div>
          </section>

          <section class="settings-card">
            <div class="settings-card-head">
              <h2>${icon('terminal')} API local</h2>
              <p>Controla perfiles desde tus propios scripts.</p>
            </div>
            <div class="settings-rows">
              <div class="setting-row">
                <div class="setting-info">
                  <strong>Estado</strong>
                  <p>${settings.api.running ? `Escuchando en 127.0.0.1:${settings.api.port}` : settings.api.error || 'API desactivada'}</p>
                </div>
                <div class="setting-control">
                  <span class="chip ${settings.api.running ? 'is-success' : settings.api.error ? 'is-danger' : ''}">${settings.api.running ? 'Activa' : settings.api.error ? 'Error' : 'Inactiva'}</span>
                </div>
              </div>
            </div>
            <div class="card-pad">
              <button class="btn btn-ghost" type="button" data-go-view="api">${icon('terminal')} Configurar API local</button>
            </div>
          </section>

          <section class="settings-card">
            <div class="settings-card-head">
              <h2>${icon('key')} Licencia</h2>
              <p>Licencia local vinculada a este ordenador.</p>
            </div>
            <div class="settings-rows">
              <div class="setting-row">
                <div class="setting-info">
                  <strong>${esc(license.licenseId || 'Sin licencia')}</strong>
                  <p>${esc(license.customer || 'Entorno de desarrollo sin licencia')}</p>
                </div>
                <div class="setting-control">
                  <span class="chip ${license.licensed ? 'is-success' : license.required ? 'is-danger' : ''}">${license.licensed ? 'Activa' : license.required ? 'Inactiva' : 'Desarrollo'}</span>
                </div>
              </div>
              <div class="setting-row">
                <div class="setting-info">
                  <strong>Código de equipo</strong>
                  <p class="mono path-text">${esc(license.machineCode || '—')}</p>
                </div>
                <div class="setting-control">
                  <button class="btn-icon-sm" type="button" data-copy-source="license-machine" title="Copiar código de equipo" aria-label="Copiar código de equipo">${icon('copy')}</button>
                </div>
              </div>
              <div class="setting-row">
                <div class="setting-info">
                  <strong>Validez</strong>
                  <p>${esc(licenseExpiry)}</p>
                </div>
                <div class="setting-control">
                  <span class="field-hint">Una licencia por ordenador</span>
                </div>
              </div>
            </div>
          </section>

          <section class="settings-card">
            <div class="settings-card-head">
              <h2>${icon('info')} Acerca de PerfilLab</h2>
              <p>Gestor local de perfiles de navegador.</p>
            </div>
            <div class="about-grid">
              <div class="about-item"><small>Versión</small><span>${esc(state.app.version)}</span></div>
              <div class="about-item"><small>Plataforma</small><span>${esc(bridge ? bridge.platform : '—')}</span></div>
              <div class="about-item"><small>Navegador</small><span>PerfilLab Browser${builtin ? ` · Chromium ${esc(builtin.engineVersion || '—')}` : ''}</span></div>
              <div class="about-item"><small>Almacenamiento</small><span>JSON local + carpetas por perfil</span></div>
            </div>
          </section>
        </div>
      </div>
    `;
  }

  // ===== Profile modal =====

  function openProfileModal(profile = null) {
    const state = app.state;
    const isEdit = Boolean(profile);
    const color = profile ? profile.color : PALETTE[state.profiles.length % PALETTE.length];
    const workspaceId = profile ? profile.workspaceId : state.workspaces[0] ? state.workspaces[0].id : '';

    const workspaceOptions = state.workspaces.map((workspace) => `<option value="${esc(workspace.id)}" ${workspace.id === workspaceId ? 'selected' : ''}>${esc(workspace.name)}</option>`).join('');
    const proxyOptions = [
      `<option value="">Sin proxy</option>`,
      ...state.proxies.map((proxy) => `<option value="${esc(proxy.id)}" ${profile && profile.proxyId === proxy.id ? 'selected' : ''}>${esc(proxy.name)} · ${esc(proxy.protocol)}://${esc(proxy.host)}:${proxy.port}</option>`),
    ].join('');
    const statusOptions = [
      `<option value="">Sin estado</option>`,
      ...profileStatuses().map((status) => `<option value="${esc(status.id)}" ${profile && profile.statusId === status.id ? 'selected' : ''}>${esc(status.name)}</option>`),
    ].join('');

    const swatches = PALETTE.map((swatch) => `
      <button class="color-swatch ${swatch === color ? 'is-active' : ''}" type="button" data-color-choice="${swatch}" style="--swatch:${swatch}" title="Color ${swatch}" aria-label="Elegir color ${swatch}"></button>
    `).join('');

    const body = `
      <form class="modal-form" id="profile-form" data-mode="${isEdit ? 'edit' : 'create'}" data-id="${esc(profile ? profile.id : '')}" novalidate>
        <div class="form-error" id="profile-form-error"></div>
        <div class="field">
          <label for="pf-name">Nombre del perfil <span class="req">*</span></label>
          <input class="input" id="pf-name" name="name" maxlength="80" value="${esc(profile ? profile.name : '')}" placeholder="Ej. Tienda — cuenta principal" autocomplete="off" data-autofocus>
        </div>
        <div class="field-row">
          <div class="field">
            <label for="pf-workspace">Espacio</label>
            <select class="select" id="pf-workspace" name="workspaceId">${workspaceOptions}</select>
          </div>
          <div class="field">
            <span class="field-label">Navegador</span>
            <input class="input" type="text" value="PerfilLab Browser (incluido)" readonly aria-label="Navegador del perfil">
            <span class="field-hint">Todos los perfiles usan el navegador integrado.</span>
          </div>
        </div>
        <div class="field-row">
          <div class="field">
            <label for="pf-status">Estado</label>
            <select class="select" id="pf-status" name="statusId">${statusOptions}</select>
            <span class="field-hint">Crea tus propios estados en Ajustes.</span>
          </div>
          <div class="field">
            <label for="pf-proxy">Proxy</label>
            <select class="select" id="pf-proxy" name="proxyId">${proxyOptions}</select>
            <span class="field-hint">Un proxy por perfil, reutilizable.</span>
          </div>
        </div>
        <div class="field">
          <label for="pf-urls">URLs de inicio</label>
          <textarea id="pf-urls" name="startUrls" placeholder="https://ejemplo.com&#10;https://otra-web.com">${esc((profile ? profile.startUrls || [] : []).join('\n'))}</textarea>
          <span class="field-hint">Una por línea. Máximo 8. Si no indicas ninguna, se abrirá la página de inicio del navegador.</span>
        </div>
        <div class="field-row">
          <div class="field">
            <label for="pf-tags">Etiquetas</label>
            <input class="input" id="pf-tags" name="tags" maxlength="200" value="${esc((profile ? profile.tags || [] : []).join(', '))}" placeholder="tienda, ads, cliente" autocomplete="off">
            <span class="field-hint">Separadas por comas.</span>
          </div>
          <div class="field">
            <span class="field-label">Color</span>
            <div class="color-row">${swatches}</div>
          </div>
        </div>
        <div class="field">
          <label for="pf-notes">Notas</label>
          <textarea id="pf-notes" name="notes" maxlength="2000" placeholder="Recordatorios, correo asociado, estado de la cuenta…">${esc(profile ? profile.notes : '')}</textarea>
        </div>
      </form>
    `;

    const footer = `
      <button class="btn btn-ghost" type="button" data-close-modal>Cancelar</button>
      <button class="btn btn-primary" type="submit" form="profile-form">${isEdit ? 'Guardar cambios' : 'Crear perfil'}</button>
    `;

    return openModal({
      title: isEdit ? 'Editar perfil' : 'Nuevo perfil',
      subtitle: isEdit ? 'Los cambios se aplican la próxima vez que abras el perfil.' : 'Una carpeta de navegador independiente para esta identidad.',
      size: 'is-wide',
      body,
      footer,
    });
  }

  // ===== Proxy modal =====

  function openProxyModal(proxy = null) {
    const isEdit = Boolean(proxy);
    const body = `
      <form class="modal-form" id="proxy-form" data-mode="${isEdit ? 'edit' : 'create'}" data-id="${esc(proxy ? proxy.id : '')}" novalidate>
        <div class="form-error" id="proxy-form-error"></div>
        <div class="field-row">
          <div class="field">
            <label for="px-name">Nombre <span class="req">*</span></label>
            <input class="input" id="px-name" name="name" maxlength="60" value="${esc(proxy ? proxy.name : '')}" placeholder="Ej. Proxy residencial ES" autocomplete="off" data-autofocus>
          </div>
          <div class="field">
            <label for="px-protocol">Protocolo</label>
            <select class="select" id="px-protocol" name="protocol">
              <option value="http" ${!proxy || proxy.protocol === 'http' ? 'selected' : ''}>HTTP</option>
              <option value="https" ${proxy && proxy.protocol === 'https' ? 'selected' : ''}>HTTPS</option>
              <option value="socks5" ${proxy && proxy.protocol === 'socks5' ? 'selected' : ''}>SOCKS5</option>
            </select>
          </div>
        </div>
        <div class="field-row">
          <div class="field">
            <label for="px-host">Host <span class="req">*</span></label>
            <input class="input is-mono" id="px-host" name="host" maxlength="255" value="${esc(proxy ? proxy.host : '')}" placeholder="proxy.ejemplo.com" autocomplete="off" spellcheck="false">
          </div>
          <div class="field">
            <label for="px-port">Puerto <span class="req">*</span></label>
            <input class="input" id="px-port" name="port" type="number" min="1" max="65535" value="${proxy ? proxy.port : ''}" placeholder="8080">
          </div>
        </div>
        <div class="field-row">
          <div class="field">
            <label for="px-username">Usuario</label>
            <input class="input" id="px-username" name="username" maxlength="128" value="${esc(proxy ? proxy.username : '')}" placeholder="Opcional" autocomplete="off">
          </div>
          <div class="field">
            <label for="px-password">Contraseña</label>
            <input class="input" id="px-password" name="password" type="password" maxlength="256" placeholder="${proxy && proxy.hasPassword ? 'Guardada · dejar vacío para conservar' : 'Opcional'}" autocomplete="new-password">
          </div>
        </div>
        ${proxy && proxy.hasPassword ? `
          <div class="check-row">
            <input type="checkbox" id="proxy-clear-password">
            <label for="proxy-clear-password">Eliminar la contraseña guardada
              <small>Si la eliminas, el proxy se usará sin autenticación.</small>
            </label>
          </div>
        ` : ''}
        <div class="field">
          <label for="px-notes">Notas</label>
          <textarea id="px-notes" name="notes" maxlength="500" placeholder="Proveedor, ubicación, plan…">${esc(proxy ? proxy.notes : '')}</textarea>
        </div>
        <div class="test-result" id="proxy-test-result"></div>
      </form>
    `;

    const footer = `
      <div class="foot-left">
        <button class="btn btn-ghost" type="button" id="proxy-test-btn">${icon('refresh')} Probar conexión</button>
      </div>
      <button class="btn btn-ghost" type="button" data-close-modal>Cancelar</button>
      <button class="btn btn-primary" type="submit" form="proxy-form">${isEdit ? 'Guardar cambios' : 'Crear proxy'}</button>
    `;

    const entry = openModal({
      title: isEdit ? 'Editar proxy' : 'Nuevo proxy',
      subtitle: 'Las credenciales se guardan cifradas y no se exportan.',
      body,
      footer,
      onMount(root) {
        const form = root.querySelector('#proxy-form');
        const testButton = root.querySelector('#proxy-test-btn');
        const resultBox = root.querySelector('#proxy-test-result');
        const clearPassword = root.querySelector('#proxy-clear-password');
        const passwordInput = root.querySelector('#px-password');

        if (clearPassword && passwordInput) {
          clearPassword.addEventListener('change', () => {
            passwordInput.disabled = clearPassword.checked;
            if (clearPassword.checked) passwordInput.value = '';
          });
        }

        testButton.addEventListener('click', async () => {
          if (testButton.dataset.busy === '1') return;
          const payload = readProxyForm(form);
          if (!payload.host || !payload.port) {
            resultBox.className = 'test-result is-visible is-error';
            resultBox.textContent = 'Indica el host y el puerto antes de probar.';
            return;
          }
          if (isEdit) payload.id = proxy.id;
          testButton.dataset.busy = '1';
          const original = testButton.innerHTML;
          testButton.disabled = true;
          testButton.innerHTML = '<span class="spinner-xs"></span> Probando…';
          resultBox.className = 'test-result is-visible';
          resultBox.textContent = 'Conectando a través del proxy…';
          try {
            const result = await callAction('proxy:test', payload);
            if (result.ok) {
              resultBox.className = 'test-result is-visible is-ok';
              resultBox.textContent = `Conexión correcta · IP ${result.ip} · ${result.latencyMs} ms`;
            } else {
              resultBox.className = 'test-result is-visible is-error';
              resultBox.textContent = result.error || 'No se pudo conectar.';
            }
          } catch (error) {
            resultBox.className = 'test-result is-visible is-error';
            resultBox.textContent = error.message;
          } finally {
            testButton.dataset.busy = '';
            testButton.disabled = false;
            testButton.innerHTML = original;
          }
        });
      },
    });
    return entry;
  }

  function readProxyForm(form) {
    const data = new FormData(form);
    const payload = {
      name: String(data.get('name') || '').trim(),
      protocol: String(data.get('protocol') || 'http'),
      host: String(data.get('host') || '').trim(),
      port: Number(data.get('port')),
      username: String(data.get('username') || '').trim(),
      notes: String(data.get('notes') || '').trim(),
    };
    const password = String(data.get('password') || '');
    if (password) payload.password = password;
    const clear = form.querySelector('#proxy-clear-password');
    if (clear && clear.checked) payload.clearPassword = true;
    return payload;
  }

  // ===== Workspace modal =====

  function openWorkspaceModal(workspace = null) {
    const isEdit = Boolean(workspace);
    const color = workspace ? workspace.color : PALETTE[app.state.workspaces.length % PALETTE.length];
    const swatches = PALETTE.map((swatch) => `
      <button class="color-swatch ${swatch === color ? 'is-active' : ''}" type="button" data-color-choice="${swatch}" style="--swatch:${swatch}" title="Color ${swatch}" aria-label="Elegir color ${swatch}"></button>
    `).join('');

    const body = `
      <form class="modal-form" id="workspace-form" data-mode="${isEdit ? 'edit' : 'create'}" data-id="${esc(workspace ? workspace.id : '')}" novalidate>
        <div class="form-error" id="workspace-form-error"></div>
        <div class="field">
          <label for="ws-name">Nombre del espacio <span class="req">*</span></label>
          <input class="input" id="ws-name" name="name" maxlength="40" value="${esc(workspace ? workspace.name : '')}" placeholder="Ej. Clientes, Marketing, Proyecto Norte" autocomplete="off" data-autofocus>
        </div>
        <div class="field">
          <span class="field-label">Color</span>
          <div class="color-row">${swatches}</div>
        </div>
      </form>
    `;

    return openModal({
      title: isEdit ? 'Editar espacio' : 'Nuevo espacio',
      subtitle: 'Agrupa perfiles para mantener el panel ordenado.',
      size: 'is-narrow',
      body,
      footer: `
        <button class="btn btn-ghost" type="button" data-close-modal>Cancelar</button>
        <button class="btn btn-primary" type="submit" form="workspace-form">${isEdit ? 'Guardar cambios' : 'Crear espacio'}</button>
      `,
    });
  }

  // ===== Status modal =====

  function openStatusModal(status = null) {
    const isEdit = Boolean(status);
    const color = status ? status.color : PALETTE[profileStatuses().length % PALETTE.length];
    const swatches = PALETTE.map((swatch) => `
      <button class="color-swatch ${swatch === color ? 'is-active' : ''}" type="button" data-color-choice="${swatch}" style="--swatch:${swatch}" title="Color ${swatch}" aria-label="Elegir color ${swatch}"></button>
    `).join('');

    const body = `
      <form class="modal-form" id="status-form" data-mode="${isEdit ? 'edit' : 'create'}" data-id="${esc(status ? status.id : '')}" novalidate>
        <div class="form-error" id="status-form-error"></div>
        <div class="field">
          <label for="st-name">Nombre del estado <span class="req">*</span></label>
          <input class="input" id="st-name" name="name" maxlength="32" value="${esc(status ? status.name : '')}" placeholder="Ej. En revisión, Cerrado, Pendiente de pago" autocomplete="off" data-autofocus>
        </div>
        <div class="field">
          <span class="field-label">Color</span>
          <div class="color-row">${swatches}</div>
        </div>
      </form>
    `;

    return openModal({
      title: isEdit ? 'Editar estado' : 'Nuevo estado',
      subtitle: 'Los estados son etiquetas con color para clasificar y filtrar perfiles.',
      size: 'is-narrow',
      body,
      footer: `
        <button class="btn btn-ghost" type="button" data-close-modal>Cancelar</button>
        <button class="btn btn-primary" type="submit" form="status-form">${isEdit ? 'Guardar cambios' : 'Crear estado'}</button>
      `,
    });
  }

  // ===== Delete / confirm modals =====

  function openDeleteProfileModal(profile) {
    const running = Boolean(runningFor(profile.id));
    const cloneAccount = cloneAccountFor(profile.id);
    const vmMachine = vmMachineFor(profile.id);
    openModal({
      title: 'Eliminar perfil',
      subtitle: profile.name,
      size: 'is-narrow',
      body: `
        <p class="confirm-copy">
          Se eliminará el perfil <strong>${esc(profile.name)}</strong> de PerfilLab.
          ${running ? ' El navegador de este perfil se cerrará antes de continuar.' : ''}
          Esta acción no se puede deshacer.
        </p>
        <div class="check-row">
          <input type="checkbox" id="delete-profile-data">
          <label for="delete-profile-data">Eliminar también la carpeta de datos del navegador
            <small>Se borrarán cookies, sesiones e historial guardados en la carpeta del perfil.</small>
          </label>
        </div>
        ${cloneAccount ? `
          <div class="callout is-warn">
            ${icon('shield')}
            <div><strong>Este perfil tiene una cuenta de Windows clon.</strong> También se eliminará la cuenta local <span class="mono">${esc(cloneAccount.username)}</span> y su carpeta de usuario. Windows pedirá permisos de administrador.</div>
          </div>
          <div class="check-row">
            <input type="checkbox" id="delete-profile-clone" checked>
            <label for="delete-profile-clone">Eliminar la cuenta de Windows del clon
              <small>Necesario para no dejar cuentas huérfanas. Si lo desactivas, el perfil no se eliminará.</small>
            </label>
          </div>
        ` : ''}
        ${vmMachine ? `
          <div class="callout is-warn">
            ${icon('monitor')}
            <div><strong>Este perfil tiene una máquina virtual Hyper-V.</strong> También se eliminará la máquina <span class="mono">${esc(vmMachine.vmName)}</span> y su disco diferencial, incluidos los datos guardados dentro del invitado. Windows pedirá permisos de administrador.</div>
          </div>
          <div class="check-row">
            <input type="checkbox" id="delete-profile-vm" checked>
            <label for="delete-profile-vm">Eliminar la máquina virtual y su disco
              <small>Necesario para no dejar máquinas huérfanas. Si lo desactivas, el perfil no se eliminará.</small>
            </label>
          </div>
        ` : ''}
        <div class="form-error" id="delete-profile-error"></div>
      `,
      footer: `
        <button class="btn btn-ghost" type="button" data-close-modal>Cancelar</button>
        <button class="btn btn-danger" type="button" id="delete-profile-confirm">Eliminar perfil</button>
      `,
      onMount(root, entry) {
        const button = root.querySelector('#delete-profile-confirm');
        const errorBox = root.querySelector('#delete-profile-error');
        button.addEventListener('click', async () => {
          if (button.dataset.busy === '1') return;
          button.dataset.busy = '1';
          button.disabled = true;
          const original = button.innerHTML;
          button.innerHTML = '<span class="spinner-xs"></span> Eliminando…';
          try {
            const deleteData = root.querySelector('#delete-profile-data').checked;
            const releaseCloneAccount = cloneAccount
              ? root.querySelector('#delete-profile-clone').checked
              : false;
            const removeVirtualMachine = vmMachine
              ? root.querySelector('#delete-profile-vm').checked
              : false;
            await callAction('profile:delete', { id: profile.id, deleteData, releaseCloneAccount, removeVirtualMachine });
            entry.close();
            const extras = [];
            if (releaseCloneAccount) extras.push('su cuenta de Windows');
            if (removeVirtualMachine) extras.push('su máquina virtual');
            const extra = extras.length ? ` y ${extras.join(' y ')}` : '';
            toast(deleteData ? `Perfil, datos${extra} eliminados.` : `Perfil${extra} eliminado.`, 'success');
          } catch (error) {
            errorBox.textContent = error.message;
            errorBox.classList.add('is-visible');
            button.disabled = false;
            button.innerHTML = original;
            button.dataset.busy = '';
          }
        });
      },
    });
  }

  function openDeleteProxyModal(proxy) {
    const affected = app.state.profiles.filter((profile) => profile.proxyId === proxy.id).length;
    openConfirmModal({
      title: 'Eliminar proxy',
      subtitle: proxy.name,
      message: `Se eliminará el proxy <strong>${esc(proxy.name)}</strong>.${affected ? ` ${plural(affected, 'perfil quedará sin proxy', 'perfiles quedarán sin proxy')}.` : ''} Esta acción no se puede deshacer.`,
      confirmLabel: 'Eliminar proxy',
      onConfirm: async () => {
        await callAction('proxy:delete', { id: proxy.id });
        toast('Proxy eliminado.', 'success');
      },
    });
  }

  function openDeleteWorkspaceModal(workspace) {
    const profiles = app.state.profiles.filter((profile) => profile.workspaceId === workspace.id);
    if (profiles.length) {
      openModal({
        title: 'No se puede eliminar el espacio',
        subtitle: workspace.name,
        size: 'is-narrow',
        body: `
          <p class="confirm-copy">
            <strong>${esc(workspace.name)}</strong> todavía contiene ${plural(profiles.length, 'perfil', 'perfiles')}.
            Mueve esos perfiles a otro espacio antes de eliminarlo.
          </p>
          <div class="callout is-warn">${icon('alert')}<div>Puedes cambiar el espacio de cada perfil desde su ventana de edición.</div></div>
        `,
        footer: `
          <button class="btn btn-ghost" type="button" data-close-modal>Cerrar</button>
          <button class="btn btn-primary" type="button" data-action="filter-workspace" data-id="${esc(workspace.id)}">Ver perfiles</button>
        `,
      });
      return;
    }
    openConfirmModal({
      title: 'Eliminar espacio',
      subtitle: workspace.name,
      message: `Se eliminará el espacio <strong>${esc(workspace.name)}</strong>. No contiene perfiles. Esta acción no se puede deshacer.`,
      confirmLabel: 'Eliminar espacio',
      onConfirm: async () => {
        await callAction('workspace:delete', { id: workspace.id });
        toast('Espacio eliminado.', 'success');
      },
    });
  }

  function openDeleteStatusModal(status) {
    const affected = app.state.profiles.filter((profile) => profile.statusId === status.id).length;
    openConfirmModal({
      title: 'Eliminar estado',
      subtitle: status.name,
      message: `Se eliminará el estado <strong>${esc(status.name)}</strong>.${affected ? ` ${plural(affected, 'perfil quedará sin estado', 'perfiles quedarán sin estado')}.` : ''} Esta acción no se puede deshacer.`,
      confirmLabel: 'Eliminar estado',
      onConfirm: async () => {
        await callAction('status:delete', { id: status.id });
        if (app.statusFilter === status.id) app.statusFilter = 'all';
        toast('Estado eliminado.', 'success');
      },
    });
  }

  function openRegenerateTokenModal() {
    openConfirmModal({
      title: 'Regenerar token',
      subtitle: 'API local',
      message: 'Se generará un token nuevo y el anterior dejará de funcionar de inmediato. Tendrás que actualizar cualquier script o automatización que use el token actual.',
      confirmLabel: 'Regenerar token',
      onConfirm: async () => {
        await callAction('api:regenerate');
        app.apiRevealed = false;
        toast('Token regenerado. Actualiza tus scripts.', 'success');
      },
    });
  }

  function openClearActivityModal() {
    openConfirmModal({
      title: 'Vaciar historial',
      message: 'Se eliminarán todos los eventos guardados en la actividad local. Los perfiles, proxies y espacios no se verán afectados.',
      confirmLabel: 'Vaciar historial',
      onConfirm: async () => {
        await callAction('activity:clear');
        toast('Historial vaciado.', 'success');
      },
    });
  }

  // ===== Actions =====

  async function startProfile(profileId) {
    const key = `start:${profileId}`;
    if (app.busy.has(key)) return;
    const profile = profileById(profileId);
    app.busy.add(key);
    scheduleRender();
    try {
      const status = await callAction('profile:start', { id: profileId });
      toast(`"${profile ? profile.name : 'Perfil'}" iniciado con ${status.browserName}.`, 'success');
    } catch (error) {
      toast(error.message, 'error');
    } finally {
      app.busy.delete(key);
      scheduleRender();
    }
  }

  async function stopProfile(profileId) {
    const key = `stop:${profileId}`;
    if (app.busy.has(key)) return;
    const profile = profileById(profileId);
    app.busy.add(key);
    scheduleRender();
    try {
      await callAction('profile:stop', { id: profileId });
      toast(`"${profile ? profile.name : 'Perfil'}" detenido.`, 'success');
    } catch (error) {
      toast(error.message, 'error');
    } finally {
      app.busy.delete(key);
      scheduleRender();
    }
  }

  async function duplicateProfile(profileId) {
    try {
      const copy = await callAction('profile:duplicate', { id: profileId });
      toast(`Perfil duplicado como "${copy.name}".`, 'success');
    } catch (error) {
      toast(error.message, 'error');
    }
  }

  async function openProfileFolder(profileId) {
    try {
      await callAction('profile:folder', { id: profileId });
      toast('Carpeta del perfil abierta.', 'success');
    } catch (error) {
      toast(error.message, 'error');
    }
  }

  function selectedProfileIds() {
    if (!app.state) return [];
    return app.state.profiles
      .filter((profile) => app.selection.has(profile.id))
      .map((profile) => profile.id);
  }

  function selectVisibleProfiles() {
    const list = filteredProfiles();
    if (!list.length) return;
    const allSelected = list.every((profile) => app.selection.has(profile.id));
    for (const profile of list) {
      if (allSelected) app.selection.delete(profile.id);
      else app.selection.add(profile.id);
    }
    scheduleRender();
  }

  function openImportChoiceModal() {
    openModal({
      title: 'Importar perfiles',
      subtitle: 'Elige el formato del archivo',
      size: 'is-narrow',
      body: `
        <div class="choice-list">
          <button class="choice-card" type="button" data-import-format="json">
            <span class="choice-icon">${icon('layers')}</span>
            <span>
              <strong>JSON de PerfilLab</strong>
              <small>Restaura una copia de seguridad completa: espacios, proxies sin contraseñas y perfiles con sus ajustes.</small>
            </span>
          </button>
          <button class="choice-card" type="button" data-import-format="csv">
            <span class="choice-icon">${icon('appgrid')}</span>
            <span>
              <strong>Hoja de cálculo CSV</strong>
              <small>Columnas: Nombre, Espacio, Navegador, Proxy, URLs, Etiquetas, Estado, Notas y Color. Los proxies se enlazan por nombre y sus credenciales nunca se leen del CSV.</small>
            </span>
          </button>
        </div>
      `,
      footer: '<button class="btn btn-ghost" type="button" data-close-modal>Cancelar</button>',
      onMount(root, entry) {
        root.querySelectorAll('[data-import-format]').forEach((button) => {
          button.addEventListener('click', async () => {
            entry.close();
            await importProfiles(null, button.dataset.importFormat);
          });
        });
      },
    });
  }

  function formatCsvImportResult(result) {
    const issues = (result.warnings || []).length + (result.errors || []).length;
    if (!issues) {
      toast(`Importación CSV: ${plural(result.profiles, 'perfil', 'perfiles')} y ${plural(result.workspaces, 'espacio', 'espacios')}.`, 'success');
      return;
    }
    const list = (items, kind) => `<ul class="result-list ${kind}">${items.map((item) => `<li>${esc(item)}</li>`).join('')}</ul>`;
    openModal({
      title: 'Resultado de la importación CSV',
      subtitle: 'Revisa las filas que necesitan atención',
      size: 'is-narrow',
      body: `
        <p class="confirm-copy">Se crearon ${plural(result.profiles, 'perfil', 'perfiles')} y ${plural(result.workspaces, 'espacio', 'espacios')}.${result.skippedProxies ? ` ${result.skippedProxies} proxy(s) no se encontraron.` : ''}</p>
        ${(result.warnings || []).length ? `<h3 class="result-title">Avisos</h3>${list(result.warnings, 'is-warn')}` : ''}
        ${(result.errors || []).length ? `<h3 class="result-title">Errores</h3>${list(result.errors, 'is-error')}` : ''}
      `,
      footer: '<button class="btn btn-primary" type="button" data-close-modal>Entendido</button>',
    });
  }

  async function importProfiles(button, format = 'json') {
    if (button) button.disabled = true;
    try {
      const result = await callAction('data:import', { format });
      if (result.canceled) return;
      setView('profiles');
      if (format === 'csv') {
        formatCsvImportResult(result);
      } else {
        toast(`Importados ${plural(result.profiles, 'perfil', 'perfiles')}, ${plural(result.workspaces, 'espacio', 'espacios')} y ${plural(result.proxies, 'proxy', 'proxies')}.`, 'success');
      }
    } catch (error) {
      toast(error.message, 'error');
    } finally {
      if (button && button.isConnected) button.disabled = false;
    }
  }

  function openExportChoiceModal(profileIds = []) {
    const selected = profileIds.filter(Boolean);
    const count = selected.length || app.state.profiles.length;
    if (!count) {
      toast('No hay perfiles para exportar.', 'warn');
      return;
    }
    const scope = selected.length
      ? plural(count, 'perfil seleccionado', 'perfiles seleccionados')
      : plural(count, 'perfil', 'perfiles');
    openModal({
      title: 'Exportar perfiles',
      subtitle: scope,
      size: 'is-narrow',
      body: `
        <div class="choice-list">
          <button class="choice-card" type="button" data-export-format="json">
            <span class="choice-icon">${icon('layers')}</span>
            <span>
              <strong>JSON de PerfilLab</strong>
              <small>Copia de seguridad con espacios, perfiles y proxies sin contraseñas.</small>
            </span>
          </button>
          <button class="choice-card" type="button" data-export-format="csv">
            <span class="choice-icon">${icon('download')}</span>
            <span>
              <strong>Hoja de cálculo CSV</strong>
              <small>Compatible con Excel y Hojas de cálculo. Incluye solo el nombre del proxy; nunca credenciales.</small>
            </span>
          </button>
        </div>
      `,
      footer: '<button class="btn btn-ghost" type="button" data-close-modal>Cancelar</button>',
      onMount(root, entry) {
        root.querySelectorAll('[data-export-format]').forEach((button) => {
          button.addEventListener('click', async () => {
            entry.close();
            await exportProfiles(null, button.dataset.exportFormat, selected);
          });
        });
      },
    });
  }

  async function exportProfiles(button, format = 'json', profileIds = []) {
    if (button) button.disabled = true;
    try {
      const result = await callAction('data:export', { format, profileIds });
      if (result.canceled) return;
      toast(`Exportados ${plural(result.profiles, 'perfil', 'perfiles')} a ${fileName(result.path)}.`, 'success');
    } catch (error) {
      toast(error.message, 'error');
    } finally {
      if (button && button.isConnected) button.disabled = false;
    }
  }

  async function executeBatch(action, workspaceId = null, extra = {}) {
    const profileIds = selectedProfileIds();
    if (!profileIds.length) throw new Error('Selecciona al menos un perfil.');
    return callAction('profile:batch', { action, profileIds, workspaceId, ...extra });
  }

  const BATCH_VERBS = {
    start: 'iniciado(s)',
    stop: 'detenido(s)',
    move: 'movido(s)',
    'add-tags': 'con etiquetas añadidas',
    'remove-tags': 'con etiquetas quitadas',
    'set-tags': 'con etiquetas actualizadas',
    'set-status': 'con estado actualizado',
    'set-proxy': 'con proxy actualizado',
    duplicate: 'duplicado(s)',
    delete: 'eliminado(s)',
  };

  function showBatchFailures(action, results) {
    const failures = results.filter((item) => !item.ok);
    if (!failures.length) return;
    const titles = {
      start: 'No se pudieron iniciar',
      stop: 'No se pudieron detener',
      move: 'No se pudieron mover',
      'add-tags': 'No se pudieron etiquetar',
      'remove-tags': 'No se pudieron etiquetar',
      'set-tags': 'No se pudieron etiquetar',
      'set-status': 'No se pudo asignar el estado',
      'set-proxy': 'No se pudo asignar el proxy',
      duplicate: 'No se pudieron duplicar',
      delete: 'No se pudieron eliminar',
    };
    openModal({
      title: titles[action] || 'Acción completada con errores',
      subtitle: plural(failures.length, 'perfil con error', 'perfiles con error'),
      size: 'is-narrow',
      body: `<ul class="result-list is-error">${failures.slice(0, 50).map((item) => `<li><strong>${esc(item.name || item.profileId)}</strong><br>${esc(item.error || 'Error desconocido')}</li>`).join('')}</ul>`,
      footer: '<button class="btn btn-primary" type="button" data-close-modal>Entendido</button>',
    });
  }

  function reportBatch(action, result, detail = '') {
    const verb = BATCH_VERBS[action] || 'procesado(s)';
    toast(`${result.succeeded} ${detail || verb}. ${result.skipped} sin cambios, ${result.failed} con error.`, result.failed ? 'warn' : 'success');
    showBatchFailures(action, result.results);
  }

  async function runBatch(action, workspaceId = null) {
    if (app.batchBusy) return;
    if (!selectedProfileIds().length) {
      toast('Selecciona al menos un perfil.', 'warn');
      return;
    }
    app.batchBusy = true;
    scheduleRender();
    try {
      const result = await executeBatch(action, workspaceId);
      reportBatch(action, result);
      if (action === 'move') app.selection.clear();
    } catch (error) {
      toast(error.message, 'error');
    } finally {
      app.batchBusy = false;
      scheduleRender();
    }
  }

  function openBulkMoveModal() {
    const count = app.selection.size;
    if (!count) {
      toast('Selecciona al menos un perfil.', 'warn');
      return;
    }
    const options = app.state.workspaces
      .map((workspace) => `<option value="${esc(workspace.id)}">${esc(workspace.name)}</option>`)
      .join('');
    openConfirmModal({
      title: 'Mover perfiles',
      subtitle: plural(count, 'perfil seleccionado', 'perfiles seleccionados'),
      message: 'Elige el espacio de trabajo de destino.',
      extra: `<label class="field"><span class="field-label">Espacio</span><select class="select" id="bulk-workspace" style="width:100%">${options}</select></label>`,
      confirmLabel: 'Mover',
      danger: false,
      onConfirm: async () => {
        const workspaceId = document.getElementById('bulk-workspace')?.value;
        if (!workspaceId) throw new Error('Selecciona un espacio de trabajo.');
        const workspace = workspaceById(workspaceId);
        const result = await executeBatch('move', workspaceId);
        app.selection.clear();
        reportBatch('move', result, `movido(s) a "${workspace ? workspace.name : 'otro espacio'}"`);
      },
    });
  }

  function openBulkTagsModal() {
    const count = app.selection.size;
    if (!count) {
      toast('Selecciona al menos un perfil.', 'warn');
      return;
    }
    openConfirmModal({
      title: 'Editar etiquetas',
      subtitle: plural(count, 'perfil seleccionado', 'perfiles seleccionados'),
      message: 'Indica las etiquetas y cómo quieres aplicarlas. Cada perfil admite hasta 10 etiquetas.',
      extra: `
        <label class="field">
          <span class="field-label">Acción</span>
          <select class="select" id="bulk-tags-mode" style="width:100%">
            <option value="add-tags">Añadir a las etiquetas actuales</option>
            <option value="remove-tags">Quitar las etiquetas indicadas</option>
            <option value="set-tags">Reemplazar todas las etiquetas</option>
          </select>
        </label>
        <label class="field">
          <span class="field-label">Etiquetas</span>
          <input class="input" id="bulk-tags-input" maxlength="200" placeholder="Ej. cliente, revisar, vip" autocomplete="off">
          <span class="field-hint">Sepáralas con comas. Cada etiqueta puede tener hasta 24 caracteres.</span>
        </label>
      `,
      confirmLabel: 'Aplicar etiquetas',
      danger: false,
      onConfirm: async () => {
        const mode = document.getElementById('bulk-tags-mode')?.value || 'add-tags';
        const tags = String(document.getElementById('bulk-tags-input')?.value || '').trim();
        if (!tags) throw new Error('Escribe al menos una etiqueta.');
        const result = await executeBatch(mode, null, { tags });
        reportBatch(mode, result);
      },
    });
  }

  function openBulkStatusModal() {
    const count = app.selection.size;
    if (!count) {
      toast('Selecciona al menos un perfil.', 'warn');
      return;
    }
    const options = profileStatuses()
      .map((status) => `<option value="${esc(status.id)}">${esc(status.name)}</option>`)
      .join('');
    openConfirmModal({
      title: 'Asignar estado',
      subtitle: plural(count, 'perfil seleccionado', 'perfiles seleccionados'),
      message: 'Elige el estado que se aplicará a todos los perfiles seleccionados. Puedes quitarlo después con «Sin estado».',
      extra: `<label class="field"><span class="field-label">Estado</span><select class="select" id="bulk-status" style="width:100%"><option value="">Sin estado</option>${options}</select></label>`,
      confirmLabel: 'Asignar estado',
      danger: false,
      onConfirm: async () => {
        const statusId = document.getElementById('bulk-status')?.value || null;
        if (statusId && !profileStatusById(statusId)) throw new Error('El estado seleccionado ya no existe.');
        const status = statusId ? profileStatusById(statusId) : null;
        const result = await executeBatch('set-status', null, { statusId });
        reportBatch('set-status', result, status ? `con estado "${status.name}"` : 'sin estado');
      },
    });
  }

  function openBulkProxyModal() {
    const count = app.selection.size;
    if (!count) {
      toast('Selecciona al menos un perfil.', 'warn');
      return;
    }
    const proxies = app.state.proxies || [];
    const options = proxies
      .map((proxy) => `<option value="${esc(proxy.id)}">${esc(proxy.name)}</option>`)
      .join('');
    openConfirmModal({
      title: 'Asignar proxy',
      subtitle: plural(count, 'perfil seleccionado', 'perfiles seleccionados'),
      message: 'Elige el proxy que usarán los perfiles seleccionados. Las credenciales guardadas se aplican automáticamente.',
      extra: `
        <label class="field">
          <span class="field-label">Proxy</span>
          <select class="select" id="bulk-proxy" style="width:100%"><option value="">Sin proxy</option>${options}</select>
        </label>
        ${proxies.length ? '' : '<div class="callout is-warn">' + icon('alert') + '<div>No hay proxies guardados. Puedes quitar el proxy de los perfiles seleccionados o crear uno en la sección Proxies.</div></div>'}
      `,
      confirmLabel: 'Asignar proxy',
      danger: false,
      onConfirm: async () => {
        const proxyId = document.getElementById('bulk-proxy')?.value || null;
        if (proxyId && !(app.state.proxies || []).some((proxy) => proxy.id === proxyId)) {
          throw new Error('El proxy seleccionado ya no existe.');
        }
        const proxy = proxyId ? proxyById(proxyId) : null;
        const result = await executeBatch('set-proxy', null, { proxyId });
        reportBatch('set-proxy', result, proxy ? `con proxy "${proxy.name}"` : 'sin proxy');
      },
    });
  }

  function openBulkDuplicateModal() {
    const count = app.selection.size;
    if (!count) {
      toast('Selecciona al menos un perfil.', 'warn');
      return;
    }
    openConfirmModal({
      title: 'Duplicar perfiles',
      subtitle: plural(count, 'perfil seleccionado', 'perfiles seleccionados'),
      message: 'Se creará una copia de cada perfil con su espacio, navegador, proxy, etiquetas, estado y URLs de inicio. Las copias no tendrán sesiones abiertas.',
      extra: '<div class="callout">' + icon('copy') + '<div>Los nombres nuevos serán «Copia de …» y se numerarán si ya existen.</div></div>',
      confirmLabel: 'Duplicar perfiles',
      danger: false,
      onConfirm: async () => {
        const result = await executeBatch('duplicate');
        reportBatch('duplicate', result);
      },
    });
  }

  function openBulkDeleteModal() {
    const count = app.selection.size;
    if (!count) {
      toast('Selecciona al menos un perfil.', 'warn');
      return;
    }
    const ids = new Set(selectedProfileIds());
    const cloneAccounts = (cloneInfo().accounts || []).filter((item) => ids.has(item.profileId));
    const vmMachines = (vmInfo().machines || []).filter((item) => ids.has(item.profileId));
    const runningCount = app.state.profiles.filter((profile) => ids.has(profile.id) && runningFor(profile.id)).length;
    openConfirmModal({
      title: 'Eliminar perfiles',
      subtitle: plural(count, 'perfil seleccionado', 'perfiles seleccionados'),
      message: `Se eliminarán ${plural(count, 'perfil', 'perfiles')} de PerfilLab.${runningCount ? ` Se cerrarán ${plural(runningCount, 'navegador en ejecución', 'navegadores en ejecución')}.` : ''} Esta acción no se puede deshacer.`,
      extra: `
        <div class="check-row">
          <input type="checkbox" id="bulk-delete-data">
          <label for="bulk-delete-data">Eliminar también las carpetas de datos del navegador
            <small>Se borrarán cookies, sesiones e historial guardados de esos perfiles.</small>
          </label>
        </div>
        ${cloneAccounts.length ? `
          <div class="callout is-warn">
            ${icon('shield')}
            <div><strong>${plural(cloneAccounts.length, 'perfil tiene una cuenta de Windows clon', 'perfiles tienen una cuenta de Windows clon')}.</strong> Marca la casilla para eliminarlas; si no, esos perfiles no se eliminarán.</div>
          </div>
          <div class="check-row">
            <input type="checkbox" id="bulk-delete-clone" checked>
            <label for="bulk-delete-clone">Eliminar las cuentas de Windows clon
              <small>Se borrarán sus carpetas de usuario. Windows pedirá permisos de administrador.</small>
            </label>
          </div>
        ` : ''}
        ${vmMachines.length ? `
          <div class="callout is-warn">
            ${icon('monitor')}
            <div><strong>${plural(vmMachines.length, 'perfil tiene una máquina virtual Hyper-V', 'perfiles tienen una máquina virtual Hyper-V')}.</strong> Marca la casilla para eliminarlas con su disco; si no, esos perfiles no se eliminarán.</div>
          </div>
          <div class="check-row">
            <input type="checkbox" id="bulk-delete-vm" checked>
            <label for="bulk-delete-vm">Eliminar las máquinas virtuales y sus discos
              <small>También se borran los datos guardados dentro del invitado.</small>
            </label>
          </div>
        ` : ''}
      `,
      confirmLabel: `Eliminar ${plural(count, 'perfil', 'perfiles')}`,
      onConfirm: async () => {
        const deleteData = document.getElementById('bulk-delete-data')?.checked || false;
        const releaseCloneAccount = cloneAccounts.length
          ? Boolean(document.getElementById('bulk-delete-clone')?.checked)
          : false;
        const removeVirtualMachine = vmMachines.length
          ? Boolean(document.getElementById('bulk-delete-vm')?.checked)
          : false;
        const result = await executeBatch('delete', null, { deleteData, releaseCloneAccount, removeVirtualMachine });
        app.selection.clear();
        reportBatch('delete', result);
      },
    });
  }

  async function testProxiesBulk(ids = null) {
    if (app.proxyBulkBusy) return;
    const all = app.state.proxies;
    const explicit = Array.isArray(ids);
    const requested = explicit
      ? [...new Set(ids)]
      : all.map((proxy) => proxy.id);
    const existing = requested.filter((id) => all.some((proxy) => proxy.id === id));
    if (!existing.length) {
      toast(explicit ? 'Los perfiles seleccionados no usan proxies guardados.' : 'No hay proxies para probar.', 'warn');
      return;
    }
    app.proxyBulkBusy = true;
    for (const id of existing) app.testResults.set(id, { status: 'pending' });
    scheduleRender();
    try {
      let ok = 0;
      let total = 0;
      for (let index = 0; index < existing.length; index += 50) {
        const chunk = existing.slice(index, index + 50);
        const result = await callAction('proxy:test-many', { ids: chunk });
        for (const item of result.results) {
          app.testResults.set(item.proxyId, item.ok
            ? { status: 'ok', ip: item.ip || '—', latencyMs: item.latencyMs }
            : { status: 'error', error: item.error || 'No se pudo conectar.' });
        }
        ok += result.ok;
        total += result.total;
        scheduleRender();
      }
      toast(`Prueba de proxies: ${ok} de ${total} disponibles.`, ok === total ? 'success' : 'warn');
    } catch (error) {
      for (const id of existing) app.testResults.delete(id);
      toast(error.message, 'error');
    } finally {
      app.proxyBulkBusy = false;
      scheduleRender();
    }
  }

  async function testProxyFromList(proxyId) {
    if (app.testResults.get(proxyId)?.status === 'pending') return;
    app.testResults.set(proxyId, { status: 'pending' });
    scheduleRender();
    try {
      const result = await callAction('proxy:test', { id: proxyId });
      app.testResults.set(proxyId, result.ok
        ? { status: 'ok', ip: result.ip, latencyMs: result.latencyMs }
        : { status: 'error', error: result.error || 'No se pudo conectar.' });
    } catch (error) {
      app.testResults.set(proxyId, { status: 'error', error: error.message });
    }
    scheduleRender();
  }

  async function refreshState() {
    const state = await callAction('state:get');
    applyState(state);
    return state;
  }

  async function saveSettings(patch, successMessage) {
    try {
      await callAction('settings:update', patch);
      if (successMessage) toast(successMessage, 'success');
      return true;
    } catch (error) {
      toast(error.message, 'error');
      scheduleRender();
      return false;
    }
  }

  async function chooseTheme(theme) {
    document.documentElement.dataset.theme = theme === 'system' ? systemTheme() : theme;
    await saveSettings({ theme });
  }

  async function saveProfilesDir() {
    const input = document.getElementById('profiles-dir');
    if (!input) return;
    const value = input.value.trim();
    const ok = await saveSettings({ profilesDir: value }, value ? 'Carpeta de perfiles actualizada.' : 'Se usará la carpeta predeterminada.');
    if (ok) await refreshState().catch(() => {});
  }

  async function refreshCloneDiagnostics() {
    try {
      const clone = await callAction('clone:status', { force: true });
      await refreshState().catch(() => {});
      if (clone.available) {
        toast(`Clonador nativo listo · ${clone.os || 'Windows'} · PowerShell ${clone.powershell || '—'}.`, 'success');
      } else {
        toast(clone.error || 'El clonador nativo no está disponible.', 'warn');
      }
    } catch (error) {
      toast(error.message, 'error');
    }
  }

  async function prepareCloneForProfile(profileId, element = null) {
    const profile = profileById(profileId);
    if (!profile) return;
    if (element) {
      if (element.dataset.busy === '1') return;
      element.dataset.busy = '1';
      element.disabled = true;
    }
    toast('Windows pedirá permisos de administrador para preparar la cuenta. Acepta el aviso de UAC.', 'info');
    try {
      const result = await callAction('clone:prepare', { profileId });
      await refreshState().catch(() => {});
      paintLaunchCloneStatus(document);
      if (result.verified) {
        toast(`Cuenta ${result.account.username} preparada y verificada para "${profile.name}".`, 'success');
      } else {
        toast(`La cuenta se creó, pero la prueba de inicio de sesión falló: ${result.verification && result.verification.error ? result.verification.error : 'revisa los detalles en Ajustes.'}`, 'warn');
      }
    } catch (error) {
      toast(error.message, 'error');
      if (element && element.isConnected) {
        element.disabled = false;
        element.dataset.busy = '';
      }
    }
  }

  async function verifyCloneForProfile(profileId) {
    const profile = profileById(profileId);
    if (!profile) return;
    try {
      const result = await callAction('clone:verify', { profileId });
      await refreshState().catch(() => {});
      if (result.ok) toast(`La cuenta del clon de "${profile.name}" inició sesión correctamente.`, 'success');
      else toast(result.error || 'La cuenta no pudo iniciar sesión.', 'warn');
    } catch (error) {
      toast(error.message, 'error');
    }
  }

  function releaseCloneForProfile(profileId) {
    const profile = profileById(profileId);
    const account = cloneAccountFor(profileId);
    if (!profile || !account) return;
    openConfirmModal({
      title: 'Liberar cuenta de Windows',
      subtitle: profile.name,
      message: `Se eliminará la cuenta local <span class="mono">${esc(account.username)}</span> y su carpeta de usuario de Windows. Windows pedirá permisos de administrador. Los clones abiertos con este perfil se cerrarán. Esta acción no se puede deshacer.`,
      confirmLabel: 'Liberar cuenta',
      onConfirm: async () => {
        try {
          await callAction('clone:release', { profileId });
          await refreshState().catch(() => {});
          toast('Cuenta de Windows liberada.', 'success');
        } catch (error) {
          toast(error.message, 'error');
        }
      },
    });
  }

  async function refreshVmDiagnostics() {
    try {
      const vm = await callAction('vm:status', { force: true });
      await refreshState().catch(() => {});
      if (vm.available) {
        toast(`Hyper-V listo · ${vm.os || 'Windows'}${vm.ramGb ? ` · ${vm.ramGb} GB de RAM` : ''}.`, 'success');
      } else {
        toast(vm.error || 'Hyper-V no está disponible en este equipo.', 'warn');
      }
    } catch (error) {
      toast(error.message, 'error');
    }
  }

  async function pickVmBaseImage() {
    try {
      const result = await callAction('vm:pick-base');
      if (result.canceled) return;
      const ok = await saveSettings({ vm: { baseImagePath: result.path } }, `Imagen base guardada${result.sizeGb ? ` (${result.sizeGb} GB)` : ''}.`);
      if (ok) await refreshState().catch(() => {});
    } catch (error) {
      toast(error.message, 'error');
    }
  }

  async function detectVmSwitches() {
    const button = document.querySelector('[data-action="vm-switches"]');
    if (button) {
      if (button.dataset.busy === '1') return;
      button.dataset.busy = '1';
      button.disabled = true;
    }
    toast('Windows pedirá permisos de administrador para consultar los conmutadores virtuales.', 'info');
    try {
      const result = await callAction('vm:switches');
      const list = Array.isArray(result.items) ? result.items : [];
      const datalist = document.getElementById('vm-switch-list');
      if (datalist) {
        datalist.innerHTML = list.map((item) => `<option value="${esc(item.name)}">${esc(item.type || '')}</option>`).join('');
      }
      toast(
        list.length ? `${plural(list.length, 'conmutador detectado', 'conmutadores detectados')}.` : 'No se detectaron conmutadores virtuales.',
        list.length ? 'success' : 'warn',
      );
    } catch (error) {
      toast(error.message, 'error');
    } finally {
      if (button && button.isConnected) {
        button.disabled = false;
        button.dataset.busy = '';
      }
    }
  }

  async function saveVmConfig() {
    const switchName = String(document.getElementById('vm-switch')?.value || '').trim();
    const memoryMb = Number(document.getElementById('vm-memory')?.value);
    const cpuCount = Number(document.getElementById('vm-cpu')?.value);
    const generation = Number(document.getElementById('vm-generation')?.value);
    const disksDir = String(document.getElementById('vm-disks-dir')?.value || '').trim();
    if (!Number.isInteger(memoryMb) || memoryMb < 1024 || memoryMb > 32768) {
      toast('La memoria de la máquina virtual debe estar entre 1024 y 32768 MB.', 'warn');
      return;
    }
    if (!Number.isInteger(cpuCount) || cpuCount < 1 || cpuCount > 16) {
      toast('Los procesadores virtuales deben estar entre 1 y 16.', 'warn');
      return;
    }
    const ok = await saveSettings({
      vm: {
        switchName: switchName || 'Default Switch',
        memoryMb,
        cpuCount,
        generation,
        disksDir,
      },
    }, 'Configuración de máquinas virtuales guardada.');
    if (ok) await refreshState().catch(() => {});
  }

  async function withBusyButton(element, task) {
    if (element) {
      if (element.dataset.busy === '1') return;
      element.dataset.busy = '1';
      element.disabled = true;
    }
    try {
      const result = await task();
      await refreshState().catch(() => {});
      return result;
    } catch (error) {
      toast(error.message, 'error');
      if (element && element.isConnected) {
        element.disabled = false;
        element.dataset.busy = '';
      }
      return null;
    }
  }

  async function prepareVmForProfile(profileId, element) {
    const profile = profileById(profileId);
    if (!profile) return;
    toast('Windows pedirá permisos de administrador para crear la máquina virtual.', 'info');
    const result = await withBusyButton(element, () => callAction('vm:prepare', { profileId }));
    if (result) toast(`Máquina virtual preparada para "${profile.name}".`, 'success');
  }

  async function startVmForProfile(profileId, element) {
    const profile = profileById(profileId);
    if (!profile) return;
    toast('Windows pedirá permisos de administrador para encender la máquina virtual.', 'info');
    const result = await withBusyButton(element, () => callAction('vm:start', { profileId }));
    if (result) toast(`Máquina virtual de "${profile.name}" encendida. Abre la aplicación dentro de su ventana.`, 'success');
  }

  async function stopVmForProfile(profileId, element) {
    const profile = profileById(profileId);
    if (!profile) return;
    toast('Windows pedirá permisos de administrador para detener la máquina virtual.', 'info');
    const result = await withBusyButton(element, () => callAction('vm:stop', { profileId }));
    if (result) toast(`Máquina virtual de "${profile.name}" detenida.`);
  }

  function removeVmForProfile(profileId) {
    const profile = profileById(profileId);
    const machine = vmMachineFor(profileId);
    if (!profile || !machine) return;
    openConfirmModal({
      title: 'Eliminar máquina virtual',
      subtitle: profile.name,
      message: `Se apagará y eliminará la máquina virtual <span class="mono">${esc(machine.vmName)}</span> y su disco diferencial. Los datos guardados dentro del invitado se perderán. Windows pedirá permisos de administrador. Esta acción no se puede deshacer.`,
      confirmLabel: 'Eliminar máquina virtual',
      onConfirm: async () => {
        try {
          await callAction('vm:remove', { profileId });
          await refreshState().catch(() => {});
          toast('Máquina virtual y disco eliminados.', 'success');
        } catch (error) {
          toast(error.message, 'error');
        }
      },
    });
  }

  async function updateApiConfig(patch) {
    if (app.busy.has('api')) return;
    app.busy.add('api');
    scheduleRender();
    try {
      await callAction('settings:update', { api: patch });
      const fresh = await refreshState();
      const api = fresh.settings.api;
      if (patch.enabled === true) {
        if (api.running) toast(`API activa en 127.0.0.1:${api.port}.`, 'success');
        else if (api.error) toast(api.error, 'error');
      } else if (patch.enabled === false) {
        toast('API local detenida.', 'info');
      } else if (patch.port !== undefined) {
        if (api.running) toast(`API escuchando en el puerto ${api.port}.`, 'success');
        else if (api.error) toast(api.error, 'error');
      }
    } catch (error) {
      toast(error.message, 'error');
    } finally {
      app.busy.delete('api');
      scheduleRender();
    }
  }

  async function copyFromSource(source) {
    if (!app.state) return;
    const api = app.state.settings.api;
    let text = '';
    let message = 'Copiado al portapapeles.';
    if (source === 'api-token') {
      text = api.token || '';
      message = 'Token copiado al portapapeles.';
    } else if (source === 'api-base') {
      text = `http://127.0.0.1:${api.port}/v1`;
      message = 'Dirección copiada.';
    } else if (source === 'curl') {
      text = curlExample(api.port);
      message = 'Ejemplo copiado. Sustituye el token antes de usarlo.';
    } else if (source === 'data-dir') {
      text = app.dataDir || '';
      message = 'Ruta copiada.';
    } else if (source === 'license-machine') {
      text = app.state.license ? app.state.license.machineCode || '' : '';
      message = 'Código de equipo copiado.';
    }
    if (!text) return;
    try {
      await callAction('app:copy', { text });
      toast(message, 'success');
    } catch (error) {
      toast(error.message, 'error');
    }
  }

  async function runAction(action, element) {
    switch (action) {
      case 'new-profile':
        openProfileModal();
        break;
      case 'import-profiles':
        openImportChoiceModal();
        break;
      case 'export-profiles':
        openExportChoiceModal([]);
        break;
      case 'bulk-start':
        await runBatch('start');
        break;
      case 'bulk-stop':
        await runBatch('stop');
        break;
      case 'bulk-move':
        openBulkMoveModal();
        break;
      case 'bulk-tags':
        openBulkTagsModal();
        break;
      case 'bulk-status':
        openBulkStatusModal();
        break;
      case 'bulk-proxy':
        openBulkProxyModal();
        break;
      case 'bulk-duplicate':
        openBulkDuplicateModal();
        break;
      case 'bulk-delete':
        openBulkDeleteModal();
        break;
      case 'bulk-test-proxies': {
        const proxyIds = [...new Set(app.state.profiles
          .filter((profile) => app.selection.has(profile.id))
          .map((profile) => profile.proxyId)
          .filter(Boolean))];
        await testProxiesBulk(proxyIds);
        break;
      }
      case 'bulk-export':
        openExportChoiceModal(selectedProfileIds());
        break;
      case 'bulk-clear':
        app.selection.clear();
        scheduleRender();
        break;
      case 'profiles-select-visible':
        selectVisibleProfiles();
        break;
      case 'proxy-test-all':
        await testProxiesBulk();
        break;
      case 'profile-start':
        await startProfile(element.dataset.id);
        break;
      case 'profile-stop':
        await stopProfile(element.dataset.id);
        break;
      case 'profile-edit': {
        const profile = profileById(element.dataset.id);
        if (profile) openProfileModal(profile);
        break;
      }
      case 'profile-delete': {
        const profile = profileById(element.dataset.id);
        if (profile) openDeleteProfileModal(profile);
        break;
      }
      case 'profile-duplicate':
        await duplicateProfile(element.dataset.id);
        break;
      case 'profile-folder':
        await openProfileFolder(element.dataset.id);
        break;
      case 'profile-apps':
        openProfileAppsModal(element.dataset.id);
        break;
      case 'apps-refresh':
        closeAllModals();
        loadDiscoveredApps(true);
        break;
      case 'app-add-exe': {
        try {
          const result = await callAction('apps:add-exe');
          if (result.canceled) return;
          toast(`"${result.app.name}" agregada a la biblioteca.`, 'success');
        } catch (error) {
          toast(error.message, 'error');
        }
        break;
      }
      case 'app-add-discovered': {
        const button = element;
        if (button.disabled) return;
        button.disabled = true;
        try {
          const addedApp = await callAction('apps:add', { target: button.dataset.target });
          toast(`"${addedApp.name}" agregada a la biblioteca.`, 'success');
        } catch (error) {
          toast(error.message, 'error');
        } finally {
          if (button.isConnected) button.disabled = false;
        }
        break;
      }
      case 'app-launch':
        openAppLaunchModal(element.dataset.id, element.dataset.profile || '');
        break;
      case 'app-edit': {
        const currentApp = appById(element.dataset.id);
        if (currentApp) openAppEditModal(currentApp);
        break;
      }
      case 'app-delete': {
        const currentApp = appById(element.dataset.id);
        if (currentApp) openAppDeleteModal(currentApp);
        break;
      }
      case 'app-favorite': {
        try {
          const updated = await callAction('apps:favorite', { id: element.dataset.id });
          toast(updated.favorite ? 'Añadida a favoritos.' : 'Quitada de favoritos.', 'success');
        } catch (error) {
          toast(error.message, 'error');
        }
        break;
      }
      case 'app-stop': {
        const instanceId = element.dataset.instance;
        if (!instanceId || element.dataset.busy === '1') return;
        element.dataset.busy = '1';
        element.disabled = true;
        try {
          await callAction('apps:stop', { instanceId });
          toast(instanceId.startsWith('vm:') ? 'Máquina virtual detenida y estado guardado.' : 'Aplicación detenida.', 'success');
        } catch (error) {
          toast(error.message, 'error');
          element.disabled = false;
          element.dataset.busy = '';
        }
        break;
      }
      case 'apps-search-clear':
        app.appQuery = '';
        scheduleRender();
        document.getElementById('apps-search')?.focus();
        break;
      case 'profile-search-clear':
        app.query = '';
        scheduleRender();
        document.getElementById('profile-search')?.focus();
        break;
      case 'reset-filters':
        app.query = '';
        app.workspaceFilter = 'all';
        app.statusFilter = 'all';
        app.sort = 'recent';
        scheduleRender();
        break;
      case 'filter-workspace':
        app.workspaceFilter = element.dataset.id || 'all';
        closeAllModals();
        setView('profiles');
        break;
      case 'workspace-new':
        openWorkspaceModal();
        break;
      case 'workspace-edit': {
        const workspace = workspaceById(element.dataset.id);
        if (workspace) openWorkspaceModal(workspace);
        break;
      }
      case 'workspace-delete': {
        const workspace = workspaceById(element.dataset.id);
        if (workspace) openDeleteWorkspaceModal(workspace);
        break;
      }
      case 'status-new':
        openStatusModal();
        break;
      case 'status-edit': {
        const status = profileStatusById(element.dataset.id);
        if (status) openStatusModal(status);
        break;
      }
      case 'status-delete': {
        const status = profileStatusById(element.dataset.id);
        if (status) openDeleteStatusModal(status);
        break;
      }
      case 'proxy-new':
        openProxyModal();
        break;
      case 'proxy-edit': {
        const proxy = proxyById(element.dataset.id);
        if (proxy) openProxyModal({ ...proxy, password: undefined });
        break;
      }
      case 'proxy-delete': {
        const proxy = proxyById(element.dataset.id);
        if (proxy) openDeleteProxyModal(proxy);
        break;
      }
      case 'proxy-test':
        await testProxyFromList(element.dataset.id);
        break;
      case 'activity-filter':
        app.activityFilter = element.dataset.level || 'all';
        scheduleRender();
        break;
      case 'activity-clear':
        openClearActivityModal();
        break;
      case 'api-port-save': {
        const input = document.getElementById('api-port');
        const port = Number(input?.value);
        if (!Number.isInteger(port) || port < 1024 || port > 65535) {
          toast('El puerto debe estar entre 1024 y 65535.', 'warn');
          return;
        }
        await updateApiConfig({ port });
        break;
      }
      case 'api-token-reveal':
        app.apiRevealed = !app.apiRevealed;
        scheduleRender();
        break;
      case 'api-token-regenerate':
        openRegenerateTokenModal();
        break;
      case 'settings-save-profiles-dir':
        await saveProfilesDir();
        break;
      case 'clone-refresh':
        await refreshCloneDiagnostics();
        break;
      case 'clone-prepare':
        await prepareCloneForProfile(element.dataset.profile, element);
        break;
      case 'clone-verify':
        await verifyCloneForProfile(element.dataset.profile);
        break;
      case 'clone-release':
        releaseCloneForProfile(element.dataset.profile);
        break;
      case 'vm-refresh':
        await refreshVmDiagnostics();
        break;
      case 'vm-pick-base':
        await pickVmBaseImage();
        break;
      case 'vm-switches':
        await detectVmSwitches();
        break;
      case 'vm-save-config':
        await saveVmConfig();
        break;
      case 'vm-prepare':
        await prepareVmForProfile(element.dataset.profile, element);
        break;
      case 'vm-start':
        await startVmForProfile(element.dataset.profile, element);
        break;
      case 'vm-stop':
        await stopVmForProfile(element.dataset.profile, element);
        break;
      case 'vm-remove':
        removeVmForProfile(element.dataset.profile);
        break;
      case 'settings-open-profiles':
        try {
          await callAction('profiles:dir:open');
          toast('Carpeta de perfiles abierta.', 'success');
        } catch (error) {
          toast(error.message, 'error');
        }
        break;
      default:
        break;
    }
  }

  // ===== Forms =====

  function showFormError(form, message) {
    const box = form.querySelector('.form-error');
    if (!box) return;
    box.textContent = message;
    box.classList.add('is-visible');
  }

  function setFormSaving(form, saving, label) {
    const button = document.querySelector(`button[type="submit"][form="${form.id}"]`);
    if (!button) return;
    if (saving) {
      button.dataset.original = button.innerHTML;
      button.disabled = true;
      button.innerHTML = `<span class="spinner-xs"></span> ${esc(label || 'Guardando…')}`;
    } else if (button.isConnected) {
      button.disabled = false;
      if (button.dataset.original) button.innerHTML = button.dataset.original;
    }
  }

  async function submitProfileForm(form) {
    if (form.dataset.saving === '1') return;
    const errorBox = form.querySelector('#profile-form-error');
    if (errorBox) errorBox.classList.remove('is-visible');
    const data = new FormData(form);
    const color = form.querySelector('.color-swatch.is-active')?.dataset.colorChoice || PALETTE[0];
    const payload = {
      name: String(data.get('name') || '').trim(),
      workspaceId: String(data.get('workspaceId') || ''),
      proxyId: String(data.get('proxyId') || '') || null,
      statusId: String(data.get('statusId') || '') || null,
      startUrls: String(data.get('startUrls') || '').split(/\r?\n/).map((line) => line.trim()).filter(Boolean),
      tags: String(data.get('tags') || '').split(',').map((tag) => tag.trim()).filter(Boolean),
      notes: String(data.get('notes') || '').trim(),
      color,
    };
    if (!payload.name) {
      showFormError(form, 'Escribe un nombre para el perfil.');
      form.querySelector('#pf-name')?.focus();
      return;
    }
    const mode = form.dataset.mode;
    const id = form.dataset.id;
    form.dataset.saving = '1';
    setFormSaving(form, true, mode === 'edit' ? 'Guardando…' : 'Creando…');
    try {
      if (mode === 'edit') await callAction('profile:update', { id, patch: payload });
      else await callAction('profile:create', payload);
      closeModalFor(form);
      toast(mode === 'edit' ? 'Perfil actualizado.' : 'Perfil creado.', 'success');
    } catch (error) {
      showFormError(form, error.message);
    } finally {
      form.dataset.saving = '';
      if (form.isConnected) setFormSaving(form, false);
    }
  }

  async function submitProxyForm(form) {
    if (form.dataset.saving === '1') return;
    const errorBox = form.querySelector('#proxy-form-error');
    if (errorBox) errorBox.classList.remove('is-visible');
    const payload = readProxyForm(form);
    if (!payload.name) {
      showFormError(form, 'Escribe un nombre para el proxy.');
      form.querySelector('#px-name')?.focus();
      return;
    }
    if (!payload.host) {
      showFormError(form, 'Indica el host del proxy.');
      form.querySelector('#px-host')?.focus();
      return;
    }
    if (!Number.isInteger(payload.port) || payload.port < 1 || payload.port > 65535) {
      showFormError(form, 'El puerto debe estar entre 1 y 65535.');
      form.querySelector('#px-port')?.focus();
      return;
    }
    const mode = form.dataset.mode;
    const id = form.dataset.id;
    form.dataset.saving = '1';
    setFormSaving(form, true, mode === 'edit' ? 'Guardando…' : 'Creando…');
    try {
      if (mode === 'edit') await callAction('proxy:update', { id, patch: payload });
      else await callAction('proxy:create', payload);
      closeModalFor(form);
      toast(mode === 'edit' ? 'Proxy actualizado.' : 'Proxy creado.', 'success');
    } catch (error) {
      showFormError(form, error.message);
    } finally {
      form.dataset.saving = '';
      if (form.isConnected) setFormSaving(form, false);
    }
  }

  async function submitAppLaunchForm(form) {
    if (form.dataset.saving === '1') return;
    const errorBox = form.querySelector('#app-launch-error');
    if (errorBox) errorBox.classList.remove('is-visible');
    const data = new FormData(form);
    const profileId = String(data.get('profileId') || '');
    const appId = form.dataset.app;
    const currentApp = appById(appId);
    if (!profileId) {
      showFormError(form, 'Selecciona un perfil.');
      return;
    }
    if (!currentApp) {
      showFormError(form, 'La aplicación ya no está en la biblioteca.');
      return;
    }
    if (cloneModeOf(currentApp) === 'vm') {
      const machine = vmMachineFor(profileId);
      if (machine && machine.running) {
        showFormError(form, 'La máquina virtual ya está encendida. Usa su ventana de conexión.');
        return;
      }
    }
    const options = currentApp.kind === 'startapp'
      ? {}
      : {
        args: String(data.get('args') || ''),
        cwd: String(data.get('cwd') || '').trim(),
      };
    form.dataset.saving = '1';
    const mode = currentApp.kind === 'executable' ? cloneModeOf(currentApp) : 'none';
    const needsAccount = mode === 'account' && !cloneAccountFor(profileId);
    setFormSaving(
      form,
      true,
      needsAccount ? 'Preparando la cuenta de Windows (UAC)…' : mode === 'vm' ? 'Encendiendo la máquina virtual (UAC)…' : 'Abriendo…',
    );
    try {
      const result = await callAction('apps:launch', { profileId, appId, options });
      closeModalFor(form);
      if (result.isolation === 'vm') {
        toast(result.message || 'Máquina virtual encendida. Abre la aplicación dentro de su ventana.', 'success');
      } else if (result.tracked) {
        toast(`"${result.appName}" abierta con el perfil "${result.profileName}".`, 'success');
      } else {
        toast(result.message || 'Windows abrió la aplicación.', 'info');
      }
    } catch (error) {
      showFormError(form, error.message);
    } finally {
      form.dataset.saving = '';
      if (form.isConnected) setFormSaving(form, false);
    }
  }

  async function submitAppEditForm(form) {
    if (form.dataset.saving === '1') return;
    const errorBox = form.querySelector('#app-edit-error');
    if (errorBox) errorBox.classList.remove('is-visible');
    const data = new FormData(form);
    const payload = {
      name: String(data.get('name') || '').trim(),
      args: String(data.get('args') || ''),
      cwd: String(data.get('cwd') || '').trim(),
    };
    const current = appById(form.dataset.id);
    if (current && current.kind === 'executable') {
      payload.cloneMode = String(data.get('cloneMode') || current.cloneMode || 'account');
    }
    if (!payload.name) {
      showFormError(form, 'Escribe un nombre para la aplicación.');
      return;
    }
    form.dataset.saving = '1';
    setFormSaving(form, true, 'Guardando…');
    try {
      await callAction('apps:update', { id: form.dataset.id, patch: payload });
      closeModalFor(form);
      toast('Aplicación actualizada.', 'success');
    } catch (error) {
      showFormError(form, error.message);
    } finally {
      form.dataset.saving = '';
      if (form.isConnected) setFormSaving(form, false);
    }
  }

  async function submitWorkspaceForm(form) {
    if (form.dataset.saving === '1') return;
    const errorBox = form.querySelector('#workspace-form-error');
    if (errorBox) errorBox.classList.remove('is-visible');
    const name = String(new FormData(form).get('name') || '').trim();
    const color = form.querySelector('.color-swatch.is-active')?.dataset.colorChoice || PALETTE[0];
    if (!name) {
      showFormError(form, 'Escribe un nombre para el espacio.');
      form.querySelector('#ws-name')?.focus();
      return;
    }
    const mode = form.dataset.mode;
    const id = form.dataset.id;
    form.dataset.saving = '1';
    setFormSaving(form, true, mode === 'edit' ? 'Guardando…' : 'Creando…');
    try {
      if (mode === 'edit') await callAction('workspace:update', { id, patch: { name, color } });
      else await callAction('workspace:create', { name, color });
      closeModalFor(form);
      toast(mode === 'edit' ? 'Espacio actualizado.' : 'Espacio creado.', 'success');
    } catch (error) {
      showFormError(form, error.message);
    } finally {
      form.dataset.saving = '';
      if (form.isConnected) setFormSaving(form, false);
    }
  }

  async function submitStatusForm(form) {
    if (form.dataset.saving === '1') return;
    const errorBox = form.querySelector('#status-form-error');
    if (errorBox) errorBox.classList.remove('is-visible');
    const name = String(new FormData(form).get('name') || '').trim();
    const color = form.querySelector('.color-swatch.is-active')?.dataset.colorChoice || PALETTE[0];
    if (!name) {
      showFormError(form, 'Escribe un nombre para el estado.');
      form.querySelector('#st-name')?.focus();
      return;
    }
    const mode = form.dataset.mode;
    const id = form.dataset.id;
    form.dataset.saving = '1';
    setFormSaving(form, true, mode === 'edit' ? 'Guardando…' : 'Creando…');
    try {
      if (mode === 'edit') await callAction('status:update', { id, patch: { name, color } });
      else await callAction('status:create', { name, color });
      closeModalFor(form);
      toast(mode === 'edit' ? 'Estado actualizado.' : 'Estado creado.', 'success');
    } catch (error) {
      showFormError(form, error.message);
    } finally {
      form.dataset.saving = '';
      if (form.isConnected) setFormSaving(form, false);
    }
  }

  // ===== Popover =====

  function closePopover() {
    if (popoverEl) {
      popoverEl.remove();
      popoverEl = null;
    }
  }

  function openProfileMenu(profile, anchor) {
    closePopover();
    const element = document.createElement('div');
    element.className = 'popover';
    element.innerHTML = `
      <button type="button" data-action="profile-edit" data-id="${esc(profile.id)}">${icon('edit')} Editar</button>
      <button type="button" data-action="profile-duplicate" data-id="${esc(profile.id)}">${icon('copy')} Duplicar</button>
      <button type="button" data-action="profile-folder" data-id="${esc(profile.id)}">${icon('folder')} Abrir carpeta</button>
      <hr>
      <button type="button" class="is-danger" data-action="profile-delete" data-id="${esc(profile.id)}">${icon('trash')} Eliminar</button>
    `;
    document.getElementById('popover-root').appendChild(element);
    popoverEl = element;
    const rect = anchor.getBoundingClientRect();
    const width = 184;
    const left = Math.min(Math.max(12, rect.right - width), window.innerWidth - width - 12);
    let top = rect.bottom + 6;
    element.style.width = `${width}px`;
    element.style.left = `${left}px`;
    element.style.top = `${top}px`;
    requestAnimationFrame(() => {
      if (!popoverEl) return;
      const height = element.offsetHeight;
      if (top + height > window.innerHeight - 12) {
        top = Math.max(12, rect.top - height - 6);
        element.style.top = `${top}px`;
      }
    });
  }

  // ===== Event wiring =====

  function isTypingTarget(target) {
    return target instanceof HTMLElement
      && (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA' || target.tagName === 'SELECT' || target.isContentEditable);
  }

  function wireEvents() {
    document.addEventListener('click', async (event) => {
      const target = event.target;

      const navButton = target.closest('[data-nav]');
      if (navButton) {
        event.preventDefault();
        closeAllModals();
        setView(navButton.dataset.nav);
        return;
      }

      if (target.closest('#topbar-api, #sidebar-api')) {
        setView('api');
        return;
      }

      const goView = target.closest('[data-go-view]');
      if (goView) {
        event.preventDefault();
        closeAllModals();
        setView(goView.dataset.goView);
        return;
      }

      const menuButton = target.closest('[data-menu-profile]');
      if (menuButton) {
        event.preventDefault();
        const profile = profileById(menuButton.dataset.menuProfile);
        if (profile) openProfileMenu(profile, menuButton);
        return;
      }

      if (!target.closest('.popover')) closePopover();

      const closeButton = target.closest('[data-close-modal]');
      if (closeButton) {
        event.preventDefault();
        closeTopModal();
        return;
      }

      const themeButton = target.closest('[data-theme-choice]');
      if (themeButton) {
        event.preventDefault();
        closePopover();
        await chooseTheme(themeButton.dataset.themeChoice);
        return;
      }

      const colorButton = target.closest('[data-color-choice]');
      if (colorButton) {
        event.preventDefault();
        const row = colorButton.closest('.color-row');
        if (row) {
          row.querySelectorAll('.color-swatch').forEach((swatch) => swatch.classList.remove('is-active'));
          colorButton.classList.add('is-active');
        }
        return;
      }

      const copyButton = target.closest('[data-copy-source]');
      if (copyButton) {
        event.preventDefault();
        closePopover();
        await copyFromSource(copyButton.dataset.copySource);
        return;
      }

      const actionButton = target.closest('[data-action]');
      if (actionButton) {
        event.preventDefault();
        if (popoverEl && popoverEl.contains(actionButton)) closePopover();
        const opensModalOnly = ['new-profile', 'workspace-new', 'proxy-new', 'workspace-edit', 'proxy-edit', 'profile-edit', 'profile-delete', 'proxy-delete', 'workspace-delete', 'activity-clear', 'api-token-regenerate'];
        if (opensModalOnly.includes(actionButton.dataset.action) && app.modalStack.length) {
          closeAllModals();
        }
        await runAction(actionButton.dataset.action, actionButton);
        return;
      }
    });

    document.addEventListener('submit', (event) => {
      const form = event.target;
      if (!(form instanceof HTMLFormElement)) return;
      if (form.id === 'profile-form') {
        event.preventDefault();
        submitProfileForm(form);
      } else if (form.id === 'proxy-form') {
        event.preventDefault();
        submitProxyForm(form);
      } else if (form.id === 'workspace-form') {
        event.preventDefault();
        submitWorkspaceForm(form);
      } else if (form.id === 'status-form') {
        event.preventDefault();
        submitStatusForm(form);
      } else if (form.id === 'app-launch-form') {
        event.preventDefault();
        submitAppLaunchForm(form);
      } else if (form.id === 'app-edit-form') {
        event.preventDefault();
        submitAppEditForm(form);
      }
    });

    document.addEventListener('change', async (event) => {
      const target = event.target;
      if (target.matches('[data-select-profile]')) {
        const id = target.dataset.selectProfile;
        if (!id) return;
        if (target.checked) app.selection.add(id);
        else app.selection.delete(id);
        scheduleRender();
        return;
      }
      if (target.id === 'filter-workspace') {
        app.workspaceFilter = target.value;
        scheduleRender();
        return;
      }
      if (target.id === 'filter-status') {
        app.statusFilter = target.value;
        scheduleRender();
        return;
      }
      if (target.id === 'sort-profiles') {
        app.sort = target.value;
        scheduleRender();
        return;
      }
      if (target.id === 'setting-close-tray') {
        const ok = await saveSettings({ closeToTray: target.checked }, target.checked ? 'La app se ocultará en la bandeja al cerrar.' : 'La app se cerrará al cerrar la ventana.');
        if (!ok) target.checked = !target.checked;
        return;
      }
      if (target.id === 'api-enabled') {
        await updateApiConfig({ enabled: target.checked });
        return;
      }
    });

    document.addEventListener('input', (event) => {
      if (event.target.id === 'profile-search') {
        app.query = event.target.value;
        scheduleRender();
      }
      if (event.target.id === 'apps-search') {
        app.appQuery = event.target.value;
        scheduleRender();
      }
    });

    document.addEventListener('keydown', (event) => {
      if (event.key === 'Escape') {
        if (popoverEl) {
          closePopover();
          return;
        }
        if (app.modalStack.length) {
          event.preventDefault();
          closeTopModal();
        }
        return;
      }
      if (event.key === 'Tab' && app.modalStack.length) {
        trapFocus(event);
        return;
      }
      if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 'n' && !app.modalStack.length) {
        event.preventDefault();
        openProfileModal();
        return;
      }
      if (event.key === '/' && !isTypingTarget(event.target) && !app.modalStack.length) {
        event.preventDefault();
        setView('profiles');
        setTimeout(() => document.getElementById('profile-search')?.focus(), 30);
        return;
      }
      if (event.key === 'F5' && !event.ctrlKey && !event.metaKey) {
        event.preventDefault();
      }
    });

    window.addEventListener('scroll', closePopover, true);
    window.addEventListener('resize', closePopover);
    window.matchMedia('(prefers-color-scheme: light)').addEventListener('change', () => {
      if (app.state && app.state.settings.theme === 'system') applyTheme();
    });
    document.getElementById('theme-toggle')?.addEventListener('click', async () => {
      if (!app.state) return;
      const current = resolveTheme(app.state.settings.theme);
      await chooseTheme(current === 'dark' ? 'light' : 'dark');
    });
    document.getElementById('new-profile-btn')?.addEventListener('click', () => openProfileModal());
  }

  // ===== Boot =====

  async function init() {
    document.documentElement.dataset.platform = bridge ? bridge.platform : '';
    wireEvents();

    if (!bridge) {
      showFatal('El puente de la aplicación no está disponible. Vuelve a abrir PerfilLab.');
      return;
    }

    bridge.onEvent((state) => applyState(state));

    try {
      const state = await callAction('state:get');
      applyState(state);
    } catch (error) {
      showFatal(error.message);
      return;
    }

    try {
      const dir = await callAction('app:data-dir');
      app.dataDir = dir.path || '';
      if (app.view === 'settings') scheduleRender();
    } catch {
      app.dataDir = '';
    }

    setInterval(updateClocks, 30000);

    if (window.matchMedia('(prefers-color-scheme: light)').matches) {
      // theme is applied from state; this only keeps the splash background in sync before load
      document.documentElement.dataset.theme = resolveTheme(app.state.settings.theme);
    }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
