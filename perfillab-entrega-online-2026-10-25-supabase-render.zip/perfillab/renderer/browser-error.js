'use strict';

(() => {
  const params = new URLSearchParams(window.location.search);
  const target = (params.get('url') || '').trim();
  const code = (params.get('code') || '').trim();
  const desc = (params.get('desc') || '').trim();

  const known = {
    '-102': 'El servidor rechazó la conexión.',
    '-105': 'No se pudo encontrar el servidor. Revisa la dirección.',
    '-106': 'No hay conexión a Internet.',
    '-118': 'La conexión tardó demasiado en responder.',
    '-201': 'El certificado de seguridad del sitio no es válido.',
  };

  const description = document.getElementById('description');
  const targetEl = document.getElementById('target');
  const retry = document.getElementById('retry');
  const codeEl = document.getElementById('code');

  if (known[code]) description.textContent = known[code];
  else if (desc) description.textContent = desc;

  let safeTarget = '';
  try {
    const parsed = new URL(target);
    if (parsed.protocol === 'http:' || parsed.protocol === 'https:') safeTarget = parsed.href;
  } catch {
    safeTarget = '';
  }

  if (safeTarget) {
    targetEl.textContent = safeTarget;
    retry.href = safeTarget;
  } else {
    retry.hidden = true;
  }

  if (code) {
    codeEl.textContent = `Código de error: ${code}`;
  }
})();
