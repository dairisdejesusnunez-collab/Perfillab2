'use strict';

(() => {
  const params = new URLSearchParams(window.location.search);
  const message = (params.get('message') || '').trim();
  if (!message) return;
  const element = document.getElementById('message');
  if (element) element.textContent = message;
})();
