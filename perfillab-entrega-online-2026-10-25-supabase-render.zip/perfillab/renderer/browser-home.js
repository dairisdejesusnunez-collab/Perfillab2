'use strict';

(() => {
  const params = new URLSearchParams(window.location.search);
  const profile = (params.get('profile') || '').trim();
  const proxy = (params.get('proxy') || '').trim();

  const nameEl = document.getElementById('profile-name');
  const proxyEl = document.getElementById('proxy-name');
  const initialEl = document.getElementById('profile-initial');

  document.title = 'Nueva pestaña';

  if (profile) {
    nameEl.textContent = profile;
    initialEl.textContent = profile.charAt(0).toUpperCase();
  }

  if (proxy) {
    proxyEl.textContent = proxy;
  }

  const search = document.getElementById('q');
  if (search) {
    search.focus({ preventScroll: true });
  }
})();
