'use strict';

(() => {
  const api = window.perfilabBrowser;
  if (!api) return;
  document.body.dataset.platform = api.platform || '';

  const el = {
    tabs: document.getElementById('tabs'),
    tabNew: document.getElementById('tab-new'),
    back: document.getElementById('back'),
    forward: document.getElementById('forward'),
    reload: document.getElementById('reload'),
    home: document.getElementById('home'),
    form: document.getElementById('address-form'),
    address: document.getElementById('address'),
    security: document.getElementById('security'),
    downloads: document.getElementById('downloads'),
    downloadProgress: document.getElementById('download-progress'),
    profileChip: document.getElementById('profile-chip'),
    profileInitial: document.getElementById('profile-initial'),
    profileName: document.getElementById('profile-name'),
    profileProxy: document.getElementById('profile-proxy'),
    notice: document.getElementById('notice'),
    noticeText: document.getElementById('notice-text'),
    findbar: document.getElementById('findbar'),
    findInput: document.getElementById('find-input'),
    findCount: document.getElementById('find-count'),
    findPrev: document.getElementById('find-prev'),
    findNext: document.getElementById('find-next'),
    findClose: document.getElementById('find-close'),
  };

  const tabElements = new Map();
  let state = null;
  let addressEditing = false;
  let lastActiveId = null;
  let findVisible = false;
  let findQuery = '';

  function icon(name) {
    return `<svg class="icon" aria-hidden="true"><use href="#i-${name}"></use></svg>`;
  }

  function hostOf(url) {
    try {
      return new URL(url).host || url;
    } catch {
      return url;
    }
  }

  function tabLabel(tab) {
    if (tab.title) return tab.title;
    if (tab.home) return 'Nueva pestaña';
    if (tab.url) return hostOf(tab.url);
    return 'Cargando…';
  }

  function activeTab() {
    if (!state) return null;
    return state.tabs.find((tab) => tab.id === state.activeTabId) || null;
  }

  function createTabElement(tab) {
    const node = document.createElement('div');
    node.className = 'tab';
    node.dataset.id = tab.id;
    node.setAttribute('role', 'tab');

    const favicon = document.createElement('span');
    favicon.className = 'tab-favicon';
    favicon.innerHTML = icon('globe');

    const title = document.createElement('span');
    title.className = 'tab-title';

    const close = document.createElement('button');
    close.type = 'button';
    close.className = 'tab-close';
    close.title = 'Cerrar pestaña (Ctrl+W)';
    close.setAttribute('aria-label', 'Cerrar pestaña');
    close.innerHTML = icon('close');

    node.append(favicon, title, close);
    node.addEventListener('click', (event) => {
      if (event.target.closest('.tab-close')) return;
      api.selectTab(tab.id).catch(() => {});
    });
    node.addEventListener('auxclick', (event) => {
      if (event.button !== 1) return;
      event.preventDefault();
      api.closeTab(tab.id).catch(() => {});
    });
    close.addEventListener('click', (event) => {
      event.stopPropagation();
      api.closeTab(tab.id).catch(() => {});
    });
    return node;
  }

  function updateTabElement(node, tab) {
    node.classList.toggle('is-active', tab.id === state.activeTabId);
    node.classList.toggle('is-loading', Boolean(tab.loading));
    node.setAttribute('aria-selected', tab.id === state.activeTabId ? 'true' : 'false');
    node.title = tabLabel(tab);

    const favicon = node.querySelector('.tab-favicon');
    const shown = favicon.dataset.src || '';
    const failed = favicon.dataset.failed || '';
    if (tab.favicon && tab.favicon !== shown && tab.favicon !== failed) {
      favicon.dataset.src = tab.favicon;
      favicon.replaceChildren();
      const img = document.createElement('img');
      img.alt = '';
      img.src = tab.favicon;
      img.addEventListener('error', () => {
        favicon.dataset.failed = tab.favicon;
        delete favicon.dataset.src;
        favicon.innerHTML = icon('globe');
      }, { once: true });
      favicon.append(img);
    } else if (!tab.favicon && shown) {
      delete favicon.dataset.src;
      delete favicon.dataset.failed;
      favicon.innerHTML = icon('globe');
    } else if (!favicon.firstChild) {
      favicon.innerHTML = icon('globe');
    }

    node.querySelector('.tab-title').textContent = tabLabel(tab);
  }

  function renderTabs() {
    const seen = new Set();
    for (const tab of state.tabs) {
      let node = tabElements.get(tab.id);
      if (!node) {
        node = createTabElement(tab);
        tabElements.set(tab.id, node);
      }
      updateTabElement(node, tab);
      el.tabs.append(node);
      seen.add(tab.id);
    }
    for (const [id, node] of tabElements) {
      if (seen.has(id)) continue;
      node.remove();
      tabElements.delete(id);
    }
  }

  function setAddress(value) {
    if (addressEditing) return;
    el.address.value = value || '';
  }

  function renderSecurity(tab) {
    let name = 'home';
    let title = 'Página de inicio local';
    let extra = '';
    if (tab) {
      if (tab.error) {
        name = 'alert';
        title = 'No se pudo cargar la página';
        extra = ' is-insecure';
      } else if (tab.home) {
        name = 'home';
      } else if (tab.secure) {
        name = 'lock';
        title = 'Conexión segura (HTTPS)';
        extra = ' is-secure';
      } else if (tab.url) {
        name = 'info';
        title = 'Conexión no segura (HTTP)';
        extra = ' is-insecure';
      }
    }
    el.security.innerHTML = icon(name);
    el.security.title = title;
    el.security.className = `security${extra}`;
  }

  function renderToolbar() {
    const tab = activeTab();
    el.back.disabled = !tab || !tab.canGoBack;
    el.forward.disabled = !tab || !tab.canGoForward;
    el.reload.innerHTML = tab && tab.loading ? icon('stop') : icon('reload');
    el.reload.title = tab && tab.loading ? 'Detener carga (Esc)' : 'Recargar (Ctrl+R)';
    el.reload.setAttribute('aria-label', tab && tab.loading ? 'Detener carga' : 'Recargar');
    renderSecurity(tab);

    const desired = tab ? tab.url : '';
    if (state.activeTabId !== lastActiveId) {
      lastActiveId = state.activeTabId;
      el.address.value = desired;
      addressEditing = false;
      if (document.activeElement === el.address) el.address.select();
      const node = tabElements.get(state.activeTabId);
      if (node) {
        requestAnimationFrame(() => node.scrollIntoView({ block: 'nearest', inline: 'nearest' }));
      }
    } else {
      setAddress(desired);
    }
  }

  function renderProfile() {
    const name = state.profile && state.profile.name ? state.profile.name : 'Perfil';
    const proxy = state.proxyLabel || 'Sin proxy';
    el.profileName.textContent = name;
    el.profileInitial.textContent = name.trim().charAt(0).toUpperCase() || 'P';
    el.profileProxy.textContent = proxy;
    el.profileChip.title = `Perfil: ${name}\nProxy: ${proxy}\nMotor: Chromium ${state.engine || ''}`;
  }

  function renderDownloads() {
    const list = Array.isArray(state.downloads) ? state.downloads : [];
    const latest = list.find((item) => item.state === 'progressing');
    if (!latest) {
      el.downloadProgress.hidden = true;
      el.downloadProgress.value = 0;
      el.downloads.title = 'Abrir carpeta de descargas';
      return;
    }
    const total = Number(latest.totalBytes) || 0;
    const received = Number(latest.receivedBytes) || 0;
    el.downloadProgress.hidden = false;
    el.downloadProgress.value = total > 0 ? Math.min(100, Math.round((received / total) * 100)) : 0;
    const percent = total > 0 ? ` (${Math.round((received / total) * 100)}%)` : '';
    el.downloads.title = `Descargando ${latest.filename}${percent}`;
  }

  function render(next) {
    if (!next || !Array.isArray(next.tabs)) return;
    state = next;
    if (!state.profile) state.profile = { name: 'Perfil' };
    renderTabs();
    renderToolbar();
    renderProfile();
    renderDownloads();
    document.body.classList.toggle('is-fullscreen', Boolean(state.fullscreen));
    if (state.findOpen && !findVisible) {
      findVisible = true;
      el.findbar.hidden = false;
    } else if (!state.findOpen && findVisible) {
      findVisible = false;
      el.findbar.hidden = true;
    }
  }

  function focusAddress() {
    el.address.focus();
    el.address.select();
  }

  function showNotice(text, level) {
    el.noticeText.textContent = String(text || '');
    el.notice.dataset.level = level === 'warn' ? 'warn' : 'info';
    el.notice.hidden = false;
  }

  function clearNotice() {
    el.notice.hidden = true;
    el.noticeText.textContent = '';
  }

  function openFind() {
    if (!findVisible) {
      findVisible = true;
      el.findbar.hidden = false;
      api.findOpen().catch(() => {});
    }
    el.findInput.focus();
    el.findInput.select();
  }

  function closeFind(skipApi) {
    if (!findVisible) return;
    findVisible = false;
    el.findbar.hidden = true;
    el.findCount.textContent = '0/0';
    if (!skipApi) api.findClose().catch(() => {});
  }

  function runFind(findNext) {
    if (!findQuery.trim()) {
      el.findCount.textContent = '0/0';
      api.findStop().catch(() => {});
      return;
    }
    api.find(findQuery, { findNext }).catch(() => {});
  }

  function updateFindCount(result) {
    const matches = Number(result.matches) || 0;
    const active = Number(result.activeMatchOrdinal) || 0;
    el.findCount.textContent = `${active}/${matches}`;
  }

  function cycleTabs(step) {
    if (!state || state.tabs.length < 2) return;
    const index = state.tabs.findIndex((tab) => tab.id === state.activeTabId);
    if (index < 0) return;
    const next = state.tabs[(index + step + state.tabs.length) % state.tabs.length];
    api.selectTab(next.id).catch(() => {});
  }

  el.tabNew.addEventListener('click', () => {
    api.newTab().catch(() => {});
  });

  el.back.addEventListener('click', () => api.back().catch(() => {}));
  el.forward.addEventListener('click', () => api.forward().catch(() => {}));
  el.home.addEventListener('click', () => api.home().catch(() => {}));
  el.reload.addEventListener('click', () => {
    const tab = activeTab();
    if (tab && tab.loading) api.stop().catch(() => {});
    else api.reload().catch(() => {});
  });

  el.downloads.addEventListener('click', () => {
    api.openDownloads().catch(() => {});
  });

  el.form.addEventListener('submit', (event) => {
    event.preventDefault();
    const value = el.address.value;
    addressEditing = false;
    el.address.blur();
    api.navigate(value).catch(() => {});
  });

  el.address.addEventListener('focus', () => {
    addressEditing = true;
    el.address.select();
  });

  el.address.addEventListener('input', () => {
    addressEditing = true;
  });

  el.address.addEventListener('blur', () => {
    addressEditing = false;
    const tab = activeTab();
    el.address.value = tab ? tab.url : '';
  });

  el.findInput.addEventListener('input', () => {
    findQuery = el.findInput.value;
    runFind(false);
  });

  el.findInput.addEventListener('keydown', (event) => {
    if (event.key === 'Enter') {
      event.preventDefault();
      runFind(true);
    } else if (event.key === 'Escape') {
      event.preventDefault();
      closeFind(false);
    }
  });

  el.findNext.addEventListener('click', () => runFind(true));
  el.findPrev.addEventListener('click', () => api.find(findQuery, { forward: false, findNext: true }).catch(() => {}));
  el.findClose.addEventListener('click', () => closeFind(false));

  document.addEventListener('keydown', (event) => {
    const ctrl = event.ctrlKey || event.metaKey;
    const key = String(event.key || '').toLowerCase();
    if (ctrl && key === 'l') {
      event.preventDefault();
      focusAddress();
    } else if (ctrl && key === 't') {
      event.preventDefault();
      api.newTab().catch(() => {});
    } else if (ctrl && key === 'w') {
      event.preventDefault();
      if (state && state.activeTabId) api.closeTab(state.activeTabId).catch(() => {});
    } else if (ctrl && key === 'r') {
      event.preventDefault();
      api.reload().catch(() => {});
    } else if (ctrl && key === 'f') {
      event.preventDefault();
      openFind();
    } else if (event.key === 'F5') {
      event.preventDefault();
      api.reload().catch(() => {});
    } else if (event.key === 'Escape' && findVisible) {
      event.preventDefault();
      closeFind(false);
    } else if (ctrl && key === 'tab') {
      event.preventDefault();
      cycleTabs(event.shiftKey ? -1 : 1);
    } else if (ctrl && (key === '=' || key === '+')) {
      event.preventDefault();
      api.zoom(1).catch(() => {});
    } else if (ctrl && key === '-') {
      event.preventDefault();
      api.zoom(-1).catch(() => {});
    } else if (ctrl && key === '0') {
      event.preventDefault();
      api.zoom(0).catch(() => {});
    }
  });

  api.onEvent((payload) => {
    if (!payload || typeof payload !== 'object') return;
    if (payload.type === 'state') {
      render(payload.state);
    } else if (payload.type === 'focus-address') {
      focusAddress();
    } else if (payload.type === 'focus-find') {
      openFind();
    } else if (payload.type === 'close-find') {
      closeFind(true);
    } else if (payload.type === 'find-result') {
      updateFindCount(payload);
    } else if (payload.type === 'notice') {
      showNotice(payload.text, payload.level);
    } else if (payload.type === 'notice-clear') {
      clearNotice();
    } else if (payload.type === 'fullscreen') {
      document.body.classList.toggle('is-fullscreen', Boolean(payload.active));
    }
  });

  api.getState().then(render).catch(() => {});
})();
