'use strict';

(function () {
  const params = new URLSearchParams(window.location.search);
  const token = String(params.get('t') || '').trim();
  const cancelMode = window.location.pathname.replace(/\/+$/, '') === '/pago/cancelado';
  const TOKEN_RE = /^[A-Za-z0-9_-]{20,200}$/;
  const KEY_RE = /^[A-Z0-9]{4}(?:-[A-Z0-9]{4}){3}$/;
  const TERMINAL = new Set(['paid', 'failed', 'cancelled', 'refunded', 'expired']);

  const el = {
    badge: document.getElementById('order-badge'),
    title: document.getElementById('order-title'),
    message: document.getElementById('order-message'),
    notice: document.getElementById('order-notice'),
    spinner: document.getElementById('order-spinner'),
    details: document.getElementById('order-details'),
    key: document.getElementById('license-key'),
    copy: document.getElementById('copy-key'),
    copyStatus: document.getElementById('copy-status'),
    metaCustomer: document.getElementById('meta-customer'),
    metaEmail: document.getElementById('meta-email'),
    metaPlan: document.getElementById('meta-plan'),
    metaExpires: document.getElementById('meta-expires'),
    metaLicense: document.getElementById('meta-license'),
    metaOrder: document.getElementById('meta-order'),
    refresh: document.getElementById('order-refresh'),
    help: document.getElementById('order-help'),
  };

  let stopped = false;
  let timer = null;
  let attempts = 0;
  let failures = 0;
  let lastStatus = '';
  let supportEmail = '';
  let supportAnchor = null;
  let currentKey = '';
  let currentOrderId = '';

  function badge(label, className) {
    if (!el.badge) return;
    el.badge.className = `order-badge ${className}`;
    el.badge.textContent = label;
  }

  function setTitle(text) {
    if (el.title) el.title.textContent = text;
  }

  function setMessage(text) {
    if (el.message) el.message.textContent = text;
  }

  function setNotice(text) {
    if (!el.notice) return;
    if (text) {
      el.notice.textContent = text;
      el.notice.hidden = false;
    } else {
      el.notice.textContent = '';
      el.notice.hidden = true;
    }
  }

  function showSpinner(visible) {
    if (el.spinner) el.spinner.hidden = !visible;
  }

  function showDetails(visible) {
    if (el.details) el.details.hidden = !visible;
  }

  function formatDate(value) {
    if (!value) return '—';
    const date = new Date(value);
    if (!Number.isFinite(date.getTime())) return String(value);
    try {
      return new Intl.DateTimeFormat('es-ES', { dateStyle: 'long', timeZone: 'UTC' }).format(date);
    } catch {
      return date.toISOString().slice(0, 10);
    }
  }

  function formatMoney(cents, currency) {
    try {
      return new Intl.NumberFormat('es-ES', {
        style: 'currency',
        currency: currency || 'USD',
        currencyDisplay: 'narrowSymbol',
      }).format(Number(cents) / 100);
    } catch {
      return `${(Number(cents) / 100).toFixed(2)} ${currency || 'USD'}`;
    }
  }

  function supportHref(orderId) {
    if (supportEmail) {
      const subject = encodeURIComponent(`Ayuda con mi compra de PerfilLab${orderId ? ` · ${orderId}` : ''}`);
      const body = encodeURIComponent(`Hola, necesito ayuda con mi compra de PerfilLab.${orderId ? `\n\nReferencia: ${orderId}` : ''}`);
      return `mailto:${supportEmail}?subject=${subject}&body=${body}`;
    }
    return '/#faq';
  }

  function setHelp(text, { orderId = '', link = true } = {}) {
    if (!el.help) return;
    el.help.textContent = '';
    el.help.append(document.createTextNode(text || ''));
    supportAnchor = null;
    if (link) {
      const anchor = document.createElement('a');
      anchor.href = supportHref(orderId);
      anchor.textContent = supportEmail ? 'Contactar con soporte' : 'Ver preguntas frecuentes';
      el.help.append(anchor);
      supportAnchor = anchor;
    }
    el.help.hidden = false;
  }

  function updateSupportAnchor(orderId) {
    if (supportAnchor) supportAnchor.href = supportHref(orderId);
  }

  function loadSupportEmail() {
    fetch('/api/store', {
      headers: { Accept: 'application/json' },
      credentials: 'omit',
      cache: 'no-store',
    })
      .then((response) => (response.ok ? response.json() : null))
      .then((data) => {
        if (data && typeof data.supportEmail === 'string' && data.supportEmail) {
          supportEmail = data.supportEmail;
          if (supportAnchor) supportAnchor.href = supportHref(currentOrderId);
        }
      })
      .catch(() => {
        // El enlace de soporte tiene un destino alternativo.
      });
  }

  function renderInvalid(message) {
    stopped = true;
    badge('Enlace no válido', 'is-error');
    setTitle('No pudimos abrir esta compra');
    setMessage(message || 'El enlace no contiene una referencia válida. Vuelve a la tienda o revisa el correo de confirmación.');
    setNotice('');
    showSpinner(false);
    showDetails(false);
    if (el.refresh) el.refresh.hidden = true;
    document.title = 'Compra no encontrada · PerfilLab';
  }

  function fillMeta(data) {
    const license = data.license && typeof data.license === 'object' ? data.license : {};
    if (el.metaCustomer) el.metaCustomer.textContent = data.customerName || license.customerName || 'Cliente';
    if (el.metaEmail) el.metaEmail.textContent = data.emailMasked || '—';
    if (el.metaPlan) {
      const months = Number(data.durationMonths) || 12;
      const labels = { monthly: 'Mensual', semiannual: 'Semestral', annual: 'Anual' };
      const label = typeof data.planLabel === 'string' && data.planLabel
        ? data.planLabel
        : (labels[data.plan] || 'Anual');
      el.metaPlan.textContent = `${label} · ${months === 1 ? '1 mes' : `${months} meses`}`;
    }
    if (el.metaExpires) el.metaExpires.textContent = formatDate(license.expiresAt);
    if (el.metaLicense) el.metaLicense.textContent = license.licenseId || '—';
    if (el.metaOrder) el.metaOrder.textContent = data.orderId || '—';
  }

  function renderPaid(data) {
    badge('Pago confirmado', 'is-paid');
    setTitle('Tu licencia está lista');
    setMessage(data.message || 'Pago confirmado. Tu licencia ya está disponible.');
    setNotice(data.notice || '');
    showSpinner(false);
    showDetails(true);
    fillMeta(data);
    const license = data.license && typeof data.license === 'object' ? data.license : {};
    const key = typeof license.licenseKey === 'string' ? license.licenseKey : '';
    currentKey = KEY_RE.test(key) ? key : '';
    if (el.key) el.key.textContent = currentKey || 'Clave no disponible';
    if (el.copy) el.copy.disabled = !currentKey;
    if (el.copyStatus) el.copyStatus.textContent = '';
    if (currentKey) {
      setHelp('Guarda tu clave. También enviamos una copia al correo indicado. Si no la recibes, puedes contactar con nosotros. ', {
        orderId: data.orderId,
      });
    } else {
      const amount = formatMoney(data.amountCents, data.currency);
      setHelp(`El pago de ${amount} está confirmado, pero la clave no se pudo mostrar. Contacta con soporte con tu referencia. `, {
        orderId: data.orderId,
      });
    }
    document.title = 'Licencia lista · PerfilLab';
  }

  function renderWaiting(data) {
    badge('Verificando pago', 'is-waiting');
    setTitle('Estamos confirmando tu pago');
    setMessage(data.message || 'PayPal aún no confirmó el pago. Esta página se actualiza automáticamente.');
    setNotice(data.notice || 'No cierres esta página. La licencia aparecerá aquí en cuanto el pago sea verificado.');
    showSpinner(true);
    showDetails(false);
    if (el.refresh) el.refresh.hidden = false;
    document.title = 'Confirmando pago · PerfilLab';
  }

  function renderTerminal(data) {
    const status = data.status;
    const configs = {
      failed: {
        label: 'Compra no completada',
        title: 'No pudimos completar la compra',
        className: 'is-error',
        titleDocument: 'Compra no completada · PerfilLab',
      },
      cancelled: {
        label: 'Compra cancelada',
        title: 'La compra fue cancelada',
        className: 'is-neutral',
        titleDocument: 'Compra cancelada · PerfilLab',
      },
      refunded: {
        label: 'Pago reembolsado',
        title: 'El pago fue reembolsado',
        className: 'is-error',
        titleDocument: 'Pago reembolsado · PerfilLab',
      },
      expired: {
        label: 'Orden expirada',
        title: 'La orden expiró',
        className: 'is-neutral',
        titleDocument: 'Orden expirada · PerfilLab',
      },
    };
    const config = configs[status] || {
      label: 'Compra cerrada',
      title: 'Estado de la compra',
      className: 'is-neutral',
      titleDocument: 'Estado de la compra · PerfilLab',
    };
    badge(config.label, config.className);
    setTitle(config.title);
    setMessage(data.message || 'El estado de esta compra no permite continuar.');
    setNotice('');
    showSpinner(false);
    showDetails(false);
    if (el.refresh) el.refresh.hidden = false;
    setHelp(`Si necesitas ayuda con esta compra, indícanos la referencia ${data.orderId || ''}. `, {
      orderId: data.orderId,
    });
    document.title = config.titleDocument;
  }

  function render(data) {
    if (!data || typeof data !== 'object') return;
    if (typeof data.orderId === 'string') currentOrderId = data.orderId;
    if (data.status !== lastStatus) {
      lastStatus = data.status;
      setNotice('');
    }
    if (data.notice) setNotice(data.notice);
    if (data.status === 'paid') {
      renderPaid(data);
      updateSupportAnchor(data.orderId);
      return;
    }
    if (data.status === 'created' || data.status === 'pending') {
      renderWaiting(data);
      updateSupportAnchor(data.orderId);
      return;
    }
    renderTerminal(data);
    updateSupportAnchor(data.orderId);
  }

  function schedule(delay) {
    if (stopped) return;
    timer = window.setTimeout(poll, delay);
  }

  async function poll() {
    if (stopped) return;
    timer = null;
    attempts += 1;
    try {
      const response = await fetch(`/api/orders/${encodeURIComponent(token)}`, {
        method: 'GET',
        headers: { Accept: 'application/json' },
        credentials: 'omit',
        cache: 'no-store',
      });
      const data = await response.json().catch(() => null);
      if (!response.ok || !data) {
        if (response.status === 404) {
          renderInvalid();
          return;
        }
        throw new Error((data && data.error && data.error.message) || 'No se pudo consultar la orden.');
      }
      failures = 0;
      render(data);
      if (TERMINAL.has(data.status)) {
        stopped = true;
        return;
      }
      if (attempts >= 120) {
        stopped = true;
        showSpinner(false);
        badge('Pago en revisión', 'is-waiting');
        setTitle('El pago sigue en revisión');
        setMessage('PayPal todavía no confirmó el cobro. No necesitas hacer nada más: la licencia se enviará al correo cuando se confirme. Puedes volver a comprobar el estado más tarde.');
        setNotice('Si el cargo ya aparece en PayPal, no vuelvas a pagar. Contacta con soporte si tienes dudas.');
        setHelp('Cuando el pago se confirme, la clave aparecerá aquí y se enviará por correo. ', {
          orderId: data.orderId,
        });
        return;
      }
      schedule(attempts < 15 ? 3000 : 6000);
    } catch (error) {
      failures += 1;
      if (failures === 2) {
        setNotice('Problema temporal de conexión. Seguimos intentando verificar el estado.');
      }
      if (failures >= 6) {
        stopped = true;
        showSpinner(false);
        badge('Sin conexión', 'is-error');
        setTitle('No podemos consultar la compra');
        setMessage('Revisa tu conexión y pulsa «Actualizar estado». Si el cargo aparece en PayPal, no vuelvas a pagar.');
        setHelp('Si el problema continúa, contacta con soporte. ', { orderId: '' });
        return;
      }
      schedule(5000);
    }
  }

  async function cancelOrder() {
    badge('Cancelando compra', 'is-waiting');
    setTitle('Cancelando la compra');
    setMessage('Estamos cerrando la orden en PayPal. No se realizará ningún cargo si aún no pagaste.');
    showSpinner(true);
    showDetails(false);
    try {
      const response = await fetch(`/api/orders/${encodeURIComponent(token)}/cancel`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Accept: 'application/json',
        },
        credentials: 'omit',
        cache: 'no-store',
        body: '{}',
      });
      const data = await response.json().catch(() => null);
      if (!response.ok || !data) {
        throw new Error((data && data.error && data.error.message) || 'No se pudo cancelar la orden.');
      }
      render(data);
      if (TERMINAL.has(data.status)) {
        stopped = true;
        return;
      }
      schedule(3000);
    } catch {
      setNotice('No pudimos confirmar la cancelación en este momento. Comprobando el estado de la orden.');
      schedule(3000);
    }
  }

  async function copyKey() {
    if (!currentKey) return;
    if (el.copyStatus) el.copyStatus.textContent = '';
    try {
      if (navigator.clipboard && window.isSecureContext) {
        await navigator.clipboard.writeText(currentKey);
      } else {
        const helper = document.createElement('textarea');
        helper.className = 'copy-helper';
        helper.value = currentKey;
        helper.setAttribute('readonly', '');
        document.body.appendChild(helper);
        helper.select();
        const copied = document.execCommand('copy');
        document.body.removeChild(helper);
        if (!copied) throw new Error('copy_failed');
      }
      if (el.copyStatus) el.copyStatus.textContent = 'Copiada al portapapeles';
    } catch {
      if (el.copyStatus) el.copyStatus.textContent = 'Selecciona la clave y cópiala manualmente';
    }
    window.setTimeout(() => {
      if (el.copyStatus) el.copyStatus.textContent = '';
    }, 5000);
  }

  if (!TOKEN_RE.test(token)) {
    renderInvalid('El enlace no contiene una referencia válida. Vuelve a la tienda o revisa el correo de confirmación.');
    return;
  }
  if (el.copy) el.copy.addEventListener('click', copyKey);
  if (el.refresh) {
    el.refresh.addEventListener('click', () => {
      if (stopped) {
        window.location.reload();
        return;
      }
      if (timer) window.clearTimeout(timer);
      poll();
    });
  }
  loadSupportEmail();
  if (cancelMode) cancelOrder();
  else poll();
})();
