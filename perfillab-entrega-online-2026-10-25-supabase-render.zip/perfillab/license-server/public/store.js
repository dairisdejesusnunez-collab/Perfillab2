'use strict';

(function () {
  const state = {
    config: null,
    plans: [],
    plan: 'annual',
    submitting: false,
  };

  const elements = {
    stock: document.getElementById('stock-status'),
    price: document.getElementById('price-amount'),
    pricePeriod: document.getElementById('price-period'),
    priceNote: document.getElementById('price-note'),
    planPill: document.getElementById('plan-pill'),
    planOptions: Array.from(document.querySelectorAll('#plan-options, #checkout-plans')),
    summaryPrice: document.getElementById('summary-price'),
    summaryPlan: document.getElementById('summary-plan'),
    message: document.getElementById('store-message'),
    buyLink: document.getElementById('buy-link'),
    form: document.getElementById('checkout-form'),
    button: document.getElementById('checkout-button'),
    terms: document.getElementById('accept-terms'),
    email: document.getElementById('customer-email'),
    name: document.getElementById('customer-name'),
    error: document.getElementById('form-error'),
    support: document.getElementById('support-link'),
    supportFooter: document.getElementById('support-link-footer'),
    year: document.getElementById('footer-year'),
    downloadLink: document.getElementById('download-link'),
    downloadNote: document.getElementById('download-note'),
    downloadMeta: document.getElementById('download-meta'),
    downloadVersionItem: document.getElementById('download-version-item'),
    downloadVersion: document.getElementById('download-version'),
    downloadSizeItem: document.getElementById('download-size-item'),
    downloadSize: document.getElementById('download-size'),
    downloadHashItem: document.getElementById('download-hash-item'),
    downloadSha256: document.getElementById('download-sha256'),
  };

  function formatPrice(amountCents, currency) {
    try {
      return new Intl.NumberFormat('es-ES', {
        style: 'currency',
        currency,
        currencyDisplay: 'narrowSymbol',
      }).format(amountCents / 100);
    } catch {
      return `${(amountCents / 100).toFixed(2)} ${currency}`;
    }
  }

  function durationText(plan) {
    return plan.months === 1 ? '1 mes' : `${plan.months} meses`;
  }

  function formatBytes(bytes) {
    if (!Number.isFinite(bytes) || bytes < 1) return '';
    if (bytes >= 1024 * 1024 * 1024) return `${(bytes / (1024 * 1024 * 1024)).toFixed(1)} GB`;
    if (bytes >= 1024 * 1024) return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
    if (bytes >= 1024) return `${Math.round(bytes / 1024)} KB`;
    return `${bytes} B`;
  }

  function normalizePlans(config) {
    const raw = Array.isArray(config.plans) ? config.plans : [];
    const plans = raw
      .filter((plan) => plan
        && typeof plan.code === 'string'
        && plan.code
        && Number.isInteger(plan.amountCents)
        && plan.amountCents > 0
        && Number.isInteger(plan.months)
        && plan.months > 0)
      .map((plan) => ({
        code: plan.code,
        label: typeof plan.label === 'string' && plan.label ? plan.label : plan.code,
        months: plan.months,
        periodLabel: typeof plan.periodLabel === 'string' && plan.periodLabel
          ? plan.periodLabel
          : (plan.months === 1 ? 'mes' : `${plan.months} meses`),
        amountCents: plan.amountCents,
        currency: typeof plan.currency === 'string' && plan.currency ? plan.currency : (config.currency || 'USD'),
        description: typeof plan.description === 'string' ? plan.description : '',
      }));
    if (!plans.length && config.price && Number.isInteger(config.price.amountCents) && config.price.amountCents > 0) {
      plans.push({
        code: config.plan && config.plan.code ? config.plan.code : 'annual',
        label: config.plan && config.plan.label ? config.plan.label : 'Anual',
        months: config.plan && Number.isInteger(config.plan.months) ? config.plan.months : 12,
        periodLabel: '12 meses',
        amountCents: config.price.amountCents,
        currency: config.price.currency || config.currency || 'USD',
        description: '',
      });
    }
    return plans;
  }

  function selectedPlan() {
    return state.plans.find((plan) => plan.code === state.plan) || state.plans[0] || null;
  }

  function updatePlanPressed() {
    for (const container of elements.planOptions) {
      for (const button of container.querySelectorAll('[data-plan]')) {
        button.setAttribute('aria-pressed', button.dataset.plan === state.plan ? 'true' : 'false');
      }
    }
  }

  function renderPlanOptions() {
    const disabled = !state.config || !state.config.checkoutEnabled;
    for (const container of elements.planOptions) {
      container.textContent = '';
      for (const plan of state.plans) {
        const button = document.createElement('button');
        button.type = 'button';
        button.className = 'plan-option';
        button.dataset.plan = plan.code;
        button.setAttribute('aria-pressed', plan.code === state.plan ? 'true' : 'false');
        button.disabled = disabled;
        const label = document.createElement('span');
        label.className = 'plan-option-label';
        label.textContent = plan.label;
        const period = document.createElement('span');
        period.className = 'plan-option-period';
        period.textContent = durationText(plan);
        const price = document.createElement('span');
        price.className = 'plan-option-price';
        price.textContent = formatPrice(plan.amountCents, plan.currency);
        button.append(label, period, price);
        container.appendChild(button);
      }
    }
  }

  function applySelectedPlan() {
    const plan = selectedPlan();
    if (!plan) return;
    const formatted = formatPrice(plan.amountCents, plan.currency);
    if (elements.price) elements.price.textContent = formatted;
    if (elements.summaryPrice) elements.summaryPrice.textContent = formatted;
    if (elements.pricePeriod) {
      const periods = { 1: '/ mes', 6: '/ semestre', 12: '/ año' };
      elements.pricePeriod.textContent = periods[plan.months] || `/ ${plan.months} meses`;
    }
    if (elements.priceNote) {
      const duration = plan.description || `Vigencia de ${durationText(plan)}`;
      elements.priceNote.textContent = `Un solo pago. ${duration}; sin renovación automática.`;
    }
    if (elements.planPill) elements.planPill.textContent = `Plan ${plan.label.toLowerCase()}`;
    if (elements.summaryPlan) elements.summaryPlan.textContent = `${plan.label} · ${durationText(plan)}`;
    if (elements.buyLink && state.config && state.config.checkoutEnabled) {
      elements.buyLink.textContent = `Elegir plan ${plan.label.toLowerCase()}`;
    }
    updatePlanPressed();
  }

  function selectPlan(code) {
    if (!state.plans.some((plan) => plan.code === code)) return;
    state.plan = code;
    applySelectedPlan();
    clearError();
  }

  function setStock(label, stateName) {
    if (!elements.stock) return;
    elements.stock.textContent = label;
    elements.stock.dataset.state = stateName;
  }

  function setMessage(text) {
    if (elements.message) elements.message.textContent = text;
  }

  function showError(message) {
    if (!elements.error) return;
    elements.error.textContent = message;
    elements.error.hidden = false;
  }

  function clearError() {
    if (!elements.error) return;
    elements.error.textContent = '';
    elements.error.hidden = true;
  }

  function updateButton() {
    if (!elements.button) return;
    const ready = Boolean(
      state.config
      && state.config.checkoutEnabled
      && state.plans.length
      && elements.terms
      && elements.terms.checked
      && !state.submitting,
    );
    elements.button.disabled = !ready;
    elements.button.textContent = state.submitting ? 'Conectando con PayPal…' : 'Continuar con PayPal';
  }

  function applySupportEmail(email) {
    if (!email) return;
    const href = `mailto:${email}`;
    if (elements.support) {
      elements.support.href = href;
      elements.support.textContent = email;
    }
    if (elements.supportFooter) {
      elements.supportFooter.href = href;
      elements.supportFooter.textContent = 'Soporte';
    }
  }

  function setDownloadMeta(version, sizeBytes, sha256) {
    if (elements.downloadVersionItem) {
      elements.downloadVersionItem.hidden = !version;
      if (version && elements.downloadVersion) elements.downloadVersion.textContent = version;
    }
    if (elements.downloadSizeItem) {
      elements.downloadSizeItem.hidden = !sizeBytes;
      if (sizeBytes && elements.downloadSize) elements.downloadSize.textContent = formatBytes(sizeBytes);
    }
    if (elements.downloadHashItem) {
      elements.downloadHashItem.hidden = !sha256;
      if (sha256 && elements.downloadSha256) elements.downloadSha256.textContent = sha256;
    }
    if (elements.downloadMeta) {
      elements.downloadMeta.hidden = !(version || sizeBytes || sha256);
    }
  }

  function applyDownload(download) {
    if (!elements.downloadLink) return;
    const url = download && typeof download.url === 'string' ? download.url : '';
    if (!/^\/(?!\/)/.test(url)) {
      elements.downloadLink.hidden = true;
      elements.downloadLink.removeAttribute('href');
      elements.downloadLink.removeAttribute('download');
      setDownloadMeta('', 0, '');
      if (elements.downloadNote) {
        elements.downloadNote.textContent = 'El instalador todavía no está publicado. Estará disponible aquí en cuanto lo publiquemos.';
      }
      return;
    }
    const version = typeof download.version === 'string' ? download.version : '';
    const sizeBytes = Number.isInteger(download.sizeBytes) && download.sizeBytes > 0 ? download.sizeBytes : 0;
    const sha256 = typeof download.sha256 === 'string' && /^[a-f0-9]{64}$/i.test(download.sha256)
      ? download.sha256.toLowerCase()
      : '';
    elements.downloadLink.hidden = false;
    elements.downloadLink.href = url;
    if (typeof download.filename === 'string' && download.filename) {
      elements.downloadLink.setAttribute('download', download.filename);
    }
    if (elements.downloadNote) {
      elements.downloadNote.textContent = typeof download.filename === 'string' && download.filename
        ? `Instalador para Windows · ${download.filename}`
        : 'Instalador para Windows';
    }
    setDownloadMeta(version, sizeBytes, sha256);
  }

  function applyConfig(config) {
    state.config = config;
    state.plans = normalizePlans(config);
    const hasPlan = (code) => state.plans.some((plan) => plan.code === code);
    const preferred = config.plan && config.plan.code;
    if (preferred && hasPlan(preferred)) {
      state.plan = preferred;
    } else if (!hasPlan(state.plan)) {
      state.plan = hasPlan('annual') ? 'annual' : (state.plans[0] ? state.plans[0].code : '');
    }
    if (config.productName) {
      document.title = `${config.productName} · Licencias`;
    }
    renderPlanOptions();
    if (state.plans.length) {
      applySelectedPlan();
    } else {
      if (elements.price) elements.price.textContent = '—';
      if (elements.summaryPrice) elements.summaryPrice.textContent = '—';
    }
    applySupportEmail(config.supportEmail);
    applyDownload(config.download);

    if (config.soldOut) {
      setStock('Agotado', 'soldout');
      setMessage('No quedan licencias disponibles en este momento. Vuelve a intentarlo más tarde.');
    } else if (!config.paymentsEnabled) {
      setStock('Ventas pausadas', 'closed');
      setMessage('La tienda está temporalmente cerrada. Vuelve a intentarlo más tarde o contacta con soporte.');
    } else if (!config.checkoutEnabled) {
      setStock('No disponible', 'closed');
      setMessage('La compra no está disponible en este momento.');
    } else {
      setStock('Disponible', 'available');
      setMessage('Precio final en USD. La clave se entrega al confirmar el pago.');
    }

    if (elements.buyLink) {
      if (config.checkoutEnabled) {
        elements.buyLink.classList.remove('is-disabled');
        elements.buyLink.removeAttribute('aria-disabled');
        elements.buyLink.textContent = state.plans.length
          ? `Elegir plan ${selectedPlan().label.toLowerCase()}`
          : 'Elegir esta licencia';
      } else {
        elements.buyLink.classList.add('is-disabled');
        elements.buyLink.setAttribute('aria-disabled', 'true');
        elements.buyLink.textContent = 'Compra no disponible';
        elements.buyLink.addEventListener('click', (event) => {
          event.preventDefault();
          setMessage(elements.message ? elements.message.textContent : 'Compra no disponible.');
        });
      }
    }
    updateButton();
  }

  async function loadConfig() {
    try {
      const response = await fetch('/api/store', {
        method: 'GET',
        headers: { Accept: 'application/json' },
        credentials: 'omit',
        cache: 'no-store',
      });
      const data = await response.json().catch(() => null);
      if (!response.ok || !data) {
        throw new Error((data && data.error && data.error.message) || 'No se pudo cargar la tienda.');
      }
      applyConfig(data);
    } catch {
      setStock('No disponible', 'closed');
      setMessage('No pudimos cargar los planes. Revisa tu conexión y recarga la página.');
      if (elements.button) elements.button.disabled = true;
      if (elements.buyLink) elements.buyLink.classList.add('is-disabled');
      if (elements.downloadLink) elements.downloadLink.hidden = true;
      if (elements.downloadMeta) elements.downloadMeta.hidden = true;
      if (elements.downloadNote) {
        elements.downloadNote.textContent = 'No pudimos comprobar el instalador. Recarga la página para volver a intentarlo.';
      }
    }
  }

  async function submitCheckout(event) {
    event.preventDefault();
    if (state.submitting) return;
    clearError();
    if (!state.config || !state.config.checkoutEnabled) {
      showError('La compra no está disponible en este momento.');
      return;
    }
    const email = elements.email ? elements.email.value.trim() : '';
    const name = elements.name ? elements.name.value.trim() : '';
    const plan = selectedPlan();
    if (!plan) {
      showError('No pudimos cargar los planes disponibles. Recarga la página e inténtalo de nuevo.');
      return;
    }
    if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      showError('Escribe un correo electrónico válido para recibir tu licencia.');
      if (elements.email) elements.email.focus();
      return;
    }
    if (!elements.terms || !elements.terms.checked) {
      showError('Debes aceptar las condiciones de compra para continuar.');
      return;
    }
    state.submitting = true;
    updateButton();
    try {
      const response = await fetch('/api/checkout', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Accept: 'application/json',
        },
        credentials: 'omit',
        cache: 'no-store',
        body: JSON.stringify({
          email,
          name,
          acceptTerms: true,
          plan: plan.code,
        }),
      });
      const data = await response.json().catch(() => null);
      if (!response.ok || !data || !data.approvalUrl) {
        const message = data && data.error && data.error.message
          ? data.error.message
          : 'No se pudo iniciar el pago. Inténtalo de nuevo.';
        throw new Error(message);
      }
      window.location.assign(data.approvalUrl);
    } catch (error) {
      state.submitting = false;
      updateButton();
      showError(error && error.message ? error.message : 'No se pudo iniciar el pago. Inténtalo de nuevo.');
    }
  }

  for (const container of elements.planOptions) {
    container.addEventListener('click', (event) => {
      const button = event.target.closest('[data-plan]');
      if (!button || button.disabled) return;
      selectPlan(button.dataset.plan);
    });
  }
  if (elements.terms) {
    elements.terms.addEventListener('change', () => {
      clearError();
      updateButton();
    });
  }
  if (elements.form) {
    elements.form.addEventListener('submit', submitCheckout);
  }
  if (elements.email) {
    elements.email.addEventListener('input', clearError);
  }
  if (elements.year) {
    elements.year.textContent = String(new Date().getFullYear());
  }
  updateButton();
  loadConfig();
})();
