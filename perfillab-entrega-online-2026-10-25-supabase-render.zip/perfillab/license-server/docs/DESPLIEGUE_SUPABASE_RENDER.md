# Despliegue en Supabase + Render

Ruta recomendada para publicar el servidor de licencias sin administrar un VPS:

- **Supabase** aporta PostgreSQL gestionado, con copias y conexión TLS.
- **Render** ejecuta el contenedor Docker del servidor con HTTPS y un dominio público.
- El keystore y la frase de paso viven como secretos del servicio; el servidor conserva la misma clave pública que ya está fijada en el cliente.

> Esta guía no crea cuentas ni recursos por ti y no contiene credenciales. Necesitas tus propias cuentas de Supabase, Render, GitHub y PayPal. No pegues contraseñas, frases de paso ni el keystore en el chat, en el repositorio ni en capturas.

## 0. Orden obligatorio

La base se inicializa **antes** del primer despliegue, porque el servidor comprueba al arrancar que existan los 50.000 asientos y la clave de firma. Si despliegas primero y la base está vacía, Render mostrará un servicio que no arranca.

1. Crear el proyecto de Supabase.
2. Crear la base remota clonando la base local completa o inicializándola desde la bóveda.
3. Exportar el keystore cifrado en base64.
4. Subir el código a un repositorio privado.
5. Crear el servicio en Render desde `render.yaml`.
6. Configurar la URL pública, PayPal y el instalador.
7. Compilar el cliente con la URL de Render antes de generar los instaladores.

## 1. Requisitos

- Node.js 24 o superior en tu equipo.
- Cuenta de Supabase.
- Cuenta de Render y un repositorio de GitHub (privado) con el código.
- El keystore del servidor (`license-server/data/keystore.json`) y su frase de paso, ya generados.
- La bóveda heredada (`license-admin/seed/vault.json`) y su contraseña. Solo se usa si eliges la inicialización desde la bóveda; el clonado completo no la necesita.
- PayPal en modo Sandbox con Client ID, Client Secret y Webhook ID.
- Opcional: SMTP para entregar la licencia por correo.
- Opcional: Inno Setup 6 para regenerar los instaladores.

La clave privada del keystore **no** se sube a Supabase ni a Render en claro. Se guarda cifrada en el secreto `PERFILLAB_KEYSTORE_BASE64` y la frase se configura aparte.

## 2. Crear y preparar Supabase

1. Entra en [supabase.com](https://supabase.com), crea un proyecto y elige una región cercana a tu público. Render usará `virginia` por defecto; si tu proyecto de Supabase está en otra región, cambia `region` en `render.yaml` o crea el servicio en la región equivalente.
2. Define una contraseña de base de datos larga y guárdala en tu gestor de secretos. La necesitarás para la URL de conexión.
3. En **Project Settings → Database → Connection string**, elige **Session pooler** (modo sesión, puerto **5432**). Es el modo recomendado para un proceso de larga duración como este servidor.
   - La URL tiene la forma:
     ```text
     postgresql://postgres.<project-ref>:<contraseña>@<host-del-pooler>:5432/postgres
     ```
   - El usuario debe ser `postgres.<project-ref>`, no solo `postgres`, cuando uses el pooler.
   - **No** uses las claves `anon` o `service_role` de Supabase como contraseña: son claves de su API, no credenciales de PostgreSQL.
4. Codifica la contraseña antes de pegarla en la URL. Si contiene `@`, `:`, `/`, `?`, `#`, `%`, `&` o espacios, debe ir codificada. En PowerShell, sin dejar la contraseña en el historial:
   ```powershell
   $seguro = Read-Host -AsSecureString 'Contraseña de Supabase'
   $texto = [Runtime.InteropServices.Marshal]::PtrToStringAuto(
     [Runtime.InteropServices.Marshal]::SecureStringToBSTR($seguro)
   )
   [uri]::EscapeDataString($texto)
   ```
   Pega el resultado en el lugar de `<contraseña>`.
5. Deja `PERFILLAB_DATABASE_SSL=require`. El pooler exige TLS. La URL puede conservar `?sslmode=require`; el servidor también aplica el cifrado con la variable.
6. Comprueba los límites del plan gratuito antes de abrir la tienda:
   - **Pausa por inactividad**: Supabase pausa los proyectos gratuitos tras unos 7 días sin actividad. Mientras el servidor reciba tráfico de licencias o administración no debería pausarse; si queda inactivo, tendrás que reanudarlo desde el panel.
   - **Conexiones**: usa `PERFILLAB_DATABASE_POOL_MAX=5` (ya está en `render.yaml`) y no ejecutes varias réplicas del servicio contra la misma base.
   - **Backups**: revisa la política de tu plan. No supongas que hay recuperación a un punto en el tiempo.

> Si la conexión directa falla por IPv6, usa el **Session pooler**. La conexión directa de Supabase puede depender de IPv6 o de un complemento IPv4 según el proyecto; el pooler evita esa duda y es el modo indicado para Render.

## 3. Inicializar la base remota

Ejecuta estos pasos desde `license-server/`, en tu equipo. El servidor local no se toca: la URL de PostgreSQL dirige las operaciones a Supabase.

### 3.1 Archivo de entorno temporal fuera del repositorio

Crea un archivo con permisos restringidos fuera del proyecto, por ejemplo `C:\Users\<usuario>\perfillab-secrets\online.env`, y escribe:

```dotenv
NODE_ENV=production
PERFILLAB_DATABASE_URL=postgresql://postgres.<project-ref>:<contraseña-codificada>@<host-del-pooler>:5432/postgres?sslmode=require
PERFILLAB_DATABASE_SSL=require
PERFILLAB_DATABASE_SCHEMA=public
PERFILLAB_DATABASE_POOL_MAX=5
PERFILLAB_DATA_DIR=.\data
PERFILLAB_KEYSTORE_PATH=.\data\keystore.json
```

Notas:

- `PERFILLAB_DATA_DIR` y `PERFILLAB_KEYSTORE_PATH` son relativos a `license-server/`; ejecuta los comandos desde esa carpeta.
- Si el keystore está en otra ruta, cambia `PERFILLAB_KEYSTORE_PATH`.
- **No** definas `PERFILLAB_KEYSTORE_BASE64` en este archivo: el comando de exportación necesita leer el archivo del keystore.
- Este archivo contiene la contraseña de la base. No lo copies al repositorio, al ZIP ni a una carpeta sincronizada.

### 3.2 Crear la base: elige un camino

Ejecuta **solo uno** de los dos. La base se inicializa una vez y los scripts se niegan a modificarla si ya contiene asientos.

#### 3.2.A Clonar la base local completa (recomendado si ya tienes datos)

Copia a Supabase el esquema, los 50.000 asientos, los ajustes, el administrador y las licencias o pedidos que ya existan en `license-server/data/perfillab.sqlite`. Conserva el mismo `keyId` y no necesita la contraseña de la bóveda.

```powershell
cd <RUTA_DEL_PROYECTO>\perfillab\license-server
node --env-file="$HOME\perfillab-secrets\online.env" scripts/clone-to-postgres.js
```

El destino debe estar vacío; si ya tiene asientos o ajustes, el script se detiene sin modificar nada. Al terminar verás un resumen como:

```json
{
  "seats": 50000,
  "keyId": "a31600beab3f7311",
  "adminUsers": 1,
  "licenses": 1,
  "database": "postgres",
  "schema": "public"
}
```

Notas:

- Se copian también las licencias locales. Si la base local solo contiene pruebas, bórralas o revócalas antes de clonar.
- El administrador local se copia con su misma contraseña. Si no la conservas, crea otro después con `scripts/admin.js create`; no hay administrador universal.
- Las sesiones administrativas abiertas no se copian: hay que volver a iniciar sesión.
- El servidor de Render debe usar **el mismo keystore** que esta base. Con otro keystore el arranque falla con «El keystore no corresponde a la base de datos de licencias».
- El script no abre el keystore ni pide frases de paso; solo copia datos que ya están cifrados.

#### 3.2.B Inicializar desde la bóveda heredada

Úsalo solo si quieres una base nueva creada a partir de la bóveda, sin copiar las licencias o pruebas de la SQLite local.

```powershell
node --env-file="$HOME\perfillab-secrets\online.env" scripts/init.js --vault ..\license-admin\seed\vault.json
```

El comando solicitará, de forma oculta:

- la contraseña de la bóveda heredada;
- la frase de paso del keystore existente (si el keystore no existe, pedirá una nueva y su confirmación).

Debes ver un resumen con:

```json
{
  "seats": 50000,
  "legacySeats": 2000,
  "keyId": "a31600beab3f7311",
  "database": "postgres"
}
```

`keyId` debe coincidir con el valor de `electron/license-public.js`. Si no coincide, **detente**: el keystore pertenece a otra clave y el cliente rechazará las licencias. No repitas la inicialización ni apuntes dos instalaciones a la misma base.

> La bóveda migra las licencias heredadas que ya estaban emitidas. Las licencias emitidas **solo** en la base SQLite local, después de la inicialización, no se copian a Supabase. Si ya hay clientes con licencias de prueba locales, reclámales o vuelve a emitirlas en la base nueva.

### 3.3 Crear o conservar el administrador

Si clonaste la base local, el administrador ya existe con su contraseña habitual: puedes saltar este paso. Si usaste la inicialización desde la bóveda, o si no conservas la contraseña del administrador clonado, crea uno nuevo:

```powershell
node --env-file="$HOME\perfillab-secrets\online.env" scripts/admin.js create --username admin
```

La contraseña se solicita dos veces y no se imprime. No existe un administrador universal. Guarda esa contraseña en tu gestor de secretos.

### 3.4 Exportar el keystore para Render

```powershell
node --env-file="$HOME\perfillab-secrets\online.env" scripts/keystore-env.js --out "$HOME\perfillab-secrets\keystore.base64"
```

El archivo contiene el keystore **cifrado** en base64, no la clave privada en claro. Para pegarlo en Render sin mostrarlo en la pantalla:

```powershell
Get-Content "$HOME\perfillab-secrets\keystore.base64" -Raw | Set-Clipboard
```

Después de pegarlo en el panel, vacía el portapapeles:

```powershell
Set-Clipboard -Value ' '
```

Conserva una copia cifrada del keystore y su frase en un gestor de secretos separado. Si pierdes la frase, no hay recuperación.

## 4. Subir el código a GitHub

El repositorio debe crearse dentro de `perfillab/`, **nunca** en la carpeta padre que contiene la bóveda, contraseñas y copias de seguridad.

```powershell
cd <RUTA_DEL_PROYECTO>\perfillab
git init
git add .
git status
```

Antes de confirmar, revisa que `git status` **no** incluya:

- `license-server/data/` ni ningún `keystore.json`, `.sqlite` o `.sqlite-wal`;
- `license-admin/seed/vault.json`;
- `.env`, `.env.online` ni archivos `*.base64`;
- `perfillab-admin-password.txt`, `perfillab-credenciales-admin.txt` ni la frase de paso.

El `.gitignore` ya cubre esos patrones, pero compruébalo. Luego:

```powershell
git commit -m "Preparar servidor de licencias para Supabase y Render"
```

Crea un repositorio **privado** en GitHub y sube la rama. Render puede leer repositorios privados; los clientes nunca necesitan acceso al código.

## 5. Crear el servicio en Render

1. En Render, elige **New → Blueprint**.
2. Conecta el repositorio. Render detectará `render.yaml` en la raíz.
3. Revisa el servicio `perfillab-licencias`: Docker, plan gratuito, región `virginia`, health check `/api/health`.
4. Render pedirá los secretos marcados con `sync: false`:
   - `PERFILLAB_DATABASE_URL`: la URL del Session pooler de Supabase.
   - `PERFILLAB_KEYSTORE_BASE64`: el contenido de `keystore.base64`, en una sola línea.
   - `PERFILLAB_KEYSTORE_PASSPHRASE`: la frase de paso del keystore.
5. Aplica el Blueprint y espera el build. El contenedor escucha en el puerto que Render inyecta en `PORT`; el `Dockerfile` ya no fija `PERFILLAB_PORT`.
6. Abre los logs. Debes ver `database: postgres`, el `keyId` esperado y la confirmación de los 50.000 asientos. Después abre:
   ```text
   https://<tu-servicio>.onrender.com/api/health
   ```
   Debe responder `{"ok":true,...}`.

Si el servicio no arranca, revisa la sección 10 antes de cambiar variables al azar.

### 5.1 Configurar la URL pública

Render asigna una URL HTTPS con la forma `https://<nombre>.onrender.com`. Cópiala exactamente del panel; no la inventes, porque el nombre puede llevar un sufijo si ya está ocupado.

En **Environment**, añade:

```text
PERFILLAB_PUBLIC_BASE_URL=https://<tu-servicio>.onrender.com
```

Guarda y vuelve a desplegar. Sin esta variable el servidor arranca, pero la tienda y PayPal quedan cerrados. Si usas un dominio propio, añádelo primero en Render, espera el certificado y usa ese dominio tanto en `PERFILLAB_PUBLIC_BASE_URL` como en el endpoint del cliente.

En el mismo panel puedes añadir después:

```text
PERFILLAB_SUPPORT_EMAIL=soporte@<tu-dominio>
PERFILLAB_PAYPAL_MODE=sandbox
PERFILLAB_PAYPAL_CLIENT_ID=<client-id>
PERFILLAB_PAYPAL_CLIENT_SECRET=<client-secret>
PERFILLAB_PAYPAL_WEBHOOK_ID=<webhook-id>
PERFILLAB_INSTALLER_URL=<url-https-del-instalador>
PERFILLAB_INSTALLER_FILENAME=PerfilLab-Setup-<versión>.exe
PERFILLAB_INSTALLER_VERSION=<versión>
PERFILLAB_INSTALLER_SHA256=<sha256>
PERFILLAB_INSTALLER_SIZE=<bytes>
```

Las credenciales de PayPal también se pueden configurar desde **PerfilLab Licencias → Pagos**; el secreto se guarda cifrado en la base. No dupliques valores contradictorios entre el panel y la consola.

### 5.2 Plan gratuito de Render

- El servicio se duerme tras unos 15 minutos sin tráfico. La primera petición tarda decenas de segundos.
- El cliente de licencias espera hasta 12 segundos por respuesta. **Despierta el servicio abriendo `/api/health` en el navegador antes de la primera activación**, o la activación puede fallar por tiempo de espera. Un plan de pago evita la suspensión.
- El disco del servicio es efímero. La base está en Supabase y el keystore va como secreto, así que un reinicio o un despliegue no pierden datos.
- No guardes copias de seguridad ni SQLite en el disco de Render.

### 5.3 RLS automático en Supabase

Cuando el servidor detecta los roles `anon` y `authenticated` de Supabase, activa RLS en todas las tablas. El servidor sigue leyendo y escribiendo como propietario; la Data API de Supabase queda sin acceso a asientos, licencias, clientes, pedidos y administradores. No desactives RLS ni concedas esas tablas a `anon` o `authenticated`.

Para comprobarlo en el **SQL Editor** de Supabase:

```sql
select relname, relrowsecurity
from pg_class c
join pg_namespace n on n.oid = c.relnamespace
where n.nspname = 'public'
  and c.relkind = 'r'
  and c.relname in ('seats','licenses','orders','customers','admin_users','settings')
order by relname;
```

Todas las filas deben mostrar `relrowsecurity = true`.

## 6. PayPal, tienda e instalador

1. Crea la aplicación Sandbox en el panel de desarrolladores de PayPal. No reutilices credenciales de ejemplo.
2. Configura el webhook con:
   ```text
   https://<tu-servicio>.onrender.com/api/paypal/webhook
   ```
   Suscribe los eventos de orden y captura que correspondan a tu integración (aprobación, captura completada, denegada, reembolsada, revertida y anulada).
3. En la consola administrativa, entra con el administrador creado y abre **Pagos**: Client ID, Client Secret, Webhook ID, modo Sandbox y los tres planes (mensual 10 USD, semestral 50 USD, anual 100 USD).
4. Haz una compra de prueba con una cuenta compradora Sandbox. La licencia se emite solo cuando el servidor verifica la captura o el webhook firmado; volver de PayPal no emite nada.
5. Publica el instalador del cliente en una URL HTTPS **pública**:
   - **GitHub Releases de un repositorio público** (no del repositorio privado del código) o
   - **Supabase Storage** con un bucket público.
   No publiques la consola administrativa ni el ZIP del código en la tienda.
6. Copia `PERFILLAB_INSTALLER_SHA256`, el tamaño y la versión desde `dist/installers.json` a las variables del servicio. El botón de descarga se oculta si el instalador no está configurado o el checksum no coincide.

## 7. Fijar el endpoint en el cliente

Este paso es el que evita que el cliente final vea `http://127.0.0.1:45900` y el error «No se pudo conectar con el servidor de licencias». El endpoint no se escribe en la pantalla de activación: se compila en el ejecutable.

En la raíz del proyecto:

```powershell
npm run license:endpoint -- --server-url=https://<tu-servicio>.onrender.com
```

Verifica que `electron/license-public.js` tenga `serverUrl` con esa URL. Después genera y verifica los instaladores:

```powershell
npm run installers
npm run verify:installers
```

Distribuye solo `dist/PerfilLab-Setup-<versión>.exe`. El comprador escribe su clave; la dirección ya viene configurada. Si reconstruyes el cliente con otro dominio, vuelve a compilar y a firmar los instaladores.

## 8. Respaldos y restauración

- Ejecuta la copia en un equipo con `pg_dump` disponible y el mismo entorno de la sección 3:
  ```powershell
  node --env-file="$HOME\perfillab-secrets\online.env" scripts/backup.js
  ```
  El script usa `pg_dump` y verifica que el volcado termine completo y contenga la tabla `seats`. Si `pg_dump` no está en el `PATH`, define `PERFILLAB_PG_DUMP` con su ruta.
- Usa la conexión de sesión o la directa para `pg_dump`; comprueba que la versión de `pg_dump` sea igual o superior a la de PostgreSQL de Supabase.
- Guarda el volcado, el keystore cifrado y la frase de paso por separado, fuera de Supabase y de Render.
- Para restaurar, crea una base vacía, restaura el volcado y arranca con el mismo keystore. No reutilices capturas de PayPal ni bases de una instalación anterior.
- Revisa la política de copias de Supabase de tu plan; el plan gratuito puede no incluir recuperación a un punto en el tiempo.

## 9. Verificación posterior

1. `/api/health` responde 200 con `ok: true`.
2. Los logs muestran `database: postgres`, el `keyId` esperado y los 50.000 asientos.
3. En Supabase, las tablas de la sección 5.3 muestran `relrowsecurity = true`; `set role anon; select count(*) from seats;` devuelve `0`.
4. `/` muestra los tres planes y el botón de descarga.
5. La consola administrativa inicia sesión por HTTPS con el administrador clonado o el nuevo, lista el inventario y muestra la auditoría.
6. Una compra Sandbox emite **una sola** licencia; repetir el webhook no duplica la emisión.
7. El cliente compilado activa una licencia real contra el servidor de Render y la conserva tras reiniciar.
8. Reinicia el servicio desde Render y confirma que el pedido, la licencia y el `keyId` siguen iguales.
9. Descarga una copia de seguridad y comprueba el manifiesto y los hashes.

## 10. Problemas frecuentes

| Síntoma | Causa probable | Solución |
| --- | --- | --- |
| `password authentication failed` | Contraseña sin codificar o usuario incorrecto | Usa `postgres.<project-ref>` y codifica la contraseña con `EscapeDataString`. |
| `getaddrinfo ENOTFOUND` | Host del pooler mal copiado | Copia la cadena exacta de **Connection string → Session pooler**. |
| `connection is insecure` o error TLS | Falta el cifrado | Define `PERFILLAB_DATABASE_SSL=require` y conserva `sslmode=require` en la URL. |
| `too many connections` | Pool grande o varias réplicas | Deja `PERFILLAB_DATABASE_POOL_MAX=5`, una sola instancia y la URL pooled. |
| `La base de datos no está inicializada` | Se desplegó antes del paso 3 | Ejecuta `clone-to-postgres.js` o `init.js` contra Supabase y vuelve a desplegar. |
| `La base de destino ya tiene datos` | Se ejecutó el clonado dos veces o después de `init.js` | Usa una base vacía; no combines clonado e inicialización. |
| `El keystore no corresponde a la base de datos` | Render usa otro keystore | Despliega el keystore de la base clonada o restaura el que corresponde al `keyId`. |
| `No se pudo abrir el keystore` | Frase incorrecta o base64 truncado | Vuelve a pegar el base64 completo y la frase exacta; no cambies la clave. |
| La tienda está cerrada | Falta `PERFILLAB_PUBLIC_BASE_URL` o PayPal | Añade la URL HTTPS y las credenciales, y redepliega. |
| La activación tarda y falla | El servicio gratuito estaba dormido | Abre `/api/health` y espera a que despierte; reintenta la activación. |
| Supabase aparece pausado | Proyecto gratuito inactivo | Reanúdalo en el panel de Supabase. |
| `/descargar` responde 404 | Instalador ausente o checksum distinto | Revisa URL, tamaño y SHA-256 del manifiesto. |
| El cliente sigue mostrando `127.0.0.1` | Instalador compilado sin endpoint | Ejecuta `license:endpoint` y regenera los instaladores. |
| El cliente guardó otra URL antes | `license-config.json` tiene prioridad sobre la compilada | Borra `%LOCALAPPDATA%\PerfilLab\license-config.json` o corrige el endpoint en el build. |

Para el procedimiento general de operaciones, rotación y compromiso de claves, consulta [`OPERACIONES.md`](OPERACIONES.md). Para otras plataformas, consulta [`DESPLIEGUE_ONLINE.md`](DESPLIEGUE_ONLINE.md).

## 11. Lista de comprobación

- [ ] Proyecto de Supabase creado y contraseña guardada.
- [ ] URL del Session pooler con la contraseña codificada.
- [ ] Base creada (clonada o inicializada) con 50.000 asientos y el `keyId` correcto.
- [ ] RLS activo en Supabase; `anon` no puede leer las tablas.
- [ ] Administrador disponible (clonado o creado sin cuenta universal).
- [ ] Keystore y frase de paso guardados por separado.
- [ ] Repositorio privado sin secretos, bóveda, keystore ni SQLite.
- [ ] Blueprint de Render desplegado y `/api/health` en verde.
- [ ] `PERFILLAB_PUBLIC_BASE_URL` con la URL real.
- [ ] PayPal Sandbox probado; live solo tras verificar.
- [ ] Instalador público con SHA-256 y tamaño correctos.
- [ ] Cliente compilado con el endpoint de Render y reinstalado.
- [ ] Copia de seguridad descargada y restauración comprobada.
