# Operaciones del servidor de licencias

Este documento cubre el despliegue, la configuración, los pagos, las copias de seguridad, la restauración y la respuesta ante incidentes del servidor central de PerfilLab. No contiene credenciales reales: los valores entre `<>` se completan en el servidor y nunca se confirman en el repositorio.

## 1. Arquitectura

```text
Cliente PerfilLab  ──HTTPS──►  Proxy inverso TLS  ──HTTP local──►  Servidor Node
Consola Licencias  ──HTTPS──►      (nginx/Caddy)                  (127.0.0.1:45900)
Tienda / PayPal    ──HTTPS──►                                     PostgreSQL gestionado
                                                                  Keystore por entorno
                                                                  Instalador del cliente por URL HTTPS
```

- `license-server/` es un servicio Node.js 24 o superior. Usa PostgreSQL mediante `pg`; SQLite (`node:sqlite`) queda solo para desarrollo o hosts con disco persistente.
- PostgreSQL guarda clientes, licencias, pedidos, transacciones, auditoría, webhooks y correo pendiente. En producción se exige `PERFILLAB_DATABASE_URL`; SQLite requiere `PERFILLAB_ALLOW_SQLITE=true` de forma explícita.
- Las claves de licencia se cifran con una clave de datos del keystore. El keystore contiene la clave privada Ed25519 y la clave de datos, cifradas con AES-256-GCM y una frase de paso derivada con scrypt.
- El keystore se carga desde `PERFILLAB_KEYSTORE_BASE64` (recomendado en hospedajes efímeros) o desde un archivo con `PERFILLAB_KEYSTORE_PATH`.
- El instalador del cliente se publica con `PERFILLAB_INSTALLER_URL` (redirección HTTPS) o `PERFILLAB_INSTALLER_PATH` (archivo local). La tienda muestra el botón de descarga solo cuando está disponible; la consola administrativa no se publica en la tienda.
- La consola de administración y el cliente PerfilLab son aplicaciones Electron independientes con instaladores Inno Setup separados (`PerfilLab-Licencias-Setup-<versión>.exe` y `PerfilLab-Setup-<versión>.exe`). No contienen la clave privada, el servidor, `.env`, la bóveda, el keystore ni secretos. Los instaladores no están firmados; SmartScreen puede advertir.
- El servidor escucha en `127.0.0.1` por defecto. La exposición pública debe hacerse a través de un proxy inverso con TLS.

Para un despliegue en un plan gratuito sin disco persistente sigue la guía específica [`DESPLIEGUE_ONLINE.md`](DESPLIEGUE_ONLINE.md).

## 2. Requisitos del host

- Linux o Windows Server de 64 bits con Node.js 24 o superior, o un contenedor equivalente.
- PostgreSQL gestionado (Neon, Supabase, Railway, Render u otro) accesible por TLS. SQLite solo se admite con disco persistente y `PERFILLAB_ALLOW_SQLITE=true`.
- Disco persistente únicamente si usas el keystore en archivo, el instalador local o copias locales.
- HTTPS con un certificado válido para el dominio de licencias.
- Salida hacia PostgreSQL y HTTPS hacia `api-m.paypal.com` (live) o `api-m.sandbox.paypal.com` (sandbox) y el servidor SMTP.
- Reloj sincronizado por NTP. La vigencia y las firmas dependen de fechas correctas.
- Usuario de servicio sin privilegios y permisos restrictivos sobre los secretos.

## 3. Variables de entorno

Copia `license-server/.env.example` a `license-server/.env` y completa los valores. En producción protege el archivo con permisos `600` y propietario del servicio. Si el hospedaje no ofrece archivos persistentes, define estas mismas variables como secretos del panel; consulta [`DESPLIEGUE_ONLINE.md`](DESPLIEGUE_ONLINE.md).

| Variable | Uso |
| --- | --- |
| `NODE_ENV` | `production` en el servidor real. |
| `PERFILLAB_HOST` | Interfaz de escucha; `127.0.0.1` si hay proxy inverso. |
| `PERFILLAB_PORT` | Puerto HTTP local; por defecto `45900`. |
| `PERFILLAB_PUBLIC_BASE_URL` | URL HTTPS pública, sin ruta ni parámetros. Obligatoria para la tienda y PayPal. |
| `PERFILLAB_TRUST_PROXY` | `true` solo detrás de un proxy que fija `X-Forwarded-For`. No lo actives si el servidor es accesible directamente. |
| `PERFILLAB_DATABASE_URL` | URL `postgres://` o `postgresql://` del servidor gestionado. Obligatoria en producción. |
| `PERFILLAB_DATABASE_SSL` | `disable`, `require` o `verify-full`. Usa `require` como mínimo con un proveedor gestionado. |
| `PERFILLAB_DATABASE_SSL_CA` / `_FILE` / `_BASE64` | Certificado CA para `verify-full`; usa una sola forma. |
| `PERFILLAB_DATABASE_SCHEMA` | Esquema de trabajo; por defecto `public`. |
| `PERFILLAB_DATABASE_POOL_MAX` | Conexiones del pool (1–50). Baja a 2–5 en planes gratuitos. |
| `PERFILLAB_ALLOW_SQLITE` | Solo desarrollo o disco persistente. En producción no la definas salvo que sepas lo que haces. |
| `PERFILLAB_DATA_DIR` | Carpeta local de datos y respaldo (`/var/lib/perfillab`). No es la base cuando hay PostgreSQL. |
| `PERFILLAB_DB_PATH` | Ruta de SQLite; solo se usa sin PostgreSQL. |
| `PERFILLAB_KEYSTORE_BASE64` | Keystore cifrado en base64. Recomendado en hospedajes sin disco persistente. |
| `PERFILLAB_KEYSTORE_PATH` | Ruta alternativa del keystore en disco. |
| `PERFILLAB_BACKUP_DIR` | Carpeta de copias; por defecto `<data>/backups`. En hosting gratuito descárgala fuera del servicio. |
| `PERFILLAB_INSTALLER_URL` | URL HTTPS del instalador. El servidor redirige con `302` y no guarda el archivo. |
| `PERFILLAB_INSTALLER_PATH` | Ruta local del instalador; exige disco persistente. |
| `PERFILLAB_INSTALLER_FILENAME` / `_VERSION` / `_SHA256` / `_SIZE` | Nombre mostrado, versión, hash y tamaño del artefacto; se verifican si se declaran. |
| `PERFILLAB_KEYSTORE_PASSPHRASE` / `_FILE` | Frase actual del keystore. Se usa al arrancar y en la rotación. |
| `PERFILLAB_NEW_KEYSTORE_PASSPHRASE` / `_FILE` | Nueva frase durante `npm run rotate-keystore`. |
| `PERFILLAB_VAULT_PASSWORD` / `_FILE` | Contraseña de la bóveda heredada; solo para `npm run init`. |
| `PERFILLAB_ADMIN_USER` / `PERFILLAB_ADMIN_PASSWORD` / `_FILE` | Administrador inicial o contraseña para los comandos de administración. |
| `PERFILLAB_PAYPAL_MODE` | `sandbox` o `live`. Sandbox por defecto. |
| `PERFILLAB_PRICE_USD` | Precio anual de respaldo en USD. Los tres planes se configuran en la consola → Pagos. |
| `PERFILLAB_PAYPAL_CLIENT_ID` / `_SECRET` | Credenciales de la aplicación PayPal del panel de desarrolladores. |
| `PERFILLAB_PAYPAL_WEBHOOK_ID` | ID del webhook creado en PayPal. |
| `PERFILLAB_SMTP_HOST` / `_PORT` / `_SECURE` | Servidor de correo; `starttls` o `tls`. `none` no se permite en producción. |
| `PERFILLAB_SMTP_USER` / `_PASS` | Credenciales SMTP. |
| `PERFILLAB_MAIL_FROM` / `PERFILLAB_MAIL_ENVELOPE_FROM` | Remitente visible y sobre de rebote. |
| `PERFILLAB_PRODUCT_NAME` | Nombre mostrado en la tienda y el correo. |
| `PERFILLAB_SUPPORT_EMAIL` | Contacto de soporte mostrado al cliente. |
| `PERFILLAB_LOG_LEVEL` | `debug`, `info`, `warn` o `error`. |

Los secretos no se pasan por argumentos de línea de comandos. Usa variables de entorno o archivos con permisos restringidos. Los registros redactan claves, tokens, contraseñas y material privado.

## 4. Preparación e inicialización

Estos pasos asumen un host con disco persistente. Para un plan gratuito con PostgreSQL gestionado y keystore en variable, usa [`DESPLIEGUE_ONLINE.md`](DESPLIEGUE_ONLINE.md); el comando de inicialización es el mismo con `PERFILLAB_DATABASE_URL`.

1. Crea el usuario de servicio y las carpetas:

   ```bash
   sudo useradd --system --home /var/lib/perfillab --shell /usr/sbin/nologin perfillab
   sudo install -d -m 700 -o perfillab -g perfillab /var/lib/perfillab /var/lib/perfillab/backups
   sudo install -d -m 700 -o root -g perfillab /etc/perfillab
   sudo install -m 600 -o root -g perfillab license-server/.env.example /etc/perfillab/perfillab.env
   ```

2. Copia el proyecto a `/opt/perfillab` con permisos de solo lectura para el servicio. No copies la bóveda heredada ni secretos a una carpeta pública.

3. Prepara la bóveda heredada. La contraseña está en `perfillab-admin-password.txt`, fuera del proyecto. Créale un archivo temporal solo para la inicialización:

   ```bash
   # Ejecuta esto en una terminal segura; no pegues la contraseña en el historial.
   install -m 600 -o root -g root /dev/null /etc/perfillab/vault.pass
   # Escribe la contraseña en el archivo con un editor y bórralo al terminar.
   ```

   Crea también la frase del keystore y la contraseña inicial del administrador sin mostrarlas por pantalla:

   ```bash
   openssl rand -base64 24 > /etc/perfillab/keystore.pass
   openssl rand -base64 24 > /etc/perfillab/admin.pass
   chmod 600 /etc/perfillab/keystore.pass /etc/perfillab/admin.pass
   ```

   Guarda la frase del keystore en el gestor de secretos antes de continuar. La contraseña del administrador se usará para el primer inicio de sesión y se puede cambiar después.

4. Detén el servidor si ya existía. Comprueba que la base PostgreSQL está vacía o que tienes una copia verificada. `npm run init` se niega a modificar una base ya inicializada.

5. Inicializa. Sustituye `<url-postgres>` por la URL real y ajusta SSL/schema:

   ```bash
   cd /opt/perfillab/license-server
   sudo -u perfillab env \
     NODE_ENV=production \
     PERFILLAB_DATABASE_URL='<url-postgres>' \
     PERFILLAB_DATABASE_SSL=require \
     PERFILLAB_DATABASE_SCHEMA=public \
     PERFILLAB_DATA_DIR=/var/lib/perfillab \
     PERFILLAB_VAULT_PASSWORD_FILE=/etc/perfillab/vault.pass \
     PERFILLAB_KEYSTORE_PASSPHRASE_FILE=/etc/perfillab/keystore.pass \
     PERFILLAB_ADMIN_USER=admin \
     PERFILLAB_ADMIN_PASSWORD_FILE=/etc/perfillab/admin.pass \
     node scripts/init.js --vault /ruta/segura/license-admin/seed/vault.json
   ```

   Debes obtener `seats: 50000`, `legacySeats: 2000`, `keyId` esperado, `database: "postgres"` y `adminCreated: true`. El `keyId` debe coincidir con `electron/license-public.js` del cliente distribuido.

6. Si el servicio no tendrá disco persistente, exporta el keystore cifrado y guárdalo como secreto `PERFILLAB_KEYSTORE_BASE64`:

   ```bash
   PERFILLAB_DATA_DIR=/var/lib/perfillab node scripts/keystore-env.js --stdout > /ruta/segura/keystore.base64
   chmod 600 /ruta/segura/keystore.base64
   ```

   El archivo contiene el keystore cifrado, no la clave en claro. Configura la frase de paso por separado en `PERFILLAB_KEYSTORE_PASSPHRASE` o `_FILE`. Pasos completos para hosting: [`DESPLIEGUE_ONLINE.md`](DESPLIEGUE_ONLINE.md).

7. Elimina `/etc/perfillab/vault.pass` y `/etc/perfillab/admin.pass` después de la inicialización. Conserva el keystore y su frase de paso por separado.

8. Arranca el servidor y comprueba:

   ```bash
   curl -fsS https://<dominio>/api/health
   ```

   La respuesta debe incluir `ok: true` y la versión. Revisa los avisos: si faltan PayPal o SMTP, la tienda o el correo quedan desactivados, pero la activación de licencias existentes sigue funcionando.

## 5. Servicio systemd

Ejemplo para Linux. Ajusta rutas y usuario.

```ini
[Unit]
Description=Servidor de licencias PerfilLab
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User=perfillab
Group=perfillab
WorkingDirectory=/opt/perfillab/license-server
EnvironmentFile=/etc/perfillab/perfillab.env
ExecStart=/usr/bin/node src/server.js
Restart=on-failure
RestartSec=5
UMask=0077
NoNewPrivileges=true
PrivateTmp=true
ProtectSystem=strict
ProtectHome=true
ReadWritePaths=/var/lib/perfillab
ReadOnlyPaths=/etc/perfillab
LimitNOFILE=4096

[Install]
WantedBy=multi-user.target
```

No uses `npm start` como servicio si el `PATH` de Node no está definido; llama directamente al binario. Verifica con `systemctl status perfillab-license`, `journalctl -u perfillab-license -f` y el endpoint de salud.

Alternativa con Docker (incluye `Dockerfile` y usuario sin privilegios):

```bash
cd license-server
docker build -t perfillab-license .
docker run --rm -p 45900:45900 --env-file .env perfillab-license
```

Dentro del contenedor la escucha debe ser `PERFILLAB_HOST=0.0.0.0`; el proxy o la plataforma terminan TLS. No incluyas secretos en la imagen ni en el repositorio: pásalos como variables de entorno o secretos del servicio. Para plataformas gratuitas consulta [`DESPLIEGUE_ONLINE.md`](DESPLIEGUE_ONLINE.md).

## 6. Proxy inverso y TLS

El servidor no termina TLS por sí mismo. Configura un proxy con un certificado válido y redirige todo el tráfico HTTP a HTTPS. Ejemplo de nginx:

```nginx
server {
    listen 443 ssl http2;
    server_name licencias.<dominio>;

    ssl_certificate     /etc/letsencrypt/live/licencias.<dominio>/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/licencias.<dominio>/privkey.pem;

    client_max_body_size 1m;
    proxy_read_timeout 60s;

    add_header Strict-Transport-Security "max-age=31536000; includeSubDomains" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header Referrer-Policy "no-referrer" always;

    location / {
        proxy_pass http://127.0.0.1:45900;
        proxy_http_version 1.1;
        proxy_set_header Host $host;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Real-IP $remote_addr;
    }
}
```

- Define `PERFILLAB_PUBLIC_BASE_URL=https://licencias.<dominio>` y `PERFILLAB_TRUST_PROXY=true`.
- Publica solo 443. Mantén `45900` en localhost y bloqueado por firewall.
- No añadas CORS. El cliente y la consola llaman al servidor desde procesos locales, no desde un navegador web.
- Si usas un CDN o balanceador, asegúrate de que sobrescribe `X-Forwarded-For` y no confía en valores del cliente.

## 7. PayPal Sandbox y producción

1. En el panel de desarrolladores de PayPal crea una aplicación **Sandbox** y obtén su Client ID y Secret. No inventes ni reutilices credenciales de ejemplo.
2. Crea un webhook con la URL `https://<dominio>/api/paypal/webhook` y suscríbete a:
   - `CHECKOUT.ORDER.APPROVED`
   - `PAYMENT.CAPTURE.COMPLETED`
   - `PAYMENT.CAPTURE.REFUNDED`
   - `PAYMENT.CAPTURE.REVERSED`
   - `PAYMENT.CAPTURE.DENIED`
   - `PAYMENT.CAPTURE.DECLINED`
   - `CHECKOUT.ORDER.DECLINED`
   - `CHECKOUT.ORDER.VOIDED`
3. Copia el **Webhook ID** a `PERFILLAB_PAYPAL_WEBHOOK_ID` o guárdalo en la consola. El servidor verifica cada notificación con `/v1/notifications/verify-webhook-signature`; no basta con que la petición parezca de PayPal.
4. Configura la cuenta que recibirá los cobros y los precios en **PerfilLab Licencias → Pagos** (requiere rol `admin`):
   - Client ID, Client Secret y Webhook ID de la aplicación PayPal.
   - Modo Sandbox o Live.
   - Precio de cada plan: **Mensual 10 USD / 1 mes**, **Semestral 50 USD / 6 meses** y **Anual 100 USD / 12 meses**.
   - Todos son pagos únicos sin renovación automática.
   El Client Secret se guarda cifrado con AES-256-GCM, es de solo escritura y no se devuelve a la consola. La configuración guardada tiene prioridad sobre las variables de entorno; al quitarla se vuelve al respaldo del entorno. `PERFILLAB_PRICE_USD` solo define el precio anual de respaldo. El importe se calcula en el servidor según el plan elegido y se comprueba contra el importe y la moneda de la captura.
5. Prueba el flujo completo con una cuenta compradora Sandbox:
   - La tienda permite elegir el plan y crea la orden en el servidor con su importe.
   - La vuelta a `/pago/retorno` solo consulta el estado al servidor. El servidor verifica la captura con la API de PayPal o con el webhook firmado; ningún parámetro del navegador autoriza la emisión.
   - El webhook `PAYMENT.CAPTURE.COMPLETED` verifica firma, importe, moneda, producto, plan y orden. La conciliación directa aplica las mismas comprobaciones. Una captura ya usada no emite una segunda licencia.
   - Un evento repetido no emite una segunda licencia. La captura tampoco puede asociarse a otra orden.
6. Revisa en la consola los pedidos, transacciones y la auditoría. En los registros aparecen los eventos ignorados con su motivo.
7. Para live: cambia a credenciales live y modo Live en **Pagos**. La URL pública debe ser HTTPS. Haz una compra real de importe mínimo antes de abrir la tienda.
8. Los cambios de precio afectan solo a órdenes nuevas. No cambies el precio mientras haya pagos en revisión y revisa la auditoría tras cada ajuste.

Nunca actives una licencia al recibir al usuario en la página de éxito, por un parámetro de la URL ni por una llamada del cliente. Esa regla está implementada en el servidor y debe mantenerse en cualquier cambio futuro.

## 8. SMTP y entrega

- Configura `PERFILLAB_SMTP_HOST`, puerto, cifrado, usuario, contraseña y remitente. En producción no se permite `none`.
- El correo de entrega se encola en `email_outbox`, con reintentos y registro de errores. Un fallo de correo no invalida la licencia.
- La consola permite reenviar el correo desde el detalle de la licencia; la acción queda auditada.
- Verifica SPF, DKIM y DMARC del dominio remitente para reducir el spam. Usa un remitente y un sobre de rebote válidos.
- Si no hay SMTP, entrega la clave manualmente por un canal seguro desde la consola.

## 9. Administradores y acceso

La contraseña inicial del administrador se define en `init` o con:

```bash
cd /opt/perfillab/license-server
PERFILLAB_ADMIN_PASSWORD_FILE=/etc/perfillab/admin.pass \
  node scripts/admin.js create --username admin
```

Otros comandos:

```bash
node scripts/admin.js list
PERFILLAB_ADMIN_PASSWORD_FILE=/etc/perfillab/new-admin.pass \
  node scripts/admin.js reset-password --username admin
node scripts/admin.js disable --username admin
node scripts/admin.js enable --username admin
```

- La consola mantiene el token solo en memoria; la sesión del servidor dura 12 horas.
- El inicio de sesión limita intentos por IP y usuario. No lo expongas sin HTTPS.
- Cada emisión, consulta de clave, revocación, cambio de estado, reenvío y rotación queda en `audit_log`.
- No compartas la consola ni el archivo `.env`. La consola no necesita la frase del keystore.

## 10. Copias de seguridad

La copia incluye la base y el keystore cifrado, con un manifiesto de hashes SHA-256. Con PostgreSQL, `npm run backup` ejecuta `pg_dump` (volcado SQL verificado: marcador final y tabla `seats`); con SQLite usa `VACUUM INTO` e integridad. No copies una base SQLite en caliente con `cp`.

```bash
cd /opt/perfillab/license-server
PERFILLAB_DATABASE_URL='<url-postgres>' \
PERFILLAB_DATABASE_SSL=require \
PERFILLAB_DATA_DIR=/var/lib/perfillab \
  node scripts/backup.js
```

`pg_dump` debe ser de la misma versión mayor o superior que el servidor gestionado. Si el servicio no tiene el binario, ejecuta la copia desde un equipo con el cliente de PostgreSQL adecuado. No pases la contraseña por argumentos: el script toma la URL del entorno.

Buenas prácticas:

- Programa una copia diaria y otra antes de cada actualización o rotación.
- En un plan gratuito, descarga la copia fuera del servicio: el disco local es efímero. Usa también las copias o recuperación del proveedor de PostgreSQL si están disponibles.
- Guarda las copias fuera del host, cifradas en reposo, con retención definida (por ejemplo 30 diarias y 12 mensuales).
- Guarda la frase de paso del keystore en un gestor de secretos **separado** de las copias. Una copia sin la frase no permite arrancar el servidor.
- Conserva al menos una copia del keystore con la frase anterior durante una rotación, hasta verificar el arranque; bórrala después si la rotación fue por compromiso.
- Prueba una restauración completa al menos una vez al trimestre.

## 11. Restauración

1. Detén el servicio: `sudo systemctl stop perfillab-license` o pausa el servicio en el panel del proveedor.
2. Haz una copia del estado actual aunque esté dañado, para no destruir evidencia.
3. Restaura una pareja **del mismo momento**: el volcado `perfillab-<fecha>.sql` (o la base SQLite) y `keystore-<fecha>.json`/`.base64` del manifiesto correspondiente. No mezcles base y keystore de fechas distintas.
4. Verifica los hashes del manifiesto:

   ```bash
   sha256sum perfillab-<fecha>.sql keystore-<fecha>.json
   ```

5. Restaura la base:
   - **PostgreSQL**: crea el esquema si no es `public` y vuelca el archivo en una base vacía. No reutilices una base con datos previos.

     ```bash
     psql "$PERFILLAB_DATABASE_URL" -v ON_ERROR_STOP=1 -c 'CREATE SCHEMA IF NOT EXISTS <esquema>;'
     psql "$PERFILLAB_DATABASE_URL" -v ON_ERROR_STOP=1 -f perfillab-<fecha>.sql
     ```

     Si el volcado se hizo con `--schema`, confirma que las tablas quedaron en el esquema esperado antes de arrancar.
   - **SQLite**: copia el archivo a `PERFILLAB_DB_PATH` con permisos `600`.
6. Restaura el keystore: si usas variable de entorno, sustituye `PERFILLAB_KEYSTORE_BASE64` por el contenido restaurado; si usas archivo, cópialo a `PERFILLAB_KEYSTORE_PATH` con permisos `600`. Configura la frase de paso correspondiente. Si no la tienes, la restauración no sirve para firmar.
7. Arranca, comprueba `/api/health`, el `keyId` mostrado en el arranque y que el inventario tiene 50.000 asientos. Inicia sesión en la consola y verifica una licencia de prueba (preferiblemente una pendiente de un entorno controlado).
8. Si la restauración pierde emisiones posteriores a la copia, revisa los pedidos y auditoría; no reutilices capturas de PayPal. Emite manualmente solo tras verificar el pago.

## 12. Rotación de la frase de paso del keystore

La clave privada y la clave de datos no cambian: las licencias emitidas siguen siendo válidas. Solo cambia el cifrado del archivo o del valor base64.

1. Detén el servidor.
2. Prepara un archivo con la nueva frase (mínimo 12 caracteres) y permisos `600`.
3. Ejecuta el comando según el modo del keystore. La copia de seguridad del keystore anterior se crea por defecto; usa `--no-backup` para omitirla:

   ```bash
   # Keystore en archivo
   cd /opt/perfillab/license-server
   sudo -u perfillab env \
     PERFILLAB_KEYSTORE_PATH=/var/lib/perfillab/keystore.json \
     PERFILLAB_KEYSTORE_PASSPHRASE_FILE=/etc/perfillab/keystore.pass \
     PERFILLAB_NEW_KEYSTORE_PASSPHRASE_FILE=/etc/perfillab/keystore-new.pass \
     node scripts/rotate-keystore.js

   # Keystore en PERFILLAB_KEYSTORE_BASE64: escribe un archivo base64 nuevo
   sudo -u perfillab env \
     PERFILLAB_KEYSTORE_BASE64='<valor-actual>' \
     PERFILLAB_KEYSTORE_PASSPHRASE_FILE=/etc/perfillab/keystore.pass \
     PERFILLAB_NEW_KEYSTORE_PASSPHRASE_FILE=/etc/perfillab/keystore-new.pass \
     node scripts/rotate-keystore.js --out /ruta/segura/keystore-nuevo.base64
   ```

4. El comando verifica el mismo `keyId` y la misma clave de datos, comprueba que la frase anterior ya no abre el keystore nuevo y escribe el resultado de forma atómica (o con permisos `600` en modo base64). La copia anterior queda cifrada con la frase antigua: en modo archivo, junto al original; en modo base64, en `PERFILLAB_DATA_DIR`. En modo base64 no modifica la variable: sustituye el secreto `PERFILLAB_KEYSTORE_BASE64` por el contenido del archivo generado.
5. Sustituye el archivo/secreto de frase por el nuevo, arranca y comprueba una activación. Borra la copia anterior y el archivo temporal de la nueva frase cuando todo esté verificado.
6. Si algo falla, detén el servidor y restaura el keystore anterior con la frase antigua.

## 13. Rotación de la clave de firma

El cliente fija la clave pública y su `keyId`; por diseño, **no** acepta una clave nueva sin actualización del cliente. La rotación de la clave de firma no está automatizada y no puede hacerse solo en el servidor.

Procedimiento planificado:

1. Genera una nueva bóveda/clave con `node scripts/provision-license.js --force` en un entorno controlado. Esto cambia `electron/license-public.js` y la contraseña inicial de la bóveda.
2. Construye y distribuye un cliente nuevo con la nueva clave pública fijada. No publiques una actualización que rompa a los clientes actuales sin un plan de migración.
3. Inicializa una instalación nueva del servidor con la nueva bóveda y el mismo límite de 50.000 asientos.
4. Reemite o migra las licencias que deban seguir activas y comunica a los clientes la nueva activación.
5. Conserva la instalación anterior solo el tiempo necesario para la transición y revócala al terminarla.

Una lista de revocaciones firmada por la clave anterior no permite a los clientes confiar en una clave nueva. La actualización del cliente es obligatoria.

## 14. Compromiso de claves o del servidor

### Si se compromete la frase de paso o el keystore

1. Aísla el servidor y detén el servicio.
2. Rota la frase de paso con `rotate-keystore` desde un host limpio y con el keystore verificado.
3. Rota credenciales de administradores, PayPal y SMTP.
4. Revisa `audit_log`, sesiones, pedidos, transacciones y webhooks en busca de emisiones o cambios no reconocidos.
5. Revoca las licencias afectadas. Si la clave privada pudo salir del keystore, trátalo como compromiso de clave de firma (siguiente apartado).
6. Restaura desde una copia anterior al incidente si hay corrupción, y vuelve a comprobar los pagos antes de reemitir.

### Si se compromete la clave privada de firma

La clave privada permite firmar licencias y listas de revocaciones falsas. La revocación por sí sola no recupera la confianza.

1. Detén el servidor y conserva evidencia.
2. Revoca todas las licencias activas que puedan estar afectadas y comunica el incidente.
3. Considera la clave anterior quemada. Genera una clave nueva, publica un cliente con la nueva clave pública fijada y migra a los clientes legítimos.
4. No confíes en listas de revocaciones firmadas por la clave comprometida como única defensa: un atacante con esa clave puede firmar una lista que excluya su licencia.
5. Revisa accesos, copias y registros para determinar el alcance. Rota también credenciales de PayPal/SMTP y la frase del keystore.
6. Si no puedes actualizar todos los clientes, la alternativa es invalidar la instalación y reemitir licencias con la nueva clave; no hay una rotación transparente con la clave fijada actual.

## 15. Monitorización y mantenimiento

- Vigila `/api/health`, el estado del servicio, el espacio en disco y los errores 5xx del proxy.
- Revisa periódicamente los webhooks ignorados/fallidos y la cola de correo.
- Mantén Node.js y el sistema operativo actualizados; prueba la actualización en un entorno de staging con una copia de la base.
- No actives `PERFILLAB_LOG_LEVEL=debug` en producción salvo para una investigación acotada.
- Los registros no deben contener claves de licencia, contraseñas, tokens ni material privado. Si añades campos nuevos, respeta la redacción existente.
- No ejecutes el servidor como root ni desde una carpeta escribible por el usuario del servicio.
- Rota las credenciales de PayPal y SMTP si hay cambios de personal o sospecha de exposición.

## 16. Verificación rápida posterior al despliegue

1. `GET /api/health` responde 200.
2. El arranque muestra `keyId` igual al del cliente, `seats: 50000`, `database: postgres` y el origen del keystore (`env` o archivo).
3. La tienda `/` muestra los tres planes; el botón de descarga aparece si configuraste el instalador del cliente. `GET /descargar` entrega el archivo o redirige a la URL externa, y `HEAD` devuelve el tamaño.
4. La consola instalada con `PerfilLab-Licencias-Setup-<versión>.exe` inicia sesión por HTTPS y muestra el inventario.
5. Una licencia pendiente se activa desde el cliente, se guarda firmada y abre la aplicación.
6. Una revocación se refleja en el cliente tras la siguiente comprobación.
7. Un pago Sandbox emite una sola licencia, incluso si PayPal reenvía el webhook.
8. **Reinicia el servicio** (en un plan gratuito, fuérzalo desde el panel) y confirma que pedidos, licencias y el `keyId` siguen iguales. Así se verifica que PostgreSQL y el keystore por entorno sobreviven al reciclado del contenedor.
9. Una copia de seguridad se restaura en un entorno de prueba y permite activar una licencia.
