# Servidor local de licencias (`/v1`)

Backend local para **PerfilLab Licencias**. Usa Express 5 y SQLite (`node:sqlite`), escucha únicamente en `127.0.0.1:45900` y expone la API bajo `/v1`. Reutiliza el mismo núcleo que el servidor central: inventario de 50.000 asientos, firmas **Ed25519 reales**, keystore cifrado, sesiones administrativas con scrypt y auditoría redactada. Este modo local siempre usa SQLite y nunca se conecta a PostgreSQL, aunque el entorno defina `PERFILLAB_DATABASE_URL`; el servidor central usa PostgreSQL y se documenta en [`DESPLIEGUE_ONLINE.md`](DESPLIEGUE_ONLINE.md).

En este modo no se contacta con PayPal ni con SMTP, no se crean órdenes y no se simulan pagos ni firmas. La tienda y el correo quedan desactivados; la emisión, renovación, activación y revocación son reales y persistentes. La sección **Pagos** de la consola muestra las credenciales y los precios en modo de solo lectura: guardar PayPal requiere el servidor central.

## Requisitos

- Windows 10 u 11 de 64 bits.
- Node.js 24 o superior (`node:sqlite` es obligatorio).
- El repositorio de PerfilLab con la carpeta `license-server/`.
- La bóveda heredada `license-admin/seed/vault.json` y su contraseña, custodiada fuera del repositorio.

La contraseña de la bóveda se encuentra en `perfillab-admin-password.txt`, fuera del árbol del proyecto. No la copies al repositorio, no la pases por argumentos de línea de comandos y no la incluyas en capturas ni registros.

## Primera inicialización

```powershell
cd license-server
npm install
```

Crea un `.env` local solo si necesitas cambiar rutas. Para pruebas locales no configures PayPal, SMTP ni `PERFILLAB_PUBLIC_BASE_URL`:

```dotenv
NODE_ENV=development
PERFILLAB_DATA_DIR=C:\PerfilLab\license-data
PERFILLAB_LOG_LEVEL=info
# PERFILLAB_KEYSTORE_PASSPHRASE_FILE=C:\PerfilLab\secretos\keystore.pass
```

No escribas contraseñas directamente en `.env` si puedes usar un archivo con permisos restringidos. `.env` no debe confirmarse en Git.

Inicializa la base y el keystore desde la bóveda heredada:

```powershell
npm run init
```

El proceso solicitará de forma oculta:

1. La contraseña de la bóveda anterior.
2. Una frase de paso nueva para el keystore (mínimo 12 caracteres), repetida para confirmar.

También puedes entregar los secretos mediante archivos, sin escribirlos en la terminal:

```powershell
$env:PERFILLAB_VAULT_PASSWORD_FILE = 'C:\PerfilLab\secretos\vault.pass'
$env:PERFILLAB_KEYSTORE_PASSPHRASE_FILE = 'C:\PerfilLab\secretos\keystore.pass'
npm run init
```

`npm run init` migra las 2.000 licencias heredadas al inventario de 50.000 asientos y genera el `keyId` de firma. **No vuelvas a ejecutarlo** sobre una instalación con emisiones salvo que sepas exactamente lo que haces: conserva la base y el keystore existentes cuando ya están inicializados.

### Crear el primer administrador

No existe ningún usuario ni contraseña universal. Crea el primer administrador con el proceso seguro, que lee la contraseña de forma oculta o desde un archivo:

```powershell
npm run admin -- create --username admin
```

La contraseña debe tener al menos 12 caracteres. Se guarda como hash scrypt con sal; nunca se escribe en claro en la base ni en la auditoría. Para cambiar la contraseña:

```powershell
npm run admin -- reset-password --username admin
```

`reset-password` revoca todas las sesiones abiertas del usuario. También existen `list`, `disable` y `enable`.

Como alternativa, `npm run init` puede crear el administrador en el mismo paso si defines `PERFILLAB_ADMIN_USER` y `PERFILLAB_ADMIN_PASSWORD_FILE` (o `PERFILLAB_ADMIN_PASSWORD`). Úsalo solo en una terminal controlada y elimina el archivo después.

## Arranque y parada

```powershell
cd license-server
npm run local
```

Si no hay frase de paso en el entorno, se solicita de forma oculta. El servidor muestra:

```text
Servidor local de licencias iniciado { listen: 'http://127.0.0.1:45900/v1', ... }
```

Comprueba la salud desde otra terminal:

```powershell
Invoke-RestMethod http://127.0.0.1:45900/v1/health
```

Respuesta esperada:

```json
{
  "ok": true,
  "service": "perfillab-license-server-local",
  "version": "1.0.0",
  "time": "2026-10-24T20:00:00.000Z"
}
```

Para detenerlo pulsa `Ctrl+C` en la terminal donde se ejecuta `npm run local`. La base SQLite se cierra de forma ordenada y el puerto queda libre. Si el proceso no responde:

```powershell
Get-NetTCPConnection -LocalPort 45900 -State Listen
# Identifica el PID y ciérralo desde el Administrador de tareas o con:
Stop-Process -Id <PID>
```

No uses `Stop-Process` sobre procesos que no hayas identificado. El servidor no es un servicio de Windows ni arranca solo con el sistema.

La API de perfiles del cliente PerfilLab usa `http://127.0.0.1:45800/v1`, así que puede convivir con este backend en el puerto 45900 sin conflicto. Si el 45900 está ocupado, arranca el backend en otro puerto:

```powershell
$env:PERFILLAB_LOCAL_PORT = '45901'
npm run local
```

Y en la consola de licencias escribe `http://127.0.0.1:45901/v1`.

La dirección de escucha no se puede cambiar: el backend siempre se enlaza a `127.0.0.1`, aunque configures otra interfaz.

## Conectar PerfilLab Licencias

1. Arranca el backend local.
2. Abre la consola desde la raíz del repositorio:

   ```powershell
   npm run admin
   ```

3. En **Dirección del servidor** deja el valor predeterminado `http://127.0.0.1:45900/v1`.
4. Pulsa **Probar conexión**. Solo consulta `/v1/health`; no inicia sesión ni envía credenciales.
5. Escribe el usuario y la contraseña creados con `npm run admin -- create` y pulsa **Iniciar sesión**.

La consola guarda únicamente la dirección del servidor. El token Bearer permanece en memoria y se pierde al cerrarla. La dirección raíz del servidor central (`https://...`) sigue siendo válida para conectarse al backend central; la consola detecta si la URL incluye `/v1` y adapta las rutas.

## Endpoints

### Públicos

| Método | Ruta | Uso |
| --- | --- | --- |
| GET | `/v1/health` | Salud del proceso y versión |
| POST | `/v1/auth/login` | Usuario y contraseña; devuelve token Bearer y vencimiento |
| POST | `/v1/license/activate` | Vincular una clave a un código de equipo y devolver el sobre firmado |
| POST | `/v1/license/validate` | Validar clave, equipo, estado y vencimiento |
| GET | `/v1/license/revocations` | Lista firmada de revocaciones con ETag |

Los endpoints del cliente también están disponibles bajo `/api/license/activate`, `/api/license/validate` y `/api/license/revocations` para el cliente instalado que ya usa esas rutas.

### Autenticados

Todos exigen `Authorization: Bearer <token>`. Salvo `GET /v1/auth/me`, `POST /v1/auth/logout` y las lecturas, las operaciones requieren rol `admin`.

| Método | Ruta | Uso |
| --- | --- | --- |
| GET | `/v1/auth/me` | Usuario y vencimiento de la sesión |
| POST | `/v1/auth/logout` | Revocar el token actual |
| GET | `/v1/profiles` | Catálogo de planes disponible |
| GET | `/v1/admin/overview` | Resumen del inventario y estado del servidor |
| GET | `/v1/admin/licenses` | Listar con `query`, `status`, `page`, `pageSize` |
| POST | `/v1/admin/licenses` | Emitir una licencia |
| POST | `/v1/admin/licenses/batch` | Emitir hasta 100 licencias por lote |
| GET | `/v1/admin/licenses.csv` | Exportar CSV compatible con Excel |
| GET | `/v1/admin/licenses/:id` | Detalle, clave completa y sobre firmado si ya está activa |
| POST | `/v1/admin/licenses/:id/revoke` | Revocar de forma permanente |
| POST | `/v1/admin/licenses/:id/renew` | Renovar según el plan elegido (1, 6 o 12 meses) desde el vencimiento o desde hoy |
| POST | `/v1/admin/licenses/:id/suspend` | Suspender temporalmente |
| POST | `/v1/admin/licenses/:id/reactivate` | Reactivar una licencia suspendida |
| POST | `/v1/admin/licenses/:id/reset-activation` | Liberar el código de equipo |
| POST | `/v1/admin/licenses/:id/resend-email` | Encolar correo (queda en cola local) |
| GET | `/v1/admin/audit` | Registro de auditoría paginado |
| GET | `/v1/admin/revocations` | Descargar la lista firmada de revocaciones |
| GET | `/v1/admin/orders` | Pedidos locales (vacíos si no hay pagos) |
| GET | `/v1/admin/orders/:id` | Detalle de pedido |
| POST | `/v1/admin/orders/:id/sync` | Responde `payments_disabled` en modo local |
| GET | `/v1/admin/transactions` | Transacciones locales |

`revoke`, `suspend` y `reset-activation` exigen un motivo de al menos 3 caracteres. `renew` acepta un motivo opcional. Las licencias revocadas no se renuevan ni reactivan: se emite una nueva. Una licencia suspendida debe reactivarse antes de renovar.

### Formato uniforme de errores

```json
{
  "error": {
    "message": "La licencia no existe.",
    "code": "license_not_found",
    "details": null
  }
}
```

- `400` parámetros inválidos, `401` sesión ausente o vencida, `403` rol insuficiente, Origin no permitido o equipo incorrecto, `404` recurso inexistente, `409` conflicto de estado o equipo, `410` licencia vencida, `413` cuerpo demasiado grande, `429` límite de intentos, `500` error interno sin detalles sensibles.
- Los límites de intentos devuelven `Retry-After`.
- Las peticiones con cabecera `Origin` se rechazan con `origin_not_allowed`; el servidor solo acepta conexiones desde `127.0.0.1`/`::1`.

## Ejemplo de uso con curl

```bash
# Iniciar sesión (no guardes el token en el historial de la shell)
curl -s -X POST http://127.0.0.1:45900/v1/auth/login \
  -H "Content-Type: application/json" \
  -d '{"username":"admin","password":"<contraseña>"}'

# Guarda el token devuelto en una variable
TOKEN="<token>"

# Emitir una licencia
curl -s -X POST http://127.0.0.1:45900/v1/admin/licenses \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"customerName":"Cliente de prueba","email":"cliente@example.com"}'

# Renovar (sustituye PL-00003 por el ID real)
curl -s -X POST http://127.0.0.1:45900/v1/admin/licenses/PL-00003/renew \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" -d '{}'

# Revocar
curl -s -X POST http://127.0.0.1:45900/v1/admin/licenses/PL-00003/revoke \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"reason":"Solicitud del cliente"}'
```

En PowerShell usa `Invoke-RestMethod` y evita pegar contraseñas o tokens en la transcripción. No guardes tokens en archivos dentro del repositorio.

## Datos y copias

Con la configuración predeterminada, la base y el keystore quedan en `license-server/data/`:

```text
data/
  perfillab.sqlite
  keystore.json
  backups/
```

Puedes cambiarlo con `PERFILLAB_DATA_DIR`. La base contiene datos personales (nombre, correo, equipo) y claves de licencia cifradas. El keystore contiene la clave privada de firma cifrada con la frase de paso.

- Detén el servidor antes de copiar la base.
- Guarda la copia de SQLite y el keystore del mismo periodo, y la frase de paso en un medio distinto.
- No distribuyas el keystore, la base, la frase de paso ni la consola con la base.
- `npm run backup` (servidor central) no está pensado para ejecutarse mientras el backend local está en marcha; para el modo local basta una copia consistente con el proceso detenido.
- Si pierdes la frase de paso, no se puede recuperar la clave de firma.

## Diagnóstico

| Síntoma | Causa y solución |
| --- | --- |
| `EADDRINUSE` al arrancar | El puerto 45900 está ocupado por otra instancia u otro proceso. Identifícalo con `Get-NetTCPConnection -LocalPort 45900 -State Listen` o usa `PERFILLAB_LOCAL_PORT=45901` y actualiza la URL de la consola. |
| `La base local o el keystore no existen` | Ejecuta `npm run init` con la bóveda heredada. |
| `No se pudo abrir el keystore` | Frase de paso incorrecta o keystore de otra instalación. No sigas intentando hasta recuperar la frase correcta. |
| `No hay administradores` o `401 invalid_session` | Crea el administrador con `npm run admin -- create --username <usuario>` o inicia sesión de nuevo. |
| La consola dice `network_error` | El backend no está arrancado, la URL es incorrecta o el puerto no coincide. Ejecuta `Invoke-RestMethod http://127.0.0.1:45900/v1/health`. |
| `origin_not_allowed` | La petición viene de un navegador con cabecera Origin. Usa la consola o curl, no una página web. |
| `loopback_only` | La petición llegó desde otra interfaz. El servidor solo acepta tráfico del propio equipo. |
| El dashboard indica pagos/correo inactivos | Es el comportamiento esperado en modo local: no hay PayPal ni SMTP. |
| API de perfiles del cliente | Usa el puerto 45800 por separado; no entra en conflicto con el servidor de licencias en 45900. |

Los registros del servidor nunca incluyen contraseñas, tokens, claves de licencia ni la clave privada. La auditoría redacta campos sensibles y guarda acciones como `license.issued`, `license.renewed`, `license.revoked`, `license.revealed` y `licenses.exported`.

## Pruebas

```powershell
cd license-server
npm test
```

Incluye la suite del backend central, SMTP y la API local `/v1`:

- salud pública, rechazo de Origin y errores uniformes;
- login, sesión, perfiles y cierre de sesión;
- permisos de operador frente a administrador;
- emisión, listado, detalle, lotes y validación de parámetros;
- activación firmada, validación, renovación, suspensión, reactivación y revocación;
- renovación de licencias vencidas y lista firmada de revocaciones con ETag;
- exportación CSV, pagos desactivados y auditoría sin secretos.

```powershell
cd ..\license-admin
npm test
```

Comprueba la normalización de direcciones, el cliente `/v1`, el modo central heredado, los errores de red, los tiempos de espera y las descargas.

## Seguridad operativa

- No expongas el puerto 45900 a Internet ni lo publiques mediante un proxy inverso. Este backend está diseñado para el mismo equipo.
- No uses credenciales de PayPal reales con este backend: los pagos están desactivados y no se procesan.
- No crees usuarios con contraseñas compartidas; cada administrador debe tener su propia cuenta.
- Mantén `perfillab-admin-password.txt`, el keystore, la base y los archivos `.pass` fuera del repositorio y de cualquier instalador.
- No inventes claves, tokens ni firmas. Las licencias emitidas aquí se firman con la clave real del keystore.
