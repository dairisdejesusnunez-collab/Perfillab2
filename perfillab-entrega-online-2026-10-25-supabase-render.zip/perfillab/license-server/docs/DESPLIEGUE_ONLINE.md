# Despliegue online del gestor de licencias y la tienda

Esta guía monta el servidor de licencias en un servicio con URL HTTPS, usando **PostgreSQL gestionado** y secretos por variables de entorno. El objetivo es que un reinicio, un despliegue nuevo o el apagado del plan gratuito **no borre pedidos, licencias ni el keystore**.

> Para la combinación concreta **Supabase + Render**, con el blueprint `render.yaml` incluido, sigue la guía específica [`DESPLIEGUE_SUPABASE_RENDER.md`](DESPLIEGUE_SUPABASE_RENDER.md). Esta guía sigue siendo la referencia general para otros proveedores y para la operación.

## 1. Qué debe persistir

| Pieza | Dónde vive en producción | Qué pasa si se pierde |
| --- | --- | --- |
| Clientes, licencias, pedidos, auditoría | PostgreSQL gestionado (Neon, Supabase, Railway, Render…) | Se pierden emisiones y pagos registrados. |
| Keystore cifrado (clave privada Ed25519 y clave de datos) | Secreto `PERFILLAB_KEYSTORE_BASE64` + frase de paso en otro secreto | No se pueden firmar licencias nuevas ni recuperar claves. |
| Instalador descargable | URL HTTPS externa (GitHub Releases, S3, R2) | La tienda deja de ofrecer la descarga; la venta sigue funcionando. |
| Copias de seguridad | Almacenamiento externo duradero | Sin copia no hay recuperación ante un borrado o corrupción. |

El sistema de archivos de un plan gratuito suele ser efímero: **no uses SQLite ni guardes el keystore solo en el disco del servicio**. El servidor lo impide en `NODE_ENV=production` salvo que actives `PERFILLAB_ALLOW_SQLITE=true`, algo reservado a desarrollo.

La clave privada nunca se escribe en la imagen, el repositorio, el cliente ni los registros. La variable `PERFILLAB_KEYSTORE_BASE64` contiene el keystore **cifrado**; sigue siendo un secreto.

## 2. Requisitos

- Cuenta en un proveedor de PostgreSQL gestionado y su URL de conexión.
- Un servicio que ejecute Node.js 24 o un contenedor (Render, Railway, Fly.io, Koyeb, VPS…).
- Un dominio o URL HTTPS del proveedor para `PERFILLAB_PUBLIC_BASE_URL`.
- Aplicación de PayPal (primero Sandbox) con Client ID, Client Secret y Webhook ID.
- El archivo de la bóveda heredada y su contraseña, disponible solo durante la inicialización.
- Opcional: SMTP para entregar la clave por correo.

## 3. Inicialización única (PostgreSQL remoto)

La base se inicializa una sola vez con los 50.000 asientos. Se puede hacer desde tu equipo (recomendado para no depender del disco del hospedaje) o desde una tarea puntual de la plataforma. El comando se conecta directamente a PostgreSQL; no crea ninguna base SQLite.

1. Prepara archivos temporales con las contraseñas, **fuera del repositorio**:

   ```bash
   install -m 600 /dev/null /ruta/segura/vault.pass
   install -m 600 /dev/null /ruta/segura/keystore.pass
   install -m 600 /dev/null /ruta/segura/admin.pass
   # Escribe cada valor con un editor y bórralos al terminar.
   ```

2. Exporta la URL y la configuración solo en esa terminal:

   ```bash
   export NODE_ENV=production
   export PERFILLAB_DATABASE_URL='postgres://usuario:contraseña@host:5432/perfillab'
   export PERFILLAB_DATABASE_SSL=require
   export PERFILLAB_DATA_DIR="$PWD/data-online"
   export PERFILLAB_VAULT_PASSWORD_FILE=/ruta/segura/vault.pass
   export PERFILLAB_KEYSTORE_PASSPHRASE_FILE=/ruta/segura/keystore.pass
   export PERFILLAB_ADMIN_USER=admin
   export PERFILLAB_ADMIN_PASSWORD_FILE=/ruta/segura/admin.pass
   ```

3. Ejecuta la inicialización desde `license-server/`:

   ```bash
   node scripts/init.js --vault ../license-admin/seed/vault.json
   ```

   Si usas otra bóveda real, cambia `--vault`. Debes ver `seats: 50000`, el `legacySeats` esperado, `keyId` y `adminCreated: true`. Ese `keyId` debe coincidir con la clave pública fijada en el cliente (`electron/license-public.js`).

   > `npm run init` se niega a modificar una base ya inicializada. No repitas la operación ni apuntes dos instalaciones a la misma base.

4. Exporta el keystore a base64. El archivo local está cifrado con la frase de paso:

   ```bash
   PERFILLAB_DATA_DIR="$PWD/data-online" node scripts/keystore-env.js --stdout > /ruta/segura/keystore.base64
   chmod 600 /ruta/segura/keystore.base64
   ```

   `--stdout` no necesita la frase de paso y no la muestra. También puedes usar `--out /ruta/segura/keystore.base64`.

5. Guarda el contenido de `keystore.base64` en el panel de secretos del hospedaje como `PERFILLAB_KEYSTORE_BASE64`, y la frase de paso como `PERFILLAB_KEYSTORE_PASSPHRASE` (o un secreto de archivo si la plataforma lo permite). **No los guardes en el mismo lugar ni los confirmes en el repositorio.**

6. Conserva una copia cifrada del keystore y la frase en un gestor de secretos separado. Si pierdes la frase, no hay recuperación posible.

7. Borra `/ruta/segura/vault.pass`, `admin.pass` y los archivos temporales cuando termines. El administrador ya existe en la base; si no lo creaste, usa `node scripts/admin.js create --username <usuario>` con `PERFILLAB_DATABASE_URL` definido.

### Alternativa: inicializar dentro de la plataforma

Si el proveedor ofrece una consola o un trabajo puntual, ejecuta los mismos pasos con las variables del servicio, captura el base64 que imprime `keystore:env --stdout` y guárdalo como secreto antes de que el disco efímero se recicle. No intentes conservar el archivo `keystore.json` en el disco del plan gratuito.

## 4. Variables del servicio

Configura al menos estas variables en el panel del hospedaje. La lista completa está en `.env.example`.

| Variable | Valor |
| --- | --- |
| `NODE_ENV` | `production` |
| `PERFILLAB_DATABASE_URL` | URL de PostgreSQL gestionado. |
| `PERFILLAB_DATABASE_SSL` | `require` (o `verify-full` con CA del proveedor). |
| `PERFILLAB_DATABASE_SCHEMA` | `public` salvo que quieras un esquema dedicado. |
| `PERFILLAB_DATABASE_POOL_MAX` | `5` en planes gratuitos con pocas conexiones. |
| `PERFILLAB_KEYSTORE_BASE64` | Keystore cifrado exportado en el paso 3. |
| `PERFILLAB_KEYSTORE_PASSPHRASE` | Frase de paso, en un secreto aparte. |
| `PERFILLAB_PUBLIC_BASE_URL` | `https://<tu-dominio>` sin ruta ni parámetros. |
| `PERFILLAB_PORT` | Opcional: si no se define, se usa la variable `PORT` que inyecta la plataforma (Render/Railway). Déjala vacía en esos casos. |
| `PERFILLAB_HOST` | Opcional: con `NODE_ENV=production` el servidor escucha en `0.0.0.0` automáticamente; el proxy de la plataforma gestiona TLS. |
| `PERFILLAB_TRUST_PROXY` | `true` detrás del proxy del proveedor. |
| `PERFILLAB_SUPPORT_EMAIL` | Correo de soporte que verá el cliente. |
| `PERFILLAB_PAYPAL_MODE` | `sandbox` hasta verificar todo; luego `live`. |
| `PERFILLAB_PRICE_USD` | `100.00` como respaldo del plan anual. |
| `PERFILLAB_PAYPAL_CLIENT_ID` / `_SECRET` / `_WEBHOOK_ID` | Credenciales reales de PayPal. |
| `PERFILLAB_INSTALLER_URL` | URL HTTPS del artefacto de instalación. |

No definas `PERFILLAB_ALLOW_SQLITE`. Tampoco definas a la vez `PERFILLAB_INSTALLER_URL` y `PERFILLAB_INSTALLER_PATH`.

Si el proveedor tiene un límite de conexiones muy bajo, usa la URL *pooled* de PostgreSQL y baja `PERFILLAB_DATABASE_POOL_MAX` a 2–5. Evita varias réplicas del servicio gratuito apuntando a la misma base con pools grandes.

## 5. Desplegar con Docker

La imagen incluida escucha en `0.0.0.0`, ejecuta como usuario sin privilegios y comprueba `/api/health`.

```bash
cd license-server
docker build -t perfillab-license .
docker run --rm -p 45900:45900 --env-file .env perfillab-license
```

Pasos en plataformas tipo Render/Railway/Fly/Koyeb:

1. Sube el repositorio (o solo `license-server/`) a un repositorio privado.
2. Crea un servicio web con Dockerfile `license-server/Dockerfile` (contexto `license-server`), o con el comando de arranque `node src/server.js` si usas buildpack de Node 24.
3. Añade las variables y secretos de la sección 4.
4. Configura el puerto interno que espera la plataforma y la comprobación de salud en `/api/health`.
5. Despliega y abre `https://<tu-dominio>/api/health`. Debe responder `ok: true`.
6. Abre la tienda en `/` y comprueba que muestra los planes. Si faltan PayPal o `PERFILLAB_PUBLIC_BASE_URL`, el servidor arranca pero la compra queda cerrada; revisa los avisos del registro.

Notas de planes gratuitos:

- El servicio puede dormir tras un periodo sin tráfico. La primera petición tarda unos segundos; la base y el keystore no se pierden.
- No escribas el keystore ni la base en `/tmp` o en el disco local efímero.
- No uses el disco local para las copias de seguridad: descárgalas o envíalas a almacenamiento externo.
- Revisa la cuota de egreso y el límite de conexiones de PostgreSQL antes de abrir la tienda.

## 6. PayPal y la tienda

1. En el panel de desarrolladores de PayPal crea una aplicación Sandbox. No inventes ni reutilices credenciales de ejemplo.
2. Crea un webhook con la URL `https://<tu-dominio>/api/paypal/webhook` y suscribe los eventos de orden y captura habituales (aprobada, completada, reembolsada, revertida, denegada, anulada).
3. Inicia sesión en la consola de administración con el usuario creado en la inicialización y abre **Pagos**:
   - Client ID, Client Secret, Webhook ID y modo Sandbox.
   - Planes: **Mensual 10 USD / 1 mes**, **Semestral 50 USD / 6 meses**, **Anual 100 USD / 12 meses**.
   - Todos son pago único, sin renovación automática.
4. Haz una compra de prueba con una cuenta compradora Sandbox. La licencia se emite solo cuando el servidor verifica la captura o el webhook firmado; volver de PayPal no emite nada.
5. Cambia a credenciales live y repite una compra mínima antes de abrir la tienda. El dominio debe ser HTTPS.

El importe se calcula en el servidor según el plan y se compara con el importe y la moneda de la captura. Los cambios de precio solo afectan a órdenes nuevas.

## 7. Publicar el instalador del cliente

La tienda muestra un botón de descarga cuando el servidor tiene un instalador configurado. El artefacto público es el instalador del cliente; la consola administrativa se distribuye aparte y no se publica en la tienda.

### Generar los instaladores

En el proyecto principal, con Inno Setup 6 instalado:

```bash
npm run installers
npm run verify:installers
```

Se generan `dist/PerfilLab-Setup-<versión>.exe` (cliente) y `dist/PerfilLab-Licencias-Setup-<versión>.exe` (consola), con `dist/installers.json` y `dist/SHA256SUMS.txt`. Ambos excluyen el servidor, PostgreSQL, `.env`, la bóveda, el keystore, las pruebas, los scripts y los secretos. No están firmados digitalmente; SmartScreen puede advertir hasta que se firmen con un certificado de código.

### URL externa (recomendada en hosting gratuito)

1. Sube solo `PerfilLab-Setup-<versión>.exe` a un almacenamiento HTTPS público sin credenciales en la URL: GitHub Releases, S3, Cloudflare R2, etc. No publiques la consola administrativa en la tienda.
2. Define los metadatos reales del manifiesto:

   ```text
   PERFILLAB_INSTALLER_URL=https://<host>/<ruta>/PerfilLab-Setup-1.1.0.exe
   PERFILLAB_INSTALLER_FILENAME=PerfilLab-Setup-1.1.0.exe
   PERFILLAB_INSTALLER_VERSION=1.1.0
   PERFILLAB_INSTALLER_SHA256=<sha256 de dist/installers.json>
   PERFILLAB_INSTALLER_SIZE=<size de dist/installers.json>
   ```

   La URL debe usar HTTPS y no incluir usuario, contraseña ni fragmento. El servidor responde `302` a `/descargar`; el archivo no pasa por su disco. No inventes el host: usa el que tengas configurado.

3. Si usas un artefacto propio, calcula los metadatos reales:

   ```bash
   sha256sum PerfilLab-Setup.exe
   stat -c '%s' PerfilLab-Setup.exe
   ```

   En Windows PowerShell: `Get-FileHash .\PerfilLab-Setup.exe -Algorithm SHA256` y `(Get-Item .\PerfilLab-Setup.exe).Length`.

### Archivo local (solo con disco persistente)

Configura `PERFILLAB_INSTALLER_PATH` con la ruta del instalador del cliente en un volumen persistente. El servidor lo transmite con `Content-Length`, `Content-Disposition`, `ETag`, `Digest` y `Cache-Control: no-store`; verifica el tamaño y el SHA-256 si los declaras. En un plan gratuito sin volumen persistente, el archivo desaparecerá tras un reinicio.

En ambos casos la descarga es pública y **no incluye ninguna licencia**: la clave se compra aparte y se activa dentro de la aplicación. El botón de la tienda se oculta si el instalador no está disponible; `/descargar` responde `404` con el código `installer_unavailable`.

## 8. Consola de administración

La consola Electron (`license-admin/`) se instala con `PerfilLab-Licencias-Setup-<versión>.exe` o se ejecuta desde el repositorio con `npm run admin`. Apunta a la URL HTTPS del servidor. No se instala en el servidor ni recibe la frase del keystore.

1. Abre **PerfilLab Licencias**.
2. Escribe `https://<tu-dominio>` como dirección y usa **Probar conexión** (solo consulta `/v1/health`).
3. Inicia sesión con el administrador creado en la inicialización. No existe una cuenta universal.
4. Configura PayPal y precios, revisa pedidos, emite o revoca licencias y consulta la auditoría.

La dirección se guarda en `%APPDATA%\PerfilLab Licencias\admin-config.json`; `PERFILLAB_LICENSE_SERVER` solo se usa si no hay una dirección guardada. El token de administración vive solo en memoria. No expongas el servidor sin HTTPS ni compartas la consola.

## 9. Copias, restauración y rotación en PostgreSQL

- **Copia**: ejecuta `npm run backup` desde un equipo que tenga `pg_dump` de la misma versión mayor o superior que la base gestionada. El script no pasa secretos por argumentos, verifica el marcador final del volcado y que exista la tabla `seats`, y genera un manifiesto con SHA-256 de la base y del keystore. No guarda la frase de paso.
- **Restauración**: restaura el volcado en una base vacía del mismo esquema y el keystore del mismo momento. Para un esquema distinto de `public`, créalo antes:

  ```bash
  psql "$PERFILLAB_DATABASE_URL" -v ON_ERROR_STOP=1 -c 'CREATE SCHEMA IF NOT EXISTS <esquema>;'
  psql "$PERFILLAB_DATABASE_URL" -v ON_ERROR_STOP=1 -f perfillab-<fecha>.sql
  ```

  Después configura `PERFILLAB_KEYSTORE_BASE64` y su frase, arranca y verifica `/api/health`, el `keyId` y una activación de prueba.

- **Rotación de la frase**: con `PERFILLAB_KEYSTORE_BASE64` definido, `npm run rotate-keystore -- --out <ruta>` escribe un keystore nuevo cifrado (no imprime la clave) y guarda por defecto una copia del anterior cifrada con la frase antigua en `PERFILLAB_DATA_DIR` (`--no-backup` la omite). Sustituye el secreto base64, comprueba que el servidor arranca antes de borrar nada y elimina la copia cuando termines. La clave privada y la clave de datos no cambian, por lo que las licencias emitidas siguen siendo válidas.
- **Rotación de la clave de firma**: no es transparente. Exige publicar un cliente con la nueva clave pública fijada y reemitir o migrar las licencias; no la hagas solo en el servidor.

Programa copias externas con retención; los planes gratuitos pueden no ofrecer recuperación a un punto en el tiempo.

## 10. Verificación posterior al despliegue

1. `GET /api/health` responde 200.
2. El arranque muestra `database: postgres`, el `keyId` esperado y `installerEnabled: true` si configuraste la descarga.
3. `/` muestra los tres planes y el botón de descarga con versión y SHA-256.
4. `/descargar` entrega el artefacto (o redirige a la URL externa) y `HEAD` responde con el tamaño.
5. La consola inicia sesión por HTTPS y lista el inventario de 50.000 asientos.
6. Un pago Sandbox emite una sola licencia, incluso si PayPal repite el webhook.
7. **Reinicia el servicio desde el panel del proveedor** y verifica que el pedido y la licencia siguen ahí y que el `keyId` no cambió. Esto confirma que PostgreSQL y el keystore por entorno están bien configurados.
8. Descarga una copia y comprueba que el manifiesto contiene los hashes de base y keystore.

## 11. Problemas frecuentes

| Síntoma | Causa probable |
| --- | --- |
| `La base de datos SQLite no existe` | Falta `PERFILLAB_DATABASE_URL` o el servicio arrancó con SQLite. |
| Error de certificado TLS de PostgreSQL | Ajusta `PERFILLAB_DATABASE_SSL`; para `verify-full` configura la CA del proveedor. |
| `too many connections` | Baja `PERFILLAB_DATABASE_POOL_MAX` y usa la URL pooled. |
| La tienda está cerrada | Faltan PayPal/URL pública o no hay asientos disponibles. |
| `/descargar` responde 404 | El instalador no está configurado, la ruta no existe o el checksum configurado no coincide. |
| `No se pudo abrir el keystore` | La frase de paso no corresponde al `PERFILLAB_KEYSTORE_BASE64` o el secreto se truncó al pegarlo. |
| El servicio despierta lento | Es el comportamiento del plan gratuito; el estado sigue en PostgreSQL. |
| Licencias de una instalación anterior no aparecen | La base es distinta, el esquema cambió o la restauración fue incompleta. No reutilices capturas de PayPal. |

Para el procedimiento general (systemd, proxy nginx, incidentes, compromiso de claves) consulta [`OPERACIONES.md`](OPERACIONES.md).
