'use strict';

const crypto = require('node:crypto');
const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');

const { createRuntime } = require('../src/server');
const {
  PaymentSettings,
  SECRET_AAD,
  SECRET_KEY,
} = require('../src/payment-settings');
const { decryptField, hashPassword, nowIso } = require('../src/security');
const { FakeMailer, createTestEnvironment } = require('./helpers/env');
const { request, startTestServer } = require('./helpers/http');

const PAYPAL = {
  clientId: 'test-client-id',
  clientSecret: 'test-client-secret',
  webhookId: 'test-webhook-id',
};
let env = null;
let server = null;

before(async () => {
  env = await createTestEnvironment();
});

after(async () => {
  if (server) await server.close();
  if (env) await env.close();
});

function makeSettings(overrides = {}) {
  return new PaymentSettings({
    db: env.db,
    keystore: env.keystore,
    config: env.config,
    audit: env.audit,
    logger: env.logger,
    ...overrides,
  });
}

test('PaymentSettings: precios por plan, secreto cifrado y sin filtrar', async () => {
  const settings = makeSettings();
  await settings.clear();

  const initial = await settings.snapshot();
  assert.equal(initial.source, 'env');
  assert.equal(initial.secretSource, 'env');
  assert.equal(initial.pricesSource, 'env');
  assert.equal(initial.plans.length, 3);
  const initialPlans = Object.fromEntries(initial.plans.map((plan) => [plan.code, plan]));
  assert.equal(initialPlans.monthly.amountCents, 1000);
  assert.equal(initialPlans.semiannual.amountCents, 5000);
  assert.equal(initialPlans.annual.amountCents, 2900);

  const saved = await settings.save({
    mode: 'sandbox',
    clientId: PAYPAL.clientId,
    clientSecret: PAYPAL.clientSecret,
    webhookId: PAYPAL.webhookId,
    prices: { monthly: 1000, semiannual: 5000, annual: 10000 },
  }, { actorType: 'admin', actorId: 'test-admin', ip: '127.0.0.1' });
  assert.equal(saved.source, 'db');
  assert.equal(saved.secretSource, 'db');
  assert.equal(saved.pricesSource, 'db');
  assert.equal(saved.secretConfigured, true);
  assert.equal(saved.clientId, PAYPAL.clientId);
  const savedPlans = Object.fromEntries(saved.plans.map((plan) => [plan.code, plan]));
  assert.equal(savedPlans.monthly.amountCents, 1000);
  assert.equal(savedPlans.semiannual.amountCents, 5000);
  assert.equal(savedPlans.annual.amountCents, 10000);
  assert.equal(savedPlans.monthly.label, 'Mensual');
  assert.equal(savedPlans.semiannual.months, 6);
  assert.equal(savedPlans.annual.description, 'Vigencia de 12 meses');
  assert.ok(!JSON.stringify(saved).includes(PAYPAL.clientSecret));

  const encrypted = await env.db.getSetting(SECRET_KEY, '');
  assert.ok(encrypted);
  assert.notEqual(encrypted, PAYPAL.clientSecret);
  assert.equal(decryptField(encrypted, env.keystore.dataKey, SECRET_AAD), PAYPAL.clientSecret);
  const audit = await env.db.all("SELECT * FROM audit_log WHERE action = 'payments.updated' ORDER BY created_at DESC");
  assert.ok(audit.length >= 1);
  assert.ok(!JSON.stringify(audit).includes(PAYPAL.clientSecret));
  assert.equal((await settings.gateway()).prices.annual, 10000);

  const withoutSecret = await settings.save({
    mode: 'sandbox',
    clientId: PAYPAL.clientId,
    clientSecret: '',
    webhookId: PAYPAL.webhookId,
    prices: { monthly: 1000, semiannual: 5000, annual: 10000 },
  }, { actorType: 'admin', actorId: 'test-admin' });
  assert.equal(withoutSecret.secretConfigured, true);
  assert.equal(withoutSecret.secretSource, 'db');

  await assert.rejects(
    settings.save({ mode: 'sandbox', clientId: '', webhookId: PAYPAL.webhookId }),
    (error) => error.code === 'missing_client_id',
  );
  await assert.rejects(
    settings.save({
      mode: 'sandbox',
      clientId: PAYPAL.clientId,
      webhookId: PAYPAL.webhookId,
      prices: { monthly: 0, semiannual: 5000, annual: 10000 },
    }),
    (error) => error.code === 'invalid_price',
  );

  const cleared = await settings.clear();
  assert.equal(cleared.source, 'env');
  assert.equal(cleared.secretSource, 'env');
  assert.equal(cleared.pricesSource, 'env');
  assert.equal(cleared.secretConfigured, true);
});

test('PaymentSettings: probar credenciales contra PayPal', async () => {
  const calls = [];
  const settings = makeSettings({
    fetchImpl: async (url, options) => {
      calls.push({ url, options });
      return new Response(JSON.stringify({ access_token: 'fake-token', expires_in: 3600 }), {
        status: 200,
        headers: { 'Content-Type': 'application/json' },
      });
    },
  });
  const result = await settings.test({
    mode: 'sandbox',
    ...PAYPAL,
  }, { actorType: 'admin', actorId: 'test-admin' });
  assert.equal(result.ok, true);
  assert.equal(result.mode, 'sandbox');
  assert.match(calls[0].url, /\/v1\/oauth2\/token$/);
  assert.match(calls[0].options.headers.Authorization, /^Basic /);

  const failing = makeSettings({
    fetchImpl: async () => new Response(JSON.stringify({ error: 'invalid_client' }), {
      status: 401,
      headers: { 'Content-Type': 'application/json' },
    }),
  });
  await assert.rejects(
    failing.test({ mode: 'sandbox', ...PAYPAL }, { actorType: 'admin', actorId: 'test-admin' }),
    (error) => error.code === 'paypal_auth_failed',
  );
});

test('HTTP: la consola configura PayPal y la tienda usa los precios guardados', async () => {
  const runtime = createRuntime({
    config: env.config,
    db: env.db,
    keystore: env.keystore,
    logger: env.logger,
    mailer: new FakeMailer(),
  });
  server = await startTestServer({
    config: env.config,
    db: env.db,
    keystore: env.keystore,
    logger: env.logger,
    runtime,
  });

  const anonymous = await request(server.baseUrl, 'GET', '/api/admin/payments');
  assert.equal(anonymous.status, 401);

  const adminLogin = await request(server.baseUrl, 'POST', '/api/admin/login', {
    body: { username: env.admin.username, password: env.admin.password },
  });
  assert.equal(adminLogin.status, 200);
  const adminToken = adminLogin.body.token;

  await env.db.run(
    `INSERT INTO admin_users(id, username, password_hash, role, disabled, created_at, password_changed_at)
     VALUES (?, ?, ?, 'operator', 0, ?, ?)`,
    [
      crypto.randomUUID(),
      'reader',
      hashPassword('reader-test-password-123'),
      nowIso(),
      nowIso(),
    ],
  );
  const readerLogin = await request(server.baseUrl, 'POST', '/api/admin/login', {
    body: { username: 'reader', password: 'reader-test-password-123' },
  });
  assert.equal(readerLogin.status, 200);
  const readerToken = readerLogin.body.token;

  const before = await request(server.baseUrl, 'GET', '/api/admin/payments', { token: adminToken });
  assert.equal(before.status, 200);
  assert.equal(before.body.plans.length, 3);
  assert.ok(!JSON.stringify(before.body).includes(PAYPAL.clientSecret));

  const saved = await request(server.baseUrl, 'POST', '/api/admin/payments', {
    token: adminToken,
    body: {
      mode: 'sandbox',
      clientId: PAYPAL.clientId,
      clientSecret: PAYPAL.clientSecret,
      webhookId: PAYPAL.webhookId,
      prices: { monthly: 1000, semiannual: 5000, annual: 10000 },
    },
  });
  assert.equal(saved.status, 200);
  assert.equal(saved.body.source, 'db');
  assert.equal(saved.body.secretConfigured, true);
  assert.ok(!JSON.stringify(saved.body).includes(PAYPAL.clientSecret));

  const store = await request(server.baseUrl, 'GET', '/api/store');
  assert.equal(store.status, 200);
  assert.equal(store.body.checkoutEnabled, true);
  assert.equal(store.body.plans.length, 3);
  const plans = Object.fromEntries(store.body.plans.map((plan) => [plan.code, plan]));
  assert.equal(plans.monthly.amountCents, 1000);
  assert.equal(plans.semiannual.amountCents, 5000);
  assert.equal(plans.annual.amountCents, 10000);
  assert.deepEqual(store.body.price, { amountCents: 10000, currency: 'USD' });
  assert.ok(!JSON.stringify(store.body).includes(PAYPAL.clientSecret));
  assert.ok(!JSON.stringify(store.body).includes(PAYPAL.clientId));

  const readerRead = await request(server.baseUrl, 'GET', '/api/admin/payments', { token: readerToken });
  assert.equal(readerRead.status, 200);
  const readerWrite = await request(server.baseUrl, 'POST', '/api/admin/payments', {
    token: readerToken,
    body: {
      mode: 'sandbox',
      clientId: PAYPAL.clientId,
      webhookId: PAYPAL.webhookId,
      prices: { monthly: 1000, semiannual: 5000, annual: 10000 },
    },
  });
  assert.equal(readerWrite.status, 403);
  assert.equal(readerWrite.body.error.code, 'role_forbidden');

  const invalid = await request(server.baseUrl, 'POST', '/api/admin/payments', {
    token: adminToken,
    body: { mode: 'sandbox', clientId: '', webhookId: PAYPAL.webhookId },
  });
  assert.equal(invalid.status, 400);
  assert.equal(invalid.body.error.code, 'missing_client_id');

  const cleared = await request(server.baseUrl, 'POST', '/api/admin/payments/clear', {
    token: adminToken,
    body: {},
  });
  assert.equal(cleared.status, 200);
  assert.equal(cleared.body.source, 'env');
  assert.equal(cleared.body.secretSource, 'env');
});
