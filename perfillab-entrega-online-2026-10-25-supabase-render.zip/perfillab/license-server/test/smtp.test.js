'use strict';

const net = require('node:net');
const { test } = require('node:test');
const assert = require('node:assert/strict');

const {
  SmtpMailer,
  SmtpError,
  buildMimeMessage,
  dotStuff,
  parseAddress,
  wrapBase64,
} = require('../src/smtp');
const { renderLicenseEmail, formatDate } = require('../src/email');

const SILENT_LOGGER = { info() {}, warn() {}, error() {} };

function startSmtpServer(options = {}) {
  const state = {
    commands: [],
    auth: [],
    messages: [],
    message: '',
    dataMode: false,
    stage: 'command',
    username: '',
  };
  const sockets = new Set();
  const server = net.createServer((socket) => {
    sockets.add(socket);
    socket.on('close', () => sockets.delete(socket));
    socket.on('error', () => {});
    socket.setEncoding('utf8');
    let buffer = '';
    socket.write('220 fake-smtp ESMTP\r\n');
    socket.on('data', (chunk) => {
      buffer += chunk;
      let index = buffer.indexOf('\r\n');
      while (index >= 0) {
        const line = buffer.slice(0, index);
        buffer = buffer.slice(index + 2);
        state.commands.push(line);
        if (state.dataMode) {
          if (line === '.') {
            state.dataMode = false;
            state.messages.push(state.message);
            state.message = '';
            socket.write('250 2.0.0 en cola\r\n');
          } else {
            state.message += `${line.startsWith('..') ? line.slice(1) : line}\r\n`;
          }
          index = buffer.indexOf('\r\n');
          continue;
        }
        const upper = line.toUpperCase();
        if (state.stage === 'login-user') {
          state.username = Buffer.from(line, 'base64').toString('utf8');
          state.stage = 'login-pass';
          socket.write('334 UGFzc3dvcmQ6\r\n');
        } else if (state.stage === 'login-pass') {
          state.auth.push({
            method: 'LOGIN',
            user: state.username,
            pass: Buffer.from(line, 'base64').toString('utf8'),
          });
          state.stage = 'command';
          socket.write('235 2.7.0 autenticado\r\n');
        } else if (upper.startsWith('EHLO') || upper.startsWith('HELO')) {
          const lines = ['250-fake-smtp'];
          if (options.starttls) lines.push('250-STARTTLS');
          if (options.auth !== false) {
            lines.push(`250-AUTH ${(options.authMethods || ['PLAIN', 'LOGIN']).join(' ')}`);
          }
          lines.push('250 OK');
          socket.write(`${lines.join('\r\n')}\r\n`);
        } else if (upper.startsWith('AUTH PLAIN ')) {
          const decoded = Buffer.from(line.slice(11), 'base64').toString('utf8').split('\0');
          state.auth.push({ method: 'PLAIN', user: decoded[1], pass: decoded[2] });
          socket.write('235 2.7.0 autenticado\r\n');
        } else if (upper === 'AUTH LOGIN') {
          state.stage = 'login-user';
          socket.write('334 VXNlcm5hbWU6\r\n');
        } else if (upper.startsWith('MAIL FROM:')) {
          socket.write('250 2.1.0 ok\r\n');
        } else if (upper.startsWith('RCPT TO:')) {
          socket.write(options.rejectRecipient ? '550 5.1.1 destinatario rechazado\r\n' : '250 2.1.5 ok\r\n');
        } else if (upper === 'DATA') {
          state.dataMode = true;
          socket.write('354 escribe el mensaje\r\n');
        } else if (upper === 'QUIT') {
          socket.write('221 2.0.0 adiós\r\n');
          socket.end();
        } else {
          socket.write('502 5.5.2 no implementado\r\n');
        }
        index = buffer.indexOf('\r\n');
      }
    });
  });
  return new Promise((resolve, reject) => {
    server.once('error', reject);
    server.listen(0, '127.0.0.1', () => {
      server.removeListener('error', reject);
      resolve({
        port: server.address().port,
        state,
        close() {
          for (const socket of sockets) socket.destroy();
          return new Promise((done) => server.close(() => done()));
        },
      });
    });
  });
}

function mailerFor(server, overrides = {}) {
  const mailer = new SmtpMailer({
    host: '127.0.0.1',
    port: server.port,
    from: 'PerfilLab <licencias@example.com>',
    envelopeFrom: 'bounces@example.com',
    user: 'smtp-user',
    pass: 'smtp-pass',
    secure: 'none',
    ...overrides,
  }, SILENT_LOGGER);
  mailer.timeoutMs = 5000;
  return mailer;
}

test('SMTP: envío autenticado con PLAIN, sobre y cabeceras correctas', async () => {
  const server = await startSmtpServer();
  try {
    const mailer = mailerFor(server);
    const text = 'Hola, cliente.\nClave: ABCD-EFGH-IJKL-MNOP\n';
    const sent = await mailer.send({
      to: 'Cliente <cliente@example.com>',
      subject: 'Tu licencia de PerfilLab',
      text,
      html: '<p>Hola, cliente.</p>',
    });
    assert.equal(sent.accepted, true);
    assert.deepEqual(server.state.auth, [{ method: 'PLAIN', user: 'smtp-user', pass: 'smtp-pass' }]);
    assert.ok(server.state.commands.includes('MAIL FROM:<bounces@example.com>'));
    assert.ok(server.state.commands.includes('RCPT TO:<cliente@example.com>'));
    assert.ok(server.state.commands.includes('QUIT'));
    const message = server.state.messages[0];
    assert.match(message, /^From: "PerfilLab" <licencias@example\.com>\r$/m);
    assert.match(message, /^To: "Cliente" <cliente@example\.com>\r$/m);
    assert.match(message, /^Subject: Tu licencia de PerfilLab\r$/m);
    assert.match(message, /^Message-ID: <[^>]+@example\.com>\r$/m);
    const encodedText = Buffer.from(text, 'utf8').toString('base64');
    assert.ok(message.includes(encodedText.slice(0, 64)));
  } finally {
    await server.close();
  }
});

test('SMTP: autenticación LOGIN cuando el servidor no ofrece PLAIN', async () => {
  const server = await startSmtpServer({ authMethods: ['LOGIN'] });
  try {
    const mailer = mailerFor(server, { user: 'usuario-login', pass: 'clave-login' });
    const sent = await mailer.send({
      to: 'cliente@example.com',
      subject: 'Prueba',
      text: 'Hola',
      html: '<p>Hola</p>',
    });
    assert.equal(sent.accepted, true);
    assert.deepEqual(server.state.auth, [{ method: 'LOGIN', user: 'usuario-login', pass: 'clave-login' }]);
  } finally {
    await server.close();
  }
});

test('SMTP: rechazo del destinatario no se reintenta', async () => {
  const server = await startSmtpServer({ rejectRecipient: true });
  try {
    const mailer = mailerFor(server);
    await assert.rejects(
      mailer.send({ to: 'cliente@example.com', subject: 'Prueba', text: 'Hola', html: '<p>Hola</p>' }),
      (error) => error instanceof SmtpError
        && error.code === 'smtp_rejected'
        && error.status === 550
        && error.retryable === false,
    );
  } finally {
    await server.close();
  }
});

test('SMTP: exige STARTTLS antes de enviar credenciales', async () => {
  const server = await startSmtpServer();
  try {
    const mailer = mailerFor(server, { secure: 'starttls' });
    await assert.rejects(
      mailer.send({ to: 'cliente@example.com', subject: 'Prueba', text: 'Hola', html: '<p>Hola</p>' }),
      (error) => error instanceof SmtpError && error.code === 'smtp_starttls_unavailable',
    );
    assert.equal(server.state.auth.length, 0);
  } finally {
    await server.close();
  }
});

test('SMTP: servidor sin AUTH y configuración no válida', async () => {
  const server = await startSmtpServer({ auth: false });
  try {
    const mailer = mailerFor(server);
    await assert.rejects(
      mailer.send({ to: 'cliente@example.com', subject: 'Prueba', text: 'Hola', html: '<p>Hola</p>' }),
      (error) => error instanceof SmtpError && error.code === 'smtp_auth_unsupported',
    );
  } finally {
    await server.close();
  }

  const disabled = new SmtpMailer({ host: '', from: '' }, SILENT_LOGGER);
  assert.equal(disabled.enabled, false);
  await assert.rejects(
    disabled.send({ to: 'cliente@example.com', subject: 'Prueba', text: 'Hola', html: '<p>Hola</p>' }),
    (error) => error.code === 'smtp_disabled',
  );
  assert.throws(
    () => new SmtpMailer({ host: '127.0.0.1', from: 'no-es-correo' }, SILENT_LOGGER),
    (error) => error.code === 'smtp_config',
  );
});

test('MIME: cabeceras, partes base64 y protección contra inyección', () => {
  assert.equal(parseAddress('no-es-correo'), null);
  assert.equal(parseAddress('Cliente <a@example.com>\r\nBcc: b@example.com'), null);
  assert.deepEqual(parseAddress('"Cliente Ñ" <Cliente@Example.COM>'), {
    name: 'Cliente Ñ',
    address: 'cliente@example.com',
  });

  const text = 'Hola, cliente.\nClave: ABCD-EFGH-IJKL-MNOP\n';
  const html = '<p>Hola, <strong>cliente</strong>.</p>';
  const message = buildMimeMessage({
    from: 'PerfilLab <licencias@example.com>',
    to: 'Cliente <cliente@example.com>',
    subject: 'Licencia ñ\r\nBcc: intruso@example.com',
    text,
    html,
  });
  assert.match(message, /^Subject: =\?UTF-8\?B\?[A-Za-z0-9+/=]+\?=\r$/m);
  assert.ok(!message.includes('\r\nBcc:'));
  assert.match(message, /^Content-Type: multipart\/alternative; boundary="perfillab-[a-f0-9]{24}"\r$/m);
  assert.match(message, /^Auto-Submitted: auto-generated\r$/m);

  const parts = [...message.matchAll(
    /Content-Transfer-Encoding: base64\r\n\r\n([\s\S]*?)\r\n--perfillab-/g,
  )].map((match) => Buffer.from(match[1].replace(/\s+/g, ''), 'base64').toString('utf8'));
  assert.deepEqual(parts, [text, html]);
});

test('MIME: dot-stuffing y líneas base64 de 76 caracteres', () => {
  assert.equal(dotStuff('.primera\r\nsegunda\n.tercera'), '..primera\r\nsegunda\r\n..tercera\r\n.\r\n');
  const encoded = wrapBase64(Buffer.alloc(150, 0x41));
  const lines = encoded.split('\r\n');
  assert.equal(lines.length, 3);
  assert.ok(lines.every((line) => line.length <= 76));
  assert.equal(Buffer.from(lines.join(''), 'base64').length, 150);
});

test('correo de licencia: contenido, escape HTML y soporte', () => {
  const content = renderLicenseEmail({
    license: {
      id: 'PL-00003',
      customer_name: 'Cliente <script>alert(1)</script>',
      issued_at: '2026-10-24T00:00:00.000Z',
      expires_at: '2027-10-24T00:00:00.000Z',
    },
    key: 'ABCD-EFGH-IJKL-MNOP',
    config: { productName: 'PerfilLab', supportEmail: 'soporte@example.com' },
    orderId: 'order-123',
  });
  assert.equal(content.subject, 'Tu licencia de PerfilLab');
  assert.match(content.text, /ABCD-EFGH-IJKL-MNOP/);
  assert.match(content.text, /Referencia: order-123/);
  assert.match(content.text, /Soporte: soporte@example\.com/);
  assert.match(content.html, /&lt;script&gt;alert\(1\)&lt;\/script&gt;/);
  assert.ok(!content.html.includes('<script>alert(1)</script>'));
  assert.match(content.html, /href="mailto:soporte@example\.com"/);
  assert.match(content.html, /ABCD-EFGH-IJKL-MNOP/);
  assert.equal(formatDate(null), 'sin vencimiento');
  assert.match(formatDate('2027-10-24T00:00:00.000Z'), /2027/);
});
