'use strict';

const crypto = require('node:crypto');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');

const legacy = require('../../../license-admin/lib/core');
const { loadConfig } = require('../../src/config');
const { openDatabase } = require('../../src/database');
const { openKeystore } = require('../../src/keystore');
const { initializeServer } = require('../../src/seats');
const { readVaultFile, unlockVault } = require('../../src/vault');
const { AuditService } = require('../../src/audit');
const { LicensesService } = require('../../src/licenses');
const { OrdersService } = require('../../src/orders');
const { AdminAuthService } = require('../../src/admin-auth');
const { EmailWorker } = require('../../src/email');
const { InstallerService } = require('../../src/installer');
const { StaticAssets } = require('../../src/http-utils');
const { createLogger } = require('../../src/logger');

const SILENT_SINK = { log() {}, warn() {}, error() {} };
const TEST_LOGGER = createLogger({ level: 'error', sink: SILENT_SINK });

const ACTIVE_MACHINE = '7K2M-9Q4X-6R8T-2W5Y';
const EXPIRED_MACHINE = '8N3P-2R5V-7T9W-4X6Z';
const TEST_ADMIN = { username: 'admin', password: 'perfillab-test-password-123' };

function createLegacyVault({ seatCount = 2000, password, privateKey, publicKey }) {
  const seats = legacy.createSeats(seatCount);
  const state = { publicKey, privateKey, seats };
  const active = legacy.issueLicense(state, {
    machineCode: ACTIVE_MACHINE,
    customer: 'Cliente Heredado Activo',
    notes: 'Licencia migrada de la bóveda anterior.',
    expiresAt: new Date(Date.now() + 180 * 24 * 60 * 60 * 1000).toISOString(),
  });
  const expired = legacy.issueLicense(state, {
    machineCode: EXPIRED_MACHINE,
    customer: 'Cliente Heredado Vencido',
    expiresAt: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(),
  });
  seats[1].expiresAt = new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString();
  const { file } = legacy.createVault({ password, privateKey, publicKey, seats });
  return {
    file,
    seats,
    active: active.seat,
    expired: expired.seat,
  };
}

function makeConfig(dataDir, overrides = {}) {
  const testDatabaseUrl = String(
    overrides.PERFILLAB_DATABASE_URL || process.env.PERFILLAB_TEST_DATABASE_URL || '',
  ).trim();
  const env = {
    NODE_ENV: 'test',
    PERFILLAB_DATA_DIR: dataDir,
    PERFILLAB_PUBLIC_BASE_URL: 'https://licencias.test',
    PERFILLAB_PRICE_USD: '29.00',
    PERFILLAB_PAYPAL_CLIENT_ID: 'test-client-id',
    PERFILLAB_PAYPAL_CLIENT_SECRET: 'test-client-secret',
    PERFILLAB_PAYPAL_WEBHOOK_ID: 'test-webhook-id',
    PERFILLAB_SUPPORT_EMAIL: 'soporte@example.com',
    ...overrides,
  };
  if (testDatabaseUrl) {
    env.PERFILLAB_DATABASE_URL = testDatabaseUrl;
    env.PERFILLAB_DATABASE_SCHEMA = overrides.PERFILLAB_DATABASE_SCHEMA
      || `perfillab_test_${Date.now().toString(36)}_${crypto.randomBytes(4).toString('hex')}`;
    env.PERFILLAB_DATABASE_POOL_MAX = env.PERFILLAB_DATABASE_POOL_MAX || '5';
  }
  const config = loadConfig(env);
  config.checkoutAttemptsPerIp = 10_000;
  config.activationAttemptsPerIp = 10_000;
  config.loginAttempts = 10_000;
  config.maxBatchItems = 100;
  return config;
}

async function createTestEnvironment(options = {}) {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'perfillab-test-'));
  const dataDir = path.join(dir, 'data');
  const vaultPassword = `vault-${crypto.randomBytes(12).toString('hex')}`;
  const keystorePassphrase = `keystore-${crypto.randomBytes(12).toString('hex')}`;
  const pair = legacy.generateKeyPair();
  const generated = createLegacyVault({
    seatCount: options.seatCount || 2000,
    password: vaultPassword,
    privateKey: pair.privateKey,
    publicKey: pair.publicKey,
  });
  const vaultPath = path.join(dir, 'vault.json');
  fs.writeFileSync(vaultPath, JSON.stringify(generated.file), { mode: 0o600 });
  const vault = unlockVault(readVaultFile(vaultPath), vaultPassword);
  const config = makeConfig(dataDir, options.env || {});
  const db = await openDatabase(config);
  let summary;
  try {
    summary = await initializeServer({
      db,
      vault,
      keystorePath: config.keystorePath,
      keystorePassphrase,
      admin: TEST_ADMIN,
    });
  } catch (error) {
    if (typeof db.dropTestSchema === 'function') await db.dropTestSchema().catch(() => {});
    await db.close().catch(() => {});
    fs.rmSync(dir, { recursive: true, force: true });
    throw error;
  }
  const keystore = openKeystore(config.keystorePath, keystorePassphrase);

  const audit = new AuditService(db);
  const licenses = new LicensesService({ db, keystore, config, audit, logger: TEST_LOGGER });
  const adminAuth = new AdminAuthService({ db, config, audit, logger: TEST_LOGGER });

  const env = {
    dir,
    dataDir,
    config,
    db,
    keystore,
    summary,
    vault,
    generated,
    admin: TEST_ADMIN,
    audit,
    licenses,
    adminAuth,
    logger: TEST_LOGGER,
    buildRuntime({ paypal, mailer } = {}) {
      const orders = new OrdersService({
        db,
        config,
        paypal,
        licenses,
        audit,
        logger: TEST_LOGGER,
      });
      const emailWorker = new EmailWorker({
        db,
        config,
        mailer,
        licenses,
        audit,
        logger: TEST_LOGGER,
        intervalMs: 60_000,
      });
      const assets = new StaticAssets(path.join(config.root, 'public'));
      const installer = new InstallerService({ config, logger: TEST_LOGGER });
      return {
        audit,
        licenses,
        paypal,
        orders,
        adminAuth,
        mailer,
        emailWorker,
        installer,
        assets,
        startedAt: Date.now(),
        maintenance() {
          return orders.maintenance();
        },
      };
    },
    async close() {
      try {
        if (typeof db.dropTestSchema === 'function') await db.dropTestSchema();
      } catch {
        // Limpieza best-effort del esquema temporal.
      }
      try {
        await db.close();
      } catch {
        // Cierre best-effort.
      }
      fs.rmSync(dir, { recursive: true, force: true });
    },
  };
  return env;
}

class FakeMailer {
  constructor() {
    this.enabled = true;
    this.sent = [];
    this.failError = null;
  }

  async send(message) {
    if (this.failError) throw this.failError;
    this.sent.push(message);
  }
}

let fakePayPalSequence = 0;

class FakePayPal {
  constructor({ priceCents = 2900, currency = 'USD' } = {}) {
    this.enabled = true;
    this.priceCents = priceCents;
    this.currency = currency;
    this.orders = new Map();
    this.captures = new Map();
    this.created = [];
    this.webhookError = null;
    this.webhookCalls = 0;
  }

  nextId(prefix) {
    fakePayPalSequence += 1;
    return `${prefix}-${String(fakePayPalSequence).padStart(6, '0')}`;
  }

  async isEnabled() {
    return this.enabled;
  }

  async createOrder(input) {
    const id = this.nextId('PAYORDER');
    this.created.push(input);
    this.orders.set(id, {
      id,
      status: 'CREATED',
      customId: input.customId,
      amountCents: input.amountCents,
      currency: input.currency,
      captures: [],
    });
    return {
      order: { id, links: [] },
      approvalUrl: `https://www.sandbox.paypal.com/checkoutnow?token=${id}`,
      request: input,
    };
  }

  markApproved(paypalOrderId) {
    const order = this.orders.get(paypalOrderId);
    if (!order) throw new Error('Orden falsa no encontrada.');
    order.status = 'APPROVED';
  }

  async getOrder(paypalOrderId) {
    const order = this.orders.get(paypalOrderId);
    if (!order) throw new Error('Orden falsa no encontrada.');
    return this.view(order);
  }

  async captureOrder(paypalOrderId) {
    const order = this.orders.get(paypalOrderId);
    if (!order) throw new Error('Orden falsa no encontrada.');
    if (order.captures.length) {
      const { PayPalError } = require('../../src/paypal');
      throw new PayPalError('La orden ya fue capturada.', {
        status: 422,
        code: 'UNPROCESSABLE_ENTITY',
        issue: 'ORDER_ALREADY_CAPTURED',
      });
    }
    const capture = {
      id: this.nextId('CAPTURE'),
      status: 'COMPLETED',
      amountCents: order.amountCents,
      currency: order.currency,
      createTime: new Date().toISOString(),
    };
    order.captures.push(capture);
    this.captures.set(capture.id, capture);
    order.status = 'COMPLETED';
    return this.view(order);
  }

  async getCapture(captureId) {
    const capture = this.captures.get(captureId);
    if (!capture) throw new Error('Captura falsa no encontrada.');
    return {
      id: capture.id,
      status: capture.status,
      amount: { value: (capture.amountCents / 100).toFixed(2), currency_code: capture.currency },
      create_time: capture.createTime,
    };
  }

  setCaptureStatus(captureId, status) {
    const capture = this.captures.get(captureId);
    if (!capture) throw new Error('Captura falsa no encontrada.');
    capture.status = status;
  }

  async verifyWebhook() {
    this.webhookCalls += 1;
    if (this.webhookError) throw this.webhookError;
    return true;
  }

  view(order) {
    const unit = {
      reference_id: 'perfillab-annual',
      custom_id: order.customId,
      invoice_id: order.customId,
      amount: {
        currency_code: order.currency,
        value: (order.amountCents / 100).toFixed(2),
      },
    };
    if (order.captures.length) {
      unit.payments = {
        captures: order.captures.map((capture) => ({
          id: capture.id,
          status: capture.status,
          amount: {
            currency_code: capture.currency,
            value: (capture.amountCents / 100).toFixed(2),
          },
          create_time: capture.createTime,
        })),
      };
    }
    return {
      id: order.id,
      status: order.status,
      purchase_units: [unit],
      payer: { email_address: 'pagador@example.com' },
    };
  }
}

module.exports = {
  ACTIVE_MACHINE,
  EXPIRED_MACHINE,
  TEST_ADMIN,
  FakeMailer,
  FakePayPal,
  TEST_LOGGER,
  SILENT_SINK,
  createTestEnvironment,
  makeConfig,
};
