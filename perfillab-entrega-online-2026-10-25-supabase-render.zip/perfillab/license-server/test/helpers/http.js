'use strict';

const http = require('node:http');

const { createLicenseServer } = require('../../src/server');

async function startTestServer({ config, db, keystore, logger, runtime }) {
  const app = createLicenseServer({ config, db, keystore, logger, runtime });
  await new Promise((resolve, reject) => {
    app.server.once('error', reject);
    app.server.listen(0, '127.0.0.1', () => {
      app.server.removeListener('error', reject);
      resolve();
    });
  });
  const address = app.server.address();
  return {
    app,
    baseUrl: `http://127.0.0.1:${address.port}`,
    async close() {
      await app.close();
    },
  };
}

function request(baseUrl, method, path, options = {}) {
  const url = new URL(path, baseUrl);
  const payload = options.body === undefined ? null : Buffer.from(JSON.stringify(options.body), 'utf8');
  const headers = { Accept: options.accept || 'application/json', ...options.headers };
  if (payload) {
    headers['Content-Type'] = options.contentType || 'application/json';
    headers['Content-Length'] = String(payload.length);
  }
  if (options.token) headers.Authorization = `Bearer ${options.token}`;
  return new Promise((resolve, reject) => {
    const req = http.request({
      method,
      hostname: url.hostname,
      port: url.port,
      path: `${url.pathname}${url.search}`,
      headers,
    }, (res) => {
      const chunks = [];
      res.on('data', (chunk) => chunks.push(chunk));
      res.on('end', () => {
        const buffer = Buffer.concat(chunks);
        const text = buffer.toString('utf8');
        let body = null;
        try {
          body = text ? JSON.parse(text) : null;
        } catch {
          body = null;
        }
        resolve({ status: res.statusCode, headers: res.headers, text, body, buffer });
      });
    });
    req.on('error', reject);
    if (payload) req.write(payload);
    req.end();
  });
}

module.exports = { request, startTestServer };
