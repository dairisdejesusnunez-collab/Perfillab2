'use strict';

const crypto = require('node:crypto');
const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');

const {
  HISTORICAL_LICENSE_LIMIT,
  LICENSE_KEY_RE,
  verifyLicense,
  verifyRevocationList,
} = require('../src/license-format');
const { decryptField, normalizeLicenseKey } = require('../src/security');
const { generateLicenseKeys, assertServerInitialized } = require('../src/seats');
const { PayPalError } = require('../src/paypal');
const {
  ACTIVE_MACHINE,
  EXPIRED_MACHINE,
  FakeMailer,
  FakePayPal,
  createTestEnvironment,
} = require('./helpers/env');
const { request, startTestServer } = require('./helpers/http');

let env = null;
let httpServer = null;
let httpRuntime = null;
const httpPayPal = new FakePayPal();
const httpMailer = new FakeMailer();

before(async () => {
  env = await createTestEnvironment();
});

async function ensureHttpServer() {
  if (httpServer) return httpServer;
  httpRuntime = env.buildRuntime({ paypal: httpPayPal, mailer: httpMailer });
  httpServer = await startTestServer({
    config: env.config,
    db: env.db,
    keystore: env.keystore,
    logger: env.logger,
    runtime: httpRuntime,
  });
  return httpServer;
}

after(async () => {
  if (httpServer) await httpServer.close();
  if (env) await env.close();
});

const MACHINE_ALPHABET = '0123456789ABCDEFGHJKMNPQRSTVWXYZ';
let emailCounter = 0;

function randomMachine() {
  let out = '';
  while (out.length < 16) out += MACHINE_ALPHABET[crypto.randomBytes(1)[0] % 32];
  return out.match(/.{4}/g).join('-');
}

function customer(prefix = 'Cliente') {
  emailCounter += 1;
  return {
    customerName: `${prefix} ${emailCounter}`,
    email: `${prefix.toLowerCase().replace(/\s+/g, '.')}.${emailCounter}@example.com`,
  };
}

function issue(input = {}, context = {}) {
  return env.licenses.issue(input, {
    actorType: 'admin',
    actorId: 'test-admin',
    source: 'test',
    ...context,
  });
}

test('migración: 50.000 asientos preservando las 2.000 claves y licencias anteriores', async () => {
  assert.equal(env.summary.seats, HISTORICAL_LICENSE_LIMIT);
  assert.equal(env.summary.legacySeats, 2000);
  assert.equal(env.summary.legacyIssued, 2);
  assert.equal(env.summary.generatedSeats, 48000);
  assert.equal(Number(await env.db.count('seats')), 50000);
  assert.equal(Number((await env.db.get("SELECT COUNT(*) AS n FROM seats WHERE source = 'legacy'")).n), 2000);
  assert.equal(Number((await env.db.get("SELECT COUNT(*) AS n FROM seats WHERE source = 'generated'")).n), 48000);
  assert.equal(Number(await env.db.count('licenses')), 2);
  assert.equal(await env.licenses.availableSeatCount(), 49998);
  assert.deepEqual(await assertServerInitialized(env.db), {
    seats: 50000,
    keyId: env.keystore.keyId,
    initializedAt: await env.db.getSetting('initialized_at'),
  });

  const seat1 = await env.db.get('SELECT seat, license_id, source FROM seats WHERE seat = 1');
  const seat2 = await env.db.get('SELECT seat, license_id, source FROM seats WHERE seat = 2');
  const seat3 = await env.db.get('SELECT seat, license_id, source FROM seats WHERE seat = 3');
  assert.deepEqual({ ...seat1 }, { seat: 1, license_id: 'PL-0001', source: 'legacy' });
  assert.deepEqual({ ...seat2 }, { seat: 2, license_id: 'PL-0002', source: 'legacy' });
  assert.deepEqual({ ...seat3 }, { seat: 3, license_id: null, source: 'legacy' });

  const key1 = decryptField(
    (await env.db.get('SELECT key_enc FROM seats WHERE seat = 1')).key_enc,
    env.keystore.dataKey,
    'seat:1',
  );
  const key3 = decryptField(
    (await env.db.get('SELECT key_enc FROM seats WHERE seat = 3')).key_enc,
    env.keystore.dataKey,
    'seat:3',
  );
  assert.equal(key1, env.generated.active.key);
  assert.equal(key3, env.generated.seats[2].key);
  assert.ok(LICENSE_KEY_RE.test(key1));
  assert.ok(LICENSE_KEY_RE.test(key3));

  const active = await env.db.get('SELECT * FROM licenses WHERE id = ?', ['PL-0001']);
  const expired = await env.db.get('SELECT * FROM licenses WHERE id = ?', ['PL-0002']);
  assert.equal(active.status, 'active');
  assert.equal(active.license_version, 1);
  assert.equal(active.machine_code, ACTIVE_MACHINE);
  assert.equal(expired.status, 'expired');

  const activeDetail = await env.licenses.reveal('PL-0001');
  assert.equal(activeDetail.license.licenseVersion, 1);
  const activeVerified = verifyLicense(activeDetail.envelope, env.keystore.publicKey);
  assert.equal(activeVerified.version, 1);
  assert.equal(activeVerified.payload.licenseKey, env.generated.active.key);
  assert.equal(activeVerified.payload.machineCode, ACTIVE_MACHINE);

  const legacyActivation = await env.licenses.activate({
    licenseKey: env.generated.active.key,
    machineCode: ACTIVE_MACHINE,
  });
  assert.equal(verifyLicense(legacyActivation.license, env.keystore.publicKey).version, 1);
  await assert.rejects(
    env.licenses.activate({
      licenseKey: env.generated.active.key,
      machineCode: randomMachine(),
    }),
    (error) => error.code === 'license_other_machine',
  );
  await assert.rejects(
    env.licenses.activate({
      licenseKey: env.generated.expired.key,
      machineCode: EXPIRED_MACHINE,
    }),
    (error) => error.code === 'license_expired',
  );

  const generatedKeys = generateLicenseKeys(1000);
  assert.equal(new Set(generatedKeys).size, 1000);
  for (const key of generatedKeys) {
    assert.ok(LICENSE_KEY_RE.test(key));
    assert.equal(normalizeLicenseKey(key), key);
  }
});

test('emisión v2, activación por equipo, suspensión y reactivación', async () => {
  const machine = randomMachine();
  const person = customer('Activo');
  const issued = await issue({
    customerName: person.customerName,
    email: person.email,
    machineCode: machine,
    machineName: 'Equipo de prueba',
  });
  assert.equal(issued.license.seat, 3);
  assert.equal(issued.licenseKey, env.generated.seats[2].key);
  assert.equal(issued.license.status, 'active');
  assert.equal(issued.license.licenseVersion, 2);
  assert.equal(issued.license.machineCode, machine);
  assert.ok(Date.parse(issued.license.expiresAt) > Date.now() + 360 * 24 * 60 * 60 * 1000);
  const verified = verifyLicense(issued.envelope, env.keystore.publicKey);
  assert.equal(verified.version, 2);
  assert.equal(verified.payload.licenseId, issued.license.id);
  assert.equal(verified.payload.machineCode, machine);
  assert.equal(verified.payload.plan, 'annual');
  assert.equal(verified.payload.product, 'perfillab');

  await assert.rejects(
    issue({ customerName: person.customerName, machineCode: machine }),
    (error) => error.code === 'machine_in_use',
  );

  const pending = await issue({ customerName: 'Pendiente de activar' });
  assert.equal(pending.license.status, 'pending');
  assert.equal(pending.envelope, null);
  const pendingMachine = randomMachine();
  const activated = await env.licenses.activate({
    licenseKey: pending.licenseKey,
    machineCode: pendingMachine,
    machineName: 'Portátil',
  });
  assert.equal(activated.info.status, 'active');
  assert.equal(activated.info.machineCode, pendingMachine);
  assert.ok(activated.license);
  assert.equal(verifyLicense(activated.license, env.keystore.publicKey).payload.seat, pending.license.seat);
  await assert.rejects(
    env.licenses.activate({ licenseKey: pending.licenseKey, machineCode: randomMachine() }),
    (error) => error.code === 'license_other_machine',
  );

  const suspended = await issue({ customerName: 'Suspendida', machineCode: randomMachine() });
  await assert.rejects(
    env.licenses.suspend(suspended.license.id, { reason: '' }),
    (error) => error.code === 'reason_required',
  );
  const suspension = await env.licenses.suspend(suspended.license.id, { reason: 'Revisión de pago', actorType: 'admin' });
  assert.equal(suspension.view.status, 'suspended');
  const suspendedValidation = await env.licenses.validate({ licenseKey: suspended.licenseKey });
  assert.equal(suspendedValidation.valid, false);
  assert.equal(suspendedValidation.status, 'suspended');
  await assert.rejects(
    env.licenses.activate({ licenseKey: suspended.licenseKey, machineCode: randomMachine() }),
    (error) => error.code === 'license_suspended',
  );
  const reactivated = await env.licenses.reactivate(suspended.license.id, { actorType: 'admin' });
  assert.equal(reactivated.view.status, 'active');
  assert.equal((await env.licenses.validate({ licenseKey: suspended.licenseKey })).valid, true);
});

test('restablecer activación permite mover la licencia a otro equipo', async () => {
  const issued = await issue({ customerName: 'Mudanza', machineCode: randomMachine() });
  const reset = await env.licenses.resetActivation(issued.license.id, { reason: 'Cambio de ordenador' });
  assert.equal(reset.view.status, 'pending');
  assert.equal(reset.view.machineCode, null);
  assert.ok(reset.warning);
  assert.equal((await env.licenses.validate({ licenseKey: issued.licenseKey })).valid, false);
  const newMachine = randomMachine();
  const activated = await env.licenses.activate({
    licenseKey: issued.licenseKey,
    machineCode: newMachine,
    machineName: 'Equipo nuevo',
  });
  assert.equal(activated.info.machineCode, newMachine);
  assert.equal(activated.info.status, 'active');
});

test('revocación firmada, estado de validación y auditoría sin claves', async () => {
  const person = customer('Revocada');
  const issued = await issue({
    customerName: person.customerName,
    email: person.email,
    machineCode: randomMachine(),
  });
  const before = await env.licenses.revocationList();
  await assert.rejects(
    env.licenses.revoke(issued.license.id, { reason: '' }),
    (error) => error.code === 'reason_required',
  );
  const result = await env.licenses.revoke(issued.license.id, {
    reason: 'Reembolso solicitado',
    actorType: 'admin',
    actorId: 'test-admin',
  });
  assert.equal(result.already, false);
  assert.equal(result.view.status, 'revoked');
  assert.equal(result.view.revokedReason, 'Reembolso solicitado');
  await assert.rejects(
    env.licenses.reactivate(issued.license.id),
    (error) => error.code === 'license_revoked_permanent',
  );
  const validation = await env.licenses.validate({ licenseKey: issued.licenseKey });
  assert.equal(validation.valid, false);
  assert.equal(validation.status, 'revoked');
  assert.match(validation.reason, /revocada/i);
  await assert.rejects(
    env.licenses.activate({ licenseKey: issued.licenseKey, machineCode: randomMachine() }),
    (error) => error.code === 'license_revoked',
  );
  const list = await env.licenses.revocationList();
  assert.notEqual(list.etag, before.etag);
  const parsed = JSON.parse(list.body);
  verifyRevocationList(parsed, env.keystore.publicKey);
  assert.ok(parsed.revoked.some((entry) => entry.licenseId === issued.license.id));

  const auditText = JSON.stringify(
    await env.db.all("SELECT details FROM audit_log WHERE action = 'license.revoked'"),
  );
  assert.equal(auditText.includes(issued.licenseKey), false);
  const csv = await env.licenses.exportRows({ query: issued.license.id });
  assert.equal(csv.length, 1);
  assert.equal(JSON.stringify(csv).includes(issued.licenseKey), false);
});

test('lotes, referencias de pago duplicadas y límites', async () => {
  const validMachine = randomMachine();
  const batch = await env.licenses.issueBatch([
    { customerName: 'Lote Uno', email: customer('Lote').email },
    { customerName: 'Lote Dos', machineCode: 'NO-ES-VALIDA' },
    { customerName: 'Lote Tres', machineCode: validMachine },
  ], { actorType: 'admin', source: 'test' });
  assert.equal(batch.issued, 2);
  assert.equal(batch.failed, 1);
  assert.equal(batch.results[1].ok, false);
  assert.equal(batch.results[1].code, 'invalid_machine_code');
  assert.ok(batch.results[0].licenseKey);
  assert.ok(batch.results[2].licenseKey);

  await assert.rejects(
    env.licenses.issueBatch(Array.from({ length: 101 }, () => ({ customerName: 'Demasiados' }))),
    (error) => error.code === 'batch_too_large',
  );
  await assert.rejects(
    env.licenses.issueBatch([]),
    (error) => error.code === 'batch_empty',
  );

  const reference = `TX-${crypto.randomBytes(6).toString('hex')}`;
  await issue({ customerName: 'Referencia única', transactionId: reference });
  await assert.rejects(
    issue({ customerName: 'Referencia repetida', transactionId: reference }),
    (error) => error.code === 'transaction_already_used',
  );
  await assert.rejects(
    issue({}),
    (error) => error.code === 'customer_required',
  );
  await assert.rejects(
    issue({ customerName: 'Correo inválido', email: 'no-es-correo' }),
    (error) => error.code === 'invalid_email',
  );
});

test('cola de correo: envío, reintento y fallo permanente', async () => {
  await env.db.run('DELETE FROM email_outbox');
  const mailer = new FakeMailer();
  const runtime = env.buildRuntime({ paypal: new FakePayPal(), mailer });
  const person = customer('Correo');
  const issued = await issue({
    customerName: person.customerName,
    email: person.email,
    machineCode: randomMachine(),
  });
  const first = await runtime.emailWorker.processOnce();
  assert.equal(first.sent, 1);
  assert.equal(first.failed, 0);
  assert.equal(mailer.sent.length, 1);
  assert.match(mailer.sent[0].text, new RegExp(issued.licenseKey.replace(/-/g, '\\-')));
  assert.match(mailer.sent[0].html, new RegExp(issued.licenseKey.replace(/-/g, '\\-')));
  const sentRow = await env.db.get('SELECT status, attempts, sent_at FROM email_outbox WHERE license_id = ?', [issued.license.id]);
  assert.equal(sentRow.status, 'sent');
  assert.equal(sentRow.attempts, 1);
  assert.ok(sentRow.sent_at);

  mailer.failError = Object.assign(new Error('SMTP temporalmente no disponible'), { retryable: true });
  const retry = await issue({ customerName: 'Reintento', email: customer('Reintento').email });
  const second = await runtime.emailWorker.processOnce();
  assert.equal(second.failed, 1);
  const retryRow = await env.db.get('SELECT status, attempts, last_error, next_attempt_at FROM email_outbox WHERE license_id = ?', [retry.license.id]);
  assert.equal(retryRow.status, 'queued');
  assert.equal(retryRow.attempts, 1);
  assert.match(retryRow.last_error, /SMTP/);
  assert.ok(Date.parse(retryRow.next_attempt_at) > Date.now());

  await env.db.run('UPDATE email_outbox SET next_attempt_at = ? WHERE license_id = ?', [new Date().toISOString(), retry.license.id]);
  mailer.failError = Object.assign(new Error('Dirección rechazada'), { retryable: false });
  const third = await runtime.emailWorker.processOnce();
  assert.equal(third.failed, 1);
  const failedRow = await env.db.get('SELECT status, attempts FROM email_outbox WHERE license_id = ?', [retry.license.id]);
  assert.equal(failedRow.status, 'failed');
  assert.equal(failedRow.attempts, 5);

  mailer.failError = null;
  const revoked = await issue({ customerName: 'Revocada antes', email: customer('RevocadaAntes').email });
  await env.licenses.revoke(revoked.license.id, { reason: 'Prueba de correo revocado' });
  await env.db.run('DELETE FROM email_outbox WHERE license_id = ?', [revoked.license.id]);
  await env.licenses.queueResend(revoked.license.id);
  const fourth = await runtime.emailWorker.processOnce();
  assert.equal(fourth.failed, 1);
  const revokedRow = await env.db.get(
    "SELECT status, last_error FROM email_outbox WHERE license_id = ? ORDER BY created_at DESC LIMIT 1",
    [revoked.license.id],
  );
  assert.equal(revokedRow.status, 'failed');
  assert.match(revokedRow.last_error, /revocada/i);
});

test('checkout PayPal: la licencia solo se emite tras captura verificada', async () => {
  const paypal = new FakePayPal();
  const mailer = new FakeMailer();
  const runtime = env.buildRuntime({ paypal, mailer });
  const person = customer('Compra');

  await assert.rejects(
    runtime.orders.createCheckout({ email: 'invalido', acceptTerms: true, ip: '127.0.0.1' }),
    (error) => error.code === 'invalid_email',
  );
  await assert.rejects(
    runtime.orders.createCheckout({ email: person.email, acceptTerms: false, ip: '127.0.0.1' }),
    (error) => error.code === 'terms_required',
  );

  const availableBefore = await env.licenses.availableSeatCount();
  const licensesBefore = Number(await env.db.count('licenses'));
  const checkout = await runtime.orders.createCheckout({
    email: person.email,
    name: person.customerName,
    acceptTerms: true,
    ip: '127.0.0.1',
  });
  assert.ok(checkout.token);
  assert.match(checkout.approvalUrl, /^https:\/\/www\.sandbox\.paypal\.com\//);
  let order = await runtime.orders.orderByToken(checkout.token);
  assert.equal(order.status, 'pending');
  assert.equal(order.license_id, null);
  assert.equal(await env.licenses.availableSeatCount(), availableBefore);
  assert.equal((await runtime.orders.publicSnapshot(order)).license, null);

  const pendingSnapshot = await runtime.orders.reconcileOrder(order, { trigger: 'return' });
  assert.equal(pendingSnapshot.status, 'pending');
  assert.equal(pendingSnapshot.license, null);
  assert.equal(Number(await env.db.count('licenses')), licensesBefore);

  paypal.markApproved(order.paypal_order_id);
  const paid = await runtime.orders.reconcileOrder(order, { trigger: 'return' });
  assert.equal(paid.status, 'paid');
  assert.ok(paid.license);
  assert.ok(LICENSE_KEY_RE.test(paid.license.licenseKey));
  assert.equal(paid.license.status, 'pending');
  const activated = await env.licenses.activate({
    licenseKey: paid.license.licenseKey,
    machineCode: randomMachine(),
    ip: '127.0.0.1',
  });
  assert.equal(verifyLicense(activated.license, env.keystore.publicKey).payload.licenseId, paid.license.licenseId);

  order = await runtime.orders.orderByToken(checkout.token);
  assert.ok(order.license_id);
  const payment = await env.db.get(
    "SELECT * FROM transactions WHERE order_id = ? AND kind = 'payment'",
    [order.id],
  );
  assert.equal(payment.status, 'completed');
  assert.equal(payment.amount_cents, 2900);
  assert.equal(payment.currency, 'USD');
  const emailRow = await env.db.get('SELECT status FROM email_outbox WHERE order_id = ?', [order.id]);
  assert.equal(emailRow.status, 'queued');

  const licenseCount = Number(await env.db.count('licenses'));
  const again = await runtime.orders.reconcileOrder(await runtime.orders.orderById(order.id), { trigger: 'return' });
  assert.equal(again.status, 'paid');
  assert.equal(Number(await env.db.count('licenses')), licenseCount);
  const transactionCount = Number((await env.db.get(
    "SELECT COUNT(*) AS n FROM transactions WHERE order_id = ? AND kind = 'payment'",
    [order.id],
  )).n);
  assert.equal(transactionCount, 1);
});

test('checkout por plan: importe, duración y licencia mensual/semestral', async () => {
  const paypal = new FakePayPal();
  const runtime = env.buildRuntime({ paypal, mailer: new FakeMailer() });
  const person = customer('Plan');

  await assert.rejects(
    runtime.orders.createCheckout({
      email: person.email, acceptTerms: true, plan: 'weekly', ip: '127.0.0.1',
    }),
    (error) => error.code === 'invalid_plan',
  );

  const monthly = await runtime.orders.createCheckout({
    email: person.email,
    name: person.customerName,
    acceptTerms: true,
    plan: 'monthly',
    ip: '127.0.0.1',
  });
  assert.equal(monthly.amountCents, 1000);
  let order = await runtime.orders.orderByToken(monthly.token);
  assert.equal(order.plan, 'monthly');
  assert.equal(order.duration_months, 1);
  assert.equal(order.amount_cents, 1000);
  assert.equal(paypal.created.at(-1).amountCents, 1000);

  paypal.markApproved(order.paypal_order_id);
  const paid = await runtime.orders.reconcileOrder(order, { trigger: 'return' });
  assert.equal(paid.status, 'paid');
  assert.equal(paid.plan, 'monthly');
  assert.equal(paid.planLabel, 'Mensual');
  assert.equal(paid.durationMonths, 1);
  const licenseRow = await env.licenses.rowById(paid.license.licenseId);
  assert.equal(licenseRow.plan, 'monthly');
  const monthMs = 30 * 24 * 60 * 60 * 1000;
  const remaining = Date.parse(licenseRow.expires_at) - Date.now();
  assert.ok(remaining > monthMs * 0.85 && remaining < monthMs * 1.1);
  const payment = await env.db.get(
    "SELECT * FROM transactions WHERE order_id = ? AND kind = 'payment'",
    [order.id],
  );
  assert.equal(payment.amount_cents, 1000);

  const semiannual = await runtime.orders.createCheckout({
    email: person.email,
    name: person.customerName,
    acceptTerms: true,
    plan: 'semiannual',
    ip: '127.0.0.1',
  });
  assert.equal(semiannual.amountCents, 5000);
  order = await runtime.orders.orderByToken(semiannual.token);
  assert.equal(order.plan, 'semiannual');
  assert.equal(order.duration_months, 6);
  const snapshot = await runtime.orders.publicSnapshot(order);
  assert.equal(snapshot.plan, 'semiannual');
  assert.equal(snapshot.planLabel, 'Semestral');
  assert.equal(snapshot.durationMonths, 6);
});

test('renovación con plan: cambia el periodo y extiende desde el vencimiento', async () => {
  const person = customer('Renewal');
  const issued = await issue({
    customerName: person.customerName,
    email: person.email,
    machineCode: randomMachine(),
    plan: 'annual',
  });
  assert.equal(issued.license.plan, 'annual');
  const renewed = await env.licenses.renew(issued.license.id, {
    plan: 'monthly',
    reason: 'Cambio a plan mensual',
    actorType: 'admin',
    actorId: 'test-admin',
    ip: '127.0.0.1',
  });
  assert.equal(renewed.renewed, true);
  assert.equal(renewed.view.plan, 'monthly');
  assert.ok(Date.parse(renewed.expiresAt) > Date.parse(issued.license.expiresAt));
  const auditRow = await env.db.get(
    "SELECT details FROM audit_log WHERE action = 'license.renewed' AND target_id = ? ORDER BY created_at DESC LIMIT 1",
    [issued.license.id],
  );
  assert.equal(JSON.parse(auditRow.details).plan, 'monthly');
  assert.equal(JSON.parse(auditRow.details).months, 1);
  await assert.rejects(
    env.licenses.renew(issued.license.id, { plan: 'weekly', actorType: 'admin', actorId: 'test-admin' }),
    (error) => error.code === 'invalid_plan',
  );
});

test('webhook PayPal: idempotencia, reembolso total y firma obligatoria', async () => {
  const paypal = new FakePayPal();
  const runtime = env.buildRuntime({ paypal, mailer: new FakeMailer() });
  const person = customer('Webhook');
  const checkout = await runtime.orders.createCheckout({
    email: person.email,
    name: person.customerName,
    acceptTerms: true,
    ip: '127.0.0.1',
  });
  let order = await runtime.orders.orderByToken(checkout.token);
  paypal.markApproved(order.paypal_order_id);
  const event = {
    id: `WH-APPROVED-${crypto.randomBytes(4).toString('hex')}`,
    event_type: 'CHECKOUT.ORDER.APPROVED',
    resource: { id: order.paypal_order_id, custom_id: order.id, invoice_id: order.id },
  };
  const outcome = await runtime.orders.processWebhook({
    headers: {},
    rawBody: JSON.stringify(event),
    ip: '127.0.0.1',
  });
  assert.equal(outcome.status, 'processed');
  order = await runtime.orders.orderById(order.id);
  assert.equal(order.status, 'paid');
  const license = await env.licenses.rowById(order.license_id);
  const licenseKey = env.licenses.keyForRow(license);

  const duplicate = await runtime.orders.processWebhook({
    headers: {},
    rawBody: JSON.stringify(event),
    ip: '127.0.0.1',
  });
  assert.equal(duplicate.duplicate, true);

  paypal.webhookError = new PayPalError('Firma inválida', { code: 'invalid_webhook_signature' });
  await assert.rejects(
    runtime.orders.processWebhook({
      headers: {},
      rawBody: JSON.stringify({
        id: `WH-FAKE-${crypto.randomBytes(4).toString('hex')}`,
        event_type: 'CHECKOUT.ORDER.APPROVED',
        resource: { id: order.paypal_order_id },
      }),
      ip: '127.0.0.1',
    }),
    (error) => error.code === 'invalid_webhook_signature',
  );
  paypal.webhookError = null;

  const payment = await env.db.get(
    "SELECT * FROM transactions WHERE order_id = ? AND kind = 'payment'",
    [order.id],
  );
  paypal.setCaptureStatus(payment.provider_id, 'REFUNDED');
  const refundEvent = {
    id: `WH-REFUND-${crypto.randomBytes(4).toString('hex')}`,
    event_type: 'PAYMENT.CAPTURE.REFUNDED',
    resource: {
      id: `REFUND-${crypto.randomBytes(4).toString('hex')}`,
      status: 'COMPLETED',
      amount: { value: '29.00', currency_code: 'USD' },
      supplementary_data: { related_ids: { capture_id: payment.provider_id } },
    },
  };
  const refund = await runtime.orders.processWebhook({
    headers: {},
    rawBody: JSON.stringify(refundEvent),
    ip: '127.0.0.1',
  });
  assert.equal(refund.status, 'processed');
  assert.equal(refund.outcome.fullRefund, true);
  order = await runtime.orders.orderById(order.id);
  assert.equal(order.status, 'refunded');
  const refundedLicense = await env.licenses.rowById(order.license_id);
  assert.equal(refundedLicense.status, 'revoked');
  assert.equal((await env.licenses.validate({ licenseKey })).valid, false);
  const refundTransaction = await env.db.get(
    "SELECT * FROM transactions WHERE order_id = ? AND kind = 'refund'",
    [order.id],
  );
  assert.equal(refundTransaction.status, 'completed');
  assert.equal(refundTransaction.amount_cents, 2900);

  const refundDuplicate = await runtime.orders.processWebhook({
    headers: {},
    rawBody: JSON.stringify(refundEvent),
    ip: '127.0.0.1',
  });
  assert.equal(refundDuplicate.duplicate, true);
  assert.equal(Number((await env.db.get(
    "SELECT COUNT(*) AS n FROM transactions WHERE order_id = ? AND kind = 'refund'",
    [order.id],
  )).n), 1);
});

test('metadatos de PayPal alterados: revisión manual sin licencia', async () => {
  const paypal = new FakePayPal();
  const runtime = env.buildRuntime({ paypal, mailer: new FakeMailer() });
  const person = customer('Alterada');
  const checkout = await runtime.orders.createCheckout({
    email: person.email,
    name: person.customerName,
    acceptTerms: true,
    ip: '127.0.0.1',
  });
  const order = await runtime.orders.orderByToken(checkout.token);
  paypal.markApproved(order.paypal_order_id);
  paypal.orders.get(order.paypal_order_id).amountCents = 100;
  const snapshot = await runtime.orders.reconcileOrder(order, { trigger: 'return' });
  assert.equal(snapshot.status, 'failed');
  assert.match(snapshot.message, /revisión/i);
  const updated = await runtime.orders.orderById(order.id);
  assert.equal(updated.status, 'failed');
  assert.equal(updated.license_id, null);
  assert.match(updated.failure_reason, /importe/i);
  assert.equal(await env.licenses.hasReservation(order.id), false);
  assert.equal(Number((await env.db.get(
    "SELECT COUNT(*) AS n FROM transactions WHERE order_id = ? AND kind = 'payment'",
    [order.id],
  )).n), 0);
});

test('cancelación local sin emitir licencia', async () => {
  const paypal = new FakePayPal();
  const runtime = env.buildRuntime({ paypal, mailer: new FakeMailer() });
  const person = customer('Cancelada');
  const checkout = await runtime.orders.createCheckout({
    email: person.email,
    name: person.customerName,
    acceptTerms: true,
    ip: '127.0.0.1',
  });
  const snapshot = await runtime.orders.handleCancel({ token: checkout.token, ip: '127.0.0.1' });
  assert.equal(snapshot.status, 'cancelled');
  assert.equal(snapshot.license, null);
  const order = await runtime.orders.orderByToken(checkout.token);
  assert.equal(order.status, 'cancelled');
  assert.equal(order.license_id, null);
  assert.equal(await env.licenses.hasReservation(order.id), false);
});

test('HTTP: salud, tienda, archivos estáticos y cabeceras de seguridad', async () => {
  const server = await ensureHttpServer();

  const health = await request(server.baseUrl, 'GET', '/api/health');
  assert.equal(health.status, 200);
  assert.equal(health.body.ok, true);
  assert.equal(health.body.service, 'perfillab-license-server');
  assert.equal(health.headers['x-content-type-options'], 'nosniff');
  assert.equal(health.headers['x-frame-options'], 'DENY');
  assert.equal(health.headers['cache-control'], 'no-store');
  assert.equal(health.headers['x-robots-tag'], 'noindex, nofollow');

  const store = await request(server.baseUrl, 'GET', '/api/store');
  assert.equal(store.status, 200);
  assert.equal(store.body.productName, 'PerfilLab');
  assert.equal(store.body.checkoutEnabled, true);
  assert.deepEqual(store.body.price, { amountCents: 2900, currency: 'USD' });
  assert.equal(store.body.supportEmail, 'soporte@example.com');
  assert.equal(store.body.plans.length, 3);
  const storePlans = Object.fromEntries(store.body.plans.map((plan) => [plan.code, plan]));
  assert.equal(storePlans.monthly.amountCents, 1000);
  assert.equal(storePlans.monthly.label, 'Mensual');
  assert.equal(storePlans.monthly.months, 1);
  assert.equal(storePlans.semiannual.amountCents, 5000);
  assert.equal(storePlans.semiannual.label, 'Semestral');
  assert.equal(storePlans.semiannual.months, 6);
  assert.equal(storePlans.annual.amountCents, 2900);
  assert.equal(storePlans.annual.label, 'Anual');
  assert.equal(storePlans.annual.months, 12);

  const home = await request(server.baseUrl, 'GET', '/', { accept: 'text/html' });
  assert.equal(home.status, 200);
  assert.match(home.headers['content-type'], /text\/html/);
  assert.match(home.headers['content-security-policy'], /script-src 'self'/);
  assert.match(home.headers['content-security-policy'], /frame-ancestors 'none'/);
  assert.match(home.text, /PerfilLab/);

  const orderPage = await request(server.baseUrl, 'GET', '/pago/retorno?t=ABCDEFGHIJKLMNOPQRSTUVWX', {
    accept: 'text/html',
  });
  assert.equal(orderPage.status, 200);
  assert.equal(orderPage.headers['x-robots-tag'], 'noindex, nofollow');
  assert.match(orderPage.text, /order\.js/);

  const missing = await request(server.baseUrl, 'GET', '/no-existe', { accept: 'text/html' });
  assert.equal(missing.status, 404);

  const missingApi = await request(server.baseUrl, 'GET', '/api/no-existe');
  assert.equal(missingApi.status, 404);
  assert.equal(missingApi.body.error.code, 'not_found');

  const notAllowed = await request(server.baseUrl, 'PUT', '/api/health');
  assert.equal(notAllowed.status, 405);
  assert.equal(notAllowed.headers.allow, 'GET, HEAD, POST');
});

test('HTTP: administración con sesión, emisión, detalle, CSV, revocación y auditoría', async () => {
  const server = await ensureHttpServer();

  const anonymous = await request(server.baseUrl, 'GET', '/api/admin/session');
  assert.equal(anonymous.status, 401);
  assert.equal(anonymous.body.error.code, 'invalid_session');

  const wrong = await request(server.baseUrl, 'POST', '/api/admin/login', {
    body: { username: 'admin', password: 'contraseña-incorrecta' },
  });
  assert.equal(wrong.status, 401);
  assert.equal(wrong.body.error.code, 'invalid_credentials');

  const login = await request(server.baseUrl, 'POST', '/api/admin/login', {
    body: { username: env.admin.username, password: env.admin.password },
  });
  assert.equal(login.status, 200);
  assert.ok(login.body.token);
  assert.equal(login.body.user.username, env.admin.username);
  const token = login.body.token;

  const session = await request(server.baseUrl, 'GET', '/api/admin/session', { token });
  assert.equal(session.status, 200);
  assert.equal(session.body.user.username, env.admin.username);

  const overview = await request(server.baseUrl, 'GET', '/api/admin/overview', { token });
  assert.equal(overview.status, 200);
  assert.equal(overview.body.summary.capacity, 50000);
  assert.equal(overview.body.server.keyId, env.keystore.keyId);

  const machine = randomMachine();
  const issued = await request(server.baseUrl, 'POST', '/api/admin/licenses', {
    token,
    body: {
      customerName: 'Cliente HTTP',
      email: 'cliente.http@example.com',
      machineCode: machine,
      notes: 'Alta desde la prueba HTTP',
    },
  });
  assert.equal(issued.status, 200);
  const licenseKey = issued.body.licenseKey;
  const licenseId = issued.body.license.id;
  assert.match(licenseKey, LICENSE_KEY_RE);
  assert.equal(issued.body.license.status, 'active');
  assert.equal(issued.body.license.machineCode, machine);

  const list = await request(server.baseUrl, 'GET', '/api/admin/licenses?query=Cliente%20HTTP', { token });
  assert.equal(list.status, 200);
  assert.ok(list.body.items.some((item) => item.id === licenseId));
  assert.ok(!JSON.stringify(list.body).includes(licenseKey));

  const detail = await request(server.baseUrl, 'GET', `/api/admin/licenses/${licenseId}`, { token });
  assert.equal(detail.status, 200);
  assert.equal(detail.body.licenseKey, licenseKey);
  assert.ok(detail.body.envelope && detail.body.envelope.signature);

  const csv = await request(server.baseUrl, 'GET', '/api/admin/licenses.csv?query=Cliente%20HTTP', {
    token,
    accept: 'text/csv',
  });
  assert.equal(csv.status, 200);
  assert.match(csv.headers['content-type'], /text\/csv/);
  assert.match(csv.headers['content-disposition'], /attachment/);
  assert.ok(csv.text.includes('ID licencia'));
  assert.ok(csv.text.includes('Cliente HTTP'));
  assert.ok(!csv.text.includes(licenseKey));

  const revoked = await request(server.baseUrl, 'POST', `/api/admin/licenses/${licenseId}/revoke`, {
    token,
    body: { reason: 'Prueba HTTP' },
  });
  assert.equal(revoked.status, 200);
  assert.equal(revoked.body.view.status, 'revoked');

  const revocations = await request(server.baseUrl, 'GET', '/api/license/revocations');
  assert.equal(revocations.status, 200);
  assert.ok(revocations.headers.etag);
  assert.equal(revocations.body.keyId, env.keystore.keyId);
  assert.ok(revocations.body.revoked.some((item) => item.licenseId === licenseId));
  assert.equal(verifyRevocationList(revocations.body, env.keystore.publicKey).keyId, env.keystore.keyId);

  const notModified = await request(server.baseUrl, 'GET', '/api/license/revocations', {
    headers: { 'If-None-Match': revocations.headers.etag },
  });
  assert.equal(notModified.status, 304);
  assert.equal(notModified.text, '');

  const adminRevocations = await request(server.baseUrl, 'GET', '/api/admin/revocations', { token });
  assert.equal(adminRevocations.status, 200);
  assert.match(adminRevocations.headers['content-disposition'], /attachment/);
  assert.ok(adminRevocations.text.includes(licenseId));

  const auditList = await request(server.baseUrl, 'GET', '/api/admin/audit?pageSize=200', { token });
  assert.equal(auditList.status, 200);
  const actions = auditList.body.items.map((item) => item.action);
  assert.ok(actions.includes('license.revealed'));
  assert.ok(actions.includes('licenses.exported'));
  assert.ok(actions.includes('license.revoked'));

  const logout = await request(server.baseUrl, 'POST', '/api/admin/logout', { token, body: {} });
  assert.equal(logout.status, 200);
  const afterLogout = await request(server.baseUrl, 'GET', '/api/admin/session', { token });
  assert.equal(afterLogout.status, 401);
});

test('HTTP: activación pública, checkout con PayPal falso, webhook, orden pagada y cancelación', async () => {
  const server = await ensureHttpServer();
  const activationMachine = randomMachine();
  const issued = await issue({ customerName: 'Cliente Activación HTTP', email: 'activacion.http@example.com' });

  const activation = await request(server.baseUrl, 'POST', '/api/license/activate', {
    body: { licenseKey: issued.licenseKey, machineCode: activationMachine },
  });
  assert.equal(activation.status, 200);
  assert.ok(activation.body.license && activation.body.license.signature);
  assert.equal(activation.body.info.status, 'active');
  assert.equal(activation.body.info.machineCode, activationMachine);

  const validation = await request(server.baseUrl, 'POST', '/api/license/validate', {
    body: { licenseKey: issued.licenseKey, machineCode: activationMachine },
  });
  assert.equal(validation.status, 200);
  assert.equal(validation.body.valid, true);
  assert.equal(validation.body.status, 'active');

  const otherMachine = await request(server.baseUrl, 'POST', '/api/license/validate', {
    body: { licenseKey: issued.licenseKey, machineCode: randomMachine() },
  });
  assert.equal(otherMachine.status, 200);
  assert.equal(otherMachine.body.valid, false);
  assert.equal(otherMachine.body.status, 'other_machine');

  const checkout = await request(server.baseUrl, 'POST', '/api/checkout', {
    body: { email: 'pagador.http@example.com', name: 'Pagador HTTP', acceptTerms: true },
  });
  assert.equal(checkout.status, 200);
  const orderToken = checkout.body.token;
  assert.match(orderToken, /^[A-Za-z0-9_-]{20,200}$/);
  assert.match(checkout.body.approvalUrl, /^https:\/\/www\.sandbox\.paypal\.com\//);
  assert.equal(checkout.body.amountCents, 2900);
  assert.equal(checkout.body.currency, 'USD');

  const orderRow = await httpRuntime.orders.orderByToken(orderToken);
  assert.equal(orderRow.status, 'pending');
  const pending = await request(server.baseUrl, 'GET', `/api/orders/${orderToken}`);
  assert.equal(pending.status, 200);
  assert.equal(pending.body.status, 'pending');
  assert.equal(pending.body.license, null);

  httpPayPal.markApproved(orderRow.paypal_order_id);
  const webhookEvent = {
    id: `WH-HTTP-${crypto.randomBytes(6).toString('hex')}`,
    event_type: 'CHECKOUT.ORDER.APPROVED',
    resource: { id: orderRow.paypal_order_id },
  };
  httpPayPal.webhookError = new PayPalError('Firma no válida.', { retryable: false });
  try {
    const forged = await request(server.baseUrl, 'POST', '/api/paypal/webhook', {
      body: { ...webhookEvent, id: `WH-FORGED-${crypto.randomBytes(4).toString('hex')}` },
    });
    assert.equal(forged.status, 400);
    assert.equal(forged.body.error.code, 'invalid_webhook');
  } finally {
    httpPayPal.webhookError = null;
  }

  const webhook = await request(server.baseUrl, 'POST', '/api/paypal/webhook', { body: webhookEvent });
  assert.equal(webhook.status, 200);
  assert.equal(webhook.body.received, true);
  assert.equal(webhook.body.status, 'processed');
  assert.equal(webhook.body.outcome.status, 'paid');

  const duplicate = await request(server.baseUrl, 'POST', '/api/paypal/webhook', { body: webhookEvent });
  assert.equal(duplicate.status, 200);
  assert.equal(duplicate.body.duplicate, true);

  const paid = await request(server.baseUrl, 'GET', `/api/orders/${orderToken}`);
  assert.equal(paid.status, 200);
  assert.equal(paid.body.status, 'paid');
  assert.match(paid.body.license.licenseKey, LICENSE_KEY_RE);
  assert.equal(paid.body.license.status, 'pending');
  assert.match(paid.body.emailMasked, /^pa\*+@example\.com$/);

  const login = await request(server.baseUrl, 'POST', '/api/admin/login', {
    body: { username: env.admin.username, password: env.admin.password },
  });
  assert.equal(login.status, 200);
  const adminToken = login.body.token;

  const orders = await request(server.baseUrl, 'GET', `/api/admin/orders?query=${encodeURIComponent(orderRow.id)}`, {
    token: adminToken,
  });
  assert.equal(orders.status, 200);
  assert.ok(orders.body.items.some((item) => item.id === orderRow.id));

  const orderDetail = await request(server.baseUrl, 'GET', `/api/admin/orders/${orderRow.id}`, { token: adminToken });
  assert.equal(orderDetail.status, 200);
  assert.equal(orderDetail.body.status, 'paid');
  assert.ok(orderDetail.body.license && orderDetail.body.license.keyMasked);
  assert.equal(orderDetail.body.transactions.length, 1);
  assert.equal(orderDetail.body.transactions[0].kind, 'payment');

  const synced = await request(server.baseUrl, 'POST', `/api/admin/orders/${orderRow.id}/sync`, {
    token: adminToken,
    body: {},
  });
  assert.equal(synced.status, 200);
  assert.equal(synced.body.status, 'paid');

  const transactions = await request(server.baseUrl, 'GET', '/api/admin/transactions', { token: adminToken });
  assert.equal(transactions.status, 200);
  assert.ok(transactions.body.items.some((item) => item.orderId === orderRow.id && item.kind === 'payment'));

  const cancelCheckout = await request(server.baseUrl, 'POST', '/api/checkout', {
    body: { email: 'cancelar.http@example.com', name: 'Cancelar HTTP', acceptTerms: true },
  });
  assert.equal(cancelCheckout.status, 200);
  const cancelled = await request(server.baseUrl, 'POST', `/api/orders/${cancelCheckout.body.token}/cancel`, {
    body: {},
  });
  assert.equal(cancelled.status, 200);
  assert.equal(cancelled.body.status, 'cancelled');
  assert.equal(cancelled.body.license, null);
  const cancelledRow = await httpRuntime.orders.orderByToken(cancelCheckout.body.token);
  assert.equal(cancelledRow.license_id, null);

  const unsupported = await request(server.baseUrl, 'POST', '/api/checkout', {
    body: { email: 'pagador.http@example.com' },
    contentType: 'text/plain',
  });
  assert.equal(unsupported.status, 415);
  assert.equal(unsupported.body.error.code, 'unsupported_media_type');

  const unknownOrder = await request(server.baseUrl, 'GET', `/api/orders/${'A'.repeat(24)}`);
  assert.equal(unknownOrder.status, 404);
  assert.equal(unknownOrder.body.error.code, 'order_not_found');
});
