'use strict';

const crypto = require('node:crypto');
const { once } = require('node:events');
const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');

const { createLocalRuntime, createLocalApp } = require('../src/local-server');
const { verifyLicense, verifyRevocationList } = require('../src/license-format');
const { hashPassword, nowIso } = require('../src/security');
const { TEST_ADMIN, createTestEnvironment } = require('./helpers/env');
const { request } = require('./helpers/http');

const OPERATOR = { username: 'operador', password: 'operador-test-password-456' };
let env = null;
let runtime = null;
let server = null;
let baseUrl = '';

before(async () => {
  env = await createTestEnvironment();
  const operatorId = crypto.randomUUID();
  const createdAt = nowIso();
  await env.db.run(
    `INSERT INTO admin_users(id, username, password_hash, role, disabled, created_at, password_changed_at)
     VALUES (?, ?, ?, 'operator', 0, ?, ?)`,
    [operatorId, OPERATOR.username, hashPassword(OPERATOR.password), createdAt, createdAt],
  );
  runtime = createLocalRuntime({
    config: env.config,
    db: env.db,
    keystore: env.keystore,
    logger: env.logger,
  });
  const app = createLocalApp({ config: env.config, runtime, logger: env.logger });
  server = app.listen(0, '127.0.0.1');
  await once(server, 'listening');
  const { port } = server.address();
  baseUrl = `http://127.0.0.1:${port}`;
});

after(async () => {
  if (server) {
    server.closeAllConnections();
    await new Promise((resolve) => server.close(resolve));
  }
  if (env) await env.close();
});

function machine() {
  const alphabet = '0123456789ABCDEFGHJKMNPQRSTVWXYZ';
  let out = '';
  while (out.length < 16) out += alphabet[crypto.randomBytes(1)[0] % 32];
  return out.match(/.{4}/g).join('-');
}

async function url() {
  return baseUrl;
}

async function login(username = TEST_ADMIN.username, password = TEST_ADMIN.password) {
  const response = await request(await url(), 'POST', '/v1/auth/login', {
    body: { username, password },
  });
  assert.equal(response.status, 200);
  return response.body.token;
}

function secretKeys(value, found = []) {
  if (!value || typeof value !== 'object') return found;
  for (const [key, item] of Object.entries(value)) {
    found.push(key);
    if (item && typeof item === 'object') secretKeys(item, found);
  }
  return found;
}

test('health público, rechazo de Origin y errores uniformes', async () => {
  const base = await url();
  const health = await request(base, 'GET', '/v1/health');
  assert.equal(health.status, 200);
  assert.equal(health.body.ok, true);
  assert.equal(health.body.service, 'perfillab-license-server-local');
  assert.ok(health.body.time);

  const origin = await request(base, 'GET', '/v1/health', {
    headers: { Origin: 'http://malicioso.example' },
  });
  assert.equal(origin.status, 403);
  assert.equal(origin.body.error.code, 'origin_not_allowed');

  const missing = await request(base, 'GET', '/v1/no-existe');
  assert.equal(missing.status, 404);
  assert.equal(missing.body.error.code, 'not_found');
  assert.equal(missing.body.error.details, null);

  const malformed = await fetch(`${base}/v1/auth/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: '{',
  });
  assert.equal(malformed.status, 400);
  assert.equal((await malformed.json()).error.code, 'invalid_json');

  const noAuth = await request(base, 'GET', '/v1/admin/overview');
  assert.equal(noAuth.status, 401);
  assert.equal(noAuth.body.error.code, 'invalid_session');
});

test('login, sesión, perfiles y cierre de sesión', async () => {
  const base = await url();
  const bad = await request(base, 'POST', '/v1/auth/login', {
    body: { username: TEST_ADMIN.username, password: 'incorrecta' },
  });
  assert.equal(bad.status, 401);
  assert.equal(bad.body.error.code, 'invalid_credentials');

  const session = await request(base, 'POST', '/v1/auth/login', {
    body: { username: TEST_ADMIN.username, password: TEST_ADMIN.password },
  });
  assert.equal(session.status, 200);
  assert.ok(session.body.token.length >= 40);
  assert.equal(session.body.user.username, TEST_ADMIN.username);
  assert.equal(session.body.user.role, 'admin');
  const token = session.body.token;

  const me = await request(base, 'GET', '/v1/auth/me', { token });
  assert.equal(me.status, 200);
  assert.equal(me.body.user.username, TEST_ADMIN.username);

  const profiles = await request(base, 'GET', '/v1/profiles', { token });
  assert.equal(profiles.status, 200);
  assert.equal(profiles.body.profiles[0].months, 12);
  assert.equal(profiles.body.profiles[0].seatLimit, 50000);

  const closed = await request(base, 'POST', '/v1/auth/logout', { token, body: {} });
  assert.equal(closed.status, 200);
  assert.equal(closed.body.ok, true);
  const expired = await request(base, 'GET', '/v1/auth/me', { token });
  assert.equal(expired.status, 401);
});

test('los operadores pueden leer pero no modificar licencias', async () => {
  const base = await url();
  const token = await login(OPERATOR.username, OPERATOR.password);
  const overview = await request(base, 'GET', '/v1/admin/overview', { token });
  assert.equal(overview.status, 200);
  assert.equal(overview.body.server.paymentsEnabled, false);
  assert.equal(overview.body.server.environment, 'local');
  assert.equal(overview.body.summary.capacity, 50000);

  const list = await request(base, 'GET', '/v1/admin/licenses', { token });
  assert.equal(list.status, 200);

  const issue = await request(base, 'POST', '/v1/admin/licenses', {
    token,
    body: { customerName: 'Sin permiso' },
  });
  assert.equal(issue.status, 403);
  assert.equal(issue.body.error.code, 'role_forbidden');

  const renew = await request(base, 'POST', '/v1/admin/licenses/PL-0001/renew', { token, body: {} });
  assert.equal(renew.status, 403);
  assert.equal(renew.body.error.code, 'role_forbidden');
});

test('crear, listar y consultar licencias con validación de parámetros', async () => {
  const base = await url();
  const token = await login();
  const person = {
    customerName: 'Cliente Local',
    email: `local.${Date.now()}@example.com`,
    notes: 'Alta desde el servidor local.',
    transactionId: `LOCAL-${Date.now()}`,
  };
  const issued = await request(base, 'POST', '/v1/admin/licenses', { token, body: person });
  assert.equal(issued.status, 201);
  assert.match(issued.body.license.id, /^PL-\d{5}/);
  assert.equal(issued.body.license.status, 'pending');
  assert.equal(issued.body.license.email, person.email);
  assert.ok(issued.body.licenseKey.length >= 16);
  assert.equal(issued.body.envelope, null);

  const list = await request(
    base,
    'GET',
    `/v1/admin/licenses?query=${encodeURIComponent(person.email)}&status=pending`,
    { token },
  );
  assert.equal(list.status, 200);
  assert.equal(list.body.total, 1);
  assert.equal(list.body.items[0].id, issued.body.license.id);
  assert.notEqual(list.body.items[0].keyMasked, issued.body.licenseKey);

  const detail = await request(base, 'GET', `/v1/admin/licenses/${issued.body.license.id}`, { token });
  assert.equal(detail.status, 200);
  assert.equal(detail.body.licenseKey, issued.body.licenseKey);
  assert.equal(detail.body.license.notes, person.notes);

  const noName = await request(base, 'POST', '/v1/admin/licenses', { token, body: { email: 'x@example.com' } });
  assert.equal(noName.status, 400);
  assert.equal(noName.body.error.code, 'customer_required');

  const badEmail = await request(base, 'POST', '/v1/admin/licenses', {
    token,
    body: { customerName: 'Correo malo', email: 'no-es-correo' },
  });
  assert.equal(badEmail.status, 400);
  assert.equal(badEmail.body.error.code, 'invalid_email');

  const duplicateTransaction = await request(base, 'POST', '/v1/admin/licenses', {
    token,
    body: { customerName: 'Transacción repetida', transactionId: person.transactionId },
  });
  assert.equal(duplicateTransaction.status, 409);
  assert.equal(duplicateTransaction.body.error.code, 'transaction_already_used');

  const badId = await request(base, 'POST', '/v1/admin/licenses/!mal/revoke', {
    token,
    body: { reason: 'prueba' },
  });
  assert.equal(badId.status, 400);
  assert.equal(badId.body.error.code, 'invalid_id');

  const emptyBatch = await request(base, 'POST', '/v1/admin/licenses/batch', {
    token,
    body: { items: [] },
  });
  assert.equal(emptyBatch.status, 400);
  assert.equal(emptyBatch.body.error.code, 'batch_empty');

  const batch = await request(base, 'POST', '/v1/admin/licenses/batch', {
    token,
    body: {
      items: [
        { customerName: 'Lote Uno' },
        { customerName: 'Lote Dos', email: `lote.${Date.now()}@example.com` },
      ],
    },
  });
  assert.equal(batch.status, 200);
  assert.equal(batch.body.issued, 2);
  assert.equal(batch.body.failed, 0);

  globalThis.localLicense = {
    token,
    id: issued.body.license.id,
    key: issued.body.licenseKey,
  };
});

test('activación firmada, validación, renovación, suspensión y revocación', async () => {
  const base = await url();
  const { token, id, key } = globalThis.localLicense;
  const equipment = machine();

  const activated = await request(base, 'POST', '/v1/license/activate', {
    body: { licenseKey: key, machineCode: equipment, machineName: 'PC local' },
  });
  assert.equal(activated.status, 200);
  assert.ok(activated.body.license);
  const verified = verifyLicense(activated.body.license, env.keystore.publicKey);
  assert.equal(verified.payload.licenseId, id);
  assert.equal(verified.payload.machineCode, equipment);
  assert.equal(activated.body.info.status, 'active');

  const valid = await request(base, 'POST', '/v1/license/validate', {
    body: { licenseKey: key, machineCode: equipment },
  });
  assert.equal(valid.status, 200);
  assert.equal(valid.body.valid, true);
  assert.equal(valid.body.status, 'active');

  const otherMachine = await request(base, 'POST', '/api/license/validate', {
    body: { licenseKey: key, machineCode: machine() },
  });
  assert.equal(otherMachine.status, 200);
  assert.equal(otherMachine.body.valid, false);
  assert.equal(otherMachine.body.status, 'other_machine');

  const duplicate = await request(base, 'POST', '/v1/admin/licenses', {
    token,
    body: { customerName: 'Equipo duplicado', machineCode: equipment },
  });
  assert.equal(duplicate.status, 409);
  assert.equal(duplicate.body.error.code, 'machine_in_use');

  const detailBefore = await request(base, 'GET', `/v1/admin/licenses/${id}`, { token });
  const renewed = await request(base, 'POST', `/v1/admin/licenses/${id}/renew`, { token, body: {} });
  assert.equal(renewed.status, 200);
  assert.equal(renewed.body.renewed, true);
  assert.ok(Date.parse(renewed.body.expiresAt) > Date.parse(detailBefore.body.license.expiresAt));
  assert.equal(renewed.body.view.status, 'active');

  const noReason = await request(base, 'POST', `/v1/admin/licenses/${id}/suspend`, { token, body: {} });
  assert.equal(noReason.status, 400);
  assert.equal(noReason.body.error.code, 'reason_required');

  const suspended = await request(base, 'POST', `/v1/admin/licenses/${id}/suspend`, {
    token,
    body: { reason: 'Revisión de pago' },
  });
  assert.equal(suspended.status, 200);
  assert.equal(suspended.body.view.status, 'suspended');
  const suspendedValidation = await request(base, 'POST', '/api/license/validate', {
    body: { licenseKey: key, machineCode: equipment },
  });
  assert.equal(suspendedValidation.body.valid, false);
  assert.equal(suspendedValidation.body.status, 'suspended');

  const reactivated = await request(base, 'POST', `/v1/admin/licenses/${id}/reactivate`, {
    token,
    body: {},
  });
  assert.equal(reactivated.status, 200);
  assert.equal(reactivated.body.view.status, 'active');

  const renewedSuspended = await request(base, 'POST', `/v1/admin/licenses/${id}/suspend`, {
    token,
    body: { reason: 'Bloqueo antes de renovar' },
  });
  assert.equal(renewedSuspended.status, 200);
  const blockedRenew = await request(base, 'POST', `/v1/admin/licenses/${id}/renew`, { token, body: {} });
  assert.equal(blockedRenew.status, 409);
  assert.equal(blockedRenew.body.error.code, 'license_suspended');
  await request(base, 'POST', `/v1/admin/licenses/${id}/reactivate`, { token, body: {} });

  const revoked = await request(base, 'POST', `/v1/admin/licenses/${id}/revoke`, {
    token,
    body: { reason: 'Solicitud del cliente' },
  });
  assert.equal(revoked.status, 200);
  assert.equal(revoked.body.view.status, 'revoked');
  assert.ok(revoked.body.view.revokedAt);

  const revokedValidation = await request(base, 'POST', '/v1/license/validate', {
    body: { licenseKey: key, machineCode: equipment },
  });
  assert.equal(revokedValidation.body.valid, false);
  assert.equal(revokedValidation.body.status, 'revoked');

  const revokedActivation = await request(base, 'POST', '/v1/license/activate', {
    body: { licenseKey: key, machineCode: equipment },
  });
  assert.equal(revokedActivation.status, 403);
  assert.equal(revokedActivation.body.error.code, 'license_revoked');

  const revokedRenew = await request(base, 'POST', `/v1/admin/licenses/${id}/renew`, { token, body: {} });
  assert.equal(revokedRenew.status, 409);
  assert.equal(revokedRenew.body.error.code, 'license_revoked_permanent');

  globalThis.localLicense.equipment = equipment;
});

test('renovación de una licencia vencida y lista firmada de revocaciones', async () => {
  const base = await url();
  const { token } = globalThis.localLicense;
  const issued = await request(base, 'POST', '/v1/admin/licenses', {
    token,
    body: { customerName: 'Licencia Vencida' },
  });
  assert.equal(issued.status, 201);
  const id = issued.body.license.id;
  const key = issued.body.licenseKey;

  await env.db.run('UPDATE licenses SET expires_at = ?, status = ?, updated_at = ? WHERE id = ?', [
    new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString(),
    'expired',
    nowIso(),
    id,
  ]);

  const expired = await request(base, 'POST', '/v1/license/validate', {
    body: { licenseKey: key },
  });
  assert.equal(expired.status, 200);
  assert.equal(expired.body.valid, false);
  assert.equal(expired.body.status, 'expired');

  const renewed = await request(base, 'POST', `/v1/admin/licenses/${id}/renew`, { token, body: {} });
  assert.equal(renewed.status, 200);
  assert.ok(Date.parse(renewed.body.expiresAt) > Date.now());
  assert.equal(renewed.body.view.status, 'pending');

  const equipment = machine();
  const activated = await request(base, 'POST', '/v1/license/activate', {
    body: { licenseKey: key, machineCode: equipment },
  });
  assert.equal(activated.status, 200);
  assert.equal(activated.body.info.status, 'active');

  const revocations = await request(base, 'GET', '/v1/license/revocations');
  assert.equal(revocations.status, 200);
  const signed = JSON.parse(revocations.body ? JSON.stringify(revocations.body) : revocations.text);
  assert.equal(verifyRevocationList(signed, env.keystore.publicKey).keyId, env.keystore.keyId);
  assert.ok(signed.revoked.some((entry) => entry.licenseId === globalThis.localLicense.id));

  const cached = await request(base, 'GET', '/v1/license/revocations', {
    headers: { 'If-None-Match': revocations.headers.etag },
  });
  assert.equal(cached.status, 304);
  assert.equal(cached.text, '');

  const adminRevocations = await request(base, 'GET', '/v1/admin/revocations', { token });
  assert.equal(adminRevocations.status, 200);
  assert.match(adminRevocations.headers['content-disposition'], /perfillab-revocaciones/);
  assert.equal(
    verifyRevocationList(JSON.parse(adminRevocations.text), env.keystore.publicKey).keyId,
    env.keystore.keyId,
  );
});

test('exportación CSV, auditoría sin secretos y consultas de pagos desactivados', async () => {
  const base = await url();
  const { token, id } = globalThis.localLicense;

  const csv = await request(base, 'GET', '/v1/admin/licenses.csv', {
    token,
    accept: 'text/csv',
  });
  assert.equal(csv.status, 200);
  assert.match(csv.headers['content-type'], /text\/csv/);
  assert.match(csv.headers['content-disposition'], /perfillab-licencias/);
  assert.match(csv.text, /ID licencia/);
  assert.match(csv.text, new RegExp(id));

  const audit = await request(base, 'GET', '/v1/admin/audit?pageSize=200', { token });
  assert.equal(audit.status, 200);
  const actions = new Set(audit.body.items.map((item) => item.action));
  for (const action of ['admin.login', 'license.issued', 'license.renewed', 'license.revoked', 'licenses.exported']) {
    assert.ok(actions.has(action), `Falta la acción ${action} en auditoría`);
  }
  const serialized = JSON.stringify(audit.body.items);
  assert.equal(serialized.includes(TEST_ADMIN.password), false);
  assert.equal(serialized.includes(OPERATOR.password), false);
  assert.equal(serialized.includes(globalThis.localLicense.key), false);
  const privatePem = env.keystore.privateKey.export({ type: 'pkcs8', format: 'pem' });
  assert.equal(serialized.includes(privatePem.trim().slice(32, 96)), false);
  for (const key of secretKeys(audit.body.items)) {
    assert.equal(/pass|secret|token|private.?key|license.?key|key_enc|key_hash/i.test(key), false, key);
  }

  const orders = await request(base, 'GET', '/v1/admin/orders', { token });
  assert.equal(orders.status, 200);
  assert.equal(orders.body.total, 0);
  assert.deepEqual(orders.body.items, []);

  const transactions = await request(base, 'GET', '/v1/admin/transactions', { token });
  assert.equal(transactions.status, 200);
  assert.equal(transactions.body.total, 0);

  const orderDetail = await request(base, 'GET', '/v1/admin/orders/ORDER-NOEXISTE', { token });
  assert.equal(orderDetail.status, 404);
  assert.equal(orderDetail.body.error.code, 'order_not_found');

  const sync = await request(base, 'POST', '/v1/admin/orders/ORDER-NOEXISTE/sync', {
    token,
    body: {},
  });
  assert.equal(sync.status, 409);
  assert.equal(sync.body.error.code, 'payments_disabled');
});

test('activación y validación rechazan claves inexistentes o incompletas', async () => {
  const base = await url();
  const missing = await request(base, 'POST', '/v1/license/activate', {
    body: { licenseKey: 'AAAA-BBBB-CCCC-DDDD' },
  });
  assert.equal(missing.status, 400);
  assert.equal(missing.body.error.code, 'missing_field');

  const unknown = await request(base, 'POST', '/v1/license/validate', {
    body: { licenseKey: 'AAAA-BBBB-CCCC-DDDD', machineCode: machine() },
  });
  assert.equal(unknown.status, 404);
  assert.equal(unknown.body.error.code, 'license_not_found');
});
