'use strict';

const crypto = require('node:crypto');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { test, after } = require('node:test');
const assert = require('node:assert/strict');

const { ConfigError, loadConfig, parsePublicBaseUrl } = require('../src/config');
const { loadLocalConfig } = require('../src/local-config');
const {
  KeystoreError,
  createKeystoreFile,
  decodeKeystoreBase64,
  loadKeystore,
  openKeystoreFromBase64,
} = require('../src/keystore');

const tempDir = fs.mkdtempSync(path.join(os.tmpdir(), 'perfillab-config-'));

after(() => {
  fs.rmSync(tempDir, { recursive: true, force: true });
});

function productionEnv(overrides = {}) {
  return {
    NODE_ENV: 'production',
    PERFILLAB_DATA_DIR: tempDir,
    PERFILLAB_PUBLIC_BASE_URL: 'https://licencias.example.com',
    ...overrides,
  };
}

test('config: producción exige PostgreSQL salvo permiso explícito de SQLite', () => {
  assert.throws(
    () => loadConfig(productionEnv()),
    (error) => error instanceof ConfigError && /PERFILLAB_DATABASE_URL/.test(error.message),
  );

  const sqlite = loadConfig(productionEnv({ PERFILLAB_ALLOW_SQLITE: 'true' }));
  assert.equal(sqlite.databaseDialect, 'sqlite');
  assert.equal(sqlite.allowSqlite, true);

  const pg = loadConfig(productionEnv({
    PERFILLAB_DATABASE_URL: 'postgres://perfillab:secret@db.example.com:5432/perfillab?sslmode=require',
    PERFILLAB_DATABASE_SSL: 'require',
    PERFILLAB_DATABASE_SCHEMA: 'perfillab',
    PERFILLAB_DATABASE_POOL_MAX: '7',
  }));
  assert.equal(pg.databaseDialect, 'postgres');
  assert.equal(pg.databaseSsl, 'require');
  assert.equal(pg.databaseSchema, 'perfillab');
  assert.equal(pg.databasePoolMax, 7);

  const defaults = loadConfig(productionEnv({
    PERFILLAB_DATABASE_URL: 'postgres://perfillab:secret@db.example.com/perfillab',
  }));
  assert.equal(defaults.databaseSchema, 'public');
  assert.equal(defaults.databasePoolMax, 10);

  assert.throws(
    () => loadConfig(productionEnv({
      PERFILLAB_ALLOW_SQLITE: 'true',
      PERFILLAB_DATABASE_URL: 'mysql://db.example.com/perfillab',
    })),
    /postgres/,
  );
  assert.throws(
    () => loadConfig(productionEnv({ PERFILLAB_ALLOW_SQLITE: 'true', PERFILLAB_DATABASE_SCHEMA: 'pg_catalog' })),
    /esquema/,
  );
  assert.throws(
    () => loadConfig(productionEnv({ PERFILLAB_ALLOW_SQLITE: 'true', PERFILLAB_DATABASE_SSL: 'yes' })),
    /SSL/,
  );
  assert.throws(
    () => loadConfig(productionEnv({
      PERFILLAB_DATABASE_URL: 'postgres://perfillab:secret@db.example.com/perfillab',
      PERFILLAB_DATABASE_SSL: 'verify-full',
      PERFILLAB_DATABASE_SSL_CA: 'no-es-un-certificado',
    })),
    /PEM/,
  );
});

test('config: HTTP solo se acepta en loopback y los endpoints remotos exigen HTTPS', () => {
  assert.equal(parsePublicBaseUrl('http://127.0.0.1:45900').origin, 'http://127.0.0.1:45900');
  assert.equal(parsePublicBaseUrl('http://localhost:45900').origin, 'http://localhost:45900');
  assert.equal(parsePublicBaseUrl('http://[::1]:45900').origin, 'http://[::1]:45900');
  assert.equal(
    parsePublicBaseUrl('https://licencias.example.com').url,
    'https://licencias.example.com',
  );
  assert.throws(
    () => parsePublicBaseUrl('http://licencias.example.com'),
    (error) => error instanceof ConfigError && /HTTPS/.test(error.message),
  );
  assert.throws(
    () => parsePublicBaseUrl('http://192.168.1.10:45900'),
    (error) => error instanceof ConfigError && /HTTPS/.test(error.message),
  );
});

test('config: el servidor local ignora PostgreSQL y conserva SQLite en loopback', () => {
  const config = loadLocalConfig({
    PERFILLAB_DATABASE_URL: 'postgres://perfillab:secret@db.example.com/perfillab',
    PERFILLAB_ALLOW_SQLITE: 'false',
    PERFILLAB_HOST: '0.0.0.0',
    PERFILLAB_PORT: '45900',
    PERFILLAB_TRUST_PROXY: 'true',
    PERFILLAB_DATA_DIR: tempDir,
  });
  assert.equal(config.databaseDialect, 'sqlite');
  assert.equal(config.host, '127.0.0.1');
  assert.equal(config.port, 45900);
  assert.equal(config.trustProxy, false);
  assert.equal(config.localMode, true);
  assert.equal(config.paymentsEnabled, false);
});

test('keystore: se carga desde PERFILLAB_KEYSTORE_BASE64 sin archivo local', () => {
  const passphrase = 'perfillab-test-keystore-passphrase';
  const pair = crypto.generateKeyPairSync('ed25519');
  const privateKey = pair.privateKey.export({ format: 'der', type: 'pkcs8' }).toString('base64');
  const publicKey = pair.publicKey.export({ format: 'der', type: 'spki' }).toString('base64');
  const file = createKeystoreFile({
    privateKey,
    publicKey,
    dataKey: crypto.randomBytes(32),
    passphrase,
  });
  const encoded = Buffer.from(JSON.stringify(file), 'utf8').toString('base64');

  const loaded = loadKeystore(
    { keystoreBase64: encoded, keystorePath: path.join(tempDir, 'no-existe.json') },
    passphrase,
  );
  assert.equal(loaded.source, 'env');
  assert.equal(loaded.keystore.keyId, file.keyId);
  assert.equal(loaded.keystore.publicKey, publicKey);

  assert.throws(
    () => openKeystoreFromBase64(encoded, 'otra-frase-de-paso-larga'),
    (error) => error instanceof KeystoreError && /frase/.test(error.message),
  );
  assert.throws(() => decodeKeystoreBase64('%%%'), /base64/);

  const config = loadConfig({
    NODE_ENV: 'test',
    PERFILLAB_DATA_DIR: tempDir,
    PERFILLAB_KEYSTORE_BASE64: encoded,
  });
  assert.equal(config.keystoreBase64, encoded);
});
