'use strict';

const crypto = require('node:crypto');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { test, after } = require('node:test');
const assert = require('node:assert/strict');

const { ConfigError } = require('../src/config');
const { InstallerService } = require('../src/installer');
const { createRuntime } = require('../src/server');
const { FakeMailer, TEST_LOGGER, createTestEnvironment, makeConfig } = require('./helpers/env');
const { request, startTestServer } = require('./helpers/http');

const tempDir = fs.mkdtempSync(path.join(os.tmpdir(), 'perfillab-installer-'));
const installerPath = path.join(tempDir, 'PerfilLab-Setup-1.2.3.exe');
const payload = Buffer.from('MZ PerfilLab installer payload for download tests', 'utf8');
fs.writeFileSync(installerPath, payload);
const sha256 = crypto.createHash('sha256').update(payload).digest('hex');

after(() => {
  fs.rmSync(tempDir, { recursive: true, force: true });
});

function serviceFor(overrides) {
  const config = makeConfig(tempDir, overrides);
  return new InstallerService({ config, logger: TEST_LOGGER });
}

test('config: valida el origen y los metadatos del instalador', () => {
  assert.throws(
    () => serviceFor({
      PERFILLAB_INSTALLER_URL: 'https://downloads.example.com/PerfilLab-Setup.exe',
      PERFILLAB_INSTALLER_PATH: installerPath,
    }),
    (error) => error instanceof ConfigError,
  );
  assert.throws(
    () => serviceFor({ PERFILLAB_INSTALLER_URL: 'http://downloads.example.com/PerfilLab-Setup.exe' }),
    /HTTPS/,
  );
  assert.throws(
    () => serviceFor({ PERFILLAB_INSTALLER_URL: 'https://user:secret@downloads.example.com/PerfilLab-Setup.exe' }),
    /credenciales/,
  );
  assert.throws(
    () => serviceFor({ PERFILLAB_INSTALLER_PATH: installerPath, PERFILLAB_INSTALLER_SHA256: 'xyz' }),
    /SHA.?256/,
  );
  assert.throws(
    () => serviceFor({ PERFILLAB_INSTALLER_PATH: installerPath, PERFILLAB_INSTALLER_SIZE: '0' }),
    /bytes/,
  );
});

test('InstallerService: sin configurar no se publica ninguna descarga', async () => {
  const info = await serviceFor({}).describe();
  assert.equal(info.enabled, false);
  assert.equal(info.url, null);
});

test('InstallerService: describe el archivo con checksum y tamaño reales', async () => {
  const info = await serviceFor({
    PERFILLAB_INSTALLER_PATH: installerPath,
    PERFILLAB_INSTALLER_VERSION: '1.2.3',
    PERFILLAB_INSTALLER_SHA256: sha256,
    PERFILLAB_INSTALLER_SIZE: String(payload.length),
    PERFILLAB_INSTALLER_FILENAME: 'PerfilLab-Setup.exe',
  }).describe();
  assert.deepEqual(info, {
    enabled: true,
    url: '/descargar',
    source: 'file',
    filename: 'PerfilLab-Setup.exe',
    version: '1.2.3',
    sha256,
    sizeBytes: payload.length,
  });
});

test('InstallerService: rechaza checksums y tamaños declarados incorrectos', async () => {
  const wrongChecksum = serviceFor({
    PERFILLAB_INSTALLER_PATH: installerPath,
    PERFILLAB_INSTALLER_SHA256: 'a'.repeat(64),
  });
  await assert.rejects(
    () => wrongChecksum.describe(),
    (error) => error.code === 'installer_checksum_mismatch',
  );

  const wrongSize = serviceFor({
    PERFILLAB_INSTALLER_PATH: installerPath,
    PERFILLAB_INSTALLER_SIZE: String(payload.length + 1),
  });
  await assert.rejects(
    () => wrongSize.describe(),
    (error) => error.code === 'installer_size_mismatch',
  );

  const missing = serviceFor({
    PERFILLAB_INSTALLER_PATH: path.join(tempDir, 'no-existe.exe'),
  });
  await assert.rejects(
    () => missing.describe(),
    (error) => error.code === 'installer_missing',
  );
});

test('InstallerService: la fuente URL redirige sin descargar desde el servidor', async () => {
  const service = serviceFor({
    PERFILLAB_INSTALLER_URL: 'https://downloads.example.com/releases/PerfilLab-Setup.exe',
    PERFILLAB_INSTALLER_VERSION: '1.2.3',
  });
  const info = await service.describe();
  assert.equal(info.enabled, true);
  assert.equal(info.source, 'url');
  assert.equal(info.url, '/descargar');
  assert.equal(info.filename, 'PerfilLab-Setup.exe');

  const headers = {};
  const res = {
    statusCode: 200,
    setHeader(name, value) { headers[name.toLowerCase()] = value; },
    end() { this.ended = true; },
  };
  await service.send({ method: 'GET' }, res);
  assert.equal(res.statusCode, 302);
  assert.equal(headers.location, 'https://downloads.example.com/releases/PerfilLab-Setup.exe');
  assert.equal(res.ended, true);
});

test('HTTP: la tienda publica la descarga y /descargar entrega el archivo', async () => {
  const env = await createTestEnvironment({
    env: {
      PERFILLAB_INSTALLER_PATH: installerPath,
      PERFILLAB_INSTALLER_VERSION: '1.2.3',
      PERFILLAB_INSTALLER_SHA256: sha256,
      PERFILLAB_INSTALLER_SIZE: String(payload.length),
      PERFILLAB_INSTALLER_FILENAME: 'PerfilLab-Setup.exe',
    },
  });
  const runtime = createRuntime({
    config: env.config,
    db: env.db,
    keystore: env.keystore,
    logger: env.logger,
    mailer: new FakeMailer(),
  });
  const server = await startTestServer({
    config: env.config,
    db: env.db,
    keystore: env.keystore,
    logger: env.logger,
    runtime,
  });
  try {
    const store = await request(server.baseUrl, 'GET', '/api/store');
    assert.equal(store.status, 200);
    assert.deepEqual(store.body.download, {
      url: '/descargar',
      filename: 'PerfilLab-Setup.exe',
      version: '1.2.3',
      sha256,
      sizeBytes: payload.length,
    });

    const download = await request(server.baseUrl, 'GET', '/descargar');
    assert.equal(download.status, 200);
    assert.equal(download.headers['content-type'], 'application/octet-stream');
    assert.equal(download.headers['content-length'], String(payload.length));
    assert.match(download.headers['content-disposition'], /^attachment; filename="PerfilLab-Setup\.exe"$/);
    assert.equal(download.headers['cache-control'], 'no-store');
    assert.equal(download.headers['x-robots-tag'], 'noindex, nofollow');
    assert.equal(download.headers.etag, `"${sha256}"`);
    assert.equal(download.headers.digest, `sha-256=${Buffer.from(sha256, 'hex').toString('base64')}`);
    assert.deepEqual(download.buffer, payload);

    const head = await request(server.baseUrl, 'HEAD', '/descargar');
    assert.equal(head.status, 200);
    assert.equal(head.headers['content-length'], String(payload.length));
    assert.equal(head.buffer.length, 0);

    const login = await request(server.baseUrl, 'POST', '/api/admin/login', {
      body: { username: env.admin.username, password: env.admin.password },
    });
    assert.equal(login.status, 200);
    const overview = await request(server.baseUrl, 'GET', '/api/admin/overview', {
      token: login.body.token,
    });
    assert.equal(overview.status, 200);
    assert.deepEqual(overview.body.server.installer, {
      enabled: true,
      filename: 'PerfilLab-Setup.exe',
      version: '1.2.3',
      sha256,
      sizeBytes: payload.length,
    });
  } finally {
    await server.close();
    await env.close();
  }
});

test('HTTP: sin instalador la tienda lo indica y /descargar responde 404', async () => {
  const env = await createTestEnvironment();
  const runtime = createRuntime({
    config: env.config,
    db: env.db,
    keystore: env.keystore,
    logger: env.logger,
    mailer: new FakeMailer(),
  });
  const server = await startTestServer({
    config: env.config,
    db: env.db,
    keystore: env.keystore,
    logger: env.logger,
    runtime,
  });
  try {
    const store = await request(server.baseUrl, 'GET', '/api/store');
    assert.equal(store.status, 200);
    assert.equal(store.body.download, null);

    const download = await request(server.baseUrl, 'GET', '/descargar');
    assert.equal(download.status, 404);
    assert.equal(download.body.error.code, 'installer_unavailable');
  } finally {
    await server.close();
    await env.close();
  }
});
