#!/usr/bin/env node
'use strict';

const fs = require('node:fs');

const { loadLocalConfig } = require('../src/local-config');
const { createLogger } = require('../src/logger');
const { openDatabase, redactConnectionString } = require('../src/database');
const { loadKeystore } = require('../src/keystore');
const { requirePassphrase } = require('../src/passphrase');
const { assertServerInitialized } = require('../src/seats');
const { createLocalRuntime, createLocalApp } = require('../src/local-server');

async function main() {
  const logger = createLogger();
  const config = loadLocalConfig(process.env);
  const databaseExists = config.databaseDialect === 'sqlite' ? fs.existsSync(config.dbPath) : true;
  const keystoreExists = Boolean(config.keystoreBase64) || fs.existsSync(config.keystorePath);
  if (!databaseExists || !keystoreExists) {
    logger.error('La base local o el keystore no existen. Ejecuta primero npm run init.', {
      database: config.databaseDialect === 'sqlite' ? config.dbPath : 'postgres',
      keystore: config.keystoreBase64 ? 'env' : config.keystorePath,
    });
    process.exit(1);
  }
  const passphrase = await requirePassphrase({
    env: process.env,
    envVar: 'PERFILLAB_KEYSTORE_PASSPHRASE',
    fileVar: 'PERFILLAB_KEYSTORE_PASSPHRASE_FILE',
    label: 'Frase de paso del keystore',
    minLength: 12,
  });
  let keystore;
  let keystoreSource;
  try {
    ({ keystore, source: keystoreSource } = loadKeystore(config, passphrase));
  } catch (error) {
    logger.error('No se pudo abrir el keystore', { message: error.message });
    process.exit(1);
  }
  let db;
  try {
    db = await openDatabase(config);
  } catch (error) {
    logger.error('No se pudo abrir la base de datos', {
      database: config.databaseDialect,
      message: error.message,
    });
    process.exit(1);
  }
  try {
    await assertServerInitialized(db);
    if (await db.getSetting('key_id', '') !== keystore.keyId) {
      throw new Error('El keystore no corresponde a la base de datos de licencias.');
    }
    if (await db.count('admin_users') === 0) {
      throw new Error('No hay administradores. Ejecuta npm run admin -- create --username <usuario>.');
    }
  } catch (error) {
    await db.close();
    logger.error('No se pudo preparar el servidor local', { message: error.message });
    process.exit(1);
  }

  const runtime = createLocalRuntime({ config, db, keystore, logger });
  const app = createLocalApp({ config, runtime, logger });
  const server = app.listen(config.port, config.host);
  server.headersTimeout = 10_000;
  server.requestTimeout = 30_000;
  server.keepAliveTimeout = 5_000;
  server.maxHeadersCount = 100;

  server.once('error', async (error) => {
    logger.error('No se pudo iniciar el servidor local', {
      code: error.code || 'listen_failed',
      listen: `${config.host}:${config.port}`,
      hint: error.code === 'EADDRINUSE'
        ? 'El puerto ya está ocupado por otro proceso; elige otro con PERFILLAB_LOCAL_PORT.'
        : undefined,
    });
    await db.close();
    process.exit(1);
  });
  server.once('listening', () => {
    logger.info('Servidor local de licencias iniciado', {
      listen: `http://${config.host}:${config.port}/v1`,
      keyId: keystore.keyId,
      keystoreSource,
      database: config.databaseDialect === 'sqlite' ? config.dbPath : redactConnectionString(config.databaseUrl),
    });
  });

  let stopping = false;
  const shutdown = (signal) => {
    if (stopping) return;
    stopping = true;
    logger.info('Deteniendo servidor local', { signal });
    server.close(async () => {
      try {
        await db.close();
      } catch {
        // Cierre best-effort.
      }
      process.exit(0);
    });
    setTimeout(() => process.exit(0), 5000).unref();
  };
  process.on('SIGINT', () => shutdown('SIGINT'));
  process.on('SIGTERM', () => shutdown('SIGTERM'));
}

main().catch((error) => {
  console.error(error.message || error);
  process.exit(1);
});
