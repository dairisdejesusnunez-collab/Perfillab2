#!/usr/bin/env node
'use strict';

const fs = require('node:fs');
const path = require('node:path');
const { DatabaseSync } = require('node:sqlite');

const { loadConfig } = require('../src/config');
const { openDatabase, redactConnectionString, SCHEMA_VERSION } = require('../src/database');
const { assertServerInitialized } = require('../src/seats');

const TABLES = [
  'settings',
  'admin_users',
  'customers',
  'seats',
  'licenses',
  'orders',
  'transactions',
  'webhook_events',
  'email_outbox',
  'audit_log',
];

const REQUIRED_SOURCE_TABLES = [...TABLES, 'schema_migrations'];

function parseArgs(argv) {
  const args = { source: '' };
  for (let index = 0; index < argv.length; index += 1) {
    const item = argv[index];
    if (item === '--source') args.source = argv[++index] || '';
    else if (item === '--help' || item === '-h') args.help = true;
    else throw new Error(`Argumento no reconocido: ${item}`);
  }
  return args;
}

function printHelp() {
  console.log(`Uso: node --env-file=<entorno> scripts/clone-to-postgres.js [--source <perfillab.sqlite>]

Crea la base completa en PostgreSQL desde la base SQLite local:
esquema, 50.000 asientos, ajustes, administradores y datos existentes.

Variables necesarias:
  PERFILLAB_DATABASE_URL   URL de PostgreSQL/Supabase (Session pooler).
  PERFILLAB_DATABASE_SSL   require para Supabase.
  PERFILLAB_DATABASE_SCHEMA public (por defecto).

La base de destino debe estar vacía. El keystore desplegado debe ser el mismo
que usa la base de origen; el script muestra el keyId que debes conservar.
No copia sesiones administrativas efímeras.`);
}

function quoteIdent(value) {
  return `"${String(value).replace(/"/g, '""')}"`;
}

function sourceTables(db) {
  return new Set(
    db.prepare("SELECT name FROM sqlite_master WHERE type = 'table' AND name NOT LIKE 'sqlite_%'")
      .all()
      .map((row) => row.name),
  );
}

function sourceColumns(db, table) {
  return db.prepare(`PRAGMA table_info(${quoteIdent(table)})`).all().map((row) => row.name);
}

function sourceCount(db, table) {
  return Number(db.prepare(`SELECT COUNT(*) AS n FROM ${quoteIdent(table)}`).get().n);
}

function normalizeValue(value) {
  if (value === undefined) return null;
  if (typeof value === 'bigint') {
    return value <= BigInt(Number.MAX_SAFE_INTEGER) && value >= BigInt(Number.MIN_SAFE_INTEGER)
      ? Number(value)
      : value.toString();
  }
  return value;
}

async function targetColumns(db, schema, table) {
  const rows = await db.all(
    `SELECT column_name FROM information_schema.columns
     WHERE table_schema = ? AND table_name = ?`,
    [schema, table],
  );
  return new Set(rows.map((row) => row.column_name));
}

async function targetCount(db, table) {
  const row = await db.get(`SELECT COUNT(*) AS n FROM ${quoteIdent(table)}`);
  return Number(row ? row.n : 0);
}

async function main() {
  const args = parseArgs(process.argv.slice(2));
  if (args.help) return printHelp();

  const config = loadConfig(process.env);
  if (config.databaseDialect !== 'postgres') {
    throw new Error('Define PERFILLAB_DATABASE_URL con la conexión PostgreSQL o Supabase.');
  }
  const sourcePath = path.resolve(args.source || config.dbPath);
  if (!fs.existsSync(sourcePath)) throw new Error(`No existe la base de origen: ${sourcePath}`);

  const source = new DatabaseSync(sourcePath, { readOnly: true });
  try {
    const tables = sourceTables(source);
    const missing = REQUIRED_SOURCE_TABLES.filter((table) => !tables.has(table));
    if (missing.length) throw new Error(`La base de origen no contiene: ${missing.join(', ')}.`);

    const sourceVersion = Number(
      source.prepare('SELECT COALESCE(MAX(version), 0) AS version FROM schema_migrations').get().version,
    );
    if (sourceVersion !== SCHEMA_VERSION) {
      throw new Error(`La base de origen está en la versión ${sourceVersion}; se esperaba ${SCHEMA_VERSION}.`);
    }
    const sourceSeats = sourceCount(source, 'seats');
    if (sourceSeats !== 50000) {
      throw new Error(`La base de origen tiene ${sourceSeats} asientos; se esperaban 50.000.`);
    }
    const sourceKeyId = source.prepare("SELECT value FROM settings WHERE key = 'key_id'").get();
    const sourcePublicKey = source.prepare("SELECT value FROM settings WHERE key = 'public_key'").get();
    if (!sourceKeyId || !sourcePublicKey) {
      throw new Error('La base de origen no tiene key_id/public_key; inicialízala antes de clonarla.');
    }

    console.log(`Origen: ${sourcePath}`);
    console.log(`Destino: ${redactConnectionString(config.databaseUrl)} (esquema ${config.databaseSchema})`);

    const db = await openDatabase(config);
    try {
      for (const table of TABLES) {
        const count = await targetCount(db, table);
        if (count > 0) {
          throw new Error(
            `La base de destino ya tiene datos en ${table} (${count}). Usa una base vacía; no se modificó nada.`,
          );
        }
      }

      const plan = [];
      for (const table of TABLES) {
        const columns = sourceColumns(source, table);
        const available = await targetColumns(db, config.databaseSchema, table);
        const unsupported = columns.filter((column) => !available.has(column));
        if (unsupported.length) {
          throw new Error(`La tabla destino ${table} no tiene las columnas: ${unsupported.join(', ')}.`);
        }
        const rows = source.prepare(
          `SELECT ${columns.map(quoteIdent).join(', ')} FROM ${quoteIdent(table)}`,
        ).all().map((row) => columns.map((column) => normalizeValue(row[column])));
        plan.push({ table, columns, rows, count: rows.length });
      }

      console.log('Copiando datos en una sola transacción...');
      await db.transaction(async () => {
        for (const item of plan) {
          if (!item.rows.length) continue;
          await db.insertMany(item.table, item.columns, item.rows, { chunkSize: 1000 });
        }
      });

      for (const item of plan) {
        const target = await targetCount(db, item.table);
        if (target !== item.count) {
          throw new Error(`La tabla ${item.table} quedó con ${target} filas; se esperaban ${item.count}.`);
        }
        console.log(`${item.table}: ${target}`);
      }

      const summary = await assertServerInitialized(db);
      const targetKeyId = await db.getSetting('key_id', '');
      const targetPublicKey = await db.getSetting('public_key', '');
      if (targetKeyId !== sourceKeyId.value || targetPublicKey !== sourcePublicKey.value) {
        throw new Error('La clave registrada en el destino no coincide con la de origen.');
      }

      const rlsTables = [...TABLES, 'admin_sessions', 'schema_migrations'];
      const rls = await db.get(
        `SELECT COUNT(*) FILTER (WHERE c.relrowsecurity) AS enabled, COUNT(*) AS total
         FROM pg_class c
         JOIN pg_namespace n ON n.oid = c.relnamespace
         WHERE n.nspname = ? AND c.relkind = 'r'
           AND c.relname IN (${rlsTables.map((table) => `'${table}'`).join(', ')})`,
        [config.databaseSchema],
      );

      console.log('Base completa creada y verificada.');
      console.log(JSON.stringify({
        seats: summary.seats,
        keyId: summary.keyId,
        adminUsers: await targetCount(db, 'admin_users'),
        licenses: await targetCount(db, 'licenses'),
        database: db.dialect,
        schema: config.databaseSchema,
      }, null, 2));
      if (Number(rls.enabled) > 0) {
        console.log(`RLS: ${Number(rls.enabled)}/${Number(rls.total)} tablas protegidas`);
      }
      console.log('Usa exactamente el mismo keystore y frase de paso en el servidor desplegado.');
      console.log('Si no conservas el administrador local, crea uno nuevo con scripts/admin.js.');
    } finally {
      await db.close();
    }
  } finally {
    source.close();
  }
}

main().catch((error) => {
  console.error(error.message || error);
  process.exit(1);
});
