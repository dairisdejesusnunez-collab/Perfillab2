#!/usr/bin/env node
'use strict';

const crypto = require('node:crypto');
const fs = require('node:fs');
const path = require('node:path');

const { loadConfig } = require('../src/config');
const { readKeystoreFile } = require('../src/keystore');

function parseArgs(argv) {
  const options = { out: '', stdout: false };
  for (let index = 0; index < argv.length; index += 1) {
    const item = argv[index];
    if (item === '--out') options.out = argv[++index] || '';
    else if (item === '--stdout') options.stdout = true;
    else if (item === '--help' || item === '-h') options.help = true;
    else throw new Error(`Argumento no reconocido: ${item}`);
  }
  return options;
}

function printHelp() {
  console.log(`Uso: npm run keystore:env -- [--out <ruta>] [--stdout]

Convierte el keystore cifrado en un valor base64 para PERFILLAB_KEYSTORE_BASE64.
Por omisión escribe data/keystore.base64 con permisos restringidos.
--stdout imprime el valor para pegarlo directamente en el panel del hospedaje.

No incluye la frase de paso: configúrala por separado en
PERFILLAB_KEYSTORE_PASSPHRASE o PERFILLAB_KEYSTORE_PASSPHRASE_FILE.`);
}

function main() {
  const options = parseArgs(process.argv.slice(2));
  if (options.help) return printHelp();
  const config = loadConfig(process.env);
  if (config.keystoreBase64) {
    throw new Error('PERFILLAB_KEYSTORE_BASE64 ya está definido; no hay un archivo que exportar.');
  }
  if (!fs.existsSync(config.keystorePath)) throw new Error('No existe el keystore del servidor.');
  readKeystoreFile(config.keystorePath);
  const encoded = fs.readFileSync(config.keystorePath).toString('base64');
  if (options.stdout) {
    process.stdout.write(`${encoded}\n`);
    return;
  }
  const target = path.resolve(options.out || path.join(config.dataDir, 'keystore.base64'));
  fs.mkdirSync(path.dirname(target), { recursive: true });
  fs.writeFileSync(target, `${encoded}\n`, { encoding: 'utf8', mode: 0o600 });
  if (process.platform !== 'win32') {
    try {
      fs.chmodSync(target, 0o600);
    } catch {
      // Permisos best-effort.
    }
  }
  const digest = crypto.createHash('sha256').update(encoded).digest('hex');
  console.log(`Keystore exportado en ${target}`);
  console.log(`Tamaño base64: ${encoded.length} caracteres · SHA-256: ${digest}`);
  console.log('Copia el contenido en PERFILLAB_KEYSTORE_BASE64 del servicio y no lo confirmes en el repositorio.');
}

try {
  main();
} catch (error) {
  console.error(error.message || error);
  process.exit(1);
}
