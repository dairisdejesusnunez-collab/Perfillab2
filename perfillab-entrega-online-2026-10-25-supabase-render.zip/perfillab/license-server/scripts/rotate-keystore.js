#!/usr/bin/env node
'use strict';

const fs = require('node:fs');
const path = require('node:path');

const { loadConfig } = require('../src/config');
const {
  openKeystore,
  openKeystoreFromBase64,
  openKeystoreObject,
  createKeystoreFile,
  writeKeystoreAtomic,
} = require('../src/keystore');
const { requirePassphrase, requireConfirmedPassphrase, secretFromEnvironment } = require('../src/passphrase');

function timestamp() {
  return new Date().toISOString().replace(/[:.]/g, '-');
}

function parseArgs(argv) {
  const options = { backup: true, out: '' };
  for (let index = 0; index < argv.length; index += 1) {
    const item = argv[index];
    if (item === '--no-backup') options.backup = false;
    else if (item === '--out') options.out = argv[++index] || '';
    else if (item === '--help' || item === '-h') options.help = true;
    else throw new Error(`Argumento no reconocido: ${item}`);
  }
  return options;
}

function printHelp() {
  console.log(`Uso: npm run rotate-keystore -- [--no-backup] [--out <ruta>]

Detén el servidor antes de ejecutar este comando.

Variables:
  PERFILLAB_KEYSTORE_PASSPHRASE o PERFILLAB_KEYSTORE_PASSPHRASE_FILE
  PERFILLAB_NEW_KEYSTORE_PASSPHRASE o PERFILLAB_NEW_KEYSTORE_PASSPHRASE_FILE

Modo archivo (PERFILLAB_KEYSTORE_PATH): reescribe el keystore y, salvo
--no-backup, guarda una copia cifrada con la frase anterior en la misma carpeta.

Modo entorno (PERFILLAB_KEYSTORE_BASE64): no puede modificar la variable del
servicio. Escribe el nuevo keystore en --out (por omisión, data/keystore-*.base64)
y muestra la ruta. Actualiza después la variable con ese contenido.

La clave privada y la clave de datos se conservan; solo cambia el cifrado.`);
}

function writePrivate(filePath, content) {
  fs.mkdirSync(path.dirname(filePath), { recursive: true });
  fs.writeFileSync(filePath, content, { encoding: 'utf8', mode: 0o600 });
  if (process.platform !== 'win32') {
    try {
      fs.chmodSync(filePath, 0o600);
    } catch {
      // Permisos best-effort.
    }
  }
}

async function main() {
  const options = parseArgs(process.argv.slice(2));
  if (options.help) return printHelp();
  const config = loadConfig(process.env);
  const envMode = Boolean(config.keystoreBase64);
  if (!envMode && !fs.existsSync(config.keystorePath)) throw new Error('No existe el keystore del servidor.');
  console.log(`Keystore: ${envMode ? 'PERFILLAB_KEYSTORE_BASE64' : config.keystorePath}`);

  const currentPassphrase = await requirePassphrase({
    env: process.env,
    envVar: 'PERFILLAB_KEYSTORE_PASSPHRASE',
    fileVar: 'PERFILLAB_KEYSTORE_PASSPHRASE_FILE',
    label: 'Frase de paso actual del keystore',
    minLength: 12,
  });
  const nextPassphrase = secretFromEnvironment(
    process.env,
    'PERFILLAB_NEW_KEYSTORE_PASSPHRASE',
    'PERFILLAB_NEW_KEYSTORE_PASSPHRASE_FILE',
  ) || await requireConfirmedPassphrase({
    env: process.env,
    envVar: 'PERFILLAB_NEW_KEYSTORE_PASSPHRASE',
    fileVar: 'PERFILLAB_NEW_KEYSTORE_PASSPHRASE_FILE',
    label: 'Nueva frase de paso del keystore',
    minLength: 12,
  });
  if (nextPassphrase.length < 12) throw new Error('La nueva frase de paso debe tener al menos 12 caracteres.');
  if (nextPassphrase === currentPassphrase) throw new Error('La nueva frase de paso debe ser distinta de la actual.');

  const current = envMode
    ? openKeystoreFromBase64(config.keystoreBase64, currentPassphrase)
    : openKeystore(config.keystorePath, currentPassphrase);
  const nextFile = createKeystoreFile({
    privateKey: current.privateKeyB64,
    publicKey: current.publicKey,
    dataKey: current.dataKey,
    passphrase: nextPassphrase,
    createdAt: current.createdAt,
  });

  if (envMode) {
    const outPath = path.resolve(options.out || path.join(config.dataDir, `keystore-${timestamp()}.base64`));
    const nextEncoded = Buffer.from(`${JSON.stringify(nextFile)}\n`, 'utf8').toString('base64');
    writePrivate(outPath, `${nextEncoded}\n`);
    const reopened = openKeystoreObject(nextFile, nextPassphrase);
    if (reopened.keyId !== current.keyId || !reopened.dataKey.equals(current.dataKey)) {
      fs.unlinkSync(outPath);
      throw new Error('La verificación posterior a la rotación falló. No se modificó ninguna variable.');
    }
    let oldStillWorks = true;
    try {
      openKeystoreObject(nextFile, currentPassphrase);
    } catch {
      oldStillWorks = false;
    }
    if (oldStillWorks) {
      fs.unlinkSync(outPath);
      throw new Error('La frase anterior todavía abre el keystore nuevo. Revisa la rotación.');
    }
    if (options.backup) {
      const backupPath = path.join(config.dataDir, `keystore-backup-${timestamp()}.base64`);
      writePrivate(backupPath, `${String(config.keystoreBase64).replace(/\s+/g, '')}\n`);
      console.log(`Copia anterior: ${backupPath} (sigue cifrada con la frase anterior).`);
    }
    console.log(`Rotación completada. keyId: ${current.keyId}`);
    console.log(`Nuevo keystore: ${outPath}`);
    console.log('Copia su contenido en PERFILLAB_KEYSTORE_BASE64 y actualiza la frase de paso del servicio.');
    console.log('La clave privada y la clave de datos no cambiaron; las licencias emitidas siguen siendo válidas.');
    return;
  }

  let backupPath = null;
  if (options.backup) {
    backupPath = path.join(path.dirname(config.keystorePath), `keystore-backup-${timestamp()}.json`);
    fs.copyFileSync(config.keystorePath, backupPath);
    if (process.platform !== 'win32') fs.chmodSync(backupPath, 0o600);
  }

  writeKeystoreAtomic(config.keystorePath, nextFile);
  const reopened = openKeystore(config.keystorePath, nextPassphrase);
  if (reopened.keyId !== current.keyId || !reopened.dataKey.equals(current.dataKey)) {
    throw new Error('La verificación posterior a la rotación falló. Restaura el keystore anterior.');
  }
  let oldStillWorks = true;
  try {
    openKeystore(config.keystorePath, currentPassphrase);
  } catch {
    oldStillWorks = false;
  }
  if (oldStillWorks) throw new Error('La frase de paso anterior todavía abre el keystore. Restaura la copia y revisa el archivo.');

  console.log(`Rotación completada. keyId: ${current.keyId}`);
  console.log('La clave privada y la clave de datos no cambiaron; las licencias emitidas siguen siendo válidas.');
  if (backupPath) {
    console.log(`Copia anterior: ${backupPath}`);
    console.log('Esa copia usa la frase anterior: bórrala cuando hayas verificado el arranque del servidor.');
  }
  console.log('Actualiza la variable o el archivo de frase de paso del servicio y arranca el servidor.');
}

main().catch((error) => {
  console.error(error.message || error);
  process.exit(1);
});
