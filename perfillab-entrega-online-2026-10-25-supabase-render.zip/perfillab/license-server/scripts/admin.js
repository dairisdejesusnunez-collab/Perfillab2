#!/usr/bin/env node
'use strict';

const crypto = require('node:crypto');

const { loadConfig } = require('../src/config');
const { openDatabase } = require('../src/database');
const { assertServerInitialized } = require('../src/seats');
const { hashPassword, nowIso } = require('../src/security');
const { requirePassphrase, requireConfirmedPassphrase, secretFromEnvironment } = require('../src/passphrase');

function parseArgs(argv) {
  const [command = '', ...rest] = argv;
  const options = { command };
  if (command === '--help' || command === '-h') {
    options.command = '';
    options.help = true;
  }
  for (let index = 0; index < rest.length; index += 1) {
    const item = rest[index];
    if (item === '--username') options.username = rest[++index] || '';
    else if (item === '--help' || item === '-h') options.help = true;
    else throw new Error(`Argumento no reconocido: ${item}`);
  }
  return options;
}

function printHelp() {
  console.log(`Uso: npm run admin -- <comando> [--username <usuario>]

Comandos:
  create           Crea un usuario administrador.
  reset-password   Cambia la contraseña y revoca sus sesiones.
  list             Lista los administradores.
  disable          Desactiva un administrador y revoca sus sesiones.
  enable           Reactiva un administrador.

La contraseña se lee de PERFILLAB_ADMIN_PASSWORD, PERFILLAB_ADMIN_PASSWORD_FILE
o se solicita de forma oculta. Nunca se pasa por argumentos de línea de comandos.
La base de datos se elige con PERFILLAB_DATABASE_URL o PERFILLAB_DB_PATH.`);
}

function validateUsername(value) {
  const username = String(value || '').trim();
  if (!/^[A-Za-z0-9._-]{3,64}$/.test(username)) {
    throw new Error('El usuario debe tener entre 3 y 64 caracteres (letras, números, punto, guion o guion bajo).');
  }
  return username;
}

async function passwordForCreate() {
  const fromEnv = secretFromEnvironment(process.env, 'PERFILLAB_ADMIN_PASSWORD', 'PERFILLAB_ADMIN_PASSWORD_FILE');
  if (fromEnv) {
    if (fromEnv.length < 12) throw new Error('La contraseña debe tener al menos 12 caracteres.');
    return fromEnv;
  }
  return requireConfirmedPassphrase({
    label: 'Contraseña del administrador',
    minLength: 12,
  });
}

async function passwordForReset() {
  return requirePassphrase({
    env: process.env,
    envVar: 'PERFILLAB_ADMIN_PASSWORD',
    fileVar: 'PERFILLAB_ADMIN_PASSWORD_FILE',
    label: 'Nueva contraseña del administrador',
    minLength: 12,
  });
}

function mustUser(options) {
  const username = validateUsername(options.username || process.env.PERFILLAB_ADMIN_USER);
  if (!username) throw new Error('Indica --username o PERFILLAB_ADMIN_USER.');
  return username;
}

async function main() {
  const options = parseArgs(process.argv.slice(2));
  if (options.help) {
    printHelp();
    return;
  }
  if (!options.command) {
    printHelp();
    process.exitCode = 1;
    return;
  }
  const config = loadConfig(process.env);
  const db = await openDatabase(config);
  try {
    await assertServerInitialized(db);
    const now = nowIso();
    if (options.command === 'list') {
      const rows = await db.all(
        `SELECT username, role, disabled, created_at, last_login_at FROM admin_users ORDER BY username`,
      );
      if (!rows.length) console.log('No hay administradores.');
      for (const row of rows) {
        console.log(`${row.username}\t${row.role}\t${row.disabled ? 'desactivado' : 'activo'}\tcreado ${row.created_at}\túltimo acceso ${row.last_login_at || '—'}`);
      }
      return;
    }
    if (options.command === 'create') {
      const username = mustUser(options);
      if (await db.get('SELECT 1 AS found FROM admin_users WHERE lower(username) = lower(?)', [username])) {
        throw new Error('Ese administrador ya existe.');
      }
      const password = await passwordForCreate();
      const passwordHash = hashPassword(password);
      await db.transaction(async () => {
        const id = crypto.randomUUID();
        await db.run(
          `INSERT INTO admin_users(id, username, password_hash, role, disabled, created_at, password_changed_at)
           VALUES (?, ?, ?, 'admin', 0, ?, ?)`,
          [id, username, passwordHash, now, now],
        );
        await db.run(
          `INSERT INTO audit_log(id, actor_type, actor_id, action, target_type, target_id, details, ip, created_at)
           VALUES (?, 'system', NULL, 'admin.created', 'admin_user', ?, ?, NULL, ?)`,
          [crypto.randomUUID(), id, JSON.stringify({ username }), now],
        );
      });
      console.log(`Administrador creado: ${username}`);
      return;
    }
    if (options.command === 'reset-password') {
      const username = mustUser(options);
      const row = await db.get('SELECT id FROM admin_users WHERE lower(username) = lower(?)', [username]);
      if (!row) throw new Error('Ese administrador no existe.');
      const password = await passwordForReset();
      const passwordHash = hashPassword(password);
      await db.transaction(async () => {
        await db.run('UPDATE admin_users SET password_hash = ?, password_changed_at = ?, disabled = 0 WHERE id = ?', [passwordHash, now, row.id]);
        await db.run('DELETE FROM admin_sessions WHERE user_id = ?', [row.id]);
        await db.run(
          `INSERT INTO audit_log(id, actor_type, actor_id, action, target_type, target_id, details, ip, created_at)
           VALUES (?, 'system', NULL, 'admin.password_reset', 'admin_user', ?, NULL, NULL, ?)`,
          [crypto.randomUUID(), row.id, now],
        );
      });
      console.log('Contraseña actualizada y sesiones revocadas.');
      return;
    }
    if (options.command === 'disable' || options.command === 'enable') {
      const username = mustUser(options);
      const row = await db.get('SELECT id FROM admin_users WHERE lower(username) = lower(?)', [username]);
      if (!row) throw new Error('Ese administrador no existe.');
      const disabled = options.command === 'disable' ? 1 : 0;
      await db.transaction(async () => {
        await db.run('UPDATE admin_users SET disabled = ? WHERE id = ?', [disabled, row.id]);
        if (disabled) await db.run('DELETE FROM admin_sessions WHERE user_id = ?', [row.id]);
        await db.run(
          `INSERT INTO audit_log(id, actor_type, actor_id, action, target_type, target_id, details, ip, created_at)
           VALUES (?, 'system', NULL, ?, 'admin_user', ?, NULL, NULL, ?)`,
          [crypto.randomUUID(), options.command === 'disable' ? 'admin.disabled' : 'admin.enabled', row.id, now],
        );
      });
      console.log(`Administrador ${disabled ? 'desactivado' : 'activado'}: ${username}`);
      return;
    }
    throw new Error(`Comando no reconocido: ${options.command}`);
  } finally {
    await db.close();
  }
}

main().catch((error) => {
  console.error(error.message || error);
  process.exit(1);
});
