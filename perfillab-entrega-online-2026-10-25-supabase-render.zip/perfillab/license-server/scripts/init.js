#!/usr/bin/env node
'use strict';

const fs = require('node:fs');
const path = require('node:path');

const { loadConfig } = require('../src/config');
const { openDatabase, redactConnectionString } = require('../src/database');
const { readVaultFile, unlockVault } = require('../src/vault');
const { initializeServer } = require('../src/seats');
const { requirePassphrase, requireConfirmedPassphrase, secretFromEnvironment } = require('../src/passphrase');

function parseArgs(argv) {
  const args = { vault: '', dataDir: '' };
  for (let index = 0; index < argv.length; index += 1) {
    const item = argv[index];
    if (item === '--vault') args.vault = argv[++index] || '';
    else if (item === '--data-dir') args.dataDir = argv[++index] || '';
    else if (item === '--help' || item === '-h') args.help = true;
    else throw new Error(`Argumento no reconocido: ${item}`);
  }
  return args;
}

function printHelp() {
  console.log(`Uso: npm run init -- [--vault <ruta>] [--data-dir <ruta>]

Variables necesarias:
  PERFILLAB_VAULT_PASSWORD o PERFILLAB_VAULT_PASSWORD_FILE
  PERFILLAB_KEYSTORE_PASSPHRASE o PERFILLAB_KEYSTORE_PASSPHRASE_FILE
  PERFILLAB_ADMIN_USER y PERFILLAB_ADMIN_PASSWORD (opcional en este paso)

Base de datos:
  PERFILLAB_DATABASE_URL (PostgreSQL) o PERFILLAB_DB_PATH (SQLite local).
  En NODE_ENV=production se exige PostgreSQL salvo PERFILLAB_ALLOW_SQLITE=true.

Keystore:
  Se usa PERFILLAB_KEYSTORE_PATH o, si existe, PERFILLAB_KEYSTORE_BASE64.
  El valor base64 contiene el keystore cifrado, nunca la clave en claro.

La bóveda inicial predeterminada es license-admin/seed/vault.json.
Usa --vault para migrar una bóveda real con licencias emitidas.`);
}

async function main() {
  const args = parseArgs(process.argv.slice(2));
  if (args.help) return printHelp();
  if (args.dataDir) process.env.PERFILLAB_DATA_DIR = path.resolve(args.dataDir);
  const config = loadConfig(process.env);
  const vaultPath = path.resolve(
    args.vault
    || process.env.PERFILLAB_VAULT_PATH
    || path.join(config.root, '..', 'license-admin', 'seed', 'vault.json'),
  );
  console.log(`Bóveda de origen: ${vaultPath}`);
  console.log(`Base de datos: ${config.databaseUrl
    ? redactConnectionString(config.databaseUrl)
    : config.dbPath}`);
  console.log(`Keystore: ${config.keystoreBase64 ? 'PERFILLAB_KEYSTORE_BASE64' : config.keystorePath}`);
  if (!fs.existsSync(vaultPath)) throw new Error('No se encontró la bóveda indicada.');

  const vaultPassword = await requirePassphrase({
    env: process.env,
    envVar: 'PERFILLAB_VAULT_PASSWORD',
    fileVar: 'PERFILLAB_VAULT_PASSWORD_FILE',
    label: 'Contraseña de la bóveda anterior',
    minLength: 1,
  });
  const vaultFile = readVaultFile(vaultPath);
  const vault = unlockVault(vaultFile, vaultPassword);
  console.log(`Bóveda desbloqueada: ${vault.seats.length} asientos, ${vault.seats.filter((seat) => seat.status === 'issued').length} emitidos.`);

  const keystoreExists = Boolean(config.keystoreBase64) || fs.existsSync(config.keystorePath);
  const keystoreOptions = {
    env: process.env,
    envVar: 'PERFILLAB_KEYSTORE_PASSPHRASE',
    fileVar: 'PERFILLAB_KEYSTORE_PASSPHRASE_FILE',
    label: keystoreExists ? 'Frase de paso del keystore existente' : 'Nueva frase de paso del keystore',
    minLength: 12,
  };
  const keystorePassphrase = keystoreExists
    ? await requirePassphrase(keystoreOptions)
    : await requireConfirmedPassphrase(keystoreOptions);

  const adminUser = String(process.env.PERFILLAB_ADMIN_USER || '').trim();
  const adminPassword = secretFromEnvironment(process.env, 'PERFILLAB_ADMIN_PASSWORD', 'PERFILLAB_ADMIN_PASSWORD_FILE');
  if (Boolean(adminUser) !== Boolean(adminPassword)) {
    throw new Error('Configura PERFILLAB_ADMIN_USER y PERFILLAB_ADMIN_PASSWORD juntos, o ninguno.');
  }
  const admin = adminUser ? { username: adminUser, password: adminPassword } : null;

  const db = await openDatabase(config);
  try {
    const summary = await initializeServer({
      db,
      vault,
      keystorePath: config.keystorePath,
      keystoreBase64: config.keystoreBase64,
      keystorePassphrase,
      admin,
    });
    console.log('Servidor inicializado correctamente.');
    console.log(JSON.stringify({
      seats: summary.seats,
      legacySeats: summary.legacySeats,
      legacyIssued: summary.legacyIssued,
      generatedSeats: summary.generatedSeats,
      available: summary.available,
      keyId: summary.keyId,
      adminCreated: summary.adminCreated,
      keystoreCreated: summary.keystoreCreated,
      keystoreSource: summary.keystoreSource,
      database: summary.database,
    }, null, 2));
    if (!summary.adminCreated) {
      console.log('No se creó un administrador. Ejecuta: npm run admin -- create --username <usuario>');
    }
  } finally {
    await db.close();
  }
}

main().catch((error) => {
  console.error(error.message || error);
  process.exit(1);
});
