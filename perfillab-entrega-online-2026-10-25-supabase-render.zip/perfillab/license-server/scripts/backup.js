#!/usr/bin/env node
'use strict';

const crypto = require('node:crypto');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { spawn } = require('node:child_process');

const { loadConfig } = require('../src/config');
const { openDatabase, redactConnectionString } = require('../src/database');
const { decodeKeystoreBase64 } = require('../src/keystore');

function timestamp() {
  return new Date().toISOString().replace(/[:.]/g, '-');
}

function runProcess(command, args, env = process.env) {
  return new Promise((resolve, reject) => {
    const child = spawn(command, args, { env, windowsHide: true });
    let stdout = '';
    let stderr = '';
    child.stdout.on('data', (chunk) => { stdout += chunk; });
    child.stderr.on('data', (chunk) => { stderr += chunk; });
    child.once('error', (error) => {
      if (error.code === 'ENOENT') {
        reject(new Error(`No se encontró ${command}. Instálalo o define PERFILLAB_PG_DUMP.`));
        return;
      }
      reject(error);
    });
    child.once('close', (code) => resolve({ code, stdout, stderr }));
  });
}

function fileSha256(filePath) {
  return crypto.createHash('sha256').update(fs.readFileSync(filePath)).digest('hex');
}

function writePrivateFile(filePath, content) {
  fs.writeFileSync(filePath, content, { encoding: 'utf8', mode: 0o600 });
  if (process.platform !== 'win32') {
    try {
      fs.chmodSync(filePath, 0o600);
    } catch {
      // Permisos best-effort.
    }
  }
}

async function backupSqlite(config, targets) {
  if (!fs.existsSync(config.dbPath)) throw new Error('No existe la base de datos del servidor.');
  const db = await openDatabase(config);
  try {
    const escaped = targets.database.replace(/'/g, "''");
    await db.exec(`VACUUM INTO '${escaped}'`);
  } finally {
    await db.close();
  }
  const check = await openDatabase({ ...config, databaseUrl: '', dbPath: targets.database }, { readOnly: true });
  try {
    const integrity = String((await check.get('PRAGMA integrity_check')).integrity_check);
    if (integrity !== 'ok') throw new Error(`La copia no supera la verificación de integridad: ${integrity}`);
    const seats = Number((await check.get('SELECT COUNT(*) AS n FROM seats')).n);
    if (seats !== config.seatLimit) throw new Error('La copia no contiene los 50.000 asientos esperados.');
  } finally {
    await check.close();
  }
}

function postgresEnv(config) {
  const url = new URL(config.databaseUrl);
  const env = {
    ...process.env,
    PGHOST: url.hostname,
    PGPORT: url.port || '5432',
    PGUSER: decodeURIComponent(url.username),
    PGPASSWORD: decodeURIComponent(url.password),
    PGDATABASE: decodeURIComponent(url.pathname.replace(/^\/+/, '')),
  };
  if (config.databaseSsl) env.PGSSLMODE = config.databaseSsl;
  if (url.searchParams.get('sslmode')) env.PGSSLMODE = url.searchParams.get('sslmode');
  let caFile = '';
  if (config.databaseSslCa) {
    caFile = path.join(os.tmpdir(), `perfillab-ca-${process.pid}-${Date.now()}.pem`);
    writePrivateFile(caFile, config.databaseSslCa);
    env.PGSSLROOTCERT = caFile;
  }
  return { env, caFile };
}

async function backupPostgres(config, targets) {
  const dump = process.env.PERFILLAB_PG_DUMP || 'pg_dump';
  const { env, caFile } = postgresEnv(config);
  const args = [
    '--format=plain',
    '--no-owner',
    '--no-privileges',
    '--schema', config.databaseSchema,
    '--file', targets.database,
  ];
  try {
    const result = await runProcess(dump, args, env);
    if (result.code !== 0) {
      const detail = String(result.stderr || '').trim().split('\n')[0] || `código ${result.code}`;
      throw new Error(`pg_dump falló: ${detail}`);
    }
  } finally {
    if (caFile) {
      try {
        fs.unlinkSync(caFile);
      } catch {
        // Limpieza best-effort.
      }
    }
  }
  const size = fs.statSync(targets.database).size;
  if (!size) throw new Error('pg_dump generó un archivo vacío.');
  const content = fs.readFileSync(targets.database, 'utf8');
  if (!content.includes('PostgreSQL database dump complete')) {
    throw new Error('La copia de PostgreSQL está incompleta: falta el marcador final de pg_dump.');
  }
  if (!/COPY\s+(?:"[^"]+"|[A-Za-z0-9_]+)\.seats\s/.test(content)) {
    throw new Error(`La copia no contiene la tabla de asientos del esquema ${config.databaseSchema}.`);
  }
  return { format: 'plain-sql', verified: 'footer-and-seats-copy' };
}

function backupKeystore(config, target) {
  if (config.keystoreBase64) {
    decodeKeystoreBase64(config.keystoreBase64);
    writePrivateFile(target, `${config.keystoreBase64.replace(/\s+/g, '')}\n`);
    return { source: 'env', encoding: 'base64' };
  }
  if (!fs.existsSync(config.keystorePath)) throw new Error('No existe el keystore del servidor.');
  fs.copyFileSync(config.keystorePath, target);
  if (process.platform !== 'win32') {
    try {
      fs.chmodSync(target, 0o600);
    } catch {
      // Permisos best-effort.
    }
  }
  return { source: 'file', encoding: 'json' };
}

async function main() {
  const config = loadConfig(process.env);
  fs.mkdirSync(config.backupDir, { recursive: true, mode: 0o700 });
  const stamp = timestamp();
  const keystoreEncoding = config.keystoreBase64 ? 'base64' : 'json';
  const dbName = config.databaseDialect === 'postgres'
    ? `perfillab-${stamp}.sql`
    : `perfillab-${stamp}.sqlite`;
  const keystoreName = `keystore-${stamp}.${keystoreEncoding}`;
  const targets = {
    database: path.join(config.backupDir, dbName),
    keystore: path.join(config.backupDir, keystoreName),
  };
  console.log(`Base de datos: ${config.databaseDialect === 'postgres'
    ? redactConnectionString(config.databaseUrl)
    : config.dbPath}`);

  let dbVerification;
  if (config.databaseDialect === 'postgres') {
    dbVerification = await backupPostgres(config, targets);
  } else {
    await backupSqlite(config, targets);
    dbVerification = { format: 'sqlite', verified: 'integrity-check-and-50000-seats' };
  }
  const keystoreInfo = backupKeystore(config, targets.keystore);

  const manifest = {
    createdAt: new Date().toISOString(),
    database: {
      engine: config.databaseDialect,
      file: path.basename(targets.database),
      sha256: fileSha256(targets.database),
      ...dbVerification,
    },
    keystore: {
      ...keystoreInfo,
      file: path.basename(targets.keystore),
      sha256: fileSha256(targets.keystore),
    },
    notice: 'La copia contiene datos personales y el keystore cifrado. Guárdala en un medio protegido, fuera del servicio, y conserva la frase de paso por separado. En hospedajes gratuitos el disco puede ser efímero: descarga la copia a un almacenamiento duradero.',
  };
  const manifestPath = path.join(config.backupDir, `manifest-${stamp}.json`);
  writePrivateFile(manifestPath, `${JSON.stringify(manifest, null, 2)}\n`);
  console.log(`Copia creada en ${config.backupDir}`);
  console.log(`Manifiesto: ${path.basename(manifestPath)}`);
  console.log(`DB SHA-256: ${manifest.database.sha256}`);
  console.log(`Keystore SHA-256: ${manifest.keystore.sha256}`);
  console.log('Guarda la frase de paso del keystore por separado. Sin ella la copia no permite firmar ni recuperar claves.');
}

main().catch((error) => {
  console.error(error.message || error);
  process.exit(1);
});
