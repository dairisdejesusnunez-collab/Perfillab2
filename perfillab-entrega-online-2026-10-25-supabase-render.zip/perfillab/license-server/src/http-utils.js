'use strict';

const fs = require('node:fs');
const net = require('node:net');
const path = require('node:path');

const { AppError } = require('./errors');

const CONTENT_TYPES = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.svg': 'image/svg+xml; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.png': 'image/png',
  '.ico': 'image/x-icon',
  '.txt': 'text/plain; charset=utf-8',
  '.webmanifest': 'application/manifest+json; charset=utf-8',
};

class RateLimitError extends AppError {
  constructor(message, retryAfterSeconds) {
    super(message, 429, 'rate_limited');
    this.retryAfter = Math.max(1, Number(retryAfterSeconds) || 1);
  }
}

class RateLimiter {
  constructor(options = {}) {
    this.buckets = new Map();
    this.maxEntries = options.maxEntries || 50_000;
    this.nextPrune = Date.now() + 60_000;
  }

  consume(bucket, identity, limit, windowMs, now = Date.now()) {
    this.prune(now);
    const key = `${bucket}\0${identity}`;
    let entry = this.buckets.get(key);
    if (!entry || now >= entry.resetAt) {
      entry = { count: 0, resetAt: now + windowMs };
      this.buckets.set(key, entry);
    }
    entry.count += 1;
    if (entry.count > limit) {
      const retryAfter = Math.ceil((entry.resetAt - now) / 1000);
      throw new RateLimitError('Demasiados intentos. Espera unos minutos antes de volver a probar.', retryAfter);
    }
    return { remaining: Math.max(0, limit - entry.count), resetAt: entry.resetAt };
  }

  reset(bucket, identity) {
    this.buckets.delete(`${bucket}\0${identity}`);
  }

  prune(now = Date.now()) {
    if (now < this.nextPrune && this.buckets.size < this.maxEntries) return;
    this.nextPrune = now + 60_000;
    for (const [key, entry] of this.buckets) {
      if (now >= entry.resetAt) this.buckets.delete(key);
    }
    if (this.buckets.size > this.maxEntries) {
      const excess = this.buckets.size - this.maxEntries;
      let removed = 0;
      for (const key of this.buckets.keys()) {
        this.buckets.delete(key);
        removed += 1;
        if (removed >= excess) break;
      }
    }
  }
}

function normalizeIp(value) {
  const raw = String(value || '').trim();
  if (!raw) return '';
  if (raw.startsWith('[')) {
    const end = raw.indexOf(']');
    const inner = end > 0 ? raw.slice(1, end) : raw;
    return net.isIP(inner) ? inner : '';
  }
  const withoutPort = /^[0-9a-fA-F:.]+$/.test(raw) ? raw : raw.replace(/:\d+$/, '');
  return net.isIP(withoutPort) ? withoutPort : '';
}

function clientIp(req, trustProxy = false) {
  if (trustProxy) {
    const forwarded = req.headers['x-forwarded-for'];
    const first = Array.isArray(forwarded) ? forwarded[0] : String(forwarded || '').split(',')[0];
    const parsed = normalizeIp(first);
    if (parsed) return parsed;
    const real = normalizeIp(req.headers['x-real-ip']);
    if (real) return real;
  }
  const remote = normalizeIp(req.socket && req.socket.remoteAddress);
  return remote || 'unknown';
}

function securityHeaders(res, { html = false, https = false } = {}) {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('Referrer-Policy', 'no-referrer');
  res.setHeader('Permissions-Policy', 'camera=(), microphone=(), geolocation=(), payment=(), usb=()');
  res.setHeader('Cross-Origin-Opener-Policy', 'same-origin');
  res.setHeader('Cross-Origin-Resource-Policy', 'same-origin');
  res.setHeader('Content-Security-Policy', html
    ? "default-src 'self'; base-uri 'none'; object-src 'none'; frame-ancestors 'none'; img-src 'self' data:; style-src 'self'; script-src 'self'; connect-src 'self'; form-action 'self'; manifest-src 'self'"
    : "default-src 'none'; base-uri 'none'; frame-ancestors 'none'; object-src 'none'");
  if (https) res.setHeader('Strict-Transport-Security', 'max-age=31536000');
}

function sendJson(res, status, payload, extraHeaders = {}) {
  if (res.headersSent) return;
  const body = Buffer.from(JSON.stringify(payload), 'utf8');
  res.statusCode = status;
  res.setHeader('Content-Type', 'application/json; charset=utf-8');
  res.setHeader('Content-Length', body.length);
  res.setHeader('Cache-Control', 'no-store');
  for (const [name, value] of Object.entries(extraHeaders)) {
    if (value !== undefined && value !== null) res.setHeader(name, value);
  }
  res.end(body);
}

function sendText(res, status, text, contentType = 'text/plain; charset=utf-8') {
  if (res.headersSent) return;
  const body = Buffer.from(String(text), 'utf8');
  res.statusCode = status;
  res.setHeader('Content-Type', contentType);
  res.setHeader('Content-Length', body.length);
  res.setHeader('Cache-Control', 'no-store');
  res.end(body);
}

function sendError(res, error, logger, requestId) {
  if (res.headersSent) {
    res.destroy();
    return;
  }
  const status = error instanceof AppError && error.status ? error.status : 500;
  if (status >= 500 && logger) {
    logger.error('Error procesando solicitud', {
      requestId,
      code: error && error.code ? error.code : 'error',
      cause: error && error.cause && error.cause.message ? error.cause.message : undefined,
    });
  }
  const expose = error instanceof AppError ? error.expose : false;
  const message = expose && error.message
    ? error.message
    : status >= 500
      ? 'Ocurrió un error interno. Inténtalo de nuevo.'
      : 'La solicitud no es válida.';
  const extra = {};
  if (error instanceof RateLimitError) extra['Retry-After'] = String(error.retryAfter);
  if (status === 413) extra.Connection = 'close';
  sendJson(res, status, {
    error: {
      message,
      code: error && error.code ? String(error.code).slice(0, 80) : 'error',
    },
  }, extra);
}

function readBody(req, limit) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    let size = 0;
    let settled = false;
    const fail = (error) => {
      if (settled) return;
      settled = true;
      req.pause();
      reject(error);
    };
    req.on('data', (chunk) => {
      if (settled) return;
      size += chunk.length;
      if (size > limit) {
        fail(new AppError('La solicitud es demasiado grande.', 413, 'payload_too_large'));
        return;
      }
      chunks.push(chunk);
    });
    req.on('end', () => {
      if (settled) return;
      settled = true;
      resolve(Buffer.concat(chunks));
    });
    req.on('error', () => fail(new AppError('No se pudo leer la solicitud.', 400, 'body_read_failed')));
    req.on('aborted', () => fail(new AppError('La solicitud se interrumpió.', 400, 'body_aborted')));
  });
}

function isJsonContentType(req) {
  const header = String(req.headers['content-type'] || '').split(';')[0].trim().toLowerCase();
  return header === 'application/json';
}

async function readJson(req, limit) {
  const buffer = await readBody(req, limit);
  if (!buffer.length) return {};
  if (!isJsonContentType(req)) {
    throw new AppError('La solicitud debe usar application/json.', 415, 'unsupported_media_type');
  }
  let data;
  try {
    data = JSON.parse(buffer.toString('utf8'));
  } catch {
    throw new AppError('La solicitud no contiene JSON válido.', 400, 'invalid_json');
  }
  if (!data || typeof data !== 'object' || Array.isArray(data)) {
    throw new AppError('La solicitud debe contener un objeto JSON.', 400, 'invalid_json');
  }
  return data;
}

function bearerToken(req) {
  const header = String(req.headers.authorization || '');
  const match = /^Bearer\s+([A-Za-z0-9_-]{20,200})$/i.exec(header);
  return match ? match[1] : '';
}

function jsonBodyToObject(value) {
  return value && typeof value === 'object' && !Array.isArray(value) ? value : {};
}

class StaticAssets {
  constructor(root) {
    this.root = path.resolve(root);
    this.cache = new Map();
  }

  read(relative) {
    if (typeof relative !== 'string' || !relative || relative.includes('\0')) return null;
    const normalizedRelative = relative.replace(/^\/+/, '');
    const filePath = path.resolve(this.root, normalizedRelative);
    if (filePath !== this.root && !filePath.startsWith(`${this.root}${path.sep}`)) return null;
    if (this.cache.has(filePath)) return this.cache.get(filePath);
    let stat;
    try {
      stat = fs.statSync(filePath);
    } catch {
      return null;
    }
    if (!stat.isFile()) return null;
    const body = fs.readFileSync(filePath);
    const entry = {
      body,
      contentType: CONTENT_TYPES[path.extname(filePath).toLowerCase()] || 'application/octet-stream',
    };
    this.cache.set(filePath, entry);
    return entry;
  }
}

function serveStatic(res, assets, relative, { cacheSeconds = 0, method = 'GET' } = {}) {
  const file = assets.read(relative);
  if (!file) return false;
  res.statusCode = 200;
  res.setHeader('Content-Type', file.contentType);
  res.setHeader('Content-Length', file.body.length);
  res.setHeader('Cache-Control', cacheSeconds > 0
    ? `public, max-age=${cacheSeconds}`
    : 'no-store');
  if (method === 'HEAD') res.end();
  else res.end(file.body);
  return true;
}

module.exports = {
  CONTENT_TYPES,
  RateLimitError,
  RateLimiter,
  StaticAssets,
  bearerToken,
  clientIp,
  isJsonContentType,
  jsonBodyToObject,
  normalizeIp,
  readBody,
  readJson,
  securityHeaders,
  sendError,
  sendJson,
  sendText,
  serveStatic,
};
