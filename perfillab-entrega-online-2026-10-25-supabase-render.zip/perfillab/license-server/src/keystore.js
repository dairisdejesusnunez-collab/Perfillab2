'use strict';

const crypto = require('node:crypto');
const fs = require('node:fs');
const path = require('node:path');

const KEYSTORE_FORMAT = 'perfillab-keystore';
const KEYSTORE_VERSION = 2;
const KDF = { name: 'scrypt', N: 32768, r: 8, p: 1, maxmem: 64 * 1024 * 1024, keylen: 32 };
const MAX_KEYSTORE_BYTES = 64 * 1024;

class KeystoreError extends Error {
  constructor(message) {
    super(message);
    this.name = 'KeystoreError';
    this.code = 'keystore_error';
  }
}

function deriveKey(passphrase, salt) {
  return crypto.scryptSync(String(passphrase), salt, KDF.keylen, {
    N: KDF.N,
    r: KDF.r,
    p: KDF.p,
    maxmem: KDF.maxmem,
  });
}

function aadFor(publicKey, keyId) {
  return Buffer.from(`${KEYSTORE_FORMAT}|${KEYSTORE_VERSION}|${publicKey}|${keyId}`, 'utf8');
}

function validateKeyPair(privateKeyB64, publicKeyB64) {
  const privateKey = crypto.createPrivateKey({
    key: Buffer.from(privateKeyB64, 'base64'),
    format: 'der',
    type: 'pkcs8',
  });
  if (privateKey.asymmetricKeyType !== 'ed25519') throw new KeystoreError('La clave privada no es Ed25519.');
  const publicDerived = crypto.createPublicKey(privateKey).export({ format: 'der', type: 'spki' }).toString('base64');
  if (publicDerived !== publicKeyB64) throw new KeystoreError('La clave pública no corresponde a la privada.');
  const probe = crypto.randomBytes(32);
  const signature = crypto.sign(null, probe, privateKey);
  const publicKey = crypto.createPublicKey({ key: Buffer.from(publicKeyB64, 'base64'), format: 'der', type: 'spki' });
  if (!crypto.verify(null, probe, publicKey, signature)) throw new KeystoreError('El par de claves no supera la prueba de firma.');
  return { privateKey, publicKey };
}

function createKeystoreFile({ privateKey, publicKey, dataKey, passphrase, createdAt = new Date().toISOString() }) {
  if (typeof privateKey !== 'string' || typeof publicKey !== 'string') throw new KeystoreError('Faltan las claves de firma.');
  if (String(passphrase || '').length < 12) throw new KeystoreError('La frase de paso del keystore debe tener al menos 12 caracteres.');
  const validated = validateKeyPair(privateKey, publicKey);
  const dataKeyBuffer = dataKey ? Buffer.from(dataKey) : crypto.randomBytes(32);
  if (dataKeyBuffer.length !== 32) throw new KeystoreError('La clave de datos no es válida.');
  const keyId = crypto.createHash('sha256').update(Buffer.from(publicKey, 'base64')).digest('hex').slice(0, 16);
  const salt = crypto.randomBytes(16);
  const derived = deriveKey(passphrase, salt);
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv('aes-256-gcm', derived, iv);
  cipher.setAAD(aadFor(publicKey, keyId));
  const plaintext = JSON.stringify({
    privateKey,
    dataKey: dataKeyBuffer.toString('base64'),
  });
  const encrypted = Buffer.concat([cipher.update(plaintext, 'utf8'), cipher.final()]);
  return {
    format: KEYSTORE_FORMAT,
    version: KEYSTORE_VERSION,
    publicKey,
    keyId,
    createdAt,
    updatedAt: new Date().toISOString(),
    kdf: {
      name: KDF.name,
      salt: salt.toString('base64'),
      N: KDF.N,
      r: KDF.r,
      p: KDF.p,
    },
    cipher: {
      name: 'aes-256-gcm',
      iv: iv.toString('base64'),
      tag: cipher.getAuthTag().toString('base64'),
      data: encrypted.toString('base64'),
    },
    probe: crypto.sign(null, Buffer.from('perfillab-keystore-probe-v1'), validated.privateKey).toString('base64'),
  };
}

function parseKeystoreObject(file) {
  if (!file || file.format !== KEYSTORE_FORMAT || Number(file.version) !== KEYSTORE_VERSION) {
    throw new KeystoreError('El keystore no tiene un formato compatible.');
  }
  if (!file.kdf || file.kdf.name !== KDF.name || !file.kdf.salt || !file.cipher) {
    throw new KeystoreError('El keystore está incompleto.');
  }
  const N = Number(file.kdf.N);
  const r = Number(file.kdf.r);
  const p = Number(file.kdf.p);
  if (N !== KDF.N || r !== KDF.r || p !== KDF.p) throw new KeystoreError('Parámetros KDF del keystore no admitidos.');
  return file;
}

function readKeystoreFile(filePath) {
  if (!fs.existsSync(filePath)) throw new KeystoreError('No existe el keystore del servidor.');
  const stat = fs.statSync(filePath);
  if (!stat.isFile() || stat.size > MAX_KEYSTORE_BYTES) throw new KeystoreError('El keystore no es válido.');
  let file;
  try {
    file = JSON.parse(fs.readFileSync(filePath, 'utf8'));
  } catch {
    throw new KeystoreError('El keystore está dañado.');
  }
  return parseKeystoreObject(file);
}

function decodeKeystoreBase64(value) {
  const raw = String(value || '').replace(/\s+/g, '');
  if (!raw) throw new KeystoreError('PERFILLAB_KEYSTORE_BASE64 está vacío.');
  if (!/^[A-Za-z0-9+/]+={0,2}$/.test(raw)) {
    throw new KeystoreError('PERFILLAB_KEYSTORE_BASE64 no es base64 válido.');
  }
  const buffer = Buffer.from(raw, 'base64');
  if (!buffer.length || buffer.length > MAX_KEYSTORE_BYTES) {
    throw new KeystoreError('El keystore de la variable de entorno no tiene un tamaño válido.');
  }
  let file;
  try {
    file = JSON.parse(buffer.toString('utf8'));
  } catch {
    throw new KeystoreError('El keystore de la variable de entorno está dañado.');
  }
  return parseKeystoreObject(file);
}

function openKeystoreObject(file, passphrase) {
  if (!file.publicKey || !file.keyId || !file.cipher.iv || !file.cipher.tag || !file.cipher.data) {
    throw new KeystoreError('El keystore está incompleto.');
  }
  const salt = Buffer.from(file.kdf.salt, 'base64');
  const derived = deriveKey(passphrase, salt);
  let plaintext;
  try {
    const decipher = crypto.createDecipheriv('aes-256-gcm', derived, Buffer.from(file.cipher.iv, 'base64'));
    decipher.setAAD(aadFor(file.publicKey, file.keyId));
    decipher.setAuthTag(Buffer.from(file.cipher.tag, 'base64'));
    plaintext = Buffer.concat([
      decipher.update(Buffer.from(file.cipher.data, 'base64')),
      decipher.final(),
    ]).toString('utf8');
  } catch {
    throw new KeystoreError('No se pudo abrir el keystore: frase de paso incorrecta o archivo dañado.');
  }
  let payload;
  try {
    payload = JSON.parse(plaintext);
  } catch {
    throw new KeystoreError('El keystore no contiene datos válidos.');
  }
  if (!payload || typeof payload.privateKey !== 'string' || typeof payload.dataKey !== 'string') {
    throw new KeystoreError('El keystore no contiene datos válidos.');
  }
  const keyId = crypto.createHash('sha256').update(Buffer.from(file.publicKey, 'base64')).digest('hex').slice(0, 16);
  if (keyId !== file.keyId) throw new KeystoreError('El identificador de clave del keystore no coincide.');
  const { privateKey, publicKey } = validateKeyPair(payload.privateKey, file.publicKey);
  const dataKey = Buffer.from(payload.dataKey, 'base64');
  if (dataKey.length !== 32) throw new KeystoreError('La clave de datos del keystore no es válida.');
  const probe = Buffer.from(String(file.probe || ''), 'base64');
  if (probe.length && !crypto.verify(null, Buffer.from('perfillab-keystore-probe-v1'), publicKey, probe)) {
    throw new KeystoreError('La prueba de firma del keystore no es válida.');
  }
  return {
    publicKey: file.publicKey,
    keyId,
    privateKeyB64: payload.privateKey,
    privateKey,
    publicKeyObject: publicKey,
    dataKey,
    createdAt: file.createdAt,
  };
}

function openKeystore(filePath, passphrase) {
  return openKeystoreObject(readKeystoreFile(filePath), passphrase);
}

function openKeystoreFromBase64(value, passphrase) {
  return openKeystoreObject(decodeKeystoreBase64(value), passphrase);
}

function loadKeystore({ keystoreBase64, keystorePath }, passphrase) {
  if (keystoreBase64) {
    return { keystore: openKeystoreFromBase64(keystoreBase64, passphrase), source: 'env' };
  }
  return { keystore: openKeystore(keystorePath, passphrase), source: 'file' };
}

function writeKeystoreAtomic(filePath, file) {
  fs.mkdirSync(path.dirname(filePath), { recursive: true });
  const temp = `${filePath}.tmp-${process.pid}-${crypto.randomBytes(4).toString('hex')}`;
  try {
    fs.writeFileSync(temp, `${JSON.stringify(file, null, 2)}\n`, { encoding: 'utf8', mode: 0o600 });
    fs.renameSync(temp, filePath);
    if (process.platform !== 'win32') {
      try {
        fs.chmodSync(filePath, 0o600);
      } catch {
        // No bloquear el arranque por permisos del sistema de archivos.
      }
    }
  } finally {
    try {
      if (fs.existsSync(temp)) fs.unlinkSync(temp);
    } catch {
      // Limpieza best-effort.
    }
  }
}

module.exports = {
  KEYSTORE_FORMAT,
  KEYSTORE_VERSION,
  KeystoreError,
  createKeystoreFile,
  decodeKeystoreBase64,
  loadKeystore,
  openKeystore,
  openKeystoreFromBase64,
  openKeystoreObject,
  parseKeystoreObject,
  readKeystoreFile,
  writeKeystoreAtomic,
  validateKeyPair,
};
