#!/usr/bin/env node
'use strict';

const crypto = require('node:crypto');
const fs = require('node:fs');
const http = require('node:http');
const path = require('node:path');

const { loadConfig, ConfigError } = require('./config');
const { createLogger } = require('./logger');
const { openDatabase } = require('./database');
const { loadKeystore } = require('./keystore');
const { secretFromEnvironment } = require('./passphrase');
const { assertServerInitialized } = require('./seats');
const { AuditService } = require('./audit');
const { LicensesService } = require('./licenses');
const { OrdersService } = require('./orders');
const { AdminAuthService } = require('./admin-auth');
const { PayPalClient, PayPalError } = require('./paypal');
const { PaymentSettings } = require('./payment-settings');
const { PLANS } = require('./plans');
const { SmtpMailer } = require('./smtp');
const { EmailWorker } = require('./email');
const { InstallerService, InstallerError } = require('./installer');
const { AppError, unauthorized, forbidden, notFound, badRequest, unavailable } = require('./errors');
const {
  RateLimiter,
  StaticAssets,
  bearerToken,
  clientIp,
  jsonBodyToObject,
  readBody,
  readJson,
  securityHeaders,
  sendError,
  sendJson,
  sendText,
  serveStatic,
} = require('./http-utils');

const { csvCell: toCsvCell } = require('./security');

function createRuntime({ config, db, keystore, logger, mailer }) {
  const audit = new AuditService(db);
  const licenses = new LicensesService({ db, keystore, config, audit, logger });
  const paymentSettings = new PaymentSettings({ db, keystore, config, audit, logger });
  const paypal = new PayPalClient({ configProvider: () => paymentSettings.paypalConfig(), logger });
  const orders = new OrdersService({ db, config, paypal, licenses, audit, logger, paymentSettings });
  const adminAuth = new AdminAuthService({ db, config, audit, logger });
  const smtp = mailer || new SmtpMailer(config.smtp, logger);
  const emailWorker = new EmailWorker({ db, config, mailer: smtp, licenses, audit, logger });
  const installer = new InstallerService({ config, logger });
  const assets = new StaticAssets(path.join(config.root, 'public'));
  const startedAt = Date.now();
  return {
    audit,
    licenses,
    paymentSettings,
    paypal,
    orders,
    adminAuth,
    mailer: smtp,
    emailWorker,
    installer,
    assets,
    startedAt,
    async maintenance() {
      const result = await orders.maintenance();
      await licenses.sweepExpired();
      emailWorker.kick();
      return result;
    },
  };
}

function fallbackPaymentStatus(config) {
  const annual = Number.isInteger(config.paypal && config.paypal.priceCents)
    && config.paypal.priceCents >= 50
    ? config.paypal.priceCents
    : 10000;
  const prices = { monthly: 1000, semiannual: 5000, annual };
  return {
    enabled: Boolean(config.paymentsEnabled),
    configured: Boolean(config.paypal && config.paypal.clientId && config.paypal.clientSecret && config.paypal.webhookId),
    source: config.paypal && (config.paypal.clientId || config.paypal.webhookId) ? 'env' : 'none',
    mode: (config.paypal && config.paypal.mode) || 'sandbox',
    currency: 'USD',
    prices,
    missing: config.missingPayments || [],
    publicBaseUrl: config.publicBaseUrl || null,
    plans: PLANS.map((plan) => ({
      code: plan.code,
      months: plan.months,
      label: plan.label,
      periodLabel: plan.periodLabel,
      description: plan.months === 1 ? 'Vigencia de 1 mes' : `Vigencia de ${plan.months} meses`,
      amountCents: prices[plan.code],
      currency: 'USD',
    })),
    local: false,
  };
}

async function paymentStatusFor(runtime, config) {
  return runtime.paymentSettings ? runtime.paymentSettings.snapshot() : fallbackPaymentStatus(config);
}

async function adminFromRequest(req, runtime, { role = 'reader' } = {}) {
  const token = bearerToken(req);
  if (!token) throw unauthorized('Inicia sesión para continuar.', 'invalid_session');
  const user = await runtime.adminAuth.authenticate(token);
  if (role === 'admin' && user.role !== 'admin') {
    throw forbidden('Tu rol no permite realizar esta acción.', 'role_forbidden');
  }
  return { token, user };
}

function pageParams(url, defaults = {}) {
  const page = Number.parseInt(url.searchParams.get('page') || String(defaults.page || 1), 10);
  const pageSize = Number.parseInt(url.searchParams.get('pageSize') || String(defaults.pageSize || 25), 10);
  return {
    page: Number.isFinite(page) && page > 0 ? page : 1,
    pageSize: Number.isFinite(pageSize) && pageSize > 0 ? pageSize : (defaults.pageSize || 25),
  };
}

function requireString(value, name, max = 200) {
  if (typeof value !== 'string' || !value.trim()) throw badRequest(`Falta el campo ${name}.`, 'missing_field');
  if (value.length > max) throw badRequest(`El campo ${name} es demasiado largo.`, 'invalid_field');
  return value.trim();
}

function optionalString(value, max = 200) {
  if (value === undefined || value === null) return '';
  if (typeof value !== 'string') throw badRequest('Uno de los campos no es válido.', 'invalid_field');
  if (value.length > max) throw badRequest('Uno de los campos es demasiado largo.', 'invalid_field');
  return value;
}

function dateForFile(date = new Date()) {
  const pad = (value) => String(value).padStart(2, '0');
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}`;
}

function createRequestHandler({ config, runtime, logger }) {
  const limiter = new RateLimiter();
  const orderLocks = new Map();
  const isSecure = String(config.publicBaseUrl || '').startsWith('https://');

  function limit(bucket, identity, max, windowMs) {
    limiter.consume(bucket, identity, max, windowMs);
  }

  async function reconcilePublicOrder(order, ip) {
    const existing = orderLocks.get(order.id);
    const now = Date.now();
    if (existing && existing.promise) return existing.promise;
    if (existing && now - existing.at < 4000) return null;
    const promise = runtime.orders.reconcileOrder(order, { trigger: 'public', ip })
      .finally(() => {
        orderLocks.set(order.id, { at: Date.now(), promise: null });
      });
    orderLocks.set(order.id, { at: now, promise });
    return promise;
  }

  async function orderTokenSnapshot(token, ip) {
    const order = await runtime.orders.orderByToken(token);
    if (!order) throw notFound('La orden no existe.', 'order_not_found');
    let notice = null;
    if (['created', 'pending'].includes(order.status) && order.paypal_order_id) {
      try {
        await reconcilePublicOrder(order, ip);
      } catch (error) {
        const transient = error instanceof PayPalError
          ? Boolean(error.retryable)
          : ['paypal_unavailable', 'paypal_capture_pending'].includes(error.code);
        if (!transient) throw error;
        notice = 'No pudimos verificar el pago con PayPal en este momento. Actualizaremos el estado automáticamente.';
      }
    }
    const fresh = (await runtime.orders.orderById(order.id)) || order;
    return { ...(await runtime.orders.publicSnapshot(fresh)), notice };
  }

  async function publicStoreConfig() {
    const soldOut = !(await runtime.licenses.hasAvailableSeat());
    const payments = await paymentStatusFor(runtime, config);
    let download = null;
    try {
      const info = await runtime.installer.describe();
      if (info.enabled) {
        download = {
          url: info.url,
          filename: info.filename,
          version: info.version,
          sha256: info.sha256,
          sizeBytes: info.sizeBytes,
        };
      }
    } catch (error) {
      logger.warn('El instalador configurado no se puede publicar', { code: error.code || 'installer_error' });
    }
    const annual = payments.plans.find((plan) => plan.code === 'annual') || payments.plans[payments.plans.length - 1];
    return {
      productName: config.productName,
      plans: payments.plans,
      plan: {
        code: 'annual',
        months: 12,
        label: 'Licencia anual · 12 meses',
      },
      price: annual ? { amountCents: annual.amountCents, currency: annual.currency } : null,
      currency: 'USD',
      checkoutEnabled: Boolean(payments.enabled && !soldOut),
      paymentsEnabled: Boolean(payments.enabled),
      paymentsMode: payments.mode,
      soldOut,
      supportEmail: config.supportEmail || null,
      termsVersion: '2026-10',
      download,
      checkedAt: new Date().toISOString(),
    };
  }

  async function handleDownload(ctx) {
    limit('download-ip', ctx.ip, 60, 60 * 60 * 1000);
    try {
      await runtime.installer.send(ctx.req, ctx.res);
    } catch (error) {
      if (error instanceof InstallerError) {
        logger.warn('Descarga del instalador no disponible', { code: error.code });
        const status = ['installer_unavailable', 'installer_missing'].includes(error.code) ? 404 : 503;
        throw new AppError(error.message, status, error.code);
      }
      throw error;
    }
    return undefined;
  }

  async function handleAdminLogin(ctx) {
    const { req, ip, res } = ctx;
    limit('login-ip', ip, config.loginAttempts, config.loginWindowMs);
    const body = await readJson(req, 8192);
    const username = requireString(body.username, 'usuario', 64);
    limit('login-user', username.toLowerCase(), config.loginAttempts * 2, config.loginWindowMs);
    const result = await runtime.adminAuth.login({
      username,
      password: optionalString(body.password, 200),
      ip,
      userAgent: req.headers['user-agent'],
    });
    limiter.reset('login-ip', ip);
    limiter.reset('login-user', username.toLowerCase());
    res.setHeader('Cache-Control', 'no-store');
    return result;
  }

  async function handleAdminOverview(ctx) {
    await adminFromRequest(ctx.req, runtime);
    const payments = await paymentStatusFor(runtime, config);
    const installerStatus = await runtime.installer.describe().catch(() => ({ enabled: false }));
    return {
      summary: await runtime.licenses.summary(),
      server: {
        version: config.version,
        environment: config.env,
        keyId: runtime.licenses.keystore.keyId,
        databaseDialect: config.databaseDialect,
        databaseSchema: config.databaseDialect === 'postgres' ? config.databaseSchema : null,
        paymentsEnabled: Boolean(payments.enabled),
        paymentsConfigured: Boolean(payments.configured),
        paymentsSource: payments.source,
        paypalMode: payments.mode,
        planMonths: config.planMonths,
        plans: payments.plans,
        maxBatchItems: config.maxBatchItems,
        publicBaseUrl: config.publicBaseUrl || null,
        emailEnabled: Boolean(runtime.mailer && runtime.mailer.enabled),
        pendingEmails: await runtime.emailWorker.pendingCount(),
        missingPayments: payments.missing,
        missingEmail: config.missingEmail,
        supportEmail: config.supportEmail || null,
        dataDir: config.dataDir,
        installer: {
          enabled: Boolean(installerStatus.enabled),
          filename: installerStatus.filename || null,
          version: installerStatus.version || null,
          sha256: installerStatus.sha256 || null,
          sizeBytes: installerStatus.sizeBytes || null,
        },
      },
      payments,
    };
  }

  function paymentsFromBody(body) {
    const prices = {};
    if (body.prices !== undefined) {
      if (!body.prices || typeof body.prices !== 'object' || Array.isArray(body.prices)) {
        throw badRequest('Los precios no tienen un formato válido.', 'invalid_price');
      }
      for (const plan of PLANS) {
        if (body.prices[plan.code] !== undefined) prices[plan.code] = body.prices[plan.code];
      }
    }
    return {
      mode: optionalString(body.mode, 16),
      clientId: optionalString(body.clientId, 200),
      clientSecret: optionalString(body.clientSecret, 200),
      webhookId: optionalString(body.webhookId, 100),
      prices,
    };
  }

  async function handlePaymentsGet(ctx) {
    await adminFromRequest(ctx.req, runtime);
    if (!runtime.paymentSettings) throw unavailable('Este servidor no admite configuración de pagos.', 'payments_unavailable');
    return runtime.paymentSettings.snapshot();
  }

  async function handlePaymentsSave(ctx) {
    const { user } = await adminFromRequest(ctx.req, runtime, { role: 'admin' });
    if (!runtime.paymentSettings) throw unavailable('Este servidor no admite configuración de pagos.', 'payments_unavailable');
    const body = await readJson(ctx.req, 16 * 1024);
    return runtime.paymentSettings.save(paymentsFromBody(body), {
      actorType: 'admin',
      actorId: user.id,
      ip: ctx.ip,
    });
  }

  async function handlePaymentsTest(ctx) {
    const { user } = await adminFromRequest(ctx.req, runtime, { role: 'admin' });
    if (!runtime.paymentSettings) throw unavailable('Este servidor no admite configuración de pagos.', 'payments_unavailable');
    const body = await readJson(ctx.req, 16 * 1024);
    return runtime.paymentSettings.test(paymentsFromBody(body), {
      actorType: 'admin',
      actorId: user.id,
      ip: ctx.ip,
    });
  }

  async function handlePaymentsClear(ctx) {
    const { user } = await adminFromRequest(ctx.req, runtime, { role: 'admin' });
    if (!runtime.paymentSettings) throw unavailable('Este servidor no admite configuración de pagos.', 'payments_unavailable');
    await readJson(ctx.req, 4096);
    return runtime.paymentSettings.clear({ actorType: 'admin', actorId: user.id, ip: ctx.ip });
  }

  async function handleIssue(ctx) {
    const { user } = await adminFromRequest(ctx.req, runtime, { role: 'admin' });
    const body = await readJson(ctx.req, 32 * 1024);
    return runtime.licenses.issue({
      customerName: optionalString(body.customerName, 160),
      email: optionalString(body.email, 254),
      machineCode: optionalString(body.machineCode, 32),
      machineName: optionalString(body.machineName, 80),
      notes: optionalString(body.notes, 500),
      plan: optionalString(body.plan, 20),
      transactionId: optionalString(body.transactionId, 100),
    }, { actorType: 'admin', actorId: user.id, ip: ctx.ip, source: 'admin' });
  }

  async function handleBatch(ctx) {
    const { user } = await adminFromRequest(ctx.req, runtime, { role: 'admin' });
    const body = await readJson(ctx.req, 256 * 1024);
    if (!Array.isArray(body.items)) throw badRequest('El lote debe contener una lista de licencias.', 'invalid_batch');
    if (body.items.length > config.maxBatchItems) {
      throw badRequest(`El lote supera el máximo de ${config.maxBatchItems}.`, 'batch_too_large');
    }
    const items = body.items.map((item) => {
      const value = jsonBodyToObject(item);
      return {
        customerName: optionalString(value.customerName, 160),
        email: optionalString(value.email, 254),
        machineCode: optionalString(value.machineCode, 32),
        machineName: optionalString(value.machineName, 80),
        notes: optionalString(value.notes, 500),
        plan: optionalString(value.plan, 20),
        transactionId: optionalString(value.transactionId, 100),
      };
    });
    return runtime.licenses.issueBatch(items, { actorType: 'admin', actorId: user.id, ip: ctx.ip });
  }

  async function handleLicenseAction(ctx, action, { role = 'admin' } = {}) {
    const { user } = await adminFromRequest(ctx.req, runtime, { role });
    const body = await readJson(ctx.req, 16 * 1024);
    const reason = optionalString(body.reason, 300);
    const plan = optionalString(body.plan, 20);
    const context = { actorType: 'admin', actorId: user.id, ip: ctx.ip };
    if (action === 'revoke') return runtime.licenses.revoke(ctx.params[0], { reason, ...context });
    if (action === 'suspend') return runtime.licenses.suspend(ctx.params[0], { reason, ...context });
    if (action === 'reactivate') return runtime.licenses.reactivate(ctx.params[0], context);
    if (action === 'reset-activation') return runtime.licenses.resetActivation(ctx.params[0], { reason, ...context });
    if (action === 'resend-email') return runtime.licenses.queueResend(ctx.params[0], context);
    if (action === 'renew') {
      return runtime.licenses.renew(ctx.params[0], {
        reason,
        plan: plan || undefined,
        ...context,
      });
    }
    throw notFound('Acción no encontrada.', 'not_found');
  }

  async function handleAdminLicenseDetail(ctx) {
    const { user } = await adminFromRequest(ctx.req, runtime);
    const detail = await runtime.licenses.reveal(ctx.params[0]);
    await runtime.audit.record({
      actorType: 'admin',
      actorId: user.id,
      action: 'license.revealed',
      targetType: 'license',
      targetId: detail.license.id,
      details: { seat: detail.license.seat },
      ip: ctx.ip,
    });
    return detail;
  }

  async function handleLicenseCsv(ctx) {
    const { user } = await adminFromRequest(ctx.req, runtime);
    const status = ctx.url.searchParams.get('status') || 'all';
    const query = ctx.url.searchParams.get('query') || '';
    const rows = await runtime.licenses.exportRows({ status, query });
    const header = [
      'ID licencia',
      'Asiento',
      'Estado',
      'Cliente',
      'Correo',
      'Producto',
      'Plan',
      'Equipo',
      'Nombre del equipo',
      'Emitida',
      'Vence',
      'Activada',
      'Transacción',
      'Revocada',
      'Motivo de revocación',
    ];
    const lines = [header.map(toCsvCell).join(',')];
    for (const row of rows) {
      lines.push([
        row.id,
        row.seat,
        row.status,
        row.customerName,
        row.email || '',
        row.product,
        row.plan,
        row.machineCode || '',
        row.machineName || '',
        row.issuedAt,
        row.expiresAt || '',
        row.activatedAt || '',
        row.transactionId || '',
        row.revokedAt || '',
        row.revokedReason || '',
      ].map(toCsvCell).join(','));
    }
    await runtime.audit.record({
      actorType: 'admin',
      actorId: user.id,
      action: 'licenses.exported',
      targetType: 'license',
      targetId: null,
      details: { total: rows.length, status, query: query.slice(0, 80) },
      ip: ctx.ip,
    });
    const body = `\uFEFF${lines.join('\r\n')}\r\n`;
    ctx.res.statusCode = 200;
    ctx.res.setHeader('Content-Type', 'text/csv; charset=utf-8');
    ctx.res.setHeader('Content-Disposition', `attachment; filename="perfillab-licencias-${dateForFile()}.csv"`);
    ctx.res.setHeader('Content-Length', Buffer.byteLength(body, 'utf8'));
    ctx.res.setHeader('Cache-Control', 'no-store');
    ctx.res.end(body);
  }

  async function handleWebhook(ctx) {
    limit('webhook-ip', ctx.ip, 600, 60_000);
    const buffer = await readBody(ctx.req, config.maxBodyBytes);
    if (!buffer.length) throw badRequest('El webhook está vacío.', 'invalid_webhook');
    if (!String(ctx.req.headers['content-type'] || '').toLowerCase().startsWith('application/json')) {
      throw badRequest('El webhook debe usar application/json.', 'invalid_webhook');
    }
    try {
      const outcome = await runtime.orders.processWebhook({
        headers: ctx.req.headers,
        rawBody: buffer.toString('utf8'),
        ip: ctx.ip,
      });
      return { received: true, ...outcome };
    } catch (error) {
      if (error instanceof PayPalError) {
        if (error.retryable) throw new AppError('PayPal no está disponible para verificar el webhook.', 503, 'paypal_unavailable');
        throw badRequest('No se pudo verificar la autenticidad del webhook.', 'invalid_webhook');
      }
      throw error;
    }
  }

  const routes = [
    {
      method: 'GET',
      path: '/api/health',
      handler: async () => ({
        ok: true,
        service: 'perfillab-license-server',
        version: config.version,
        time: new Date().toISOString(),
      }),
    },
    {
      method: 'GET',
      path: '/api/store',
      handler: async () => publicStoreConfig(),
    },
    {
      method: 'GET',
      path: '/descargar',
      handler: handleDownload,
    },
    {
      method: 'HEAD',
      path: '/descargar',
      handler: handleDownload,
    },
    {
      method: 'POST',
      path: '/api/checkout',
      handler: async (ctx) => {
        limit('checkout-ip', ctx.ip, config.checkoutAttemptsPerIp, config.checkoutWindowMs);
        const body = await readJson(ctx.req, 16 * 1024);
        return runtime.orders.createCheckout({
          email: optionalString(body.email, 254),
          name: optionalString(body.name, 160),
          acceptTerms: body.acceptTerms === true,
          plan: optionalString(body.plan, 20),
          ip: ctx.ip,
        });
      },
    },
    {
      method: 'GET',
      path: /^\/api\/orders\/([A-Za-z0-9_-]{20,200})$/,
      handler: async (ctx) => {
        limit('order-view-ip', ctx.ip, 600, 60 * 60 * 1000);
        ctx.res.setHeader('X-Robots-Tag', 'noindex, nofollow');
        return orderTokenSnapshot(ctx.params[0], ctx.ip);
      },
    },
    {
      method: 'POST',
      path: /^\/api\/orders\/([A-Za-z0-9_-]{20,200})\/cancel$/,
      handler: async (ctx) => {
        limit('order-cancel-ip', ctx.ip, 20, 60 * 60 * 1000);
        ctx.res.setHeader('X-Robots-Tag', 'noindex, nofollow');
        await readJson(ctx.req, 4096);
        return runtime.orders.handleCancel({ token: ctx.params[0], ip: ctx.ip });
      },
    },
    {
      method: 'POST',
      path: '/api/license/activate',
      handler: async (ctx) => {
        limit('activation-ip', ctx.ip, config.activationAttemptsPerIp, config.activationWindowMs);
        const body = await readJson(ctx.req, 16 * 1024);
        const result = await runtime.licenses.activate({
          licenseKey: requireString(body.licenseKey, 'clave de licencia', 64),
          machineCode: requireString(body.machineCode, 'código de equipo', 32),
          machineName: optionalString(body.machineName, 80),
          ip: ctx.ip,
        });
        return { ...result, serverTime: new Date().toISOString() };
      },
    },
    {
      method: 'POST',
      path: '/api/license/validate',
      handler: async (ctx) => {
        limit('validate-ip', ctx.ip, 120, 15 * 60 * 1000);
        const body = await readJson(ctx.req, 16 * 1024);
        return runtime.licenses.validate({
          licenseKey: requireString(body.licenseKey, 'clave de licencia', 64),
          machineCode: optionalString(body.machineCode, 32),
        });
      },
    },
    {
      method: 'GET',
      path: '/api/license/revocations',
      handler: async (ctx) => {
        limit('revocations-ip', ctx.ip, 300, 15 * 60 * 1000);
        const current = await runtime.licenses.revocationList();
        ctx.res.setHeader('ETag', current.etag);
        ctx.res.setHeader('Cache-Control', 'no-cache');
        ctx.res.setHeader('Content-Type', 'application/json; charset=utf-8');
        if (String(ctx.req.headers['if-none-match'] || '').trim() === current.etag) {
          ctx.res.statusCode = 304;
          ctx.res.end();
          return undefined;
        }
        ctx.res.statusCode = 200;
        ctx.res.setHeader('Content-Length', Buffer.byteLength(current.body, 'utf8'));
        ctx.res.end(current.body);
        return undefined;
      },
    },
    {
      method: 'POST',
      path: '/api/paypal/webhook',
      handler: handleWebhook,
    },
    {
      method: 'POST',
      path: '/api/admin/login',
      handler: handleAdminLogin,
    },
    {
      method: 'POST',
      path: '/api/admin/logout',
      handler: async (ctx) => {
        await adminFromRequest(ctx.req, runtime);
        return runtime.adminAuth.logout(bearerToken(ctx.req));
      },
    },
    {
      method: 'GET',
      path: '/api/admin/session',
      handler: async (ctx) => {
        const { user } = await adminFromRequest(ctx.req, runtime);
        return { user };
      },
    },
    {
      method: 'GET',
      path: '/api/admin/overview',
      handler: handleAdminOverview,
    },
    {
      method: 'GET',
      path: '/api/admin/payments',
      handler: handlePaymentsGet,
    },
    {
      method: 'POST',
      path: '/api/admin/payments',
      handler: handlePaymentsSave,
    },
    {
      method: 'POST',
      path: '/api/admin/payments/test',
      handler: handlePaymentsTest,
    },
    {
      method: 'POST',
      path: '/api/admin/payments/clear',
      handler: handlePaymentsClear,
    },
    {
      method: 'GET',
      path: '/api/admin/licenses',
      handler: async (ctx) => {
        await adminFromRequest(ctx.req, runtime);
        const { page, pageSize } = pageParams(ctx.url, { pageSize: 25 });
        return runtime.licenses.list({
          query: ctx.url.searchParams.get('query') || '',
          status: ctx.url.searchParams.get('status') || 'all',
          page,
          pageSize,
        });
      },
    },
    {
      method: 'GET',
      path: '/api/admin/licenses.csv',
      handler: handleLicenseCsv,
    },
    {
      method: 'POST',
      path: '/api/admin/licenses',
      handler: handleIssue,
    },
    {
      method: 'POST',
      path: '/api/admin/licenses/batch',
      handler: handleBatch,
    },
    {
      method: 'GET',
      path: /^\/api\/admin\/licenses\/([A-Za-z0-9._-]{3,100})$/,
      handler: handleAdminLicenseDetail,
    },
    {
      method: 'POST',
      path: /^\/api\/admin\/licenses\/([A-Za-z0-9._-]{3,100})\/revoke$/,
      handler: (ctx) => handleLicenseAction(ctx, 'revoke'),
    },
    {
      method: 'POST',
      path: /^\/api\/admin\/licenses\/([A-Za-z0-9._-]{3,100})\/suspend$/,
      handler: (ctx) => handleLicenseAction(ctx, 'suspend'),
    },
    {
      method: 'POST',
      path: /^\/api\/admin\/licenses\/([A-Za-z0-9._-]{3,100})\/reactivate$/,
      handler: (ctx) => handleLicenseAction(ctx, 'reactivate'),
    },
    {
      method: 'POST',
      path: /^\/api\/admin\/licenses\/([A-Za-z0-9._-]{3,100})\/reset-activation$/,
      handler: (ctx) => handleLicenseAction(ctx, 'reset-activation'),
    },
    {
      method: 'POST',
      path: /^\/api\/admin\/licenses\/([A-Za-z0-9._-]{3,100})\/resend-email$/,
      handler: (ctx) => handleLicenseAction(ctx, 'resend-email', { role: 'reader' }),
    },
    {
      method: 'POST',
      path: /^\/api\/admin\/licenses\/([A-Za-z0-9._-]{3,100})\/renew$/,
      handler: (ctx) => handleLicenseAction(ctx, 'renew'),
    },
    {
      method: 'GET',
      path: '/api/admin/orders',
      handler: async (ctx) => {
        await adminFromRequest(ctx.req, runtime);
        const { page, pageSize } = pageParams(ctx.url, { pageSize: 25 });
        return runtime.orders.listOrders({
          status: ctx.url.searchParams.get('status') || 'all',
          query: ctx.url.searchParams.get('query') || '',
          page,
          pageSize,
        });
      },
    },
    {
      method: 'GET',
      path: /^\/api\/admin\/orders\/([A-Za-z0-9-]{8,100})$/,
      handler: async (ctx) => {
        await adminFromRequest(ctx.req, runtime);
        return runtime.orders.orderDetail(ctx.params[0]);
      },
    },
    {
      method: 'POST',
      path: /^\/api\/admin\/orders\/([A-Za-z0-9-]{8,100})\/sync$/,
      handler: async (ctx) => {
        const { user } = await adminFromRequest(ctx.req, runtime);
        await readJson(ctx.req, 4096);
        try {
          await runtime.orders.syncAdminOrder(ctx.params[0], {
            actorType: 'admin',
            actorId: user.id,
            ip: ctx.ip,
          });
        } catch (error) {
          if (error instanceof PayPalError) {
            throw new AppError('No se pudo verificar la orden con PayPal.', 502, 'paypal_unavailable');
          }
          throw error;
        }
        return runtime.orders.orderDetail(ctx.params[0]);
      },
    },
    {
      method: 'GET',
      path: '/api/admin/transactions',
      handler: async (ctx) => {
        await adminFromRequest(ctx.req, runtime);
        const { page, pageSize } = pageParams(ctx.url, { pageSize: 50 });
        return runtime.orders.listTransactions({ page, pageSize });
      },
    },
    {
      method: 'GET',
      path: '/api/admin/audit',
      handler: async (ctx) => {
        await adminFromRequest(ctx.req, runtime);
        const { page, pageSize } = pageParams(ctx.url, { pageSize: 50 });
        return runtime.audit.list({ page, pageSize });
      },
    },
    {
      method: 'GET',
      path: '/api/admin/revocations',
      handler: async (ctx) => {
        await adminFromRequest(ctx.req, runtime);
        const current = await runtime.licenses.revocationList();
        ctx.res.statusCode = 200;
        ctx.res.setHeader('Content-Type', 'application/json; charset=utf-8');
        ctx.res.setHeader('Content-Disposition', `attachment; filename="perfillab-revocaciones-${dateForFile()}.json"`);
        ctx.res.setHeader('Content-Length', Buffer.byteLength(current.body, 'utf8'));
        ctx.res.setHeader('Cache-Control', 'no-store');
        ctx.res.end(current.body);
        return undefined;
      },
    },
  ];

  const staticRoutes = {
    '/': ['index.html', 0],
    '/index.html': ['index.html', 0],
    '/styles.css': ['styles.css', 300],
    '/store.js': ['store.js', 300],
    '/pago/retorno': ['order.html', 0],
    '/pago/cancelado': ['order.html', 0],
    '/order.js': ['order.js', 300],
    '/favicon.svg': ['favicon.svg', 86_400],
    '/robots.txt': ['robots.txt', 3600],
  };

  async function handler(req, res) {
    const requestId = crypto.randomBytes(6).toString('hex');
    res.setHeader('X-Request-Id', requestId);
    const rawUrl = String(req.url || '');
    if (rawUrl.length > 4096) {
      securityHeaders(res, { html: false, https: isSecure });
      sendJson(res, 414, { error: { message: 'La URL es demasiado larga.', code: 'uri_too_long' } });
      return;
    }
    let url;
    try {
      url = new URL(rawUrl, 'http://localhost');
    } catch {
      securityHeaders(res, { html: false, https: isSecure });
      sendJson(res, 400, { error: { message: 'La URL no es válida.', code: 'invalid_url' } });
      return;
    }
    const pathname = url.pathname;
    const isApi = pathname.startsWith('/api/');
    securityHeaders(res, { html: !isApi, https: isSecure });
    if (isApi) {
      res.setHeader('X-Robots-Tag', 'noindex, nofollow');
    }
    if (req.method !== 'GET' && req.method !== 'POST' && req.method !== 'HEAD') {
      res.setHeader('Allow', 'GET, HEAD, POST');
      securityHeaders(res, { html: false, https: isSecure });
      sendJson(res, 405, { error: { message: 'Método no permitido.', code: 'method_not_allowed' } });
      return;
    }
    if (pathname.startsWith('/pago/')) {
      res.setHeader('X-Robots-Tag', 'noindex, nofollow');
    }

    if (!isApi && (req.method === 'GET' || req.method === 'HEAD')) {
      const staticRoute = staticRoutes[pathname];
      if (staticRoute) {
        const [file, cacheSeconds] = staticRoute;
        if (serveStatic(res, runtime.assets, file, { cacheSeconds, method: req.method })) return;
        logger.error('Archivo estático no encontrado', { requestId, file });
        sendText(res, 404, 'No encontrado.', 'text/plain; charset=utf-8');
        return;
      }
    }

    if (!['GET', 'POST', 'HEAD'].includes(req.method)) {
      securityHeaders(res, { html: false, https: isSecure });
      sendJson(res, 405, { error: { message: 'Método no permitido.', code: 'method_not_allowed' } });
      return;
    }

    try {
      for (const route of routes) {
        if (route.method !== req.method) continue;
        let params = [];
        if (typeof route.path === 'string') {
          if (pathname !== route.path) continue;
        } else {
          const match = route.path.exec(pathname);
          if (!match) continue;
          params = match.slice(1);
        }
        const ctx = {
          req,
          res,
          url,
          pathname,
          method: req.method,
          ip: clientIp(req, config.trustProxy),
          requestId,
          params,
        };
        const data = await route.handler(ctx);
        if (!res.headersSent && data !== undefined) sendJson(res, 200, data);
        if (!res.headersSent && data === undefined) res.end();
        return;
      }
      throw notFound('Recurso no encontrado.', 'not_found');
    } catch (error) {
      if (!(error instanceof AppError) && !(error instanceof PayPalError)) {
        logger.error('Excepción no controlada', {
          requestId,
          message: error && error.message ? error.message : 'error',
        });
      }
      sendError(res, error instanceof PayPalError ? new AppError('No se pudo contactar con PayPal.', 502, 'paypal_unavailable') : error, logger, requestId);
    }
  }

  handler.prune = (now = Date.now()) => {
    for (const [id, entry] of orderLocks) {
      if (!entry.promise && now - entry.at > 30 * 60 * 1000) orderLocks.delete(id);
    }
  };
  return handler;
}

function createLicenseServer({ config, db, keystore, logger, mailer, runtime: providedRuntime }) {
  const runtime = providedRuntime || createRuntime({ config, db, keystore, logger, mailer });
  const handler = createRequestHandler({ config, runtime, logger });
  const server = http.createServer(handler);
  server.headersTimeout = 10_000;
  server.requestTimeout = 30_000;
  server.keepAliveTimeout = 5_000;
  server.maxHeadersCount = 100;
  server.maxRequestsPerSocket = 500;
  server.on('clientError', (error, socket) => {
    if (socket.writable) socket.end('HTTP/1.1 400 Bad Request\r\nConnection: close\r\n\r\n');
    else socket.destroy();
  });
  let maintenanceTimer = null;
  return {
    server,
    handler,
    runtime,
    async startBackground() {
      await runtime.emailWorker.start();
      const run = async () => {
        try {
          await runtime.maintenance();
          handler.prune();
        } catch (error) {
          logger.error('Fallo en el mantenimiento periódico', { code: error.code || 'error' });
        }
      };
      const initial = setTimeout(() => { run(); }, 5000);
      if (initial.unref) initial.unref();
      maintenanceTimer = setInterval(() => { run(); }, 10 * 60 * 1000);
      if (maintenanceTimer.unref) maintenanceTimer.unref();
    },
    async close() {
      if (maintenanceTimer) clearInterval(maintenanceTimer);
      runtime.emailWorker.stop();
      await new Promise((resolve) => {
        if (!server.listening) return resolve();
        server.close(() => resolve());
        setTimeout(resolve, 5000).unref();
        return undefined;
      });
    },
    stopBackground() {
      if (maintenanceTimer) clearInterval(maintenanceTimer);
      runtime.emailWorker.stop();
    },
  };
}

async function checkRuntimeConfig({ config, db, keystore, logger }) {
  const initialized = await assertServerInitialized(db);
  if ((await db.getSetting('key_id', '')) !== keystore.keyId) {
    throw new Error('El keystore no corresponde a la base de datos de licencias.');
  }
  if ((await db.getSetting('public_key', '')) !== keystore.publicKey) {
    throw new Error('La clave pública del keystore no coincide con la registrada.');
  }
  if ((await db.count('admin_users')) === 0) {
    logger.warn('No hay usuarios administradores. Crea uno con npm run admin -- create.');
  }
  return initialized;
}

async function main() {
  const logger = createLogger();
  let config;
  try {
    config = loadConfig(process.env);
  } catch (error) {
    if (error instanceof ConfigError) {
      logger.error('Configuración no válida', { message: error.message });
      process.exit(1);
    }
    throw error;
  }
  const passphrase = secretFromEnvironment(
    process.env,
    'PERFILLAB_KEYSTORE_PASSPHRASE',
    'PERFILLAB_KEYSTORE_PASSPHRASE_FILE',
  );
  if (!passphrase) {
    logger.error('Falta PERFILLAB_KEYSTORE_PASSPHRASE o PERFILLAB_KEYSTORE_PASSPHRASE_FILE.');
    process.exit(1);
  }
  if (config.databaseDialect === 'sqlite' && !fs.existsSync(config.dbPath)) {
    logger.error('La base de datos SQLite no existe. Ejecuta primero npm run init.', {
      database: config.dbPath,
    });
    process.exit(1);
  }
  if (!config.keystoreBase64 && !fs.existsSync(config.keystorePath)) {
    logger.error('No existe el keystore. Ejecuta npm run init o define PERFILLAB_KEYSTORE_BASE64.', {
      keystorePath: config.keystorePath,
    });
    process.exit(1);
  }
  let keystore;
  let keystoreSource;
  try {
    const loaded = loadKeystore(
      { keystoreBase64: config.keystoreBase64, keystorePath: config.keystorePath },
      passphrase,
    );
    keystore = loaded.keystore;
    keystoreSource = loaded.source;
  } catch (error) {
    logger.error('No se pudo abrir el keystore', { message: error.message });
    process.exit(1);
  }
  let db;
  try {
    db = await openDatabase(config);
  } catch (error) {
    logger.error('No se pudo abrir la base de datos', {
      message: error.message,
      code: error.code || 'database_error',
    });
    process.exit(1);
  }
  let runtimeServer;
  try {
    await checkRuntimeConfig({ config, db, keystore, logger });
    runtimeServer = createLicenseServer({ config, db, keystore, logger });
  } catch (error) {
    await db.close().catch(() => {});
    logger.error('No se pudo preparar el servidor', { message: error.message });
    process.exit(1);
  }
  await new Promise((resolve, reject) => {
    runtimeServer.server.once('error', reject);
    runtimeServer.server.listen(config.port, config.host, () => {
      runtimeServer.server.removeListener('error', reject);
      resolve();
    });
  }).catch(async (error) => {
    logger.error('No se pudo iniciar el servidor HTTP', {
      code: error.code || 'listen_failed',
      port: config.port,
      host: config.host,
    });
    await db.close().catch(() => {});
    process.exit(1);
  });

  await runtimeServer.startBackground();
  logger.info('Servidor de licencias iniciado', {
    listen: `${config.host}:${config.port}`,
    publicBaseUrl: config.publicBaseUrl || null,
    keyId: keystore.keyId,
    keystoreSource,
    database: db.dialect,
    databaseTarget: db.identity,
    paymentsEnabled: config.paymentsEnabled,
    paypalMode: config.paypal.mode,
    emailEnabled: Boolean(runtimeServer.runtime.mailer.enabled),
    installerEnabled: config.installer.enabled,
    environment: config.env,
  });
  if (!config.paymentsEnabled) logger.warn('Pagos desactivados', { missing: config.missingPayments });
  if (!config.emailEnabled) logger.warn('Correo desactivado', { missing: config.missingEmail });
  if (!config.installer.enabled) logger.warn('El instalador no está publicado; la tienda no mostrará la descarga.');
  if (config.paypal.mode === 'live') logger.info('PayPal en modo LIVE');
  if (!config.publicBaseUrl) logger.warn('PERFILLAB_PUBLIC_BASE_URL no está configurada; la tienda está cerrada.');
  if (config.host !== '127.0.0.1' && config.host !== 'localhost' && !isSecureBase(config.publicBaseUrl)) {
    logger.warn('El servidor escucha en red sin HTTPS directo. Usa un proxy inverso TLS para producción.');
  }

  let stopping = false;
  const shutdown = async (signal) => {
    if (stopping) return;
    stopping = true;
    logger.info('Deteniendo servidor', { signal });
    await runtimeServer.close();
    try {
      await db.close();
    } catch {
      // Cierre best-effort.
    }
    process.exit(0);
  };
  process.on('SIGINT', () => shutdown('SIGINT'));
  process.on('SIGTERM', () => shutdown('SIGTERM'));
}

function isSecureBase(value) {
  return String(value || '').startsWith('https://');
}

if (require.main === module) {
  main().catch((error) => {
    console.error(error && error.stack ? error.stack : error);
    process.exit(1);
  });
}

module.exports = {
  createRuntime,
  createRequestHandler,
  createLicenseServer,
  checkRuntimeConfig,
};
