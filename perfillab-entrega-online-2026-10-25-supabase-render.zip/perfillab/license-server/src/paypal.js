'use strict';

const { AppError } = require('./errors');
const { sanitizeText } = require('./security');

class PayPalError extends Error {
  constructor(message, options = {}) {
    super(message);
    this.name = 'PayPalError';
    this.status = options.status || 0;
    this.code = options.code || 'paypal_error';
    this.debugId = options.debugId || null;
    this.retryable = Boolean(options.retryable);
    this.issue = options.issue || null;
  }
}

function safeId(value) {
  const id = String(value || '');
  if (!/^[A-Za-z0-9-]{1,80}$/.test(id)) throw new PayPalError('Identificador de PayPal no válido.');
  return encodeURIComponent(id);
}

function amountFromCents(cents) {
  return (Number(cents) / 100).toFixed(2);
}

function isPayPalApprovalUrl(value) {
  let url;
  try {
    url = new URL(String(value || ''));
  } catch {
    return false;
  }
  if (url.protocol !== 'https:' || url.username || url.password) return false;
  return url.hostname === 'paypal.com' || url.hostname.endsWith('.paypal.com');
}

class PayPalClient {
  constructor({ config, configProvider, fetchImpl, logger }) {
    if (!config && typeof configProvider !== 'function') throw new Error('Falta la configuración de PayPal.');
    this.staticConfig = config || null;
    this.configProvider = typeof configProvider === 'function' ? configProvider : null;
    this.fetch = fetchImpl || globalThis.fetch;
    this.logger = logger;
    this.token = null;
    this.tokenExpiresAt = 0;
    this.tokenFingerprint = '';
    if (typeof this.fetch !== 'function') throw new Error('fetch no está disponible en este entorno.');
  }

  async resolveConfig() {
    const config = this.configProvider ? await this.configProvider() : this.staticConfig;
    return config || {};
  }

  async isEnabled() {
    const config = await this.resolveConfig();
    return Boolean(
      config.clientId
      && config.clientSecret
      && config.webhookId
      && config.apiBase,
    );
  }

  credentialFingerprint(config) {
    return `${config.apiBase}|${config.clientId}|${config.clientSecret}`;
  }

  async readResponse(response) {
    const text = await response.text();
    if (text.length > 5 * 1024 * 1024) throw new PayPalError('Respuesta de PayPal demasiado grande.', { retryable: false });
    let data = null;
    if (text) {
      try {
        data = JSON.parse(text);
      } catch {
        data = null;
      }
    }
    return { data, text };
  }

  async accessToken() {
    const config = await this.resolveConfig();
    const now = Date.now();
    const fingerprint = this.credentialFingerprint(config);
    if (fingerprint !== this.tokenFingerprint) {
      this.token = null;
      this.tokenExpiresAt = 0;
      this.tokenFingerprint = fingerprint;
    }
    if (this.token && now < this.tokenExpiresAt - 60_000) return this.token;
    let response;
    try {
      response = await this.fetch(`${config.apiBase}/v1/oauth2/token`, {
        method: 'POST',
        headers: {
          Authorization: `Basic ${Buffer.from(`${config.clientId}:${config.clientSecret}`).toString('base64')}`,
          'Content-Type': 'application/x-www-form-urlencoded',
          Accept: 'application/json',
          'User-Agent': 'PerfilLab-License-Server/1.0',
        },
        body: 'grant_type=client_credentials',
        signal: AbortSignal.timeout(20_000),
      });
    } catch (error) {
      throw new PayPalError('No se pudo conectar con PayPal.', { code: 'paypal_network', retryable: true, issue: error.message });
    }
    const { data } = await this.readResponse(response);
    if (!response.ok || !data || !data.access_token) {
      throw new PayPalError('PayPal rechazó la autenticación del servidor.', {
        status: response.status,
        code: data && data.error ? String(data.error) : 'paypal_auth_failed',
        debugId: response.headers.get('paypal-debug-id') || null,
        retryable: response.status >= 500 || response.status === 429,
      });
    }
    if (typeof data.access_token !== 'string' || data.access_token.length > 4096) {
      throw new PayPalError('PayPal devolvió un token no válido.');
    }
    const expires = Number(data.expires_in) || 300;
    this.token = data.access_token;
    this.tokenExpiresAt = now + Math.max(60, expires) * 1000;
    return this.token;
  }

  async request(method, path, { body, idempotencyKey, form, retryAuth = true } = {}) {
    const config = await this.resolveConfig();
    const token = await this.accessToken();
    const headers = {
      Authorization: `Bearer ${token}`,
      Accept: 'application/json',
      'User-Agent': 'PerfilLab-License-Server/1.0',
      Prefer: 'return=representation',
    };
    if (idempotencyKey) headers['PayPal-Request-Id'] = String(idempotencyKey).slice(0, 108);
    let payload;
    if (form) {
      headers['Content-Type'] = 'application/x-www-form-urlencoded';
      payload = body;
    } else if (body !== undefined) {
      headers['Content-Type'] = 'application/json';
      payload = JSON.stringify(body);
    }
    let response;
    try {
      response = await this.fetch(`${config.apiBase}${path}`, {
        method,
        headers,
        body: payload,
        signal: AbortSignal.timeout(25_000),
      });
    } catch (error) {
      throw new PayPalError('No se pudo conectar con PayPal.', { code: 'paypal_network', retryable: true, issue: error.message });
    }
    if (response.status === 401 && retryAuth) {
      this.token = null;
      this.tokenExpiresAt = 0;
      this.tokenFingerprint = '';
      return this.request(method, path, { body, idempotencyKey, form, retryAuth: false });
    }
    const { data, text } = await this.readResponse(response);
    if (!response.ok) {
      const issue = data && Array.isArray(data.details) && data.details[0]
        ? sanitizeText(`${data.details[0].issue || ''}: ${data.details[0].description || ''}`, 300)
        : null;
      const code = data && (data.name || data.error) ? String(data.name || data.error).slice(0, 80) : 'paypal_http_error';
      const retryable = response.status >= 500 || response.status === 429 || response.status === 408;
      throw new PayPalError(`PayPal respondió con un error (${response.status}).`, {
        status: response.status,
        code,
        issue,
        debugId: response.headers.get('paypal-debug-id') || null,
        retryable,
      });
    }
    if (!data) throw new PayPalError('PayPal devolvió una respuesta no válida.', { status: response.status });
    return data;
  }

  async createOrder({
    amountCents,
    currency,
    description,
    customId,
    invoiceId,
    returnUrl,
    cancelUrl,
    brandName,
    requestId,
    referenceId = 'perfillab-annual',
  }) {
    if (!Number.isInteger(amountCents) || amountCents < 50) throw new PayPalError('Importe de PayPal no válido.');
    if (!/^[A-Z]{3}$/.test(String(currency || ''))) throw new PayPalError('Moneda de PayPal no válida.');
    if (!/^[a-z0-9][a-z0-9-]{0,63}$/.test(String(referenceId || ''))) throw new PayPalError('Referencia de PayPal no válida.');
    const data = await this.request('POST', '/v2/checkout/orders', {
      idempotencyKey: requestId,
      body: {
        intent: 'CAPTURE',
        purchase_units: [
          {
            reference_id: referenceId,
            custom_id: String(customId).slice(0, 127),
            invoice_id: String(invoiceId).slice(0, 127),
            description: sanitizeText(description, 127),
            amount: {
              currency_code: currency,
              value: amountFromCents(amountCents),
            },
          },
        ],
        application_context: {
          brand_name: sanitizeText(brandName || 'PerfilLab', 127),
          locale: 'es-ES',
          shipping_preference: 'NO_SHIPPING',
          user_action: 'PAY_NOW',
          return_url: returnUrl,
          cancel_url: cancelUrl,
        },
      },
    });
    if (!data.id || !Array.isArray(data.links)) throw new PayPalError('PayPal no devolvió un enlace de aprobación.');
    const approval = data.links.find((link) => link && (link.rel === 'approve' || link.rel === 'payer-action'));
    if (!approval || !isPayPalApprovalUrl(approval.href)) {
      throw new PayPalError('PayPal no devolvió un enlace de aprobación seguro.');
    }
    return { order: data, approvalUrl: approval.href };
  }

  async getOrder(orderId) {
    return this.request('GET', `/v2/checkout/orders/${safeId(orderId)}`);
  }

  async captureOrder(orderId, requestId) {
    return this.request('POST', `/v2/checkout/orders/${safeId(orderId)}/capture`, {
      idempotencyKey: requestId,
      body: {},
    });
  }

  async getCapture(captureId) {
    return this.request('GET', `/v2/payments/captures/${safeId(captureId)}`);
  }

  async verifyWebhook({ headers, event }) {
    const config = await this.resolveConfig();
    if (!config.webhookId) throw new PayPalError('El webhook de PayPal no está configurado.');
    const get = (name) => sanitizeText(headers[name] || headers[name.toLowerCase()] || '', 1024);
    const transmissionId = get('paypal-transmission-id');
    const transmissionTime = get('paypal-transmission-time');
    const certUrl = get('paypal-cert-url');
    const authAlgo = get('paypal-auth-algo');
    const transmissionSig = get('paypal-transmission-sig');
    const certId = get('paypal-cert-id');
    if (!transmissionId || !transmissionTime || !certUrl || !authAlgo || !transmissionSig) {
      throw new PayPalError('Faltan cabeceras de firma del webhook.');
    }
    if (certUrl.length > 2048 || !/^https:\/\//.test(certUrl)) throw new PayPalError('cert-url del webhook no válido.');
    const data = await this.request('POST', '/v1/notifications/verify-webhook-signature', {
      body: {
        auth_algo: authAlgo,
        cert_id: certId,
        cert_url: certUrl,
        transmission_id: transmissionId,
        transmission_sig: transmissionSig,
        transmission_time: transmissionTime,
        webhook_event: event,
        webhook_id: config.webhookId,
      },
    });
    if (data.verification_status !== 'SUCCESS') {
      throw new AppError('La firma del webhook de PayPal no es válida.', 400, 'invalid_webhook_signature');
    }
    return true;
  }
}

module.exports = { PayPalClient, PayPalError, amountFromCents, isPayPalApprovalUrl };
