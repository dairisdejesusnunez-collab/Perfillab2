'use strict';

const crypto = require('node:crypto');
const net = require('node:net');
const express = require('express');

const { AuditService } = require('./audit');
const { LicensesService } = require('./licenses');
const { OrdersService } = require('./orders');
const { AdminAuthService } = require('./admin-auth');
const { AppError, badRequest, unauthorized, forbidden, notFound } = require('./errors');
const { RateLimiter, bearerToken, clientIp, securityHeaders } = require('./http-utils');
const { csvCell } = require('./security');
const { PLANS } = require('./plans');

const LICENSE_ID_RE = /^[A-Za-z0-9._-]{3,100}$/;
const ORDER_ID_RE = /^[A-Za-z0-9-]{8,100}$/;
const LICENSE_ACTIONS = new Set([
  'revoke',
  'suspend',
  'reactivate',
  'reset-activation',
  'resend-email',
  'renew',
]);

function createLocalRuntime({ config, db, keystore, logger }) {
  const audit = new AuditService(db);
  const licenses = new LicensesService({ db, keystore, config, audit, logger });
  const orders = new OrdersService({ db, config, paypal: null, licenses, audit, logger });
  const adminAuth = new AdminAuthService({ db, config, audit, logger });
  return { config, db, keystore, logger, audit, licenses, orders, adminAuth };
}

function requestId() {
  return crypto.randomBytes(6).toString('hex');
}

function isLoopback(address) {
  const raw = String(address || '');
  if (raw === '::1') return true;
  if (raw.startsWith('::ffff:')) return raw.slice(7) === '127.0.0.1';
  return net.isIPv4(raw) && raw.startsWith('127.');
}

function stringField(body, name, { max = 200, required = false } = {}) {
  const value = body && body[name];
  if (value === undefined || value === null || value === '') {
    if (required) throw badRequest(`Falta el campo ${name}.`, 'missing_field');
    return '';
  }
  if (typeof value !== 'string') throw badRequest(`El campo ${name} no es válido.`, 'invalid_field');
  if (value.length > max) throw badRequest(`El campo ${name} es demasiado largo.`, 'invalid_field');
  return value;
}

function intParam(value, fallback, min, max) {
  const parsed = Number.parseInt(String(value || ''), 10);
  if (!Number.isFinite(parsed)) return fallback;
  return Math.min(Math.max(parsed, min), max);
}

function licenseId(req) {
  const id = String(req.params.id || '');
  if (!LICENSE_ID_RE.test(id)) throw badRequest('El identificador de licencia no es válido.', 'invalid_id');
  return id;
}

function orderId(req) {
  const id = String(req.params.id || '');
  if (!ORDER_ID_RE.test(id)) throw badRequest('El identificador de pedido no es válido.', 'invalid_id');
  return id;
}

function pageParams(req, defaultPageSize) {
  return {
    page: intParam(req.query.page, 1, 1, 1_000_000),
    pageSize: intParam(req.query.pageSize, defaultPageSize, 10, 200),
  };
}

function dateForFile(date = new Date()) {
  const pad = (value) => String(value).padStart(2, '0');
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}`;
}

function licenseInput(body) {
  return {
    customerName: stringField(body, 'customerName', { max: 160 }),
    email: stringField(body, 'email', { max: 254 }),
    machineCode: stringField(body, 'machineCode', { max: 32 }),
    machineName: stringField(body, 'machineName', { max: 80 }),
    notes: stringField(body, 'notes', { max: 500 }),
    plan: stringField(body, 'plan', { max: 20 }),
    transactionId: stringField(body, 'transactionId', { max: 100 }),
  };
}

function localPaymentsStatus(config) {
  const prices = { monthly: 1000, semiannual: 5000, annual: 10000 };
  return {
    enabled: false,
    configured: false,
    editable: false,
    local: true,
    readOnly: true,
    source: 'none',
    mode: 'disabled',
    clientId: '',
    webhookId: '',
    secretConfigured: false,
    pricesSource: 'default',
    currency: 'USD',
    prices,
    plans: PLANS.map((plan) => ({
      code: plan.code,
      months: plan.months,
      label: plan.label,
      periodLabel: plan.periodLabel,
      description: plan.months === 1 ? 'Vigencia de 1 mes' : `Vigencia de ${plan.months} meses`,
      amountCents: prices[plan.code],
      currency: 'USD',
    })),
    publicBaseUrl: null,
    webhookPath: null,
    webhookUrl: null,
    missing: [],
    updatedAt: null,
    environment: 'local',
    message: 'El servidor local no procesa pagos. Configura PayPal en el servidor central.',
    supportEmail: config.supportEmail || null,
  };
}

function authMiddleware(runtime) {
  return async (req, res, next) => {
    const token = bearerToken(req);
    if (!token) {
      next(unauthorized('Inicia sesión para continuar.', 'invalid_session'));
      return;
    }
    try {
      req.admin = await runtime.adminAuth.authenticate(token);
      req.adminToken = token;
      next();
    } catch (error) {
      next(error);
    }
  };
}

function adminOnly(req, res, next) {
  if (!req.admin || req.admin.role !== 'admin') {
    next(forbidden('Tu rol no permite realizar esta acción.', 'role_forbidden'));
    return;
  }
  next();
}

function errorPayload(error) {
  const status = error instanceof AppError && error.status ? error.status : 500;
  const message = error instanceof AppError && error.expose && error.message
    ? error.message
    : status >= 500
      ? 'Ocurrió un error interno. Inténtalo de nuevo.'
      : 'La solicitud no es válida.';
  return {
    status,
    body: {
      error: {
        message,
        code: error && error.code ? String(error.code).slice(0, 80) : 'error',
        details: error && error.details ? error.details : null,
      },
    },
  };
}

function createLocalApp({ config, runtime, logger }) {
  const app = express();
  const limiter = new RateLimiter();
  const requireAuth = authMiddleware(runtime);
  app.disable('x-powered-by');
  app.disable('etag');

  app.use((req, res, next) => {
    securityHeaders(res, { html: false });
    res.setHeader('Cache-Control', 'no-store');
    res.setHeader('X-Request-Id', requestId());
    if (!isLoopback(req.socket.remoteAddress)) {
      res.status(403).json({
        error: {
          message: 'El servidor local solo acepta conexiones desde este equipo.',
          code: 'loopback_only',
        },
      });
      return;
    }
    next();
  });

  app.use((req, res, next) => {
    if (req.headers.origin) {
      res.status(403).json({
        error: {
          message: 'Las peticiones con cabecera Origin no están permitidas en el servidor local.',
          code: 'origin_not_allowed',
        },
      });
      return;
    }
    next();
  });

  app.use(express.json({ limit: '256kb', strict: true, type: 'application/json' }));

  app.get('/v1/health', (req, res) => {
    res.json({
      ok: true,
      service: 'perfillab-license-server-local',
      version: config.version,
      time: new Date().toISOString(),
    });
  });

  app.post('/v1/auth/login', async (req, res, next) => {
    try {
      const ip = clientIp(req, false);
      limiter.consume('login-ip', ip, config.loginAttempts, config.loginWindowMs);
      const username = stringField(req.body, 'username', { max: 64, required: true }).trim();
      limiter.consume('login-user', username.toLowerCase(), config.loginAttempts * 2, config.loginWindowMs);
      const password = stringField(req.body, 'password', { max: 200, required: true });
      const result = await runtime.adminAuth.login({
        username,
        password,
        ip,
        userAgent: req.headers['user-agent'],
      });
      limiter.reset('login-ip', ip);
      limiter.reset('login-user', username.toLowerCase());
      res.json(result);
    } catch (error) {
      next(error);
    }
  });

  app.get('/v1/auth/me', requireAuth, (req, res) => {
    res.json({ user: req.admin });
  });

  app.post('/v1/auth/logout', requireAuth, async (req, res, next) => {
    try {
      await runtime.adminAuth.logout(req.adminToken);
      res.json({ ok: true });
    } catch (error) {
      next(error);
    }
  });

  app.get('/v1/profiles', requireAuth, (req, res) => {
    res.json({
      profiles: [{
        id: `${config.product}-${config.plan}`,
        product: config.product,
        plan: config.plan,
        label: 'Licencia anual',
        months: config.planMonths,
        seatLimit: config.seatLimit,
      }],
    });
  });

  app.get('/v1/admin/overview', requireAuth, async (req, res, next) => {
    try {
      const pendingEmails = Number((await runtime.db.get(
        `SELECT COUNT(*) AS n FROM email_outbox WHERE status IN ('queued', 'sending')`,
      )).n);
      res.json({
        summary: await runtime.licenses.summary(),
        server: {
          version: config.version,
          environment: 'local',
          keyId: runtime.keystore.keyId,
          paymentsEnabled: false,
          paypalMode: 'disabled',
          planMonths: config.planMonths,
          plans: localPaymentsStatus(config).plans,
          maxBatchItems: config.maxBatchItems,
          publicBaseUrl: null,
          emailEnabled: false,
          pendingEmails,
          missingPayments: [],
          missingEmail: [],
          supportEmail: config.supportEmail || null,
          dataDir: config.dataDir,
        },
        payments: localPaymentsStatus(config),
      });
    } catch (error) {
      next(error);
    }
  });

  app.get('/v1/admin/payments', requireAuth, (req, res) => {
    res.json(localPaymentsStatus(config));
  });

  app.post('/v1/admin/payments', requireAuth, adminOnly, (req, res, next) => {
    next(new AppError(
      'El servidor local no procesa pagos. Configura PayPal en el servidor central.',
      409,
      'payments_disabled',
    ));
  });

  app.post('/v1/admin/payments/test', requireAuth, adminOnly, (req, res, next) => {
    next(new AppError(
      'El servidor local no procesa pagos. Configura PayPal en el servidor central.',
      409,
      'payments_disabled',
    ));
  });

  app.post('/v1/admin/payments/clear', requireAuth, adminOnly, (req, res, next) => {
    next(new AppError(
      'El servidor local no procesa pagos. Configura PayPal en el servidor central.',
      409,
      'payments_disabled',
    ));
  });

  app.get('/v1/admin/licenses', requireAuth, async (req, res, next) => {
    try {
      const { page, pageSize } = pageParams(req, 25);
      res.json(await runtime.licenses.list({
        query: String(req.query.query || ''),
        status: String(req.query.status || 'all'),
        page,
        pageSize,
      }));
    } catch (error) {
      next(error);
    }
  });

  app.get('/v1/admin/licenses.csv', requireAuth, async (req, res, next) => {
    try {
      const status = String(req.query.status || 'all');
      const rows = await runtime.licenses.exportRows({
        status,
        query: String(req.query.query || ''),
      });
      const header = [
        'ID licencia',
        'Asiento',
        'Estado',
        'Cliente',
        'Correo',
        'Producto',
        'Plan',
        'Equipo',
        'Nombre del equipo',
        'Emitida',
        'Vence',
        'Activada',
        'Transacción',
        'Revocada',
        'Motivo de revocación',
      ];
      const lines = [header.map(csvCell).join(',')];
      for (const row of rows) {
        lines.push([
          row.id,
          row.seat,
          row.status,
          row.customerName,
          row.email || '',
          row.product,
          row.plan,
          row.machineCode || '',
          row.machineName || '',
          row.issuedAt,
          row.expiresAt || '',
          row.activatedAt || '',
          row.transactionId || '',
          row.revokedAt || '',
          row.revokedReason || '',
        ].map(csvCell).join(','));
      }
      await runtime.audit.record({
        actorType: 'admin',
        actorId: req.admin.id,
        action: 'licenses.exported',
        targetType: 'license',
        targetId: null,
        details: { total: rows.length, status },
        ip: clientIp(req, false),
      });
      const body = `\uFEFF${lines.join('\r\n')}\r\n`;
      res.status(200);
      res.setHeader('Content-Type', 'text/csv; charset=utf-8');
      res.setHeader('Content-Disposition', `attachment; filename="perfillab-licencias-${dateForFile()}.csv"`);
      res.setHeader('Content-Length', Buffer.byteLength(body, 'utf8'));
      res.end(body);
    } catch (error) {
      next(error);
    }
  });

  app.post('/v1/admin/licenses', requireAuth, adminOnly, async (req, res, next) => {
    try {
      const result = await runtime.licenses.issue(licenseInput(req.body), {
        actorType: 'admin',
        actorId: req.admin.id,
        ip: clientIp(req, false),
        source: 'local-admin',
      });
      res.status(201).json(result);
    } catch (error) {
      next(error);
    }
  });

  app.post('/v1/admin/licenses/batch', requireAuth, adminOnly, async (req, res, next) => {
    try {
      const items = req.body && req.body.items;
      if (!Array.isArray(items)) throw badRequest('El lote debe contener una lista de licencias.', 'invalid_batch');
      if (!items.length) throw badRequest('El lote no contiene licencias para emitir.', 'batch_empty');
      if (items.length > config.maxBatchItems) {
        throw badRequest(`El lote supera el máximo de ${config.maxBatchItems} licencias.`, 'batch_too_large');
      }
      const result = await runtime.licenses.issueBatch(items.map(licenseInput), {
        actorType: 'admin',
        actorId: req.admin.id,
        ip: clientIp(req, false),
      });
      res.json(result);
    } catch (error) {
      next(error);
    }
  });

  app.get('/v1/admin/licenses/:id', requireAuth, async (req, res, next) => {
    try {
      const id = licenseId(req);
      const detail = await runtime.licenses.reveal(id);
      await runtime.audit.record({
        actorType: 'admin',
        actorId: req.admin.id,
        action: 'license.revealed',
        targetType: 'license',
        targetId: detail.license.id,
        details: { seat: detail.license.seat },
        ip: clientIp(req, false),
      });
      res.json(detail);
    } catch (error) {
      next(error);
    }
  });

  app.post('/v1/admin/licenses/:id/:action', requireAuth, async (req, res, next) => {
    try {
      const action = String(req.params.action || '');
      if (!LICENSE_ACTIONS.has(action)) throw notFound('Acción no encontrada.', 'not_found');
      if (action !== 'resend-email' && req.admin.role !== 'admin') {
        throw forbidden('Tu rol no permite realizar esta acción.', 'role_forbidden');
      }
      const id = licenseId(req);
      const reason = stringField(req.body, 'reason', { max: 300 });
      const plan = stringField(req.body, 'plan', { max: 20 });
      const context = { actorType: 'admin', actorId: req.admin.id, ip: clientIp(req, false) };
      if (action === 'revoke') res.json(await runtime.licenses.revoke(id, { reason, ...context }));
      else if (action === 'suspend') res.json(await runtime.licenses.suspend(id, { reason, ...context }));
      else if (action === 'reactivate') res.json(await runtime.licenses.reactivate(id, context));
      else if (action === 'reset-activation') {
        res.json(await runtime.licenses.resetActivation(id, { reason, ...context }));
      } else if (action === 'resend-email') res.json(await runtime.licenses.queueResend(id, context));
      else res.json(await runtime.licenses.renew(id, { reason, plan: plan || undefined, ...context }));
    } catch (error) {
      next(error);
    }
  });

  app.get('/v1/admin/orders', requireAuth, async (req, res, next) => {
    try {
      const { page, pageSize } = pageParams(req, 25);
      res.json(await runtime.orders.listOrders({
        status: String(req.query.status || 'all'),
        query: String(req.query.query || ''),
        page,
        pageSize,
      }));
    } catch (error) {
      next(error);
    }
  });

  app.get('/v1/admin/orders/:id', requireAuth, async (req, res, next) => {
    try {
      res.json(await runtime.orders.orderDetail(orderId(req)));
    } catch (error) {
      next(error);
    }
  });

  app.post('/v1/admin/orders/:id/sync', requireAuth, adminOnly, (req, res, next) => {
    try {
      orderId(req);
      throw new AppError(
        'Los pagos están desactivados en el servidor local. No hay nada que sincronizar.',
        409,
        'payments_disabled',
      );
    } catch (error) {
      next(error);
    }
  });

  app.get('/v1/admin/transactions', requireAuth, async (req, res, next) => {
    try {
      const { page, pageSize } = pageParams(req, 50);
      res.json(await runtime.orders.listTransactions({ page, pageSize }));
    } catch (error) {
      next(error);
    }
  });

  app.get('/v1/admin/audit', requireAuth, async (req, res, next) => {
    try {
      const { page, pageSize } = pageParams(req, 50);
      res.json(await runtime.audit.list({ page, pageSize }));
    } catch (error) {
      next(error);
    }
  });

  app.get('/v1/admin/revocations', requireAuth, async (req, res, next) => {
    try {
      const current = await runtime.licenses.revocationList();
      res.status(200);
      res.setHeader('Content-Type', 'application/json; charset=utf-8');
      res.setHeader('Content-Disposition', `attachment; filename="perfillab-revocaciones-${dateForFile()}.json"`);
      res.setHeader('Content-Length', Buffer.byteLength(current.body, 'utf8'));
      res.end(current.body);
    } catch (error) {
      next(error);
    }
  });

  async function activateHandler(req, res, next) {
    try {
      limiter.consume(
        'activation-ip',
        clientIp(req, false),
        config.activationAttemptsPerIp,
        config.activationWindowMs,
      );
      const result = await runtime.licenses.activate({
        licenseKey: stringField(req.body, 'licenseKey', { max: 64, required: true }),
        machineCode: stringField(req.body, 'machineCode', { max: 32, required: true }),
        machineName: stringField(req.body, 'machineName', { max: 80 }),
        ip: clientIp(req, false),
      });
      res.json({ ...result, serverTime: new Date().toISOString() });
    } catch (error) {
      next(error);
    }
  }

  async function validateHandler(req, res, next) {
    try {
      limiter.consume('validate-ip', clientIp(req, false), 120, 15 * 60 * 1000);
      res.json(await runtime.licenses.validate({
        licenseKey: stringField(req.body, 'licenseKey', { max: 64, required: true }),
        machineCode: stringField(req.body, 'machineCode', { max: 32 }),
      }));
    } catch (error) {
      next(error);
    }
  }

  async function revocationsHandler(req, res, next) {
    try {
      limiter.consume('revocations-ip', clientIp(req, false), 300, 15 * 60 * 1000);
      const current = await runtime.licenses.revocationList();
      res.setHeader('ETag', current.etag);
      res.setHeader('Cache-Control', 'no-cache');
      if (String(req.headers['if-none-match'] || '').trim() === current.etag) {
        res.status(304).end();
        return;
      }
      res.status(200);
      res.setHeader('Content-Type', 'application/json; charset=utf-8');
      res.setHeader('Content-Length', Buffer.byteLength(current.body, 'utf8'));
      res.end(current.body);
    } catch (error) {
      next(error);
    }
  }

  for (const prefix of ['/v1/license', '/api/license']) {
    app.post(`${prefix}/activate`, activateHandler);
    app.post(`${prefix}/validate`, validateHandler);
    app.get(`${prefix}/revocations`, revocationsHandler);
  }

  app.use((req, res) => {
    res.status(404).json({
      error: {
        message: 'El recurso solicitado no existe.',
        code: 'not_found',
        details: null,
      },
    });
  });

  app.use((error, req, res, next) => {
    if (res.headersSent) {
      next(error);
      return;
    }
    if (error && error.type === 'entity.parse.failed') {
      error = new AppError('La solicitud no contiene JSON válido.', 400, 'invalid_json');
    } else if (error && error.type === 'entity.too.large') {
      error = new AppError('La solicitud es demasiado grande.', 413, 'payload_too_large');
    }
    const { status, body } = errorPayload(error);
    if (Number(error && error.retryAfter) > 0) res.setHeader('Retry-After', String(error.retryAfter));
    if (status >= 500) logger.error('Error procesando solicitud local', { code: body.error.code });
    res.status(status).json(body);
  });

  return app;
}

module.exports = { createLocalRuntime, createLocalApp };
