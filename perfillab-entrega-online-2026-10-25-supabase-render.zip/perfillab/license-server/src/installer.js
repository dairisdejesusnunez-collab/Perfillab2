'use strict';

const crypto = require('node:crypto');
const fs = require('node:fs');

class InstallerError extends Error {
  constructor(message, code = 'installer_unavailable') {
    super(message);
    this.name = 'InstallerError';
    this.code = code;
  }
}

function hashFile(filePath) {
  return new Promise((resolve, reject) => {
    const hash = crypto.createHash('sha256');
    const stream = fs.createReadStream(filePath);
    stream.on('error', reject);
    stream.on('data', (chunk) => hash.update(chunk));
    stream.on('end', () => resolve(hash.digest('hex')));
  });
}

class InstallerService {
  constructor({ config, logger }) {
    this.config = config;
    this.logger = logger;
    this.cache = null;
  }

  get settings() {
    return this.config.installer || { enabled: false, source: 'none' };
  }

  async fileStat() {
    const settings = this.settings;
    let stat;
    try {
      stat = await fs.promises.stat(settings.path);
    } catch {
      throw new InstallerError('El instalador configurado no está disponible en el servidor.', 'installer_missing');
    }
    if (!stat.isFile()) {
      throw new InstallerError('El instalador configurado no es un archivo.', 'installer_missing');
    }
    if (settings.sizeBytes && stat.size !== settings.sizeBytes) {
      throw new InstallerError(
        'El tamaño del instalador no coincide con PERFILLAB_INSTALLER_SIZE.',
        'installer_size_mismatch',
      );
    }
    return stat;
  }

  async fileSha256(stat) {
    const settings = this.settings;
    if (this.cache && this.cache.mtimeMs === stat.mtimeMs && this.cache.size === stat.size) {
      return this.cache.sha256;
    }
    const sha256 = await hashFile(settings.path);
    if (settings.sha256 && sha256 !== settings.sha256) {
      throw new InstallerError(
        'El SHA-256 del instalador no coincide con PERFILLAB_INSTALLER_SHA256.',
        'installer_checksum_mismatch',
      );
    }
    this.cache = { mtimeMs: stat.mtimeMs, size: stat.size, sha256 };
    return sha256;
  }

  async describe() {
    const settings = this.settings;
    if (!settings.enabled) {
      return { enabled: false, url: null, filename: null, version: null, sha256: null, sizeBytes: null };
    }
    if (settings.source === 'url') {
      return {
        enabled: true,
        url: '/descargar',
        source: 'url',
        filename: settings.filename,
        version: settings.version,
        sha256: settings.sha256,
        sizeBytes: settings.sizeBytes,
      };
    }
    const stat = await this.fileStat();
    const sha256 = await this.fileSha256(stat);
    return {
      enabled: true,
      url: '/descargar',
      source: 'file',
      filename: settings.filename,
      version: settings.version,
      sha256,
      sizeBytes: stat.size,
    };
  }

  async send(req, res) {
    const settings = this.settings;
    if (!settings.enabled) {
      throw new InstallerError('El instalador todavía no está publicado.', 'installer_unavailable');
    }
    res.setHeader('Cache-Control', 'no-store');
    res.setHeader('X-Robots-Tag', 'noindex, nofollow');
    if (settings.source === 'url') {
      res.statusCode = 302;
      res.setHeader('Location', settings.url);
      res.end();
      return;
    }
    const stat = await this.fileStat();
    const sha256 = await this.fileSha256(stat);
    res.statusCode = 200;
    res.setHeader('Content-Type', 'application/octet-stream');
    res.setHeader('Content-Length', stat.size);
    res.setHeader('Content-Disposition', `attachment; filename="${settings.filename.replace(/"/g, '')}"`);
    res.setHeader('ETag', `"${sha256}"`);
    res.setHeader('Digest', `sha-256=${Buffer.from(sha256, 'hex').toString('base64')}`);
    if (req.method === 'HEAD') {
      res.end();
      return;
    }
    await new Promise((resolve, reject) => {
      const stream = fs.createReadStream(settings.path);
      stream.on('error', reject);
      res.on('finish', resolve);
      res.on('close', resolve);
      stream.pipe(res);
    });
  }
}

module.exports = { InstallerService, InstallerError };
