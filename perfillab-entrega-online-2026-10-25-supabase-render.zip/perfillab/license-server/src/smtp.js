'use strict';

const crypto = require('node:crypto');
const net = require('node:net');
const os = require('node:os');
const tls = require('node:tls');

const { isValidEmail, normalizeEmail } = require('./security');

class SmtpError extends Error {
  constructor(message, options = {}) {
    super(message);
    this.name = 'SmtpError';
    this.code = options.code || 'smtp_error';
    this.retryable = Boolean(options.retryable);
    this.status = options.status || 0;
  }
}

function parseAddress(input) {
  const raw = String(input || '').replace(/[\r\n]/g, ' ').trim();
  if (!raw) return null;
  let name = '';
  let address = raw;
  const angled = /^(.*?)<([^<>]+)>$/.exec(raw);
  if (angled) {
    name = angled[1].trim().replace(/^"(.*)"$/, '$1').trim();
    address = angled[2].trim();
  }
  if (!isValidEmail(address)) return null;
  return { name, address: normalizeEmail(address) };
}

function encodeName(value) {
  const text = String(value || '').replace(/[\r\n]/g, ' ').trim();
  if (!text) return '';
  if (/^[\x20-\x7E]+$/.test(text) && !/["\\]/.test(text)) return `"${text}"`;
  return `=?UTF-8?B?${Buffer.from(text, 'utf8').toString('base64')}?=`;
}

function encodeSubject(value) {
  const text = String(value || '').replace(/[\r\n]+/g, ' ').trim();
  if (/^[\x20-\x7E]*$/.test(text)) return text;
  return `=?UTF-8?B?${Buffer.from(text, 'utf8').toString('base64')}?=`;
}

function formatMailbox(parsed) {
  return parsed.name ? `${encodeName(parsed.name)} <${parsed.address}>` : parsed.address;
}

function wrapBase64(buffer) {
  return (buffer.toString('base64').match(/.{1,76}/g) || ['']).join('\r\n');
}

function dotStuff(value) {
  const normalized = String(value).replace(/\r?\n/g, '\r\n');
  const stuffed = normalized.replace(/^\./gm, '..');
  return `${stuffed.endsWith('\r\n') ? stuffed : `${stuffed}\r\n`}.\r\n`;
}

function buildMimeMessage({ from, to, subject, text, html, messageId }) {
  const fromParsed = parseAddress(from);
  const toParsed = parseAddress(to);
  if (!fromParsed || !toParsed) throw new SmtpError('Dirección de correo no válida.', { code: 'smtp_address' });
  const boundary = `perfillab-${crypto.randomBytes(12).toString('hex')}`;
  const domain = fromParsed.address.split('@')[1] || 'localhost';
  const id = messageId || `<${crypto.randomUUID()}@${domain}>`;
  const headers = [
    `From: ${formatMailbox(fromParsed)}`,
    `To: ${formatMailbox(toParsed)}`,
    `Subject: ${encodeSubject(subject)}`,
    `Date: ${new Date().toUTCString()}`,
    `Message-ID: ${id}`,
    'MIME-Version: 1.0',
    `Content-Type: multipart/alternative; boundary="${boundary}"`,
    'Auto-Submitted: auto-generated',
    'X-Auto-Response-Suppress: All',
  ];
  const textPart = [
    `--${boundary}`,
    'Content-Type: text/plain; charset=utf-8',
    'Content-Transfer-Encoding: base64',
    '',
    wrapBase64(Buffer.from(String(text || ''), 'utf8')),
  ];
  const htmlPart = [
    `--${boundary}`,
    'Content-Type: text/html; charset=utf-8',
    'Content-Transfer-Encoding: base64',
    '',
    wrapBase64(Buffer.from(String(html || ''), 'utf8')),
  ];
  return `${headers.join('\r\n')}\r\n\r\n${textPart.join('\r\n')}\r\n${htmlPart.join('\r\n')}\r\n--${boundary}--\r\n`;
}

class SmtpConnection {
  constructor(socket, timeoutMs) {
    this.socket = socket;
    this.buffer = '';
    this.current = null;
    this.queue = [];
    this.waiters = [];
    this.error = null;
    this.detached = false;
    this.closed = false;
    socket.setTimeout(timeoutMs);
    socket.on('data', (chunk) => this.onData(chunk));
    socket.on('error', (error) => this.fail(new SmtpError('Error de conexión SMTP.', {
      code: 'smtp_network',
      retryable: true,
      status: 0,
    })));
    socket.on('close', () => {
      this.closed = true;
      if (!this.detached && !this.endedCleanly && !this.error) {
        this.fail(new SmtpError('El servidor SMTP cerró la conexión.', { code: 'smtp_closed', retryable: true }));
      }
    });
    socket.on('timeout', () => {
      this.fail(new SmtpError('Tiempo de espera agotado con el servidor SMTP.', { code: 'smtp_timeout', retryable: true }));
    });
  }

  onData(chunk) {
    if (this.detached) return;
    this.buffer += chunk.toString('utf8');
    while (true) {
      const index = this.buffer.indexOf('\n');
      if (index < 0) break;
      let line = this.buffer.slice(0, index);
      this.buffer = this.buffer.slice(index + 1);
      if (line.endsWith('\r')) line = line.slice(0, -1);
      if (!line) continue;
      const match = /^(\d{3})([ -])(.*)$/.exec(line);
      if (!match) {
        this.fail(new SmtpError('El servidor SMTP devolvió una respuesta no válida.', { code: 'smtp_protocol' }));
        return;
      }
      if (!this.current) this.current = { code: Number(match[1]), lines: [] };
      if (this.current.code !== Number(match[1])) {
        this.fail(new SmtpError('El servidor SMTP devolvió una respuesta incoherente.', { code: 'smtp_protocol' }));
        return;
      }
      this.current.lines.push(match[3]);
      if (match[2] === ' ') {
        const response = this.current;
        this.current = null;
        this.deliver(response);
      }
    }
  }

  deliver(response) {
    const waiter = this.waiters.shift();
    if (waiter) waiter.resolve(response);
    else this.queue.push(response);
  }

  fail(error) {
    if (this.error) return;
    this.error = error;
    while (this.waiters.length) this.waiters.shift().reject(error);
  }

  readResponse() {
    if (this.queue.length) return Promise.resolve(this.queue.shift());
    if (this.error) return Promise.reject(this.error);
    return new Promise((resolve, reject) => {
      this.waiters.push({ resolve, reject });
    });
  }

  send(line) {
    if (this.error) throw this.error;
    this.socket.write(`${line}\r\n`);
  }

  sendData(value) {
    if (this.error) throw this.error;
    this.socket.write(dotStuff(value));
  }

  detach() {
    this.detached = true;
    this.socket.removeAllListeners('data');
    this.socket.removeAllListeners('error');
    this.socket.removeAllListeners('close');
    this.socket.removeAllListeners('timeout');
    this.socket.setTimeout(0);
    return this.socket;
  }

  end() {
    try {
      this.endedCleanly = true;
      this.socket.end();
    } catch {
      // Cierre best-effort.
    }
  }

  destroy() {
    try {
      this.socket.destroy();
    } catch {
      // Cierre best-effort.
    }
  }
}

function connectPlain(host, port, timeoutMs) {
  return new Promise((resolve, reject) => {
    const socket = net.connect({ host, port });
    const timer = setTimeout(() => {
      socket.destroy();
      reject(new SmtpError('No se pudo conectar con el servidor SMTP.', { code: 'smtp_timeout', retryable: true }));
    }, timeoutMs);
    socket.once('connect', () => {
      clearTimeout(timer);
      socket.removeListener('error', onError);
      resolve(socket);
    });
    const onError = () => {
      clearTimeout(timer);
      reject(new SmtpError('No se pudo conectar con el servidor SMTP.', { code: 'smtp_network', retryable: true }));
    };
    socket.once('error', onError);
  });
}

function connectTls({ host, port, timeoutMs, servername = host }) {
  return new Promise((resolve, reject) => {
    const socket = tls.connect({ host, port, servername, rejectUnauthorized: true });
    const timer = setTimeout(() => {
      socket.destroy();
      reject(new SmtpError('No se pudo conectar con el servidor SMTP seguro.', { code: 'smtp_timeout', retryable: true }));
    }, timeoutMs);
    socket.once('secureConnect', () => {
      clearTimeout(timer);
      socket.removeListener('error', onError);
      resolve(socket);
    });
    const onError = () => {
      clearTimeout(timer);
      reject(new SmtpError('No se pudo establecer TLS con el servidor SMTP.', { code: 'smtp_tls', retryable: true }));
    };
    socket.once('error', onError);
  });
}

function upgradeTls(socket, host, timeoutMs) {
  return new Promise((resolve, reject) => {
    const secureSocket = tls.connect({ socket, servername: host, rejectUnauthorized: true });
    const timer = setTimeout(() => {
      secureSocket.destroy();
      reject(new SmtpError('Tiempo de espera agotado al iniciar TLS.', { code: 'smtp_timeout', retryable: true }));
    }, timeoutMs);
    secureSocket.once('secureConnect', () => {
      clearTimeout(timer);
      secureSocket.removeListener('error', onError);
      resolve(secureSocket);
    });
    const onError = () => {
      clearTimeout(timer);
      reject(new SmtpError('No se pudo iniciar TLS con el servidor SMTP.', { code: 'smtp_tls', retryable: true }));
    };
    secureSocket.once('error', onError);
  });
}

function failureFor(response, context) {
  const code = response ? response.code : 0;
  if (code === 421) return new SmtpError('El servidor SMTP no está disponible.', { code: 'smtp_unavailable', retryable: true, status: code });
  return new SmtpError(`El servidor SMTP rechazó ${context}.`, {
    code: 'smtp_rejected',
    retryable: code >= 400 && code < 500,
    status: code,
  });
}

function expect(response, allowed, context) {
  if (!allowed.includes(response.code)) throw failureFor(response, context);
  return response;
}

function extensionInfo(response) {
  const names = new Set();
  const auth = new Set();
  for (const raw of response.lines) {
    const line = raw.trim();
    const name = line.split(/\s+/)[0];
    if (!name) continue;
    const upper = name.toUpperCase();
    if (upper === 'AUTH') {
      for (const method of line.slice(4).trim().split(/\s+/)) {
        if (method) auth.add(method.toUpperCase());
      }
    } else if (upper.startsWith('AUTH=')) {
      auth.add(upper.slice(5));
    } else {
      names.add(upper);
    }
  }
  return { names, auth };
}

class SmtpMailer {
  constructor(config, logger) {
    this.config = config;
    this.logger = logger;
    this.timeoutMs = 20_000;
    this.from = config && config.host ? parseAddress(config.from) : null;
    this.envelopeFrom = config && config.host
      ? parseAddress(config.envelopeFrom || config.from)
      : null;
    if (config && config.host && (!this.from || !this.envelopeFrom)) {
      throw new SmtpError('PERFILLAB_MAIL_FROM no es una dirección válida.', { code: 'smtp_config' });
    }
    this.enabled = Boolean(config && config.host && this.from);
  }

  async ehlo(connection) {
    const hostname = String(os.hostname() || 'localhost').replace(/[^A-Za-z0-9.-]/g, '') || 'localhost';
    connection.send(`EHLO ${hostname}`);
    const response = await connection.readResponse();
    expect(response, [250], 'EHLO');
    return extensionInfo(response);
  }

  async authenticate(connection, extensions) {
    const user = this.config.user;
    const pass = this.config.pass;
    if (!user && !pass) return;
    if (!user || !pass) throw new SmtpError('Las credenciales SMTP están incompletas.', { code: 'smtp_auth_config' });
    if (extensions.auth.size === 0) {
      throw new SmtpError('El servidor SMTP no admite autenticación compatible.', { code: 'smtp_auth_unsupported' });
    }
    if (extensions.auth.has('PLAIN')) {
      const payload = Buffer.from(`\0${user}\0${pass}`, 'utf8').toString('base64');
      connection.send(`AUTH PLAIN ${payload}`);
      expect(await connection.readResponse(), [235], 'AUTH PLAIN');
      return;
    }
    if (extensions.auth.has('LOGIN')) {
      connection.send('AUTH LOGIN');
      expect(await connection.readResponse(), [334], 'AUTH LOGIN');
      connection.send(Buffer.from(user, 'utf8').toString('base64'));
      expect(await connection.readResponse(), [334], 'AUTH LOGIN usuario');
      connection.send(Buffer.from(pass, 'utf8').toString('base64'));
      expect(await connection.readResponse(), [235], 'AUTH LOGIN contraseña');
      return;
    }
    throw new SmtpError('El servidor SMTP no admite un método de autenticación compatible.', { code: 'smtp_auth_unsupported' });
  }

  async send({ to, subject, text, html }) {
    if (!this.enabled) throw new SmtpError('El envío de correo no está configurado.', { code: 'smtp_disabled' });
    const recipient = parseAddress(to);
    if (!recipient) throw new SmtpError('El destinatario del correo no es válido.', { code: 'smtp_address' });
    const message = buildMimeMessage({
      from: this.config.from,
      to: formatMailbox(recipient),
      subject,
      text,
      html,
    });
    let connection = null;
    try {
      if (this.config.secure === 'tls') {
        connection = new SmtpConnection(
          await connectTls({ host: this.config.host, port: this.config.port, timeoutMs: this.timeoutMs }),
          this.timeoutMs,
        );
      } else {
        connection = new SmtpConnection(
          await connectPlain(this.config.host, this.config.port, this.timeoutMs),
          this.timeoutMs,
        );
      }
      expect(await connection.readResponse(), [220], 'la conexión');
      let extensions = await this.ehlo(connection);
      if (this.config.secure === 'starttls') {
        if (!extensions.names.has('STARTTLS')) {
          throw new SmtpError('El servidor SMTP no ofrece STARTTLS; no se enviarán credenciales sin cifrar.', {
            code: 'smtp_starttls_unavailable',
          });
        }
        connection.send('STARTTLS');
        expect(await connection.readResponse(), [220], 'STARTTLS');
        const socket = connection.detach();
        const secureSocket = await upgradeTls(socket, this.config.host, this.timeoutMs);
        connection = new SmtpConnection(secureSocket, this.timeoutMs);
        extensions = await this.ehlo(connection);
      }
      await this.authenticate(connection, extensions);
      connection.send(`MAIL FROM:<${this.envelopeFrom.address}>`);
      expect(await connection.readResponse(), [250], 'MAIL FROM');
      connection.send(`RCPT TO:<${recipient.address}>`);
      expect(await connection.readResponse(), [250, 251], 'RCPT TO');
      connection.send('DATA');
      expect(await connection.readResponse(), [354], 'DATA');
      connection.sendData(message);
      expect(await connection.readResponse(), [250], 'el mensaje');
      connection.send('QUIT');
      try {
        await connection.readResponse();
      } catch {
        // El QUIT no determina el resultado del envío.
      }
      connection.end();
      return { accepted: true };
    } catch (error) {
      if (connection) connection.destroy();
      if (error instanceof SmtpError) throw error;
      throw new SmtpError('No se pudo enviar el correo.', { code: 'smtp_error', retryable: true });
    }
  }
}

module.exports = {
  SmtpMailer,
  SmtpError,
  buildMimeMessage,
  dotStuff,
  parseAddress,
  wrapBase64,
};
