'use strict';

class AppError extends Error {
  constructor(message, status = 400, code = 'bad_request', options = {}) {
    super(message);
    this.name = 'AppError';
    this.status = status;
    this.code = code;
    this.expose = options.expose !== false;
    this.details = options.details || null;
    this.cause = options.cause;
  }
}

function badRequest(message, code = 'invalid_input') {
  return new AppError(message, 400, code);
}

function unauthorized(message = 'No autorizado.', code = 'unauthorized') {
  return new AppError(message, 401, code);
}

function forbidden(message = 'Acceso denegado.', code = 'forbidden') {
  return new AppError(message, 403, code);
}

function notFound(message = 'No encontrado.', code = 'not_found') {
  return new AppError(message, 404, code);
}

function conflict(message, code = 'conflict') {
  return new AppError(message, 409, code);
}

function tooMany(message = 'Demasiados intentos. Inténtalo más tarde.', code = 'rate_limited') {
  return new AppError(message, 429, code);
}

function unavailable(message, code = 'unavailable') {
  return new AppError(message, 503, code);
}

module.exports = {
  AppError,
  badRequest,
  unauthorized,
  forbidden,
  notFound,
  conflict,
  tooMany,
  unavailable,
};
