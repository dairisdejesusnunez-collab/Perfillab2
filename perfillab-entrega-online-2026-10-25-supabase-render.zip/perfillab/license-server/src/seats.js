'use strict';

const crypto = require('node:crypto');
const fs = require('node:fs');

const { HISTORICAL_LICENSE_LIMIT, keyIdFor } = require('./license-format');
const {
  encryptField,
  keyHash,
  randomToken,
  hashPassword,
  groupCode,
  nowIso,
} = require('./security');
const {
  openKeystore,
  openKeystoreFromBase64,
  createKeystoreFile,
  writeKeystoreAtomic,
} = require('./keystore');

const LICENSE_ALPHABET = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
const SEAT_INSERT_COLUMNS = [
  'seat',
  'license_id',
  'key_hash',
  'key_enc',
  'source',
  'reserved_order_id',
  'reserved_at',
  'created_at',
  'allocated_at',
];
const LICENSE_INSERT_COLUMNS = [
  'id',
  'seat',
  'key_hash',
  'customer_id',
  'customer_name',
  'email',
  'product',
  'plan',
  'status',
  'license_version',
  'machine_code',
  'machine_name',
  'transaction_id',
  'notes',
  'issued_at',
  'starts_at',
  'expires_at',
  'activated_at',
  'revoked_at',
  'revoked_reason',
  'suspended_at',
  'suspended_reason',
  'created_at',
  'updated_at',
];

class InitializationError extends Error {
  constructor(message) {
    super(message);
    this.name = 'InitializationError';
    this.code = 'initialization_error';
  }
}

function generateLicenseKeys(count, usedKeys = new Set()) {
  if (!Number.isInteger(count) || count < 0) throw new Error('Cantidad de claves no válida.');
  const added = [];
  let candidate = '';
  while (added.length < count) {
    const bytes = crypto.randomBytes(4096);
    for (const byte of bytes) {
      if (byte >= 252) continue;
      candidate += LICENSE_ALPHABET[byte % 36];
      if (candidate.length < 16) continue;
      const key = groupCode(candidate);
      candidate = '';
      if (!usedKeys.has(key)) {
        usedKeys.add(key);
        added.push(key);
        if (added.length === count) break;
      }
    }
  }
  return added;
}

function uniqueLicenseId(seat, existingIds) {
  let id = `PL-${String(seat).padStart(5, '0')}`;
  while (existingIds.has(id)) id = `PL-${String(seat).padStart(5, '0')}-${randomToken(3)}`;
  existingIds.add(id);
  return id;
}

function validateAdminCredentials({ username, password }) {
  const user = String(username || '').trim();
  if (!/^[A-Za-z0-9._-]{3,64}$/.test(user)) {
    throw new InitializationError('El usuario administrador debe tener entre 3 y 64 caracteres (letras, números, punto, guion o guion bajo).');
  }
  const pass = String(password || '');
  if (pass.length < 12) throw new InitializationError('La contraseña del administrador debe tener al menos 12 caracteres.');
  if (pass.length > 200) throw new InitializationError('La contraseña del administrador es demasiado larga.');
  return { username: user, password: pass };
}

async function seedDatabase({
  db,
  vault,
  keystore,
  admin,
  now = nowIso(),
}) {
  const legacyBySeat = new Map(vault.seats.map((seat) => [seat.seat, seat]));
  const usedKeys = new Set(vault.seats.map((seat) => seat.key));
  const existingIds = new Set(vault.seats.map((seat) => seat.id));
  const generatedCount = HISTORICAL_LICENSE_LIMIT - legacyBySeat.size;
  const generatedKeys = generateLicenseKeys(generatedCount, usedKeys);
  let generatedIndex = 0;

  const issuedLegacy = vault.seats.filter((seat) => seat.status === 'issued');
  const activeByMachine = new Map();
  for (const seat of issuedLegacy) {
    const expiresAt = seat.expiresAt ? Date.parse(seat.expiresAt) : null;
    if (expiresAt && expiresAt <= Date.now()) continue;
    if (activeByMachine.has(seat.machineCode)) {
      throw new InitializationError(
        'La bóveda contiene más de una licencia vigente para el mismo código de equipo. '
        + 'Resuélvelo en el administrador anterior antes de migrar; no se modificó ningún dato.',
      );
    }
    activeByMachine.set(seat.machineCode, seat.id);
  }

  const seatRows = [];
  const licenseRows = [];
  for (let seatNumber = 1; seatNumber <= HISTORICAL_LICENSE_LIMIT; seatNumber += 1) {
    const legacy = legacyBySeat.get(seatNumber);
    const key = legacy ? legacy.key : generatedKeys[generatedIndex++];
    const issued = Boolean(legacy && legacy.status === 'issued');
    const licenseId = issued ? legacy.id : null;
    const allocatedAt = issued ? legacy.issuedAt : null;
    seatRows.push([
      seatNumber,
      licenseId,
      keyHash(keystore.dataKey, key),
      encryptField(key, keystore.dataKey, `seat:${seatNumber}`),
      legacy ? 'legacy' : 'generated',
      null,
      null,
      now,
      allocatedAt,
    ]);
    if (issued) {
      const expired = legacy.expiresAt ? Date.parse(legacy.expiresAt) <= Date.now() : false;
      licenseRows.push([
        legacy.id,
        seatNumber,
        keyHash(keystore.dataKey, key),
        null,
        legacy.customer,
        null,
        'perfillab',
        'annual',
        expired ? 'expired' : 'active',
        1,
        legacy.machineCode,
        null,
        null,
        legacy.notes,
        legacy.issuedAt,
        legacy.issuedAt,
        legacy.expiresAt,
        legacy.issuedAt,
        null,
        null,
        null,
        null,
        legacy.issuedAt,
        legacy.issuedAt,
      ]);
    }
  }

  await db.transaction(async () => {
    await db.insertMany('seats', SEAT_INSERT_COLUMNS, seatRows, { chunkSize: 2000 });
    if (licenseRows.length) {
      await db.insertMany('licenses', LICENSE_INSERT_COLUMNS, licenseRows, { chunkSize: 500 });
    }

    await db.setSetting('initialized_at', now, now);
    await db.setSetting('seat_limit', String(HISTORICAL_LICENSE_LIMIT), now);
    await db.setSetting('legacy_seats', String(vault.seats.length), now);
    await db.setSetting('legacy_issued', String(issuedLegacy.length), now);
    await db.setSetting('key_id', keystore.keyId, now);
    await db.setSetting('public_key', keystore.publicKey, now);
    await db.setSetting('revocation_changed_at', now, now);
    await db.setSetting('product', 'perfillab', now);
    await db.setSetting('plan', 'annual', now);

    if (admin) {
      await db.run(
        `INSERT INTO admin_users(id, username, password_hash, role, disabled, created_at, password_changed_at)
         VALUES (?, ?, ?, 'admin', 0, ?, ?)`,
        [crypto.randomUUID(), admin.username, hashPassword(admin.password), now, now],
      );
    }

    await db.run(
      `INSERT INTO audit_log(id, actor_type, actor_id, action, target_type, target_id, details, ip, created_at)
       VALUES (?, 'system', NULL, 'server.initialized', 'server', NULL, ?, NULL, ?)`,
      [crypto.randomUUID(), JSON.stringify({
        seats: HISTORICAL_LICENSE_LIMIT,
        legacySeats: vault.seats.length,
        legacyIssued: issuedLegacy.length,
        keyId: keystore.keyId,
        adminCreated: Boolean(admin),
      }), now],
    );
  });

  return {
    seats: HISTORICAL_LICENSE_LIMIT,
    legacySeats: vault.seats.length,
    legacyIssued: issuedLegacy.length,
    generatedSeats: generatedCount,
    available: HISTORICAL_LICENSE_LIMIT - issuedLegacy.length,
    keyId: keystore.keyId,
    publicKey: keystore.publicKey,
    adminCreated: Boolean(admin),
    initializedAt: now,
  };
}

async function initializeServer({
  db,
  vault,
  keystorePath,
  keystorePassphrase,
  keystoreBase64,
  admin,
}) {
  if (!db || !vault) throw new InitializationError('Faltan dependencias para inicializar el servidor.');
  const existingSeats = await db.count('seats');
  if (existingSeats > 0) {
    throw new InitializationError('La base de datos ya está inicializada. No se modificó ningún dato.');
  }
  let keystore;
  let keystoreSource;
  if (keystoreBase64) {
    keystore = openKeystoreFromBase64(keystoreBase64, keystorePassphrase);
    keystoreSource = 'env';
  } else if (fs.existsSync(keystorePath)) {
    keystore = openKeystore(keystorePath, keystorePassphrase);
    keystoreSource = 'file';
  } else {
    const file = createKeystoreFile({
      privateKey: vault.privateKey,
      publicKey: vault.publicKey,
      passphrase: keystorePassphrase,
    });
    writeKeystoreAtomic(keystorePath, file);
    keystore = openKeystore(keystorePath, keystorePassphrase);
    keystoreSource = 'created';
  }
  if (keystoreSource !== 'created' && keystore.publicKey !== vault.publicKey) {
    throw new InitializationError(
      'El keystore existente usa una clave distinta a la bóveda. '
      + 'Restaura el keystore correcto o usa otra base de datos; no se sobrescribió nada.',
    );
  }
  if (keyIdFor(keystore.publicKey) !== keystore.keyId) {
    throw new InitializationError('El keystore no tiene un identificador de clave coherente.');
  }
  const validatedAdmin = admin ? validateAdminCredentials(admin) : null;
  const summary = await seedDatabase({ db, vault, keystore, admin: validatedAdmin });
  return {
    ...summary,
    keystoreCreated: keystoreSource === 'created',
    keystoreSource,
    dbPath: db.filePath || null,
    database: db.dialect,
    keystorePath: keystoreSource === 'env' ? null : keystorePath,
  };
}

async function assertServerInitialized(db) {
  const seats = await db.count('seats');
  if (seats !== HISTORICAL_LICENSE_LIMIT) {
    throw new InitializationError(`El registro debe contener ${HISTORICAL_LICENSE_LIMIT} asientos; contiene ${seats}.`);
  }
  const initializedAt = await db.getSetting('initialized_at', '');
  if (!initializedAt) throw new InitializationError('La base de datos no está marcada como inicializada.');
  const badRow = await db.get(
    `SELECT COUNT(*) AS n FROM seats
     WHERE key_hash IS NULL OR key_enc IS NULL OR length(key_hash) < 32 OR length(key_enc) < 16`,
  );
  const bad = Number(badRow ? badRow.n : 0);
  if (bad) throw new InitializationError(`Hay ${bad} asientos con datos de clave inválidos.`);
  return {
    seats,
    keyId: await db.getSetting('key_id', ''),
    initializedAt,
  };
}

module.exports = {
  InitializationError,
  LICENSE_ALPHABET,
  SEAT_INSERT_COLUMNS,
  LICENSE_INSERT_COLUMNS,
  generateLicenseKeys,
  uniqueLicenseId,
  validateAdminCredentials,
  initializeServer,
  seedDatabase,
  assertServerInitialized,
};
