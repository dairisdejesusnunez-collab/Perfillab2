'use strict';

const crypto = require('node:crypto');
const fs = require('node:fs');
const path = require('node:path');
const { AsyncLocalStorage } = require('node:async_hooks');
const { DatabaseSync } = require('node:sqlite');

const SCHEMA_VERSION = 2;
const PG_PARAM_LIMIT = 60_000;
const SQLITE_PARAM_LIMIT = 30_000;

const SQLITE_MIGRATIONS = [
  {
    version: 1,
    sql: `
      CREATE TABLE settings (
        key TEXT PRIMARY KEY,
        value TEXT NOT NULL,
        updated_at TEXT NOT NULL
      );

      CREATE TABLE admin_users (
        id TEXT PRIMARY KEY,
        username TEXT NOT NULL UNIQUE COLLATE NOCASE,
        password_hash TEXT NOT NULL,
        role TEXT NOT NULL DEFAULT 'admin' CHECK (role IN ('admin', 'operator')),
        disabled INTEGER NOT NULL DEFAULT 0 CHECK (disabled IN (0, 1)),
        created_at TEXT NOT NULL,
        password_changed_at TEXT NOT NULL,
        last_login_at TEXT
      );

      CREATE TABLE admin_sessions (
        token_hash TEXT PRIMARY KEY,
        user_id TEXT NOT NULL REFERENCES admin_users(id) ON DELETE CASCADE,
        created_at TEXT NOT NULL,
        last_seen_at TEXT NOT NULL,
        expires_at TEXT NOT NULL,
        ip TEXT,
        user_agent TEXT
      );
      CREATE INDEX idx_admin_sessions_user ON admin_sessions(user_id);
      CREATE INDEX idx_admin_sessions_expires ON admin_sessions(expires_at);

      CREATE TABLE customers (
        id TEXT PRIMARY KEY,
        email TEXT NOT NULL UNIQUE COLLATE NOCASE,
        name TEXT NOT NULL DEFAULT '',
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL
      );

      CREATE TABLE seats (
        seat INTEGER PRIMARY KEY CHECK (seat >= 1 AND seat <= 50000),
        license_id TEXT UNIQUE,
        key_hash TEXT NOT NULL UNIQUE,
        key_enc TEXT NOT NULL,
        source TEXT NOT NULL CHECK (source IN ('legacy', 'generated')),
        reserved_order_id TEXT,
        reserved_at TEXT,
        created_at TEXT NOT NULL,
        allocated_at TEXT
      );
      CREATE INDEX idx_seats_available ON seats(license_id, reserved_order_id, seat);
      CREATE INDEX idx_seats_reserved ON seats(reserved_order_id);

      CREATE TABLE licenses (
        id TEXT PRIMARY KEY,
        seat INTEGER NOT NULL UNIQUE REFERENCES seats(seat),
        key_hash TEXT NOT NULL UNIQUE,
        customer_id TEXT REFERENCES customers(id) ON DELETE SET NULL,
        customer_name TEXT NOT NULL,
        email TEXT,
        product TEXT NOT NULL,
        plan TEXT NOT NULL,
        status TEXT NOT NULL CHECK (status IN ('pending', 'active', 'expired', 'revoked', 'suspended')),
        license_version INTEGER NOT NULL DEFAULT 2 CHECK (license_version IN (1, 2)),
        machine_code TEXT,
        machine_name TEXT,
        transaction_id TEXT UNIQUE,
        notes TEXT NOT NULL DEFAULT '',
        issued_at TEXT NOT NULL,
        starts_at TEXT NOT NULL,
        expires_at TEXT,
        activated_at TEXT,
        revoked_at TEXT,
        revoked_reason TEXT,
        suspended_at TEXT,
        suspended_reason TEXT,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL
      );
      CREATE UNIQUE INDEX idx_licenses_active_machine
        ON licenses(machine_code)
        WHERE machine_code IS NOT NULL AND status = 'active';
      CREATE INDEX idx_licenses_status ON licenses(status, issued_at DESC);
      CREATE INDEX idx_licenses_issued ON licenses(issued_at DESC);
      CREATE INDEX idx_licenses_email ON licenses(email COLLATE NOCASE);
      CREATE INDEX idx_licenses_customer ON licenses(customer_name COLLATE NOCASE);
      CREATE INDEX idx_licenses_expires ON licenses(expires_at);

      CREATE TABLE orders (
        id TEXT PRIMARY KEY,
        token_hash TEXT NOT NULL UNIQUE,
        email TEXT NOT NULL COLLATE NOCASE,
        customer_name TEXT NOT NULL DEFAULT '',
        status TEXT NOT NULL CHECK (status IN ('created', 'pending', 'paid', 'failed', 'cancelled', 'refunded', 'expired')),
        paypal_order_id TEXT UNIQUE,
        approval_url TEXT,
        amount_cents INTEGER NOT NULL CHECK (amount_cents > 0),
        currency TEXT NOT NULL,
        product TEXT NOT NULL,
        plan TEXT NOT NULL,
        license_id TEXT UNIQUE REFERENCES licenses(id),
        payer_email TEXT,
        failure_reason TEXT,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL,
        paid_at TEXT,
        refunded_at TEXT,
        completed_at TEXT
      );
      CREATE INDEX idx_orders_status ON orders(status, created_at DESC);
      CREATE INDEX idx_orders_email ON orders(email, created_at DESC);
      CREATE INDEX idx_orders_created ON orders(created_at);

      CREATE TABLE transactions (
        id TEXT PRIMARY KEY,
        kind TEXT NOT NULL CHECK (kind IN ('payment', 'refund')),
        provider TEXT NOT NULL,
        provider_id TEXT NOT NULL UNIQUE,
        order_id TEXT REFERENCES orders(id) ON DELETE SET NULL,
        license_id TEXT REFERENCES licenses(id) ON DELETE SET NULL,
        amount_cents INTEGER NOT NULL,
        currency TEXT NOT NULL,
        status TEXT NOT NULL,
        created_at TEXT NOT NULL
      );
      CREATE INDEX idx_transactions_created ON transactions(created_at DESC);
      CREATE INDEX idx_transactions_license ON transactions(license_id);

      CREATE TABLE webhook_events (
        id TEXT PRIMARY KEY,
        event_type TEXT NOT NULL,
        resource_id TEXT,
        order_id TEXT,
        status TEXT NOT NULL CHECK (status IN ('processing', 'processed', 'failed', 'ignored')),
        error TEXT,
        received_at TEXT NOT NULL,
        processed_at TEXT
      );
      CREATE INDEX idx_webhook_events_received ON webhook_events(received_at DESC);

      CREATE TABLE email_outbox (
        id TEXT PRIMARY KEY,
        license_id TEXT REFERENCES licenses(id) ON DELETE CASCADE,
        order_id TEXT REFERENCES orders(id) ON DELETE SET NULL,
        to_email TEXT NOT NULL,
        kind TEXT NOT NULL,
        status TEXT NOT NULL CHECK (status IN ('queued', 'sending', 'sent', 'failed')),
        attempts INTEGER NOT NULL DEFAULT 0,
        last_error TEXT,
        next_attempt_at TEXT NOT NULL,
        created_at TEXT NOT NULL,
        sent_at TEXT
      );
      CREATE INDEX idx_email_outbox_pending ON email_outbox(status, next_attempt_at);
      CREATE INDEX idx_email_outbox_license ON email_outbox(license_id);

      CREATE TABLE audit_log (
        id TEXT PRIMARY KEY,
        actor_type TEXT NOT NULL,
        actor_id TEXT,
        action TEXT NOT NULL,
        target_type TEXT,
        target_id TEXT,
        details TEXT,
        ip TEXT,
        created_at TEXT NOT NULL
      );
      CREATE INDEX idx_audit_created ON audit_log(created_at DESC);
      CREATE INDEX idx_audit_action ON audit_log(action, created_at DESC);
    `,
  },
  {
    version: 2,
    sql: `
      ALTER TABLE orders ADD COLUMN duration_months INTEGER NOT NULL DEFAULT 12
        CHECK (duration_months >= 1 AND duration_months <= 60);
      UPDATE orders SET duration_months = CASE plan
        WHEN 'monthly' THEN 1
        WHEN 'semiannual' THEN 6
        ELSE 12
      END;
    `,
  },
];

const POSTGRES_MIGRATIONS = [
  {
    version: 1,
    sql: `
      CREATE TABLE settings (
        key TEXT PRIMARY KEY,
        value TEXT NOT NULL,
        updated_at TEXT NOT NULL
      );

      CREATE TABLE admin_users (
        id TEXT PRIMARY KEY,
        username TEXT NOT NULL,
        password_hash TEXT NOT NULL,
        role TEXT NOT NULL DEFAULT 'admin' CHECK (role IN ('admin', 'operator')),
        disabled INTEGER NOT NULL DEFAULT 0 CHECK (disabled IN (0, 1)),
        created_at TEXT NOT NULL,
        password_changed_at TEXT NOT NULL,
        last_login_at TEXT
      );
      CREATE UNIQUE INDEX idx_admin_users_username_lower ON admin_users(lower(username));

      CREATE TABLE admin_sessions (
        token_hash TEXT PRIMARY KEY,
        user_id TEXT NOT NULL REFERENCES admin_users(id) ON DELETE CASCADE,
        created_at TEXT NOT NULL,
        last_seen_at TEXT NOT NULL,
        expires_at TEXT NOT NULL,
        ip TEXT,
        user_agent TEXT
      );
      CREATE INDEX idx_admin_sessions_user ON admin_sessions(user_id);
      CREATE INDEX idx_admin_sessions_expires ON admin_sessions(expires_at);

      CREATE TABLE customers (
        id TEXT PRIMARY KEY,
        email TEXT NOT NULL,
        name TEXT NOT NULL DEFAULT '',
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL
      );
      CREATE UNIQUE INDEX idx_customers_email_lower ON customers(lower(email));

      CREATE TABLE seats (
        seat INTEGER PRIMARY KEY CHECK (seat >= 1 AND seat <= 50000),
        license_id TEXT UNIQUE,
        key_hash TEXT NOT NULL UNIQUE,
        key_enc TEXT NOT NULL,
        source TEXT NOT NULL CHECK (source IN ('legacy', 'generated')),
        reserved_order_id TEXT,
        reserved_at TEXT,
        created_at TEXT NOT NULL,
        allocated_at TEXT
      );
      CREATE INDEX idx_seats_available ON seats(license_id, reserved_order_id, seat);
      CREATE INDEX idx_seats_reserved ON seats(reserved_order_id);

      CREATE TABLE licenses (
        id TEXT PRIMARY KEY,
        seat INTEGER NOT NULL UNIQUE REFERENCES seats(seat),
        key_hash TEXT NOT NULL UNIQUE,
        customer_id TEXT REFERENCES customers(id) ON DELETE SET NULL,
        customer_name TEXT NOT NULL,
        email TEXT,
        product TEXT NOT NULL,
        plan TEXT NOT NULL,
        status TEXT NOT NULL CHECK (status IN ('pending', 'active', 'expired', 'revoked', 'suspended')),
        license_version INTEGER NOT NULL DEFAULT 2 CHECK (license_version IN (1, 2)),
        machine_code TEXT,
        machine_name TEXT,
        transaction_id TEXT UNIQUE,
        notes TEXT NOT NULL DEFAULT '',
        issued_at TEXT NOT NULL,
        starts_at TEXT NOT NULL,
        expires_at TEXT,
        activated_at TEXT,
        revoked_at TEXT,
        revoked_reason TEXT,
        suspended_at TEXT,
        suspended_reason TEXT,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL
      );
      CREATE UNIQUE INDEX idx_licenses_active_machine
        ON licenses(machine_code)
        WHERE machine_code IS NOT NULL AND status = 'active';
      CREATE INDEX idx_licenses_status ON licenses(status, issued_at DESC);
      CREATE INDEX idx_licenses_issued ON licenses(issued_at DESC);
      CREATE INDEX idx_licenses_email ON licenses(lower(email));
      CREATE INDEX idx_licenses_customer ON licenses(lower(customer_name));
      CREATE INDEX idx_licenses_expires ON licenses(expires_at);

      CREATE TABLE orders (
        id TEXT PRIMARY KEY,
        token_hash TEXT NOT NULL UNIQUE,
        email TEXT NOT NULL,
        customer_name TEXT NOT NULL DEFAULT '',
        status TEXT NOT NULL CHECK (status IN ('created', 'pending', 'paid', 'failed', 'cancelled', 'refunded', 'expired')),
        paypal_order_id TEXT UNIQUE,
        approval_url TEXT,
        amount_cents INTEGER NOT NULL CHECK (amount_cents > 0),
        currency TEXT NOT NULL,
        product TEXT NOT NULL,
        plan TEXT NOT NULL,
        license_id TEXT UNIQUE REFERENCES licenses(id),
        payer_email TEXT,
        failure_reason TEXT,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL,
        paid_at TEXT,
        refunded_at TEXT,
        completed_at TEXT
      );
      CREATE INDEX idx_orders_status ON orders(status, created_at DESC);
      CREATE INDEX idx_orders_email ON orders(email, created_at DESC);
      CREATE INDEX idx_orders_created ON orders(created_at);

      CREATE TABLE transactions (
        id TEXT PRIMARY KEY,
        kind TEXT NOT NULL CHECK (kind IN ('payment', 'refund')),
        provider TEXT NOT NULL,
        provider_id TEXT NOT NULL UNIQUE,
        order_id TEXT REFERENCES orders(id) ON DELETE SET NULL,
        license_id TEXT REFERENCES licenses(id) ON DELETE SET NULL,
        amount_cents INTEGER NOT NULL,
        currency TEXT NOT NULL,
        status TEXT NOT NULL,
        created_at TEXT NOT NULL
      );
      CREATE INDEX idx_transactions_created ON transactions(created_at DESC);
      CREATE INDEX idx_transactions_license ON transactions(license_id);

      CREATE TABLE webhook_events (
        id TEXT PRIMARY KEY,
        event_type TEXT NOT NULL,
        resource_id TEXT,
        order_id TEXT,
        status TEXT NOT NULL CHECK (status IN ('processing', 'processed', 'failed', 'ignored')),
        error TEXT,
        received_at TEXT NOT NULL,
        processed_at TEXT
      );
      CREATE INDEX idx_webhook_events_received ON webhook_events(received_at DESC);

      CREATE TABLE email_outbox (
        id TEXT PRIMARY KEY,
        license_id TEXT REFERENCES licenses(id) ON DELETE CASCADE,
        order_id TEXT REFERENCES orders(id) ON DELETE SET NULL,
        to_email TEXT NOT NULL,
        kind TEXT NOT NULL,
        status TEXT NOT NULL CHECK (status IN ('queued', 'sending', 'sent', 'failed')),
        attempts INTEGER NOT NULL DEFAULT 0,
        last_error TEXT,
        next_attempt_at TEXT NOT NULL,
        created_at TEXT NOT NULL,
        sent_at TEXT
      );
      CREATE INDEX idx_email_outbox_pending ON email_outbox(status, next_attempt_at);
      CREATE INDEX idx_email_outbox_license ON email_outbox(license_id);

      CREATE TABLE audit_log (
        id TEXT PRIMARY KEY,
        actor_type TEXT NOT NULL,
        actor_id TEXT,
        action TEXT NOT NULL,
        target_type TEXT,
        target_id TEXT,
        details TEXT,
        ip TEXT,
        created_at TEXT NOT NULL
      );
      CREATE INDEX idx_audit_created ON audit_log(created_at DESC);
      CREATE INDEX idx_audit_action ON audit_log(action, created_at DESC);
    `,
  },
  {
    version: 2,
    sql: `
      ALTER TABLE orders ADD COLUMN duration_months INTEGER NOT NULL DEFAULT 12
        CHECK (duration_months >= 1 AND duration_months <= 60);
      UPDATE orders SET duration_months = CASE plan
        WHEN 'monthly' THEN 1
        WHEN 'semiannual' THEN 6
        ELSE 12
      END;
    `,
  },
];

class MigrationError extends Error {
  constructor(message) {
    super(message);
    this.name = 'MigrationError';
    this.code = 'migration_error';
  }
}

class DatabaseError extends Error {
  constructor(message, options = {}) {
    super(message);
    this.name = 'DatabaseError';
    this.code = options.code || 'database_error';
  }
}

class Mutex {
  constructor() {
    this.locked = false;
    this.waiters = [];
  }

  acquire() {
    if (!this.locked) {
      this.locked = true;
      return Promise.resolve();
    }
    return new Promise((resolve) => this.waiters.push(resolve));
  }

  release() {
    const next = this.waiters.shift();
    if (next) next();
    else this.locked = false;
  }
}

function normalizeParams(params = []) {
  if (!Array.isArray(params)) throw new TypeError('Los parámetros SQL deben ser un array.');
  return params.map((value) => {
    if (value === undefined) return null;
    if (typeof value === 'boolean') return value ? 1 : 0;
    return value;
  });
}

function quoteIdent(value) {
  return `"${String(value).replace(/"/g, '""')}"`;
}

function validateIdentifier(value, label) {
  if (!/^[a-z_][a-z0-9_]*$/i.test(String(value || ''))) {
    throw new DatabaseError(`${label} no es un identificador SQL válido.`);
  }
  return String(value);
}

function toPostgresPlaceholders(sql) {
  let output = '';
  let position = 0;
  let state = 'normal';
  for (let index = 0; index < sql.length; index += 1) {
    const char = sql[index];
    if (state === 'single') {
      output += char;
      if (char === "'") {
        if (sql[index + 1] === "'") {
          output += sql[index + 1];
          index += 1;
        } else {
          state = 'normal';
        }
      }
      continue;
    }
    if (state === 'double') {
      output += char;
      if (char === '"') state = 'normal';
      continue;
    }
    if (char === "'") {
      state = 'single';
      output += char;
      continue;
    }
    if (char === '"') {
      state = 'double';
      output += char;
      continue;
    }
    if (char === '?') {
      position += 1;
      output += `$${position}`;
      continue;
    }
    output += char;
  }
  return output;
}

function buildInsertSql(table, columns, rowCount) {
  const rows = [];
  for (let row = 0; row < rowCount; row += 1) {
    rows.push(`(${columns.map(() => '?').join(', ')})`);
  }
  return `INSERT INTO ${table} (${columns.join(', ')}) VALUES ${rows.join(', ')}`;
}

class Database {
  constructor(dialect) {
    this.dialect = dialect;
    this.closed = false;
  }

  get isPostgres() {
    return this.dialect === 'postgres';
  }

  get isSqlite() {
    return this.dialect === 'sqlite';
  }

  async insertMany(table, columns, rows, options = {}) {
    if (!Array.isArray(rows) || rows.length === 0) return 0;
    const safeTable = validateIdentifier(table, 'La tabla');
    if (!Array.isArray(columns) || columns.length === 0) throw new DatabaseError('Faltan columnas para la inserción.');
    const safeColumns = columns.map((column) => validateIdentifier(column, 'La columna'));
    for (const row of rows) {
      if (!Array.isArray(row) || row.length !== safeColumns.length) {
        throw new DatabaseError('Cada fila debe tener el mismo número de columnas.');
      }
    }
    const limit = this.isPostgres ? PG_PARAM_LIMIT : SQLITE_PARAM_LIMIT;
    const requested = Number(options.chunkSize) > 0 ? Number(options.chunkSize) : rows.length;
    const chunkSize = Math.max(1, Math.min(requested, Math.floor(limit / safeColumns.length)));
    let inserted = 0;
    await this.transaction(async () => {
      for (let offset = 0; offset < rows.length; offset += chunkSize) {
        const chunk = rows.slice(offset, offset + chunkSize);
        const statement = buildInsertSql(safeTable, safeColumns, chunk.length);
        const result = await this.run(statement, chunk.flat());
        inserted += Number(result.changes || 0);
      }
    });
    return inserted;
  }

  async getSetting(key, fallback = null) {
    const row = await this.get('SELECT value FROM settings WHERE key = ?', [key]);
    return row ? row.value : fallback;
  }

  async setSetting(key, value, now = new Date().toISOString()) {
    return this.run(
      `INSERT INTO settings(key, value, updated_at) VALUES (?, ?, ?)
       ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_at = excluded.updated_at`,
      [key, String(value), now],
    );
  }

  async count(table) {
    const allowed = new Set(['seats', 'licenses', 'orders', 'customers', 'transactions', 'email_outbox', 'admin_users']);
    if (!allowed.has(table)) throw new Error('Tabla no permitida.');
    const row = await this.get(`SELECT COUNT(*) AS n FROM ${table}`);
    return Number(row ? row.n : 0);
  }
}

class SqliteDatabase extends Database {
  constructor(options = {}) {
    super('sqlite');
    if (typeof options.filePath !== 'string' || !options.filePath) {
      throw new DatabaseError('Falta la ruta del archivo SQLite.');
    }
    this.filePath = path.resolve(options.filePath);
    this.readOnly = Boolean(options.readOnly);
    this.als = new AsyncLocalStorage();
    this.mutex = new Mutex();
    fs.mkdirSync(path.dirname(this.filePath), { recursive: true });
    this.raw = new DatabaseSync(this.filePath, this.readOnly ? { readOnly: true } : {});
    if (!this.readOnly) {
      this.raw.exec(`
        PRAGMA journal_mode = WAL;
        PRAGMA foreign_keys = ON;
        PRAGMA busy_timeout = 5000;
        PRAGMA synchronous = FULL;
        PRAGMA trusted_schema = OFF;
      `);
    }
  }

  static async open(options = {}) {
    const database = new SqliteDatabase(options);
    if (!database.readOnly) await database.migrate();
    return database;
  }

  get identity() {
    return this.filePath;
  }

  async withConnection(fn) {
    const context = this.als.getStore();
    if (context) return fn(this.raw);
    await this.mutex.acquire();
    try {
      return fn(this.raw);
    } finally {
      this.mutex.release();
    }
  }

  async exec(sql) {
    await this.withConnection((raw) => raw.exec(sql));
  }

  async get(sql, params = []) {
    const values = normalizeParams(params);
    return this.withConnection((raw) => raw.prepare(sql).get(...values));
  }

  async all(sql, params = []) {
    const values = normalizeParams(params);
    return this.withConnection((raw) => raw.prepare(sql).all(...values));
  }

  async run(sql, params = []) {
    const values = normalizeParams(params);
    const result = await this.withConnection((raw) => raw.prepare(sql).run(...values));
    return {
      changes: Number(result.changes || 0),
      lastInsertRowid: result.lastInsertRowid,
    };
  }

  async transaction(fn) {
    if (typeof fn !== 'function') throw new TypeError('La transacción necesita una función.');
    const current = this.als.getStore();
    if (current) {
      const name = `sp_${++current.savepoint}`;
      current.depth += 1;
      this.raw.exec(`SAVEPOINT ${name}`);
      try {
        const result = await fn();
        this.raw.exec(`RELEASE SAVEPOINT ${name}`);
        return result;
      } catch (error) {
        try {
          this.raw.exec(`ROLLBACK TO SAVEPOINT ${name}`);
          this.raw.exec(`RELEASE SAVEPOINT ${name}`);
        } catch {
          // El error original es el relevante.
        }
        throw error;
      } finally {
        current.depth -= 1;
      }
    }
    await this.mutex.acquire();
    const context = { depth: 1, savepoint: 0 };
    try {
      this.raw.exec('BEGIN IMMEDIATE');
      return await this.als.run(context, async () => {
        try {
          const result = await fn();
          this.raw.exec('COMMIT');
          return result;
        } catch (error) {
          try {
            this.raw.exec('ROLLBACK');
          } catch {
            // El error original es el relevante.
          }
          throw error;
        }
      });
    } finally {
      this.mutex.release();
    }
  }

  async migrate() {
    this.raw.exec(`
      CREATE TABLE IF NOT EXISTS schema_migrations (
        version INTEGER PRIMARY KEY,
        applied_at TEXT NOT NULL
      );
    `);
    const applied = new Set(
      this.raw.prepare('SELECT version FROM schema_migrations').all().map((row) => Number(row.version)),
    );
    for (const migration of SQLITE_MIGRATIONS) {
      if (applied.has(migration.version)) continue;
      await this.transaction(async () => {
        this.raw.exec(migration.sql);
        await this.run('INSERT INTO schema_migrations(version, applied_at) VALUES (?, ?)', [
          migration.version,
          new Date().toISOString(),
        ]);
      });
    }
    const current = Number(
      this.raw.prepare('SELECT COALESCE(MAX(version), 0) AS version FROM schema_migrations').get().version,
    );
    if (current !== SCHEMA_VERSION) {
      throw new MigrationError(`La base de datos SQLite está en la versión ${current}; se esperaba ${SCHEMA_VERSION}.`);
    }
  }

  async close() {
    if (this.closed) return;
    await this.mutex.acquire();
    try {
      if (!this.closed) {
        this.raw.close();
        this.closed = true;
      }
    } finally {
      this.mutex.release();
    }
  }
}

function redactConnectionString(connectionString) {
  try {
    const url = new URL(connectionString);
    const user = url.username ? 'usuario' : '';
    const auth = user ? `${user}@` : '';
    return `postgresql://${auth}${url.hostname}${url.port ? `:${url.port}` : ''}${url.pathname}`;
  } catch {
    return 'postgresql://(configurada)';
  }
}

function parseSslOptions(mode, ca) {
  switch (String(mode || '').toLowerCase()) {
    case '':
      return undefined;
    case 'disable':
    case 'off':
      return false;
    case 'require':
      return { rejectUnauthorized: false, ...(ca ? { ca } : {}) };
    case 'verify-full':
    case 'verify-identity':
      return { rejectUnauthorized: true, ...(ca ? { ca } : {}) };
    default:
      throw new DatabaseError('Modo SSL de PostgreSQL no válido. Usa disable, require o verify-full.', {
        code: 'invalid_database_ssl',
      });
  }
}

class PostgresDatabase extends Database {
  constructor(options = {}) {
    super('postgres');
    if (!options.connectionString) throw new DatabaseError('Falta la URL de PostgreSQL.');
    this.als = new AsyncLocalStorage();
    this.schema = String(options.schema || 'public');
    this.identity = redactConnectionString(options.connectionString);
    this.pool = options.pool;
    this.ownsPool = Boolean(options.ownsPool);
    this.pool.on('error', (error) => {
      if (typeof options.onPoolError === 'function') {
        try {
          options.onPoolError(error);
        } catch {
          // El manejador de errores no debe tumbar el proceso.
        }
      }
    });
  }

  static async open(options = {}) {
    let pg;
    try {
      pg = require('pg');
    } catch {
      throw new DatabaseError(
        'PostgreSQL requiere la dependencia "pg". Ejecuta npm install en license-server.',
        { code: 'pg_dependency_missing' },
      );
    }
    pg.types.setTypeParser(20, (value) => Number(value));
    pg.types.setTypeParser(1700, (value) => Number(value));

    const schema = String(options.schema || 'public');
    if (!/^[A-Za-z_][A-Za-z0-9_]{0,62}$/.test(schema) || schema.startsWith('pg_')) {
      throw new DatabaseError('El esquema de PostgreSQL no es válido.', { code: 'invalid_database_schema' });
    }
    const ssl = parseSslOptions(options.ssl, options.sslCa);
    const baseConfig = {
      connectionString: options.connectionString,
      application_name: 'perfillab-license-server',
      max: Number(options.poolMax) > 0 ? Number(options.poolMax) : 10,
      idleTimeoutMillis: 30_000,
      connectionTimeoutMillis: 15_000,
      ...(ssl === undefined ? {} : { ssl }),
    };

    if (schema !== 'public') {
      const client = new pg.Client(baseConfig);
      try {
        await client.connect();
        await client.query(`CREATE SCHEMA IF NOT EXISTS ${quoteIdent(schema)}`);
      } finally {
        await client.end().catch(() => {});
      }
    }

    const pool = new pg.Pool({
      ...baseConfig,
      options: schema === 'public' ? undefined : `-c search_path=${schema}`,
    });
    const database = new PostgresDatabase({
      ...options,
      connectionString: options.connectionString,
      schema,
      pool,
      ownsPool: true,
    });
    try {
      await database.migrate();
      await database.enableSupabaseRowLevelSecurity();
    } catch (error) {
      await pool.end().catch(() => {});
      throw error;
    }
    return database;
  }

  // Supabase expone el esquema public por la Data API. Sin políticas, RLS deja
  // las tablas accesibles solo para su propietario, que es el propio servidor.
  async enableSupabaseRowLevelSecurity() {
    const roles = await this.all(
      "SELECT rolname FROM pg_roles WHERE rolname IN ('anon', 'authenticated')",
    );
    if (!roles.length) return false;
    const tables = [
      'settings',
      'admin_users',
      'admin_sessions',
      'customers',
      'seats',
      'licenses',
      'orders',
      'transactions',
      'webhook_events',
      'email_outbox',
      'audit_log',
      'schema_migrations',
    ];
    const existing = new Set(
      (await this.all(
        `SELECT table_name FROM information_schema.tables
         WHERE table_schema = ? AND table_type = 'BASE TABLE'`,
        [this.schema],
      )).map((row) => row.table_name),
    );
    for (const table of tables) {
      if (!existing.has(table)) continue;
      await this.exec(`ALTER TABLE ${quoteIdent(table)} ENABLE ROW LEVEL SECURITY`);
    }
    return true;
  }

  async query(sql, params = []) {
    const context = this.als.getStore();
    const runner = context ? context.client : this.pool;
    const values = normalizeParams(params);
    return runner.query(toPostgresPlaceholders(sql), values);
  }

  async exec(sql) {
    const context = this.als.getStore();
    const runner = context ? context.client : this.pool;
    await runner.query(sql);
  }

  async get(sql, params = []) {
    const result = await this.query(sql, params);
    return result.rows[0];
  }

  async all(sql, params = []) {
    const result = await this.query(sql, params);
    return result.rows;
  }

  async run(sql, params = []) {
    const result = await this.query(sql, params);
    return { changes: Number(result.rowCount || 0) };
  }

  async transaction(fn) {
    if (typeof fn !== 'function') throw new TypeError('La transacción necesita una función.');
    const current = this.als.getStore();
    if (current) {
      const name = `sp_${++current.savepoint}`;
      current.depth += 1;
      await current.client.query(`SAVEPOINT ${name}`);
      try {
        const result = await fn();
        await current.client.query(`RELEASE SAVEPOINT ${name}`);
        return result;
      } catch (error) {
        try {
          await current.client.query(`ROLLBACK TO SAVEPOINT ${name}`);
          await current.client.query(`RELEASE SAVEPOINT ${name}`);
        } catch {
          // El error original es el relevante.
        }
        throw error;
      } finally {
        current.depth -= 1;
      }
    }
    const client = await this.pool.connect();
    const context = { client, depth: 1, savepoint: 0 };
    try {
      await client.query('BEGIN');
      const result = await this.als.run(context, () => fn());
      await client.query('COMMIT');
      return result;
    } catch (error) {
      try {
        await client.query('ROLLBACK');
      } catch {
        // El error original es el relevante.
      }
      throw error;
    } finally {
      client.release();
    }
  }

  async migrate() {
    await this.exec(`
      CREATE TABLE IF NOT EXISTS schema_migrations (
        version INTEGER PRIMARY KEY,
        applied_at TEXT NOT NULL
      );
    `);
    const applied = new Set(
      (await this.all('SELECT version FROM schema_migrations')).map((row) => Number(row.version)),
    );
    for (const migration of POSTGRES_MIGRATIONS) {
      if (applied.has(migration.version)) continue;
      await this.transaction(async () => {
        await this.exec(migration.sql);
        await this.run('INSERT INTO schema_migrations(version, applied_at) VALUES (?, ?)', [
          migration.version,
          new Date().toISOString(),
        ]);
      });
    }
    const row = await this.get('SELECT COALESCE(MAX(version), 0) AS version FROM schema_migrations');
    const current = Number(row ? row.version : 0);
    if (current !== SCHEMA_VERSION) {
      throw new MigrationError(`La base de datos PostgreSQL está en la versión ${current}; se esperaba ${SCHEMA_VERSION}.`);
    }
  }

  async dropTestSchema() {
    if (this.closed) return;
    if (!/^perfillab_test_[a-z0-9_]+$/.test(this.schema)) {
      throw new DatabaseError('Solo se pueden eliminar esquemas temporales de pruebas.');
    }
    await this.pool.query(`DROP SCHEMA IF EXISTS ${quoteIdent(this.schema)} CASCADE`);
  }

  async close() {
    if (this.closed) return;
    this.closed = true;
    if (this.ownsPool) await this.pool.end();
  }
}

async function openDatabase(source, options = {}) {
  let settings;
  if (typeof source === 'string') settings = { ...options, filePath: source };
  else if (source && typeof source === 'object') settings = { ...source, ...options };
  else throw new DatabaseError('Configuración de base de datos no válida.');

  if (settings.databaseUrl) {
    return PostgresDatabase.open({
      ...settings,
      connectionString: settings.databaseUrl,
      ssl: settings.databaseSsl,
      sslCa: settings.databaseSslCa,
      poolMax: settings.databasePoolMax,
      schema: settings.databaseSchema,
    });
  }
  return SqliteDatabase.open({
    ...settings,
    filePath: settings.filePath || settings.dbPath,
  });
}

function isUniqueViolation(error) {
  if (!error) return false;
  if (String(error.code || '') === '23505') return true;
  return /UNIQUE constraint failed|constraint failed: .*UNIQUE/i.test(String(error.message || ''));
}

function uuid() {
  return crypto.randomUUID();
}

module.exports = {
  SCHEMA_VERSION,
  SQLITE_MIGRATIONS,
  POSTGRES_MIGRATIONS,
  MIGRATIONS: SQLITE_MIGRATIONS,
  Database,
  SqliteDatabase,
  PostgresDatabase,
  DatabaseError,
  MigrationError,
  openDatabase,
  isUniqueViolation,
  toPostgresPlaceholders,
  redactConnectionString,
  uuid,
};
