'use strict';

const crypto = require('node:crypto');
const fs = require('node:fs');

const { validateKeyPair } = require('./keystore');
const { normalizeLegacyLicenseKey, normalizeMachineCode } = require('./security');
const { HISTORICAL_LICENSE_LIMIT } = require('./license-format');

const VAULT_FORMAT = 'perfillab-license-vault';
const VAULT_VERSION = 1;
const MAX_VAULT_BYTES = 8 * 1024 * 1024;

class VaultError extends Error {
  constructor(message) {
    super(message);
    this.name = 'VaultError';
    this.code = 'vault_error';
  }
}

function readVaultFile(filePath) {
  if (!fs.existsSync(filePath)) throw new VaultError('No existe el archivo de la bóveda indicado.');
  const stat = fs.statSync(filePath);
  if (!stat.isFile() || stat.size > MAX_VAULT_BYTES) throw new VaultError('La bóveda no es válida o es demasiado grande.');
  let data;
  try {
    data = JSON.parse(fs.readFileSync(filePath, 'utf8'));
  } catch {
    throw new VaultError('La bóveda no contiene JSON válido.');
  }
  if (!data || data.format !== VAULT_FORMAT || Number(data.version) !== VAULT_VERSION) {
    throw new VaultError('La bóveda no tiene un formato compatible.');
  }
  if (!data.kdf || data.kdf.name !== 'scrypt' || !data.kdf.salt || !data.cipher) {
    throw new VaultError('La bóveda está incompleta.');
  }
  return data;
}

function unlockVault(file, password) {
  if (!password) throw new VaultError('Falta la contraseña de la bóveda.');
  const N = Number(file.kdf.N);
  const r = Number(file.kdf.r);
  const p = Number(file.kdf.p);
  if (!Number.isInteger(N) || !Number.isInteger(r) || !Number.isInteger(p) || N < 1024 || N > 1 << 20 || r < 1 || r > 32 || p < 1 || p > 8) {
    throw new VaultError('Los parámetros de la bóveda no son válidos.');
  }
  let key;
  try {
    key = crypto.scryptSync(String(password), Buffer.from(file.kdf.salt, 'base64'), 32, {
      N,
      r,
      p,
      maxmem: 128 * 1024 * 1024,
    });
  } catch {
    throw new VaultError('No se pudo derivar la clave de la bóveda.');
  }
  let payload;
  try {
    if (!file.cipher.iv || !file.cipher.tag || !file.cipher.data) throw new Error('incompleta');
    const decipher = crypto.createDecipheriv('aes-256-gcm', key, Buffer.from(file.cipher.iv, 'base64'));
    decipher.setAuthTag(Buffer.from(file.cipher.tag, 'base64'));
    payload = JSON.parse(Buffer.concat([
      decipher.update(Buffer.from(file.cipher.data, 'base64')),
      decipher.final(),
    ]).toString('utf8'));
  } catch {
    throw new VaultError('La contraseña de la bóveda no es correcta o la bóveda está dañada.');
  }
  if (!payload || typeof payload.privateKey !== 'string' || !Array.isArray(payload.seats)) {
    throw new VaultError('La bóveda no contiene datos válidos.');
  }
  let pair;
  try {
    pair = validateKeyPair(payload.privateKey, file.publicKey);
  } catch {
    throw new VaultError('La clave de firma de la bóveda no es válida.');
  }
  const seats = validateSeats(payload.seats);
  return {
    publicKey: file.publicKey,
    privateKey: payload.privateKey,
    privateKeyObject: pair.privateKey,
    seats,
    createdAt: file.createdAt || null,
    updatedAt: file.updatedAt || null,
  };
}

function validateSeats(seats) {
  if (!Array.isArray(seats) || seats.length < 1 || seats.length > HISTORICAL_LICENSE_LIMIT) {
    throw new VaultError('La cantidad de asientos de la bóveda no es válida.');
  }
  const seenSeats = new Set();
  const seenKeys = new Set();
  const seenIds = new Set();
  const normalized = [];
  for (const item of seats) {
    if (!item || typeof item !== 'object') throw new VaultError('La bóveda contiene un asiento no válido.');
    const seat = Number(item.seat);
    if (!Number.isInteger(seat) || seat < 1 || seat > HISTORICAL_LICENSE_LIMIT || seenSeats.has(seat)) {
      throw new VaultError('La bóveda contiene números de asiento no válidos o duplicados.');
    }
    if (typeof item.id !== 'string' || !item.id || item.id.length > 80 || seenIds.has(item.id)) {
      throw new VaultError('La bóveda contiene identificadores de licencia no válidos o duplicados.');
    }
    const key = normalizeLegacyLicenseKey(item.key);
    if (!key || key !== item.key) throw new VaultError(`El asiento ${seat} tiene una clave con formato no válido.`);
    if (seenKeys.has(key)) throw new VaultError('La bóveda contiene claves de licencia duplicadas.');
    const status = String(item.status || '');
    if (!['available', 'issued'].includes(status)) throw new VaultError(`El asiento ${seat} tiene un estado no válido.`);
    let machineCode = '';
    let issuedAt = null;
    let expiresAt = null;
    let customer = '';
    if (status === 'issued') {
      machineCode = normalizeMachineCode(item.machineCode);
      if (!machineCode) throw new VaultError(`La licencia ${item.id} no tiene un código de equipo válido.`);
      if (!Number.isFinite(Date.parse(item.issuedAt))) throw new VaultError(`La licencia ${item.id} no tiene una fecha de emisión válida.`);
      if (item.expiresAt !== null && item.expiresAt !== undefined && !Number.isFinite(Date.parse(item.expiresAt))) {
        throw new VaultError(`La licencia ${item.id} no tiene una fecha de vencimiento válida.`);
      }
      customer = String(item.customer || '').trim().slice(0, 160);
      if (!customer) throw new VaultError(`La licencia ${item.id} no tiene cliente.`);
      issuedAt = new Date(item.issuedAt).toISOString();
      expiresAt = item.expiresAt ? new Date(item.expiresAt).toISOString() : null;
    }
    seenSeats.add(seat);
    seenKeys.add(key);
    seenIds.add(item.id);
    normalized.push({
      seat,
      id: item.id,
      key,
      status,
      customer,
      machineCode,
      issuedAt,
      expiresAt,
      notes: String(item.notes || '').slice(0, 500),
    });
  }
  normalized.sort((a, b) => a.seat - b.seat);
  return normalized;
}

module.exports = {
  VAULT_FORMAT,
  VAULT_VERSION,
  VaultError,
  readVaultFile,
  unlockVault,
  validateSeats,
};
