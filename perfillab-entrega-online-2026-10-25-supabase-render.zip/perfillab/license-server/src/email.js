'use strict';

const { escapeHtml, maskEmail, nowIso, sanitizeText } = require('./security');
const { effectiveStatus } = require('./licenses');
const { planByCode, DEFAULT_PLAN_CODE } = require('./plans');

const MAX_ATTEMPTS = 5;
const RETRY_DELAYS_MS = [60_000, 5 * 60_000, 20 * 60_000, 2 * 60 * 60_000, 6 * 60 * 60_000];

function formatDate(value) {
  if (!value) return 'sin vencimiento';
  const date = new Date(value);
  if (!Number.isFinite(date.getTime())) return String(value);
  try {
    return new Intl.DateTimeFormat('es-ES', { dateStyle: 'long', timeZone: 'UTC' }).format(date);
  } catch {
    return date.toISOString().slice(0, 10);
  }
}

function planTextFor(license, config) {
  const plan = planByCode(license.plan) || planByCode(config.plan) || planByCode(DEFAULT_PLAN_CODE);
  const months = plan.months;
  return {
    label: plan.label,
    short: `${plan.label} (${months === 1 ? '1 mes' : `${months} meses`})`,
  };
}

function renderLicenseEmail({ license, key, config, orderId }) {
  const productName = sanitizeText(config.productName || 'PerfilLab', 80);
  const customer = sanitizeText(license.customer_name || 'cliente', 160);
  const expires = formatDate(license.expires_at);
  const issued = formatDate(license.issued_at);
  const support = sanitizeText(config.supportEmail || '', 160);
  const reference = String(orderId || license.id);
  const plan = planTextFor(license, config);
  const subject = `Tu licencia de ${productName}`;
  const lines = [
    `Hola, ${customer}:`,
    '',
    `Gracias por tu compra. Tu licencia de ${productName} ya está lista.`,
    '',
    `Clave de licencia: ${key}`,
    `Plan: ${plan.short}`,
    `Emitida: ${issued}`,
    `Válida hasta: ${expires}`,
    `Referencia: ${reference}`,
    '',
    'Cómo activarla:',
    `1. Abre ${productName} en el equipo donde la vas a usar.`,
    '2. En la ventana de licencia, elige «Activar licencia».',
    '3. Pega la clave. La licencia quedará vinculada a ese equipo.',
    '',
    'Cada licencia permite un solo equipo. Después de la activación, la licencia',
    'funciona sin conexión hasta su fecha de vencimiento. La licencia no se renueva',
    'automáticamente.',
    '',
    'Guarda este correo y no compartas tu clave: cualquiera que la tenga puede',
    'intentar activarla. Si necesitas mover la licencia a otro equipo, contacta con',
    'soporte para que se restablezca la activación.',
    '',
    support ? `Soporte: ${support}` : null,
    'Este mensaje se generó automáticamente; no respondas a este correo.',
  ].filter((line) => line !== null);
  const text = `${lines.join('\n')}\n`;

  const supportHtml = support
    ? `<p style="margin:18px 0 0;color:#64748b;font-size:13px">Soporte: <a href="mailto:${escapeHtml(support)}" style="color:#0f766e">${escapeHtml(support)}</a></p>`
    : '';
  const html = `<!doctype html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>${escapeHtml(subject)}</title>
</head>
<body style="margin:0;padding:0;background:#f1f5f9;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Helvetica,Arial,sans-serif;color:#0f172a">
<div style="max-width:560px;margin:0 auto;padding:32px 20px">
  <div style="background:#0b1220;border-radius:16px;padding:24px 28px;color:#e2e8f0">
    <div style="font-size:12px;letter-spacing:.14em;text-transform:uppercase;color:#5eead4">${escapeHtml(productName)}</div>
    <h1 style="margin:8px 0 0;font-size:24px;line-height:1.2;color:#ffffff">Tu licencia está lista</h1>
  </div>
  <div style="background:#ffffff;border-radius:16px;padding:28px;margin-top:16px;border:1px solid #e2e8f0">
    <p style="margin:0 0 16px;font-size:15px;line-height:1.6">Hola, <strong>${escapeHtml(customer)}</strong>:</p>
    <p style="margin:0 0 20px;font-size:15px;line-height:1.6">Gracias por tu compra. Esta es tu clave de licencia ${escapeHtml(plan.label.toLowerCase())} para un equipo:</p>
    <div style="border:1px solid #cbd5e1;background:#f8fafc;border-radius:12px;padding:18px;text-align:center">
      <div style="font-family:ui-monospace,SFMono-Regular,Menlo,Consolas,monospace;font-size:20px;letter-spacing:.08em;font-weight:700;color:#0f172a">${escapeHtml(key)}</div>
    </div>
    <table role="presentation" style="width:100%;border-collapse:collapse;margin:20px 0 4px;font-size:14px">
      <tr><td style="padding:6px 0;color:#64748b">Plan</td><td style="padding:6px 0;text-align:right">${escapeHtml(plan.short)}</td></tr>
      <tr><td style="padding:6px 0;color:#64748b">Emitida</td><td style="padding:6px 0;text-align:right">${escapeHtml(issued)}</td></tr>
      <tr><td style="padding:6px 0;color:#64748b">Válida hasta</td><td style="padding:6px 0;text-align:right;font-weight:600">${escapeHtml(expires)}</td></tr>
      <tr><td style="padding:6px 0;color:#64748b">Referencia</td><td style="padding:6px 0;text-align:right;font-family:ui-monospace,Menlo,Consolas,monospace;font-size:12px">${escapeHtml(reference)}</td></tr>
    </table>
    <h2 style="margin:24px 0 10px;font-size:16px">Cómo activarla</h2>
    <ol style="margin:0;padding-left:20px;font-size:14px;line-height:1.7;color:#334155">
      <li>Abre ${escapeHtml(productName)} en el equipo donde la vas a usar.</li>
      <li>En la ventana de licencia, elige «Activar licencia».</li>
      <li>Pega la clave. La licencia quedará vinculada a ese equipo.</li>
    </ol>
    <p style="margin:20px 0 0;font-size:13px;line-height:1.6;color:#64748b">
      Cada licencia permite un solo equipo. Después de la activación funciona sin conexión
      hasta su vencimiento. No se renueva automáticamente. No compartas esta clave.
      Si necesitas mover la licencia, contacta con soporte.
    </p>
    ${supportHtml}
  </div>
  <p style="margin:16px 4px 0;font-size:11px;color:#94a3b8;line-height:1.5">Mensaje automático de ${escapeHtml(productName)}. No respondas a este correo.</p>
</div>
</body>
</html>`;
  return { subject, text, html };
}

class EmailWorker {
  constructor({ db, config, mailer, licenses, audit, logger, intervalMs = 30_000, maxAttempts = MAX_ATTEMPTS }) {
    this.db = db;
    this.config = config;
    this.mailer = mailer;
    this.licenses = licenses;
    this.audit = audit;
    this.logger = logger;
    this.intervalMs = intervalMs;
    this.maxAttempts = maxAttempts;
    this.timer = null;
    this.kickTimer = null;
    this.running = false;
    this.stopped = true;
  }

  async start() {
    if (!this.stopped) return;
    this.stopped = false;
    await this.db.run(
      `UPDATE email_outbox SET status = 'queued', next_attempt_at = ?, last_error = COALESCE(last_error, 'Envío interrumpido')
       WHERE status = 'sending'`,
      [nowIso()],
    );
    this.timer = setInterval(() => this.kick(), this.intervalMs);
    if (this.timer.unref) this.timer.unref();
    this.kick();
  }

  stop() {
    this.stopped = true;
    if (this.timer) clearInterval(this.timer);
    if (this.kickTimer) clearTimeout(this.kickTimer);
    this.timer = null;
    this.kickTimer = null;
  }

  kick() {
    if (this.stopped || this.running || this.kickTimer) return;
    this.kickTimer = setTimeout(async () => {
      this.kickTimer = null;
      try {
        await this.processOnce();
      } catch (error) {
        this.logger.error('Fallo procesando la cola de correo', { code: error.code || 'error' });
      }
    }, 0);
    if (this.kickTimer.unref) this.kickTimer.unref();
  }

  async processOnce(limit = 10) {
    if (this.running) return { skipped: true, reason: 'running' };
    if (!this.mailer || !this.mailer.enabled) return { skipped: true, reason: 'disabled' };
    this.running = true;
    let sent = 0;
    let failed = 0;
    try {
      const due = await this.db.all(
        `SELECT id FROM email_outbox
         WHERE status IN ('queued', 'failed') AND attempts < ? AND next_attempt_at <= ?
         ORDER BY created_at ASC LIMIT ?`,
        [this.maxAttempts, nowIso(), limit],
      );
      for (const item of due) {
        const claimed = await this.db.run(
          `UPDATE email_outbox SET status = 'sending', attempts = attempts + 1
           WHERE id = ? AND status IN ('queued', 'failed') AND attempts < ?`,
          [item.id, this.maxAttempts],
        );
        if (Number(claimed.changes) !== 1) continue;
        const row = await this.db.get('SELECT * FROM email_outbox WHERE id = ?', [item.id]);
        if (!row) continue;
        try {
          await this.deliver(row);
          sent += 1;
        } catch (error) {
          failed += 1;
          await this.markFailure(row, error);
        }
      }
    } finally {
      this.running = false;
    }
    return { sent, failed };
  }

  async deliver(row) {
    const license = await this.licenses.rowById(row.license_id);
    if (!license) throw this.permanent('La licencia asociada ya no existe.');
    if (license.email && String(license.email).toLowerCase() !== String(row.to_email).toLowerCase()) {
      throw this.permanent('El correo de la licencia no coincide con el destinatario.');
    }
    const status = effectiveStatus(license);
    if (status === 'revoked') throw this.permanent('La licencia fue revocada antes del envío.');
    const key = this.licenses.keyForRow(license);
    const content = renderLicenseEmail({
      license,
      key,
      config: this.config,
      orderId: row.order_id,
    });
    await this.mailer.send({
      to: row.to_email,
      subject: content.subject,
      text: content.text,
      html: content.html,
    });
    const now = nowIso();
    await this.db.run(
      `UPDATE email_outbox SET status = 'sent', sent_at = ?, last_error = NULL, next_attempt_at = ? WHERE id = ?`,
      [now, now, row.id],
    );
    await this.audit.record({
      actorType: 'system',
      actorId: null,
      action: 'email.sent',
      targetType: 'license',
      targetId: license.id,
      details: { email: maskEmail(row.to_email), attempts: row.attempts },
    });
    this.logger.info('Correo de licencia enviado', { emailId: row.id, licenseId: license.id, attempts: row.attempts });
  }

  permanent(message) {
    const error = new Error(message);
    error.permanent = true;
    return error;
  }

  async markFailure(row, error) {
    const message = sanitizeText(error && error.message ? error.message : 'No se pudo enviar el correo.', 300);
    const permanent = Boolean(error && (
      error.permanent
      || error.retryable === false
      || error.code === 'key_decrypt_failed'
      || error.code === 'smtp_address'
    ));
    const exhausted = row.attempts >= this.maxAttempts;
    const delay = RETRY_DELAYS_MS[Math.min(row.attempts - 1, RETRY_DELAYS_MS.length - 1)];
    const next = new Date(Date.now() + delay).toISOString();
    if (permanent || exhausted) {
      await this.db.run(
        `UPDATE email_outbox SET status = 'failed', last_error = ?, next_attempt_at = ?,
         attempts = CASE WHEN ? = 1 THEN ? ELSE attempts END WHERE id = ?`,
        [message, nowIso(), permanent ? 1 : 0, this.maxAttempts, row.id],
      );
      await this.audit.record({
        actorType: 'system',
        actorId: null,
        action: 'email.failed',
        targetType: 'license',
        targetId: row.license_id,
        details: { emailId: row.id, attempts: row.attempts, permanent, error: message },
      });
      this.logger.warn('Correo de licencia no enviado', { emailId: row.id, permanent, attempts: row.attempts });
      return;
    }
    await this.db.run(
      `UPDATE email_outbox SET status = 'queued', last_error = ?, next_attempt_at = ? WHERE id = ?`,
      [message, next, row.id],
    );
    this.logger.warn('Reintento de correo programado', { emailId: row.id, attempts: row.attempts, nextAttemptAt: next });
  }

  async pendingCount() {
    const row = await this.db.get(
      `SELECT COUNT(*) AS n FROM email_outbox WHERE status IN ('queued', 'sending')`,
    );
    return Number(row ? row.n : 0);
  }
}

module.exports = { EmailWorker, renderLicenseEmail, formatDate };
