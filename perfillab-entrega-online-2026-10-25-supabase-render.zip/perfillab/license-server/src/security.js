'use strict';

const crypto = require('node:crypto');

const LICENSE_KEY_RE = /^[A-Z0-9]{4}(?:-[A-Z0-9]{4}){3}$/;
const CROCKFORD = '0123456789ABCDEFGHJKMNPQRSTVWXYZ';
const LICENSE_ALPHABET = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
const SCRYPT = { N: 32768, r: 8, p: 1, maxmem: 64 * 1024 * 1024, keylen: 32 };
const PASSWORD_MIN = 12;
const PASSWORD_MAX = 200;

function nowIso() {
  return new Date().toISOString();
}

function randomToken(bytes = 32) {
  return crypto.randomBytes(bytes).toString('base64url');
}

function sha256Hex(value) {
  return crypto.createHash('sha256').update(value).digest('hex');
}

function hashToken(token) {
  return sha256Hex(`perfillab-token-v1\0${token}`);
}

function keyHash(dataKey, licenseKey) {
  return crypto.createHmac('sha256', dataKey)
    .update('perfillab-license-key-v1\0')
    .update(licenseKey)
    .digest('hex');
}

function groupCode(value, size = 4) {
  const matches = String(value).match(new RegExp(`.{1,${size}}`, 'g'));
  return matches ? matches.join('-') : '';
}

function normalizeLicenseKey(input) {
  const cleaned = String(input || '').toUpperCase().replace(/[^A-Z0-9]/g, '');
  if (cleaned.length !== 16) return '';
  const grouped = groupCode(cleaned);
  return LICENSE_KEY_RE.test(grouped) ? grouped : '';
}

function normalizeLegacyLicenseKey(input) {
  const cleaned = String(input || '')
    .toUpperCase()
    .replace(/[^0-9A-Z]/g, '')
    .replace(/[IL]/g, '1')
    .replace(/O/g, '0')
    .replace(/U/g, 'V');
  if (cleaned.length !== 16) return '';
  const grouped = groupCode(cleaned);
  for (const char of cleaned) {
    if (!CROCKFORD.includes(char)) return '';
  }
  return grouped;
}

function normalizeMachineCode(input) {
  const cleaned = String(input || '')
    .toUpperCase()
    .replace(/[^0-9A-Z]/g, '')
    .replace(/[IL]/g, '1')
    .replace(/O/g, '0')
    .replace(/U/g, 'V');
  if (cleaned.length !== 16) return '';
  for (const char of cleaned) {
    if (!CROCKFORD.includes(char)) return '';
  }
  return groupCode(cleaned);
}

function randomLicenseKey() {
  let out = '';
  while (out.length < 16) {
    const byte = crypto.randomBytes(1)[0];
    if (byte < 252) out += LICENSE_ALPHABET[byte % 36];
  }
  return groupCode(out);
}

function hashPassword(password) {
  const value = String(password || '');
  if (value.length < PASSWORD_MIN) throw new Error(`La contraseña debe tener al menos ${PASSWORD_MIN} caracteres.`);
  if (value.length > PASSWORD_MAX) throw new Error('La contraseña es demasiado larga.');
  const salt = crypto.randomBytes(16);
  const derived = crypto.scryptSync(value, salt, SCRYPT.keylen, {
    N: SCRYPT.N,
    r: SCRYPT.r,
    p: SCRYPT.p,
    maxmem: SCRYPT.maxmem,
  });
  return `scrypt$1$${SCRYPT.N}$${SCRYPT.r}$${SCRYPT.p}$${salt.toString('base64url')}$${derived.toString('base64url')}`;
}

function verifyPassword(password, stored) {
  const value = String(password || '');
  const parts = String(stored || '').split('$');
  if (parts.length !== 7 || parts[0] !== 'scrypt' || parts[1] !== '1') return false;
  const N = Number(parts[2]);
  const r = Number(parts[3]);
  const p = Number(parts[4]);
  if (!Number.isInteger(N) || !Number.isInteger(r) || !Number.isInteger(p)) return false;
  if (N < 1024 || N > 1 << 20 || r < 1 || r > 32 || p < 1 || p > 8) return false;
  let salt;
  let expected;
  try {
    salt = Buffer.from(parts[5], 'base64url');
    expected = Buffer.from(parts[6], 'base64url');
  } catch {
    return false;
  }
  if (salt.length < 8 || expected.length < 16) return false;
  let actual;
  try {
    actual = crypto.scryptSync(value, salt, expected.length, {
      N,
      r,
      p,
      maxmem: 128 * 1024 * 1024,
    });
  } catch {
    return false;
  }
  return actual.length === expected.length && crypto.timingSafeEqual(actual, expected);
}

function encryptField(plaintext, key, aad) {
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv('aes-256-gcm', key, iv);
  cipher.setAAD(Buffer.from(String(aad || ''), 'utf8'));
  const data = Buffer.concat([cipher.update(String(plaintext), 'utf8'), cipher.final()]);
  return `v1.${iv.toString('base64url')}.${cipher.getAuthTag().toString('base64url')}.${data.toString('base64url')}`;
}

function decryptField(value, key, aad) {
  const parts = String(value || '').split('.');
  if (parts.length !== 4 || parts[0] !== 'v1') throw new Error('El dato cifrado no tiene un formato válido.');
  const iv = Buffer.from(parts[1], 'base64url');
  const tag = Buffer.from(parts[2], 'base64url');
  const data = Buffer.from(parts[3], 'base64url');
  if (iv.length !== 12 || tag.length !== 16) throw new Error('El dato cifrado está dañado.');
  const decipher = crypto.createDecipheriv('aes-256-gcm', key, iv);
  decipher.setAAD(Buffer.from(String(aad || ''), 'utf8'));
  decipher.setAuthTag(tag);
  return Buffer.concat([decipher.update(data), decipher.final()]).toString('utf8');
}

function addMonthsIso(value, months) {
  const source = new Date(value);
  if (!Number.isFinite(source.getTime())) throw new Error('Fecha no válida.');
  const day = source.getUTCDate();
  const shifted = new Date(source.getTime());
  shifted.setUTCDate(1);
  shifted.setUTCMonth(shifted.getUTCMonth() + months);
  const lastDay = new Date(Date.UTC(shifted.getUTCFullYear(), shifted.getUTCMonth() + 1, 0)).getUTCDate();
  shifted.setUTCDate(Math.min(day, lastDay));
  return shifted.toISOString();
}

function isValidEmail(input) {
  const value = String(input || '').trim();
  if (!value || value.length > 254) return false;
  if (/\s/.test(value)) return false;
  const at = value.lastIndexOf('@');
  if (at < 1 || at > 64) return false;
  const local = value.slice(0, at);
  const domain = value.slice(at + 1);
  if (local.length > 64 || domain.length > 253) return false;
  if (!/^[A-Za-z0-9.!#$%&'*+/=?^_`{|}~-]+$/.test(local)) return false;
  if (local.startsWith('.') || local.endsWith('.') || local.includes('..')) return false;
  const labels = domain.split('.');
  if (labels.length < 2) return false;
  for (const label of labels) {
    if (!label || label.length > 63) return false;
    if (!/^[A-Za-z0-9](?:[A-Za-z0-9-]*[A-Za-z0-9])?$/.test(label)) return false;
  }
  if (!/^[A-Za-z]{2,63}$/.test(labels[labels.length - 1])) return false;
  return true;
}

function normalizeEmail(input) {
  return String(input || '').trim().toLowerCase();
}

function maskEmail(input) {
  const value = normalizeEmail(input);
  const at = value.indexOf('@');
  if (at < 1) return '—';
  const local = value.slice(0, at);
  const visible = local.slice(0, Math.min(2, local.length));
  return `${visible}${'*'.repeat(Math.max(3, Math.min(8, local.length - visible.length)))}${value.slice(at)}`;
}

function sanitizeText(input, maxLength = 160) {
  return String(input || '')
    .replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/g, '')
    .replace(/\s+/g, ' ')
    .trim()
    .slice(0, maxLength);
}

function escapeHtml(input) {
  return String(input === undefined || input === null ? '' : input)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

function formatCents(cents) {
  return (Number(cents) / 100).toFixed(2);
}

function maskLicenseKey(key) {
  const value = String(key || '');
  if (!LICENSE_KEY_RE.test(value)) return '••••-••••-••••-••••';
  return `••••-••••-••••-${value.slice(-4)}`;
}

function csvCell(value) {
  let text = value === null || value === undefined ? '' : String(value);
  if (/^[=+\-@\t\r]/.test(text)) text = `'${text}`;
  return `"${text.replace(/"/g, '""')}"`;
}

function compareSecrets(a, b) {
  const left = Buffer.from(String(a || ''));
  const right = Buffer.from(String(b || ''));
  if (left.length !== right.length) return false;
  return crypto.timingSafeEqual(left, right);
}

module.exports = {
  LICENSE_KEY_RE,
  CROCKFORD,
  PASSWORD_MIN,
  PASSWORD_MAX,
  nowIso,
  randomToken,
  sha256Hex,
  hashToken,
  keyHash,
  groupCode,
  normalizeLicenseKey,
  normalizeLegacyLicenseKey,
  normalizeMachineCode,
  randomLicenseKey,
  hashPassword,
  verifyPassword,
  encryptField,
  decryptField,
  addMonthsIso,
  isValidEmail,
  normalizeEmail,
  maskEmail,
  sanitizeText,
  escapeHtml,
  formatCents,
  maskLicenseKey,
  csvCell,
  compareSecrets,
};
