'use strict';

const crypto = require('node:crypto');

const SECRET_KEY = /pass|secret|token|authorization|cookie|private.?key|license.?key|key_enc|key_hash/i;

function sanitizeDetails(value, depth = 0) {
  if (depth > 3) return '[recortado]';
  if (value === null || value === undefined) return null;
  if (typeof value === 'string') return value.slice(0, 400);
  if (typeof value === 'number' || typeof value === 'boolean') return value;
  if (Array.isArray(value)) return value.slice(0, 25).map((item) => sanitizeDetails(item, depth + 1));
  if (typeof value === 'object') {
    const out = {};
    for (const [key, item] of Object.entries(value)) {
      out[key] = SECRET_KEY.test(key) ? '[redactado]' : sanitizeDetails(item, depth + 1);
    }
    return out;
  }
  return String(value).slice(0, 400);
}

class AuditService {
  constructor(db) {
    this.db = db;
  }

  async record(input = {}) {
    const details = input.details ? JSON.stringify(sanitizeDetails(input.details)) : null;
    const entry = {
      id: crypto.randomUUID(),
      actorType: String(input.actorType || 'system').slice(0, 32),
      actorId: input.actorId ? String(input.actorId).slice(0, 80) : null,
      action: String(input.action || 'unknown').slice(0, 80),
      targetType: input.targetType ? String(input.targetType).slice(0, 40) : null,
      targetId: input.targetId ? String(input.targetId).slice(0, 100) : null,
      details,
      ip: input.ip ? String(input.ip).slice(0, 64) : null,
      createdAt: new Date().toISOString(),
    };
    await this.db.run(
      `INSERT INTO audit_log(id, actor_type, actor_id, action, target_type, target_id, details, ip, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        entry.id,
        entry.actorType,
        entry.actorId,
        entry.action,
        entry.targetType,
        entry.targetId,
        entry.details,
        entry.ip,
        entry.createdAt,
      ],
    );
    return entry.id;
  }

  async list({ page = 1, pageSize = 50 } = {}) {
    const size = Math.min(Math.max(Number(pageSize) || 50, 10), 200);
    const totalRow = await this.db.get('SELECT COUNT(*) AS n FROM audit_log');
    const total = Number(totalRow ? totalRow.n : 0);
    const pages = Math.max(1, Math.ceil(total / size));
    const current = Math.min(Math.max(Number(page) || 1, 1), pages);
    const rows = await this.db.all(
      `SELECT id, actor_type, actor_id, action, target_type, target_id, details, ip, created_at
       FROM audit_log ORDER BY created_at DESC LIMIT ? OFFSET ?`,
      [size, (current - 1) * size],
    );
    return {
      items: rows.map((row) => ({
        id: row.id,
        actorType: row.actor_type,
        actorId: row.actor_id,
        action: row.action,
        targetType: row.target_type,
        targetId: row.target_id,
        details: row.details ? JSON.parse(row.details) : null,
        ip: row.ip,
        createdAt: row.created_at,
      })),
      total,
      page: current,
      pages,
      pageSize: size,
    };
  }
}

module.exports = { AuditService, sanitizeDetails };
