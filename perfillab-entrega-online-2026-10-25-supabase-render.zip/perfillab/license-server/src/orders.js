'use strict';

const crypto = require('node:crypto');

const {
  isValidEmail,
  hashToken,
  maskEmail,
  normalizeEmail,
  nowIso,
  randomToken,
  sanitizeText,
} = require('./security');
const {
  AppError,
  badRequest,
  conflict,
  notFound,
  unavailable,
} = require('./errors');
const { PayPalError } = require('./paypal');
const { effectiveStatus } = require('./licenses');
const { DEFAULT_PLAN_CODE, planByCode } = require('./plans');

class OrderMetadataError extends Error {
  constructor(message) {
    super(message);
    this.name = 'OrderMetadataError';
    this.code = 'paypal_metadata_mismatch';
  }
}

function parsePayPalAmount(value) {
  if (typeof value !== 'string' || !/^\d{1,9}\.\d{2}$/.test(value)) return null;
  const [whole, fraction] = value.split('.');
  const cents = Number(whole) * 100 + Number(fraction);
  return Number.isSafeInteger(cents) ? cents : null;
}

function normalizePayPalCurrency(value) {
  const currency = String(value || '').toUpperCase();
  return /^[A-Z]{3}$/.test(currency) ? currency : '';
}

function extractCaptureIdFromLinks(links) {
  if (!Array.isArray(links)) return '';
  for (const link of links) {
    if (!link || typeof link.href !== 'string') continue;
    const match = /\/captures\/([A-Za-z0-9-]{1,80})$/.exec(link.href);
    if (match) return match[1];
  }
  return '';
}

function transactionRefundId(value) {
  return `refund:${String(value || '').slice(0, 100)}`;
}

class OrdersService {
  constructor({ db, config, paypal, licenses, audit, logger, paymentSettings = null }) {
    this.db = db;
    this.config = config;
    this.paypal = paypal;
    this.licenses = licenses;
    this.audit = audit;
    this.logger = logger;
    this.paymentSettings = paymentSettings;
    this.reconcileLocks = new Map();
  }

  async paymentGateway() {
    if (this.paymentSettings) return this.paymentSettings.gateway();
    const annual = Number.isInteger(this.config.paypal && this.config.paypal.priceCents)
      && this.config.paypal.priceCents >= 50
      ? this.config.paypal.priceCents
      : 10000;
    return {
      enabled: Boolean(this.config.paymentsEnabled),
      currency: (this.config.paypal && this.config.paypal.currency) || 'USD',
      prices: { monthly: 1000, semiannual: 5000, annual },
      publicBaseUrl: this.config.publicBaseUrl || '',
      mode: (this.config.paypal && this.config.paypal.mode) || 'sandbox',
    };
  }

  planForOrder(order) {
    return planByCode(order && order.plan) || planByCode(DEFAULT_PLAN_CODE);
  }

  async orderById(id) {
    return this.db.get('SELECT * FROM orders WHERE id = ?', [String(id)]);
  }

  async orderByToken(token) {
    if (typeof token !== 'string' || !/^[A-Za-z0-9_-]{20,200}$/.test(token)) return null;
    return this.db.get('SELECT * FROM orders WHERE token_hash = ?', [hashToken(token)]);
  }

  async orderByPayPalId(paypalId) {
    if (!paypalId) return null;
    return this.db.get('SELECT * FROM orders WHERE paypal_order_id = ?', [String(paypalId)]);
  }

  async publicSnapshot(order) {
    if (!order) return null;
    const plan = this.planForOrder(order);
    let license = null;
    if (order.license_id) {
      const row = await this.licenses.rowById(order.license_id);
      if (row) {
        const key = this.licenses.keyForRow(row);
        license = {
          licenseId: row.id,
          licenseKey: key,
          status: effectiveStatus(row),
          customerName: row.customer_name,
          plan: row.plan,
          expiresAt: row.expires_at || null,
          issuedAt: row.issued_at,
        };
        if (order.status !== 'paid') delete license.licenseKey;
      }
    }
    const messages = {
      created: 'Estamos preparando el pago.',
      pending: 'Pago pendiente de confirmación. Esta página se actualizará automáticamente.',
      paid: 'Pago confirmado. Tu licencia ya está disponible.',
      failed: 'No se pudo completar la compra. No se realizó ningún cargo o el pago requiere revisión; contacta con soporte.',
      cancelled: 'La compra fue cancelada y no se realizó ningún cargo.',
      refunded: 'El pago fue reembolsado y la licencia quedó revocada.',
      expired: 'La orden expiró sin completarse.',
    };
    return {
      orderId: order.id,
      status: order.status,
      paid: order.status === 'paid',
      amountCents: order.amount_cents,
      currency: order.currency,
      plan: plan.code,
      planLabel: plan.label,
      durationMonths: Number(order.duration_months) || plan.months,
      emailMasked: maskEmail(order.email),
      customerName: order.customer_name || '',
      createdAt: order.created_at,
      paidAt: order.paid_at || null,
      license,
      message: messages[order.status] || 'Estado de la orden no disponible.',
      checkedAt: nowIso(),
    };
  }

  async createCheckout({ email, name, acceptTerms, plan: planCode, ip } = {}) {
    const gateway = await this.paymentGateway();
    if (!gateway.enabled || !this.paypal || !(await this.paypal.isEnabled())) {
      throw unavailable('Los pagos no están disponibles en este servidor.', 'payments_unavailable');
    }
    if (!this.config.publicBaseUrl) throw unavailable('La tienda no tiene una URL pública configurada.', 'store_unavailable');
    if (acceptTerms !== true) throw badRequest('Debes aceptar las condiciones de compra.', 'terms_required');
    const plan = planByCode(planCode === undefined || planCode === null || planCode === '' ? DEFAULT_PLAN_CODE : planCode);
    if (!plan) throw badRequest('El plan seleccionado no es válido.', 'invalid_plan');
    const amountCents = gateway.prices[plan.code];
    if (!Number.isInteger(amountCents) || amountCents < 50) {
      throw unavailable('El plan seleccionado no tiene un precio configurado.', 'price_unavailable');
    }
    const currency = gateway.currency;
    const normalizedEmail = normalizeEmail(email);
    if (!isValidEmail(normalizedEmail)) throw badRequest('Introduce un correo electrónico válido.', 'invalid_email');
    const customerName = sanitizeText(name, 160) || normalizedEmail;
    if (!(await this.licenses.hasAvailableSeat())) {
      throw conflict('No quedan licencias disponibles.', 'sold_out');
    }
    const id = crypto.randomUUID();
    const token = randomToken(32);
    const now = nowIso();
    const period = plan.months === 1 ? '1 mes' : `${plan.months} meses`;
    await this.db.transaction(async () => {
      await this.db.run(
        `INSERT INTO orders(
           id, token_hash, email, customer_name, status, paypal_order_id, approval_url, amount_cents, currency,
           product, plan, duration_months, license_id, payer_email, failure_reason, created_at, updated_at, paid_at, refunded_at, completed_at
         ) VALUES (?, ?, ?, ?, 'created', NULL, NULL, ?, ?, ?, ?, ?, NULL, NULL, NULL, ?, ?, NULL, NULL, NULL)`,
        [
          id,
          hashToken(token),
          normalizedEmail,
          customerName,
          amountCents,
          currency,
          this.config.product,
          plan.code,
          plan.months,
          now,
          now,
        ],
      );
      await this.audit.record({
        actorType: 'public',
        actorId: null,
        action: 'order.created',
        targetType: 'order',
        targetId: id,
        details: { amountCents, currency, plan: plan.code, durationMonths: plan.months },
        ip,
      });
    });

    let created;
    try {
      created = await this.paypal.createOrder({
        amountCents,
        currency,
        description: `${this.config.productName} · Licencia ${plan.label.toLowerCase()} (${period})`,
        customId: id,
        invoiceId: id,
        referenceId: `perfillab-${plan.code}`,
        returnUrl: `${this.config.publicBaseUrl}/pago/retorno?t=${encodeURIComponent(token)}`,
        cancelUrl: `${this.config.publicBaseUrl}/pago/cancelado?t=${encodeURIComponent(token)}`,
        brandName: this.config.productName,
        requestId: `pl-create-${id}`,
      });
    } catch (error) {
      await this.markTerminal(id, 'failed', 'No se pudo iniciar el pago con PayPal.', 'order.paypal_create_failed', ip);
      this.logger.error('No se pudo crear la orden de PayPal', {
        orderId: id,
        code: error.code || 'error',
        debugId: error.debugId || null,
      });
      throw new AppError('No se pudo iniciar el pago. Inténtalo de nuevo más tarde.', 502, 'paypal_unavailable');
    }

    try {
      await this.db.run(
        `UPDATE orders SET paypal_order_id = ?, approval_url = ?, status = 'pending', updated_at = ? WHERE id = ?`,
        [created.order.id, created.approvalUrl, nowIso(), id],
      );
    } catch (error) {
      await this.markTerminal(id, 'failed', 'No se pudo registrar la orden de PayPal.', 'order.paypal_link_failed', ip);
      throw new AppError('No se pudo iniciar el pago. Inténtalo de nuevo más tarde.', 502, 'paypal_unavailable');
    }
    await this.audit.record({
      actorType: 'public',
      actorId: null,
      action: 'order.pending',
      targetType: 'order',
      targetId: id,
      details: { paypalOrderId: created.order.id },
      ip,
    });
    return {
      orderId: id,
      token,
      approvalUrl: created.approvalUrl,
      amountCents,
      currency,
    };
  }

  async markTerminal(orderId, status, reason, action, ip, { keepLicense = false } = {}) {
    return this.db.transaction(async () => {
      const order = await this.orderById(orderId);
      if (!order) return null;
      if (order.license_id && !keepLicense) return order;
      if (['paid', 'refunded'].includes(order.status)) return order;
      const now = nowIso();
      await this.db.run(
        `UPDATE orders SET status = ?, failure_reason = ?, updated_at = ? WHERE id = ? AND license_id IS NULL`,
        [status, sanitizeText(reason, 300), now, orderId],
      );
      await this.licenses.releaseReservation(orderId);
      await this.audit.record({
        actorType: 'system',
        actorId: null,
        action,
        targetType: 'order',
        targetId: orderId,
        details: { reason: sanitizeText(reason, 300), status },
        ip,
      });
      return this.orderById(orderId);
    });
  }

  async flagManualReview(order, reason, { captureId = null, payerEmail = null, ip = null } = {}) {
    const current = await this.orderById(order.id);
    if (!current) return null;
    if (current.status === 'paid' || current.license_id) return current;
    const now = nowIso();
    await this.db.transaction(async () => {
      await this.db.run(
        `UPDATE orders SET status = 'failed', failure_reason = ?, payer_email = COALESCE(?, payer_email),
         paid_at = COALESCE(paid_at, ?), updated_at = ? WHERE id = ? AND license_id IS NULL`,
        [sanitizeText(reason, 300), payerEmail, captureId ? now : null, now, current.id],
      );
      if (captureId) {
        const exists = await this.db.get('SELECT id FROM transactions WHERE provider_id = ?', [captureId]);
        if (!exists) {
          await this.db.run(
            `INSERT INTO transactions(id, kind, provider, provider_id, order_id, license_id, amount_cents, currency, status, created_at)
             VALUES (?, 'payment', 'paypal', ?, ?, NULL, ?, ?, 'review', ?)`,
            [crypto.randomUUID(), captureId, current.id, current.amount_cents, current.currency, now],
          );
        }
      }
      await this.licenses.releaseReservation(current.id);
      await this.audit.record({
        actorType: 'system',
        actorId: null,
        action: 'order.manual_review',
        targetType: 'order',
        targetId: current.id,
        details: { reason: sanitizeText(reason, 300), captureId },
        ip,
      });
    });
    this.logger.error('Orden marcada para revisión manual', {
      orderId: current.id,
      reason: sanitizeText(reason, 300),
      captureId,
    });
    return this.orderById(current.id);
  }

  validatePayPalOrder(order, paypalOrder) {
    if (!paypalOrder || typeof paypalOrder !== 'object' || !paypalOrder.id) {
      throw new OrderMetadataError('PayPal no devolvió una orden válida.');
    }
    if (String(paypalOrder.id) !== String(order.paypal_order_id)) {
      throw new OrderMetadataError('El identificador de la orden de PayPal no coincide.');
    }
    if (!Array.isArray(paypalOrder.purchase_units) || paypalOrder.purchase_units.length !== 1) {
      throw new OrderMetadataError('La orden de PayPal no contiene exactamente una unidad de compra.');
    }
    const unit = paypalOrder.purchase_units[0];
    if (!unit || String(unit.custom_id || '') !== String(order.id)) {
      throw new OrderMetadataError('El identificador interno del pago no coincide.');
    }
    if (unit.invoice_id && String(unit.invoice_id) !== String(order.id)) {
      throw new OrderMetadataError('La factura del pago no coincide.');
    }
    if (!unit.amount || normalizePayPalCurrency(unit.amount.currency_code) !== order.currency) {
      throw new OrderMetadataError('La moneda del pago no coincide.');
    }
    if (parsePayPalAmount(unit.amount.value) !== Number(order.amount_cents)) {
      throw new OrderMetadataError('El importe del pago no coincide.');
    }
    return unit;
  }

  extractCapture(order, paypalOrder, unit) {
    const captures = unit && unit.payments && Array.isArray(unit.payments.captures)
      ? unit.payments.captures
      : [];
    if (!captures.length) return null;
    if (captures.length > 1) {
      throw new OrderMetadataError('PayPal devolvió varias capturas para una sola licencia.');
    }
    const capture = captures[0];
    if (!capture || !/^[A-Za-z0-9-]{1,80}$/.test(String(capture.id || ''))) {
      throw new OrderMetadataError('La captura de PayPal no tiene un identificador válido.');
    }
    if (capture.status === 'PENDING') return { pending: true, capture };
    if (!['COMPLETED', 'REFUNDED', 'PARTIALLY_REFUNDED', 'REVERSED'].includes(capture.status)) return null;
    if (!capture.amount || normalizePayPalCurrency(capture.amount.currency_code) !== order.currency) {
      throw new OrderMetadataError('La moneda capturada no coincide.');
    }
    if (parsePayPalAmount(capture.amount.value) !== Number(order.amount_cents)) {
      throw new OrderMetadataError('El importe capturado no coincide.');
    }
    const payerEmail = paypalOrder && paypalOrder.payer && isValidEmail(paypalOrder.payer.email_address)
      ? normalizeEmail(paypalOrder.payer.email_address)
      : null;
    return {
      pending: false,
      capture: {
        id: capture.id,
        status: capture.status,
        amountCents: parsePayPalAmount(capture.amount.value),
        currency: normalizePayPalCurrency(capture.amount.currency_code),
        createTime: capture.create_time || null,
        payerEmail,
      },
    };
  }

  async ensureReservationForCapture(order) {
    if (await this.licenses.hasReservation(order.id)) return true;
    try {
      const seat = await this.licenses.reserveSeat(order.id);
      await this.audit.record({
        actorType: 'system',
        actorId: null,
        action: 'order.seat_reserved',
        targetType: 'order',
        targetId: order.id,
        details: { seat },
      });
      return true;
    } catch (error) {
      if (error instanceof AppError && error.code === 'capacity_exhausted') {
        await this.markTerminal(
          order.id,
          'failed',
          'No quedaban licencias disponibles antes de capturar el pago. No se realizó ningún cargo.',
          'order.sold_out',
          null,
        );
        return false;
      }
      throw error;
    }
  }

  async reconcileOrder(order, options = {}) {
    if (!order) throw notFound('La orden no existe.', 'order_not_found');
    const existing = this.reconcileLocks.get(order.id);
    if (existing) return existing;
    const pending = this._reconcileOrder(order, options).finally(() => {
      this.reconcileLocks.delete(order.id);
    });
    this.reconcileLocks.set(order.id, pending);
    return pending;
  }

  async _reconcileOrder(order, { trigger = 'return', ip = null } = {}) {
    if (!order) throw notFound('La orden no existe.', 'order_not_found');
    if (!this.paypal || !(await this.paypal.isEnabled())) throw unavailable('Los pagos no están disponibles.', 'payments_unavailable');
    if (order.status === 'paid' || order.status === 'refunded') return this.publicSnapshot(order);
    if (!order.paypal_order_id) {
      return this.publicSnapshot(
        (await this.markTerminal(order.id, 'failed', 'La orden no tiene un pago asociado.', 'order.invalid', ip)) || order,
      );
    }

    let paypalOrder;
    try {
      paypalOrder = await this.paypal.getOrder(order.paypal_order_id);
    } catch (error) {
      this.logger.warn('No se pudo consultar la orden de PayPal', {
        orderId: order.id,
        trigger,
        code: error.code || 'error',
        retryable: Boolean(error.retryable),
      });
      throw new AppError('No se pudo verificar el pago con PayPal. Inténtalo en unos instantes.', 502, 'paypal_unavailable');
    }

    let unit;
    try {
      unit = this.validatePayPalOrder(order, paypalOrder);
    } catch (error) {
      if (error instanceof OrderMetadataError) {
        const updated = await this.flagManualReview(order, error.message, { ip });
        return this.publicSnapshot(updated);
      }
      throw error;
    }

    let captureInfo;
    try {
      captureInfo = this.extractCapture(order, paypalOrder, unit);
    } catch (error) {
      if (error instanceof OrderMetadataError) {
        const updated = await this.flagManualReview(order, error.message, { ip });
        return this.publicSnapshot(updated);
      }
      throw error;
    }

    if (paypalOrder.status === 'APPROVED' && !captureInfo) {
      if (!(await this.ensureReservationForCapture(order))) {
        return this.publicSnapshot(await this.orderById(order.id));
      }
      try {
        paypalOrder = await this.paypal.captureOrder(order.paypal_order_id, `pl-capture-${order.id}`);
      } catch (error) {
        const alreadyCaptured = error instanceof PayPalError
          && (String(error.issue || '').includes('ORDER_ALREADY_CAPTURED') || String(error.code || '').includes('ORDER_ALREADY_CAPTURED'));
        if (alreadyCaptured) {
          paypalOrder = await this.paypal.getOrder(order.paypal_order_id);
        } else {
          this.logger.warn('La captura de PayPal no se completó', {
            orderId: order.id,
            trigger,
            code: error.code || 'error',
            status: error.status || 0,
            retryable: Boolean(error.retryable),
          });
          if (error instanceof PayPalError && !error.retryable) {
            const updated = await this.markTerminal(
              order.id,
              'failed',
              'PayPal no pudo completar el cobro. No se emitió ninguna licencia.',
              'order.capture_failed',
              ip,
            );
            return this.publicSnapshot(updated || order);
          }
          throw new AppError('PayPal no confirmó el cobro. La orden queda pendiente de reintento.', 502, 'paypal_capture_pending');
        }
      }
      try {
        unit = this.validatePayPalOrder(order, paypalOrder);
        captureInfo = this.extractCapture(order, paypalOrder, unit);
      } catch (error) {
        if (error instanceof OrderMetadataError) {
          const updated = await this.flagManualReview(order, error.message, {
            captureId: null,
            ip,
          });
          return this.publicSnapshot(updated);
        }
        throw error;
      }
    }

    if (captureInfo && captureInfo.pending) {
      const now = nowIso();
      await this.db.run(`UPDATE orders SET status = 'pending', updated_at = ? WHERE id = ? AND status NOT IN ('paid', 'refunded')`, [now, order.id]);
      await this.audit.record({
        actorType: 'system', actorId: null, action: 'order.capture_pending', targetType: 'order',
        targetId: order.id, details: { trigger, paypalStatus: paypalOrder.status }, ip,
      });
      return this.publicSnapshot(await this.orderById(order.id));
    }

    if (captureInfo && captureInfo.capture && captureInfo.capture.status === 'COMPLETED') {
      return this.finalizePaid(order.id, captureInfo.capture, { trigger, ip });
    }

    if (['VOIDED', 'EXPIRED'].includes(paypalOrder.status)) {
      const updated = await this.markTerminal(
        order.id,
        paypalOrder.status === 'EXPIRED' ? 'expired' : 'cancelled',
        'PayPal anuló o expiró la orden sin cobro.',
        'order.closed_by_paypal',
        ip,
      );
      return this.publicSnapshot(updated || order);
    }

    if (captureInfo && captureInfo.capture && ['REFUNDED', 'REVERSED', 'PARTIALLY_REFUNDED'].includes(captureInfo.capture.status)) {
      return this.publicSnapshot(await this.orderById(order.id));
    }

    return this.publicSnapshot(await this.orderById(order.id));
  }

  async finalizePaid(orderId, capture, { trigger = 'return', ip = null } = {}) {
    let result;
    try {
      result = await this.db.transaction(async () => {
        const order = await this.orderById(orderId);
        if (!order) throw notFound('La orden no existe.', 'order_not_found');
        if (order.license_id) {
          return { order, already: true, licenseKey: null };
        }
        if (order.status === 'refunded') return { order, already: true, licenseKey: null };
        const existingTx = await this.db.get('SELECT * FROM transactions WHERE provider_id = ?', [capture.id]);
        if (existingTx) {
          if (existingTx.order_id === order.id) {
            return { order, already: true, licenseKey: null };
          }
          throw new AppError('La captura de PayPal ya está asociada a otra orden.', 409, 'capture_already_used');
        }
        const payerEmail = capture.payerEmail || null;
        const issued = await this.licenses.issue({
          customerName: order.customer_name || order.email,
          email: order.email,
          machineCode: null,
          notes: '',
          plan: order.plan,
          transactionId: capture.id,
          reservedOrderId: order.id,
          orderId: order.id,
          queueEmail: true,
          source: 'paypal',
        }, { actorType: 'system', actorId: null, source: 'paypal', ip });
        const now = nowIso();
        await this.db.run(
          `INSERT INTO transactions(id, kind, provider, provider_id, order_id, license_id, amount_cents, currency, status, created_at)
           VALUES (?, 'payment', 'paypal', ?, ?, ?, ?, ?, 'completed', ?)`,
          [crypto.randomUUID(), capture.id, order.id, issued.license.id, capture.amountCents, capture.currency, now],
        );
        await this.db.run(
          `UPDATE orders SET status = 'paid', license_id = ?, payer_email = ?, paid_at = ?, completed_at = ?,
           failure_reason = NULL, updated_at = ? WHERE id = ?`,
          [issued.license.id, payerEmail, capture.createTime || now, now, now, order.id],
        );
        await this.audit.record({
          actorType: 'system',
          actorId: null,
          action: 'order.paid',
          targetType: 'order',
          targetId: order.id,
          details: { licenseId: issued.license.id, captureId: capture.id, trigger },
          ip,
        });
        return { order: await this.orderById(order.id), already: false, licenseKey: issued.licenseKey, license: issued.license };
      });
    } catch (error) {
      if (error instanceof AppError && ['capacity_exhausted', 'seat_conflict'].includes(error.code)) {
        await this.recordUnfulfilledPayment(orderId, capture, error, ip);
      }
      throw error;
    }
    if (result.already) {
      return this.publicSnapshot(await this.orderById(orderId));
    }
    this.logger.info('Orden pagada y licencia emitida', {
      orderId,
      licenseId: result.license.id,
      captureId: capture.id,
      trigger,
    });
    return this.publicSnapshot(await this.orderById(orderId));
  }

  async recordUnfulfilledPayment(orderId, capture, error, ip) {
    const order = await this.orderById(orderId);
    if (!order) return;
    const now = nowIso();
    await this.db.transaction(async () => {
      const existingTx = await this.db.get('SELECT id FROM transactions WHERE provider_id = ?', [capture.id]);
      if (!existingTx) {
        await this.db.run(
          `INSERT INTO transactions(id, kind, provider, provider_id, order_id, license_id, amount_cents, currency, status, created_at)
           VALUES (?, 'payment', 'paypal', ?, ?, NULL, ?, ?, 'review', ?)`,
          [crypto.randomUUID(), capture.id, order.id, capture.amountCents, capture.currency, now],
        );
      }
      await this.db.run(
        `UPDATE orders SET status = 'failed', failure_reason = ?, payer_email = ?, paid_at = COALESCE(paid_at, ?), updated_at = ?
         WHERE id = ? AND license_id IS NULL`,
        [
          'El pago se capturó pero no había un asiento disponible. Es necesario reembolsar manualmente.',
          capture.payerEmail || null,
          capture.createTime || now,
          now,
          order.id,
        ],
      );
      await this.licenses.releaseReservation(order.id);
      await this.audit.record({
        actorType: 'system',
        actorId: null,
        action: 'order.fulfillment_failed',
        targetType: 'order',
        targetId: order.id,
        details: { captureId: capture.id, error: error.code },
        ip,
      });
    });
    this.logger.error('Pago capturado sin licencia emitida; se requiere revisión manual', {
      orderId,
      captureId: capture.id,
    });
  }

  async handleReturn({ token, paypalOrderId, ip } = {}) {
    const order = await this.orderByToken(token);
    if (!order) throw notFound('La orden no existe.', 'order_not_found');
    if (paypalOrderId && order.paypal_order_id && paypalOrderId !== order.paypal_order_id) {
      await this.audit.record({
        actorType: 'public', actorId: null, action: 'order.return_token_mismatch', targetType: 'order',
        targetId: order.id, details: null, ip,
      });
    }
    return this.reconcileOrder(order, { trigger: 'return', ip });
  }

  async handleCancel({ token, ip } = {}) {
    const order = await this.orderByToken(token);
    if (!order) throw notFound('La orden no existe.', 'order_not_found');
    if (order.status === 'paid' || order.status === 'refunded') return this.publicSnapshot(order);
    if (order.paypal_order_id) {
      try {
        const snapshot = await this.reconcileOrder(order, { trigger: 'cancel', ip });
        if (snapshot && (snapshot.status === 'paid' || snapshot.status === 'refunded')) return snapshot;
      } catch {
        // La cancelación local no debe depender de la red.
      }
    }
    const updated = await this.markTerminal(order.id, 'cancelled', 'El cliente canceló el pago.', 'order.cancelled', ip);
    return this.publicSnapshot(updated || (await this.orderById(order.id)));
  }

  async syncAdminOrder(orderId, context = {}) {
    const order = await this.orderById(orderId);
    if (!order) throw notFound('La orden no existe.', 'order_not_found');
    if (order.status === 'paid' || order.status === 'refunded') return this.publicSnapshot(order);
    if (!order.paypal_order_id) throw badRequest('La orden no tiene un pago de PayPal asociado.', 'invalid_order');
    const snapshot = await this.reconcileOrder(order, { trigger: 'admin', ip: context.ip });
    await this.audit.record({
      actorType: context.actorType || 'admin',
      actorId: context.actorId || null,
      action: 'order.synced',
      targetType: 'order',
      targetId: order.id,
      details: { status: snapshot.status },
      ip: context.ip,
    });
    return snapshot;
  }

  async orderForEvent(event) {
    const resource = event.resource && typeof event.resource === 'object' ? event.resource : {};
    const candidates = [];
    const addCandidate = (id) => {
      const value = String(id || '');
      if (/^[A-Za-z0-9-]{8,80}$/.test(value) && !candidates.includes(value)) candidates.push(value);
    };
    addCandidate(resource.custom_id);
    addCandidate(resource.invoice_id);
    addCandidate(resource.id && String(event.event_type || '').startsWith('CHECKOUT.ORDER') ? resource.id : '');
    addCandidate(resource.supplementary_data
      && resource.supplementary_data.related_ids
      && resource.supplementary_data.related_ids.order_id);
    if (Array.isArray(resource.purchase_units) && resource.purchase_units[0]) {
      addCandidate(resource.purchase_units[0].custom_id);
    }
    for (const candidate of candidates) {
      const byInternal = await this.orderById(candidate);
      if (byInternal) return byInternal;
      const byPayPal = await this.orderByPayPalId(candidate);
      if (byPayPal) return byPayPal;
    }
    return null;
  }

  async handleRefundEvent(event, ip) {
    const resource = event.resource && typeof event.resource === 'object' ? event.resource : {};
    const related = resource.supplementary_data && resource.supplementary_data.related_ids
      ? resource.supplementary_data.related_ids
      : {};
    let captureId = String(related.capture_id || '').trim();
    if (!captureId) captureId = extractCaptureIdFromLinks(resource.links);
    if (!captureId) {
      const candidate = String(resource.id || '');
      if (await this.db.get(`SELECT id FROM transactions WHERE provider_id = ? AND kind = 'payment'`, [candidate])) {
        captureId = candidate;
      }
    }
    if (!captureId) return { ignored: true, reason: 'capture_not_found' };
    const payment = await this.db.get(`SELECT * FROM transactions WHERE provider_id = ? AND kind = 'payment'`, [captureId]);
    if (!payment) return { ignored: true, reason: 'transaction_not_found' };

    let capture;
    try {
      capture = await this.paypal.getCapture(captureId);
    } catch (error) {
      this.logger.warn('No se pudo verificar el reembolso con PayPal', {
        captureId,
        code: error.code || 'error',
        retryable: Boolean(error.retryable),
      });
      throw new AppError('No se pudo verificar el reembolso con PayPal.', 502, 'paypal_unavailable');
    }
    if (!capture || String(capture.id) !== captureId) {
      throw new AppError('PayPal devolvió una captura no válida.', 502, 'paypal_metadata_mismatch');
    }
    const captureAmount = capture.amount && parsePayPalAmount(capture.amount.value);
    if (captureAmount !== Number(payment.amount_cents)
      || normalizePayPalCurrency(capture.amount && capture.amount.currency_code) !== payment.currency) {
      throw new AppError('Los importes del reembolso no coinciden.', 409, 'refund_amount_mismatch');
    }
    let refundAmount = null;
    if (resource.amount) {
      refundAmount = parsePayPalAmount(resource.amount.value);
      if (normalizePayPalCurrency(resource.amount.currency_code) !== payment.currency) refundAmount = null;
    }
    if (resource.status && !['COMPLETED', 'PENDING'].includes(resource.status)) {
      return { ignored: true, reason: 'refund_not_completed' };
    }
    if (resource.status === 'PENDING') return { ignored: true, reason: 'refund_pending' };
    const fullRefund = ['REFUNDED', 'REVERSED'].includes(capture.status)
      || event.event_type === 'PAYMENT.CAPTURE.REVERSED';
    if (!fullRefund) {
      if (!refundAmount || refundAmount <= 0 || refundAmount > captureAmount) {
        throw new AppError('El reembolso parcial no tiene un importe válido.', 409, 'refund_amount_mismatch');
      }
      const refundId = transactionRefundId(resource.id || crypto.randomUUID());
      if (await this.db.get('SELECT id FROM transactions WHERE provider_id = ?', [refundId])) {
        return { ignored: true, reason: 'refund_already_recorded' };
      }
      const now = nowIso();
      await this.db.transaction(async () => {
        await this.db.run(
          `INSERT INTO transactions(id, kind, provider, provider_id, order_id, license_id, amount_cents, currency, status, created_at)
           VALUES (?, 'refund', 'paypal', ?, ?, ?, ?, ?, 'completed', ?)`,
          [crypto.randomUUID(), refundId, payment.order_id, payment.license_id, refundAmount, payment.currency, now],
        );
        await this.audit.record({
          actorType: 'system', actorId: null, action: 'order.partially_refunded', targetType: 'order',
          targetId: payment.order_id, details: { refundAmount, captureId }, ip,
        });
      });
      return { partialRefund: true, refundAmount };
    }
    if (refundAmount === null) refundAmount = captureAmount;
    if (refundAmount <= 0 || refundAmount > captureAmount) {
      throw new AppError('El importe del reembolso no es válido.', 409, 'refund_amount_mismatch');
    }
    const refundId = event.event_type === 'PAYMENT.CAPTURE.REVERSED'
      ? `reversal:${resource.id || captureId}`
      : transactionRefundId(resource.id || crypto.randomUUID());
    if (await this.db.get('SELECT id FROM transactions WHERE provider_id = ?', [refundId])) {
      return { ignored: true, reason: 'refund_already_recorded' };
    }
    const now = nowIso();
    let revokedLicenseId = null;
    await this.db.transaction(async () => {
      const order = payment.order_id ? await this.orderById(payment.order_id) : null;
      await this.db.run(
        `INSERT INTO transactions(id, kind, provider, provider_id, order_id, license_id, amount_cents, currency, status, created_at)
         VALUES (?, 'refund', 'paypal', ?, ?, ?, ?, ?, 'completed', ?)`,
        [crypto.randomUUID(), refundId, payment.order_id, payment.license_id, refundAmount, payment.currency, now],
      );
      if (order) {
        await this.db.run(
          `UPDATE orders SET status = 'refunded', refunded_at = ?, updated_at = ? WHERE id = ?`,
          [now, now, order.id],
        );
      }
      if (payment.license_id) {
        const license = await this.licenses.rowById(payment.license_id);
        if (license && license.status !== 'revoked') {
          await this.licenses.revoke(payment.license_id, {
            reason: 'Reembolso completo de PayPal',
            actorType: 'system',
            actorId: null,
            ip,
          });
          revokedLicenseId = payment.license_id;
        }
      }
      await this.audit.record({
        actorType: 'system', actorId: null, action: 'order.refunded', targetType: 'order',
        targetId: payment.order_id, details: { refundAmount, captureId, revokedLicenseId }, ip,
      });
    });
    this.logger.warn('Pago reembolsado y licencia revocada', {
      orderId: payment.order_id,
      licenseId: revokedLicenseId,
      captureId,
    });
    return { fullRefund: true, refundAmount, revokedLicenseId };
  }

  async handleWebhookEvent(event, ip) {
    const type = String(event.event_type);
    if (['CHECKOUT.ORDER.APPROVED', 'PAYMENT.CAPTURE.COMPLETED'].includes(type)) {
      const order = await this.orderForEvent(event);
      if (!order) return { ignored: true, reason: 'order_not_found' };
      const snapshot = await this.reconcileOrder(order, { trigger: 'webhook', ip });
      return { orderId: order.id, status: snapshot.status };
    }
    if (['PAYMENT.CAPTURE.REFUNDED', 'PAYMENT.CAPTURE.REVERSED'].includes(type)) {
      return this.handleRefundEvent(event, ip);
    }
    if (['PAYMENT.CAPTURE.DENIED', 'PAYMENT.CAPTURE.DECLINED', 'CHECKOUT.ORDER.DECLINED'].includes(type)) {
      const order = await this.orderForEvent(event);
      if (!order || order.status === 'paid' || order.license_id) return { ignored: true, reason: 'order_not_applicable' };
      const updated = await this.markTerminal(
        order.id,
        'failed',
        'PayPal rechazó el pago. No se emitió ninguna licencia.',
        'order.payment_denied',
        ip,
      );
      return { orderId: order.id, status: updated ? updated.status : 'failed' };
    }
    if (['CHECKOUT.ORDER.VOIDED'].includes(type)) {
      const order = await this.orderForEvent(event);
      if (!order || order.status === 'paid' || order.license_id) return { ignored: true, reason: 'order_not_applicable' };
      const updated = await this.markTerminal(
        order.id,
        'cancelled',
        'PayPal anuló la orden.',
        'order.voided',
        ip,
      );
      return { orderId: order.id, status: updated ? updated.status : 'cancelled' };
    }
    return { ignored: true, reason: 'event_not_handled' };
  }

  async processWebhook({ headers, rawBody, ip } = {}) {
    if (!(await this.paymentGateway()).enabled || !this.paypal || !(await this.paypal.isEnabled())) {
      throw unavailable('El webhook no está configurado.', 'payments_unavailable');
    }
    let event;
    try {
      event = JSON.parse(rawBody);
    } catch {
      throw badRequest('El webhook no contiene JSON válido.', 'invalid_webhook');
    }
    const eventId = String(event && event.id || '');
    const eventType = String(event && event.event_type || '');
    if (!/^[A-Za-z0-9._-]{1,128}$/.test(eventId) || !/^[A-Z0-9._]{3,80}$/.test(eventType)) {
      throw badRequest('El webhook no tiene identificadores válidos.', 'invalid_webhook');
    }
    await this.paypal.verifyWebhook({ headers, event });

    const receivedAt = nowIso();
    const orderForEvent = await this.orderForEvent(event);
    let row = await this.db.get('SELECT id, status FROM webhook_events WHERE id = ?', [eventId]);
    if (row && row.status !== 'failed') {
      return { duplicate: true, status: row.status };
    }
    if (row && row.status === 'failed') {
      await this.db.run(
        `UPDATE webhook_events SET status = 'processing', error = NULL, received_at = ?, processed_at = NULL,
         order_id = COALESCE(?, order_id) WHERE id = ?`,
        [receivedAt, orderForEvent ? orderForEvent.id : null, eventId],
      );
    } else {
      await this.db.run(
        `INSERT INTO webhook_events(id, event_type, resource_id, order_id, status, error, received_at, processed_at)
         VALUES (?, ?, ?, ?, 'processing', NULL, ?, NULL)`,
        [
          eventId,
          eventType,
          sanitizeText(event.resource && event.resource.id, 100) || null,
          orderForEvent ? orderForEvent.id : null,
          receivedAt,
        ],
      );
    }

    try {
      const outcome = await this.handleWebhookEvent(event, ip);
      const status = outcome && outcome.ignored ? 'ignored' : 'processed';
      await this.db.run(
        `UPDATE webhook_events SET status = ?, processed_at = ?, error = ? WHERE id = ?`,
        [status, nowIso(), outcome && outcome.ignored ? sanitizeText(outcome.reason, 200) : null, eventId],
      );
      await this.audit.record({
        actorType: 'paypal',
        actorId: null,
        action: 'webhook.processed',
        targetType: 'webhook',
        targetId: eventId,
        details: { eventType, outcome },
        ip,
      });
      return { duplicate: false, status, outcome };
    } catch (error) {
      const message = error instanceof AppError ? error.message : 'Error al procesar el webhook.';
      await this.db.run(
        `UPDATE webhook_events SET status = 'failed', processed_at = ?, error = ? WHERE id = ?`,
        [nowIso(), sanitizeText(message, 300), eventId],
      );
      this.logger.error('Error al procesar webhook de PayPal', {
        eventId,
        eventType,
        code: error.code || 'error',
      });
      throw error;
    }
  }

  async listOrders({ status = 'all', query = '', page = 1, pageSize = 25 } = {}) {
    const params = [];
    const conditions = [];
    if (['created', 'pending', 'paid', 'failed', 'cancelled', 'refunded', 'expired'].includes(String(status))) {
      conditions.push('status = ?');
      params.push(String(status));
    }
    const text = sanitizeText(query, 120);
    if (text) {
      const like = `%${text.replace(/[\\%_]/g, (match) => `\\${match}`)}%`;
      conditions.push(
        `(lower(id) LIKE lower(?) ESCAPE '\\' OR lower(email) LIKE lower(?) ESCAPE '\\' `
        + `OR lower(paypal_order_id) LIKE lower(?) ESCAPE '\\' OR lower(failure_reason) LIKE lower(?) ESCAPE '\\')`,
      );
      params.push(like, like, like, like);
    }
    const where = conditions.length ? `WHERE ${conditions.join(' AND ')}` : '';
    const totalRow = await this.db.get(`SELECT COUNT(*) AS n FROM orders ${where}`, params);
    const total = Number(totalRow ? totalRow.n : 0);
    const size = Math.min(Math.max(Number(pageSize) || 25, 10), 100);
    const pages = Math.max(1, Math.ceil(total / size));
    const current = Math.min(Math.max(Number(page) || 1, 1), pages);
    const rows = await this.db.all(
      `SELECT * FROM orders ${where} ORDER BY created_at DESC LIMIT ? OFFSET ?`,
      [...params, size, (current - 1) * size],
    );
    return {
      items: rows.map((row) => this.adminOrderView(row)),
      total,
      page: current,
      pages,
      pageSize: size,
    };
  }

  adminOrderView(row) {
    const plan = this.planForOrder(row);
    return {
      id: row.id,
      email: row.email,
      customerName: row.customer_name || '',
      status: row.status,
      amountCents: row.amount_cents,
      currency: row.currency,
      plan: plan.code,
      planLabel: plan.label,
      durationMonths: Number(row.duration_months) || plan.months,
      paypalOrderId: row.paypal_order_id,
      licenseId: row.license_id,
      payerEmail: row.payer_email,
      failureReason: row.failure_reason,
      createdAt: row.created_at,
      updatedAt: row.updated_at,
      paidAt: row.paid_at,
      refundedAt: row.refunded_at,
      completedAt: row.completed_at,
    };
  }

  async orderDetail(id) {
    const order = await this.orderById(id);
    if (!order) throw notFound('La orden no existe.', 'order_not_found');
    let license = null;
    if (order.license_id) {
      const row = await this.licenses.rowById(order.license_id);
      if (row) {
        let keyMasked = '••••-••••-••••-••••';
        try {
          keyMasked = this._maskKey(this.licenses.keyForRow(row));
        } catch {
          keyMasked = 'error';
        }
        license = {
          id: row.id,
          status: effectiveStatus(row),
          customerName: row.customer_name,
          expiresAt: row.expires_at,
          machineCode: row.machine_code,
          keyMasked,
        };
      }
    }
    const transactions = (await this.db.all(
      'SELECT id, kind, provider_id, amount_cents, currency, status, created_at FROM transactions WHERE order_id = ? ORDER BY created_at ASC',
      [order.id],
    )).map((item) => ({
      id: item.id,
      kind: item.kind,
      providerId: item.provider_id,
      amountCents: item.amount_cents,
      currency: item.currency,
      status: item.status,
      createdAt: item.created_at,
    }));
    return {
      ...this.adminOrderView(order),
      approvalUrl: order.approval_url,
      license,
      transactions,
    };
  }

  _maskKey(key) {
    return `••••-••••-••••-${String(key || '').slice(-4)}`;
  }

  async listTransactions({ page = 1, pageSize = 50 } = {}) {
    const totalRow = await this.db.get('SELECT COUNT(*) AS n FROM transactions');
    const total = Number(totalRow ? totalRow.n : 0);
    const size = Math.min(Math.max(Number(pageSize) || 50, 10), 200);
    const pages = Math.max(1, Math.ceil(total / size));
    const current = Math.min(Math.max(Number(page) || 1, 1), pages);
    const rows = await this.db.all(
      `SELECT * FROM transactions ORDER BY created_at DESC LIMIT ? OFFSET ?`,
      [size, (current - 1) * size],
    );
    return {
      items: rows.map((row) => ({
        id: row.id,
        kind: row.kind,
        provider: row.provider,
        providerId: row.provider_id,
        orderId: row.order_id,
        licenseId: row.license_id,
        amountCents: row.amount_cents,
        currency: row.currency,
        status: row.status,
        createdAt: row.created_at,
      })),
      total,
      page: current,
      pages,
      pageSize: size,
    };
  }

  async maintenance() {
    const now = Date.now();
    const cutoff = new Date(now - 24 * 60 * 60 * 1000).toISOString();
    const stale = await this.db.all(
      `SELECT id FROM orders
       WHERE status IN ('created', 'pending') AND license_id IS NULL AND created_at <= ?`,
      [cutoff],
    );
    let expired = 0;
    for (const row of stale) {
      const updated = await this.markTerminal(
        row.id,
        'expired',
        'La orden expiró sin un pago confirmado.',
        'order.expired',
        null,
      );
      if (updated) expired += 1;
    }
    const sessions = await this.db.run('DELETE FROM admin_sessions WHERE expires_at <= ?', [nowIso()]);
    const webhooks = await this.db.run(
      `UPDATE webhook_events SET status = 'failed', processed_at = ?,
       error = COALESCE(error, 'Procesamiento interrumpido') WHERE status = 'processing' AND received_at <= ?`,
      [nowIso(), cutoff],
    );
    const emails = await this.db.run(
      `UPDATE email_outbox SET status = 'failed', next_attempt_at = ?,
       last_error = COALESCE(last_error, 'Envío interrumpido') WHERE status = 'sending' AND created_at <= ?`,
      [nowIso(), cutoff],
    );
    return {
      ordersExpired: expired,
      sessionsRemoved: Number(sessions.changes || 0),
      webhooksReset: Number(webhooks.changes || 0),
      emailsReset: Number(emails.changes || 0),
    };
  }
}

module.exports = {
  OrdersService,
  OrderMetadataError,
  parsePayPalAmount,
  extractCaptureIdFromLinks,
};
