'use strict';

const DEFAULT_PLAN_CODE = 'annual';
const MAX_PRICE_CENTS = 10_000_000;

const PLANS = Object.freeze([
  Object.freeze({
    code: 'monthly',
    months: 1,
    label: 'Mensual',
    periodLabel: 'mes',
    defaultPriceCents: 1000,
  }),
  Object.freeze({
    code: 'semiannual',
    months: 6,
    label: 'Semestral',
    periodLabel: '6 meses',
    defaultPriceCents: 5000,
  }),
  Object.freeze({
    code: 'annual',
    months: 12,
    label: 'Anual',
    periodLabel: '12 meses',
    defaultPriceCents: 10000,
  }),
]);

const PLAN_BY_CODE = new Map(PLANS.map((plan) => [plan.code, plan]));

function planByCode(code) {
  return PLAN_BY_CODE.get(String(code || '').trim().toLowerCase()) || null;
}

function normalizePlanCode(code, fallback = DEFAULT_PLAN_CODE) {
  const plan = planByCode(code);
  return plan ? plan.code : fallback;
}

function planMonths(code) {
  const plan = planByCode(code);
  return plan ? plan.months : 0;
}

function planLabel(code) {
  const plan = planByCode(code);
  return plan ? plan.label : String(code || '');
}

function planDescription(plan) {
  if (!plan) return '';
  return plan.months === 1 ? 'Vigencia de 1 mes' : `Vigencia de ${plan.months} meses`;
}

function sanitizePriceCents(value) {
  const parsed = typeof value === 'string' && /^\d+(?:[.,]\d{1,2})?$/.test(value.trim())
    ? Math.round(Number(value.trim().replace(',', '.')) * 100)
    : Number(value);
  if (!Number.isInteger(parsed) || parsed < 50 || parsed > MAX_PRICE_CENTS) return null;
  return parsed;
}

module.exports = {
  DEFAULT_PLAN_CODE,
  MAX_PRICE_CENTS,
  PLANS,
  planByCode,
  normalizePlanCode,
  planMonths,
  planLabel,
  planDescription,
  sanitizePriceCents,
};
