'use strict';

const SENSITIVE_KEY = /pass|secret|token|authorization|cookie|private.?key|license.?key|key_enc|key_hash/i;

function redact(value, depth = 0) {
  if (depth > 4) return '[profundidad]';
  if (value === null || value === undefined) return value;
  if (typeof value === 'string') return value.length > 1000 ? `${value.slice(0, 1000)}…` : value;
  if (typeof value === 'number' || typeof value === 'boolean') return value;
  if (Array.isArray(value)) return value.slice(0, 50).map((item) => redact(item, depth + 1));
  if (typeof value === 'object') {
    const out = {};
    for (const [key, item] of Object.entries(value)) {
      out[key] = SENSITIVE_KEY.test(key) ? '[redactado]' : redact(item, depth + 1);
    }
    return out;
  }
  return String(value);
}

function createLogger(options = {}) {
  const level = options.level || process.env.PERFILLAB_LOG_LEVEL || 'info';
  const sink = options.sink || console;
  const levels = { debug: 10, info: 20, warn: 30, error: 40 };
  const minimum = levels[level] || 20;
  function emit(targetLevel, message, data) {
    if ((levels[targetLevel] || 20) < minimum) return;
    const entry = {
      time: new Date().toISOString(),
      level: targetLevel,
      msg: String(message || ''),
      ...(data && typeof data === 'object' ? redact(data) : {}),
    };
    const method = targetLevel === 'error' ? 'error' : targetLevel === 'warn' ? 'warn' : 'log';
    sink[method](JSON.stringify(entry));
  }
  return {
    debug: (message, data) => emit('debug', message, data),
    info: (message, data) => emit('info', message, data),
    warn: (message, data) => emit('warn', message, data),
    error: (message, data) => emit('error', message, data),
  };
}

const logger = createLogger();

module.exports = { createLogger, logger, redact };
