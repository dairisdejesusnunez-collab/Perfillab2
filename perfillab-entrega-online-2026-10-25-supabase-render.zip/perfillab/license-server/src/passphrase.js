'use strict';

const fs = require('node:fs');
const readline = require('node:readline');

const MAX_SECRET_FILE_BYTES = 4096;

function readSecretFile(filePath) {
  const stat = fs.statSync(filePath);
  if (!stat.isFile() || stat.size > MAX_SECRET_FILE_BYTES) {
    throw new Error('El archivo de secreto no es válido o es demasiado grande.');
  }
  return fs.readFileSync(filePath, 'utf8').replace(/\r?\n$/, '');
}

function secretFromEnvironment(env, name, fileVar) {
  const direct = typeof env[name] === 'string' ? env[name] : '';
  if (direct) return direct;
  const filePath = typeof env[fileVar] === 'string' ? env[fileVar].trim() : '';
  if (!filePath) return '';
  return readSecretFile(filePath);
}

function promptHidden(question) {
  return new Promise((resolve, reject) => {
    if (!process.stdin.isTTY || !process.stdout.isTTY) {
      reject(new Error('No hay una terminal interactiva para solicitar el secreto.'));
      return;
    }
    const rl = readline.createInterface({
      input: process.stdin,
      output: process.stdout,
      terminal: true,
    });
    let settled = false;
    const finish = (fn, value) => {
      if (settled) return;
      settled = true;
      process.stdout.write('\n');
      rl.close();
      fn(value);
    };
    rl._writeToOutput = () => {};
    rl.on('SIGINT', () => {
      if (settled) return;
      settled = true;
      rl.close();
      process.stdout.write('\n');
      reject(new Error('Operación cancelada.'));
    });
    process.stdout.write(question);
    rl.question('', (answer) => finish(resolve, answer));
  });
}

async function requirePassphrase(options = {}) {
  const env = options.env || process.env;
  const name = options.envVar || 'PERFILLAB_KEYSTORE_PASSPHRASE';
  const fileVar = options.fileVar || 'PERFILLAB_KEYSTORE_PASSPHRASE_FILE';
  const label = options.label || 'Frase de paso del keystore';
  const minLength = options.minLength === undefined ? 12 : options.minLength;
  const value = secretFromEnvironment(env, name, fileVar) || await promptHidden(`${label}: `);
  if (!value) throw new Error(`${label} no configurada.`);
  if (value.length < minLength) throw new Error(`${label} debe tener al menos ${minLength} caracteres.`);
  if (value.length > 500) throw new Error(`${label} es demasiado larga.`);
  return value;
}

async function requireConfirmedPassphrase(options = {}) {
  const env = options.env || process.env;
  const fromEnvironment = secretFromEnvironment(
    env,
    options.envVar || 'PERFILLAB_KEYSTORE_PASSPHRASE',
    options.fileVar || 'PERFILLAB_KEYSTORE_PASSPHRASE_FILE',
  );
  if (fromEnvironment) return requirePassphrase({ ...options, env });
  const first = await promptHidden(`${options.label || 'Frase de paso'} (nueva): `);
  if (!first) throw new Error('La frase de paso no puede estar vacía.');
  if (first.length < (options.minLength === undefined ? 12 : options.minLength)) {
    throw new Error(`La frase de paso debe tener al menos ${options.minLength === undefined ? 12 : options.minLength} caracteres.`);
  }
  const second = await promptHidden('Confirmar frase de paso: ');
  if (first !== second) throw new Error('Las frases de paso no coinciden.');
  return first;
}

module.exports = {
  secretFromEnvironment,
  requirePassphrase,
  requireConfirmedPassphrase,
  promptHidden,
  readSecretFile,
};
