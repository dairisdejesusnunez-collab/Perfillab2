'use strict';

const { AppError, badRequest } = require('./errors');
const { PayPalClient } = require('./paypal');
const { decryptField, encryptField, nowIso } = require('./security');
const {
  PLANS,
  planByCode,
  sanitizePriceCents,
} = require('./plans');


const PAYPAL_SANDBOX = 'https://api-m.sandbox.paypal.com';
const PAYPAL_LIVE = 'https://api-m.paypal.com';
const SETTINGS_KEY = 'payments.settings';
const SECRET_KEY = 'payments.paypal_secret';
const SECRET_AAD = 'payments:paypal_secret';
const CURRENCY = 'USD';

function clean(value, max = 300) {
  return typeof value === 'string' ? value.trim().slice(0, max) : '';
}

function normalizeMode(value, fallback = 'sandbox') {
  const mode = clean(value, 16).toLowerCase() || fallback;
  if (!['sandbox', 'live'].includes(mode)) {
    throw badRequest('El modo de PayPal debe ser sandbox o live.', 'invalid_mode');
  }
  return mode;
}

function apiBaseFor(mode) {
  return mode === 'live' ? PAYPAL_LIVE : PAYPAL_SANDBOX;
}

class PaymentSettings {
  constructor({ db, keystore, config, audit, logger, fetchImpl = null }) {
    this.db = db;
    this.keystore = keystore;
    this.config = config;
    this.audit = audit;
    this.logger = logger;
    this.fetchImpl = fetchImpl;
  }

  async readStored() {
    const raw = await this.db.getSetting(SETTINGS_KEY, '');
    if (!raw) return null;
    try {
      const parsed = JSON.parse(raw);
      if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) return null;
      return parsed;
    } catch {
      this.logger.warn('La configuración de pagos guardada no es JSON válido.');
      return null;
    }
  }

  async readStoredSecret() {
    const encrypted = await this.db.getSetting(SECRET_KEY, '');
    if (!encrypted) return '';
    try {
      return decryptField(encrypted, this.keystore.dataKey, SECRET_AAD);
    } catch {
      this.logger.error('No se pudo descifrar el secreto de PayPal guardado.');
      return '';
    }
  }

  storedPrices(stored) {
    const prices = stored && stored.prices && typeof stored.prices === 'object' ? stored.prices : {};
    const output = {};
    for (const plan of PLANS) {
      const candidate = sanitizePriceCents(prices[plan.code]);
      output[plan.code] = candidate || this.defaultPrice(plan);
    }
    return output;
  }

  defaultPrice(plan) {
    if (plan.code === 'annual' && Number.isInteger(this.config.paypal.priceCents) && this.config.paypal.priceCents >= 50) {
      return this.config.paypal.priceCents;
    }
    return plan.defaultPriceCents;
  }

  async resolve() {
    const stored = await this.readStored();
    const storedSecret = await this.readStoredSecret();
    const env = this.config.paypal || {};
    const storedIdentity = Boolean(stored && (stored.clientId || stored.webhookId));
    const clientId = storedIdentity ? clean(stored.clientId, 200) : clean(env.clientId, 200);
    const webhookId = storedIdentity ? clean(stored.webhookId, 100) : clean(env.webhookId, 100);
    const clientSecret = storedSecret || clean(env.clientSecret, 200);
    const mode = normalizeMode(stored && stored.mode ? stored.mode : env.mode, 'sandbox');
    const prices = this.storedPrices(stored);
    const storedPrices = Boolean(stored && stored.prices && typeof stored.prices === 'object');
    const envPrice = Number.isInteger(env.priceCents) && env.priceCents >= 50;
    const missing = [];
    if (!this.config.publicBaseUrl) missing.push('publicBaseUrl');
    if (!clientId) missing.push('clientId');
    if (!clientSecret) missing.push('clientSecret');
    if (!webhookId) missing.push('webhookId');
    return {
      stored,
      source: storedIdentity ? 'db' : (clientId || webhookId || env.clientSecret ? 'env' : 'none'),
      mode,
      apiBase: apiBaseFor(mode),
      clientId,
      clientSecret,
      webhookId,
      configured: Boolean(clientId && clientSecret && webhookId),
      enabled: Boolean(clientId && clientSecret && webhookId && this.config.publicBaseUrl),
      prices,
      pricesSource: storedPrices ? 'db' : (envPrice ? 'env' : 'default'),
      missing,
      updatedAt: stored && stored.updatedAt ? String(stored.updatedAt) : null,
      secretUpdatedAt: stored && stored.secretUpdatedAt ? String(stored.secretUpdatedAt) : null,
      secretSource: storedSecret ? 'db' : (env.clientSecret ? 'env' : 'none'),
    };
  }

  async isEnabled() {
    return (await this.resolve()).enabled;
  }

  async gateway() {
    const resolved = await this.resolve();
    return {
      enabled: resolved.enabled,
      currency: CURRENCY,
      prices: { ...resolved.prices },
      publicBaseUrl: this.config.publicBaseUrl || '',
      mode: resolved.mode,
    };
  }

  async checkoutPlan(code) {
    const plan = planByCode(code);
    if (!plan) return null;
    const resolved = await this.resolve();
    const amountCents = resolved.prices[plan.code];
    return { ...plan, amountCents, currency: CURRENCY };
  }

  async paypalConfig() {
    const resolved = await this.resolve();
    return {
      mode: resolved.mode,
      apiBase: resolved.apiBase,
      clientId: resolved.clientId,
      clientSecret: resolved.clientSecret,
      webhookId: resolved.webhookId,
      currency: CURRENCY,
      priceCents: resolved.prices.annual,
    };
  }

  plansFrom(resolved) {
    return PLANS.map((plan) => ({
      code: plan.code,
      months: plan.months,
      label: plan.label,
      periodLabel: plan.periodLabel,
      description: plan.months === 1 ? 'Vigencia de 1 mes' : `Vigencia de ${plan.months} meses`,
      amountCents: resolved.prices[plan.code],
      currency: CURRENCY,
    }));
  }

  async publicPlans() {
    return this.plansFrom(await this.resolve());
  }

  async snapshot() {
    const resolved = await this.resolve();
    return {
      enabled: resolved.enabled,
      configured: resolved.configured,
      source: resolved.source,
      mode: resolved.mode,
      clientId: resolved.clientId,
      webhookId: resolved.webhookId,
      secretConfigured: Boolean(resolved.clientSecret),
      secretSource: resolved.secretSource,
      secretUpdatedAt: resolved.secretUpdatedAt,
      pricesSource: resolved.pricesSource,
      plans: this.plansFrom(resolved),
      currency: CURRENCY,
      publicBaseUrl: this.config.publicBaseUrl || null,
      webhookPath: '/api/paypal/webhook',
      webhookUrl: this.config.publicBaseUrl ? `${this.config.publicBaseUrl}/api/paypal/webhook` : null,
      missing: resolved.missing,
      updatedAt: resolved.updatedAt,
      environment: this.config.env,
      local: false,
    };
  }

  async save(input = {}, context = {}) {
    const data = input && typeof input === 'object' ? input : {};
    const stored = await this.readStored();
    const existingSecret = await this.readStoredSecret();
    const envSecret = clean(this.config.paypal && this.config.paypal.clientSecret, 200);
    const mode = normalizeMode(data.mode, (stored && stored.mode) || (this.config.paypal && this.config.paypal.mode));
    const clientId = clean(data.clientId, 200);
    const webhookId = clean(data.webhookId, 100);
    const providedSecret = clean(data.clientSecret, 200);
    if (!clientId) throw badRequest('Escribe el Client ID de PayPal.', 'missing_client_id');
    if (!/^[A-Za-z0-9._-]{8,200}$/.test(clientId)) {
      throw badRequest('El Client ID de PayPal no tiene un formato válido.', 'invalid_client_id');
    }
    if (!webhookId) throw badRequest('Escribe el ID del webhook de PayPal.', 'missing_webhook_id');
    if (!/^[A-Za-z0-9_-]{6,100}$/.test(webhookId)) {
      throw badRequest('El ID del webhook de PayPal no tiene un formato válido.', 'invalid_webhook_id');
    }
    if (providedSecret && !/^[\x21-\x7E]{8,200}$/.test(providedSecret)) {
      throw badRequest('El Client Secret de PayPal no tiene un formato válido.', 'invalid_client_secret');
    }
    if (!providedSecret && !existingSecret && !envSecret) {
      throw badRequest('Escribe el Client Secret de PayPal.', 'missing_client_secret');
    }
    if (mode === 'live' && (!this.config.publicBaseUrl || !String(this.config.publicBaseUrl).startsWith('https://'))) {
      throw badRequest(
        'PayPal en modo live exige que el servidor tenga una URL pública HTTPS configurada.',
        'live_requires_https',
      );
    }
    const priceInput = data.prices && typeof data.prices === 'object' ? data.prices : {};
    const previousPrices = this.storedPrices(stored);
    const prices = {};
    for (const plan of PLANS) {
      const raw = priceInput[plan.code] !== undefined ? priceInput[plan.code] : previousPrices[plan.code];
      const cents = sanitizePriceCents(raw);
      if (!cents) {
        throw badRequest(
          `El precio del plan ${plan.label} no es válido. Debe estar entre 0,50 y 100.000 USD.`,
          'invalid_price',
        );
      }
      prices[plan.code] = cents;
    }
    const now = nowIso();
    const secretChanged = Boolean(providedSecret);
    const record = {
      version: 1,
      mode,
      clientId,
      webhookId,
      prices,
      updatedAt: now,
      secretUpdatedAt: secretChanged ? now : ((stored && stored.secretUpdatedAt) || null),
    };
    await this.db.transaction(async () => {
      await this.db.setSetting(SETTINGS_KEY, JSON.stringify(record), now);
      if (secretChanged) {
        await this.db.setSetting(SECRET_KEY, encryptField(providedSecret, this.keystore.dataKey, SECRET_AAD), now);
      }
      await this.audit.record({
        actorType: context.actorType || 'admin',
        actorId: context.actorId || null,
        action: 'payments.updated',
        targetType: 'payments',
        targetId: 'paypal',
        details: {
          mode,
          clientId: `${clientId.slice(0, 6)}…${clientId.slice(-4)}`,
          webhookId: `${webhookId.slice(0, 4)}…${webhookId.slice(-3)}`,
          prices,
          secretChanged,
        },
        ip: context.ip,
      });
    });
    this.logger.info('Configuración de PayPal actualizada', { mode, secretChanged });
    return this.snapshot();
  }

  async clear(context = {}) {
    await this.db.transaction(async () => {
      await this.db.run('DELETE FROM settings WHERE key = ?', [SETTINGS_KEY]);
      await this.db.run('DELETE FROM settings WHERE key = ?', [SECRET_KEY]);
      await this.audit.record({
        actorType: context.actorType || 'admin',
        actorId: context.actorId || null,
        action: 'payments.cleared',
        targetType: 'payments',
        targetId: 'paypal',
        details: null,
        ip: context.ip,
      });
    });
    return this.snapshot();
  }

  async test(input = {}, context = {}) {
    const data = input && typeof input === 'object' ? input : {};
    const resolved = await this.resolve();
    const mode = normalizeMode(data.mode, resolved.mode);
    const clientId = clean(data.clientId, 200) || resolved.clientId;
    const clientSecret = clean(data.clientSecret, 200) || resolved.clientSecret;
    const webhookId = clean(data.webhookId, 100) || resolved.webhookId;
    if (!clientId || !clientSecret) {
      throw badRequest('Completa el Client ID y el Client Secret antes de probar la conexión.', 'payments_incomplete');
    }
    const client = new PayPalClient({
      config: {
        mode,
        apiBase: apiBaseFor(mode),
        clientId,
        clientSecret,
        webhookId,
        currency: CURRENCY,
      },
      fetchImpl: this.fetchImpl || undefined,
      logger: this.logger,
    });
    try {
      await client.accessToken();
    } catch (error) {
      await this.audit.record({
        actorType: context.actorType || 'admin',
        actorId: context.actorId || null,
        action: 'payments.test_failed',
        targetType: 'payments',
        targetId: 'paypal',
        details: { mode, code: error.code || 'paypal_error', status: error.status || 0 },
        ip: context.ip,
      });
      throw new AppError(
        'PayPal rechazó las credenciales. Revisa el Client ID, el Client Secret y el modo sandbox/live.',
        502,
        'paypal_auth_failed',
      );
    }
    await this.audit.record({
      actorType: context.actorType || 'admin',
      actorId: context.actorId || null,
      action: 'payments.tested',
      targetType: 'payments',
      targetId: 'paypal',
      details: { mode, webhookConfigured: Boolean(webhookId) },
      ip: context.ip,
    });
    return {
      ok: true,
      mode,
      webhookConfigured: Boolean(webhookId),
      message: 'PayPal aceptó las credenciales. Guarda los cambios para aplicarlos a la tienda.',
    };
  }
}

module.exports = {
  PaymentSettings,
  SETTINGS_KEY,
  SECRET_KEY,
  SECRET_AAD,
};
