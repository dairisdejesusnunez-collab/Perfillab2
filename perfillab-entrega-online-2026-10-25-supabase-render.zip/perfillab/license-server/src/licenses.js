'use strict';

const crypto = require('node:crypto');

const {
  LICENSE_VERSION,
  LICENSE_VERSION_V1,
  signLicenseV1,
  signLicenseV2,
  signRevocationList,
} = require('./license-format');
const {
  addMonthsIso,
  decryptField,
  hashToken,
  keyHash,
  maskLicenseKey,
  normalizeEmail,
  normalizeLegacyLicenseKey,
  normalizeLicenseKey,
  normalizeMachineCode,
  nowIso,
  sanitizeText,
  isValidEmail,
} = require('./security');
const { AppError, badRequest, conflict, notFound } = require('./errors');
const { isUniqueViolation } = require('./database');
const { DEFAULT_PLAN_CODE, planByCode } = require('./plans');

const DATE_REASON_MIN = 3;
const DATE_REASON_MAX = 300;

function escapeLike(value) {
  return String(value).replace(/[\\%_]/g, (match) => `\\${match}`);
}

function buildListFilter({ query = '', status = 'all' } = {}, dataKey) {
  const conditions = [];
  const params = [];
  const normalizedStatus = String(status || 'all');
  if (['pending', 'active', 'expired', 'revoked', 'suspended'].includes(normalizedStatus)) {
    conditions.push('l.status = ?');
    params.push(normalizedStatus);
  }
  const text = sanitizeText(query, 120);
  if (text) {
    const normalizedKey = normalizeLicenseKey(text);
    const hashes = [];
    if (normalizedKey) hashes.push(keyHash(dataKey, normalizedKey));
    const legacyKey = normalizeLegacyLicenseKey(text);
    if (legacyKey && legacyKey !== normalizedKey) hashes.push(keyHash(dataKey, legacyKey));
    const like = `%${escapeLike(text)}%`;
    const keyClause = hashes.length
      ? ` OR l.key_hash IN (${hashes.map(() => '?').join(', ')})`
      : '';
    conditions.push(
      `(lower(l.id) LIKE lower(?) ESCAPE '\\' OR lower(l.customer_name) LIKE lower(?) ESCAPE '\\' `
      + `OR lower(l.email) LIKE lower(?) ESCAPE '\\' OR lower(l.machine_code) LIKE lower(?) ESCAPE '\\'${keyClause})`,
    );
    params.push(like, like, like, like, ...hashes);
  }
  return {
    where: conditions.length ? `WHERE ${conditions.join(' AND ')}` : '',
    params,
  };
}

function effectiveStatus(row, now = Date.now()) {
  if (!row) return 'unknown';
  if (row.status === 'revoked' || row.status === 'suspended') return row.status;
  if (row.expires_at && Date.parse(row.expires_at) <= now) return 'expired';
  if (!row.machine_code) return 'pending';
  return 'active';
}

function reasonText(value) {
  const reason = sanitizeText(value, DATE_REASON_MAX);
  if (reason.length < DATE_REASON_MIN) throw badRequest('Indica un motivo de al menos 3 caracteres.', 'reason_required');
  return reason;
}

function uniqueConflictText(error) {
  return `${error?.message || ''} ${error?.detail || ''} ${error?.constraint || ''}`;
}

class LicensesService {
  constructor({ db, keystore, config, audit, logger }) {
    this.db = db;
    this.keystore = keystore;
    this.config = config;
    this.audit = audit;
    this.logger = logger;
    this.revocationCache = null;
  }

  normalizeCustomerName(value) {
    const customer = sanitizeText(value, 160);
    if (!customer) throw badRequest('Escribe el nombre del cliente.', 'customer_required');
    return customer;
  }

  normalizeEmailInput(value, { required = false } = {}) {
    const raw = String(value || '').trim();
    if (!raw) {
      if (required) throw badRequest('Escribe un correo electrónico válido.', 'email_required');
      return '';
    }
    if (!isValidEmail(raw)) throw badRequest('El correo electrónico no es válido.', 'invalid_email');
    return normalizeEmail(raw);
  }

  normalizeTransactionId(value) {
    const raw = String(value || '').trim();
    if (!raw) return null;
    if (raw.length > 100 || !/^[A-Za-z0-9._:@-]+$/.test(raw)) {
      throw badRequest('La referencia de pago no es válida.', 'invalid_transaction');
    }
    return raw;
  }

  async sweepExpired(now = nowIso()) {
    const result = await this.db.run(
      `UPDATE licenses SET status = 'expired', updated_at = ?
       WHERE status IN ('active', 'pending') AND expires_at IS NOT NULL AND expires_at <= ?`,
      [now, now],
    );
    const changed = Number(result.changes || 0);
    if (changed) this.logger.info('Licencias marcadas como vencidas', { count: changed });
    return changed;
  }

  keyForRow(row) {
    if (!row || !row.seat_key_enc) throw new Error('La licencia no tiene clave cifrada.');
    try {
      return decryptField(row.seat_key_enc, this.keystore.dataKey, `seat:${row.seat}`);
    } catch {
      this.logger.error('No se pudo descifrar la clave de una licencia', { licenseId: row.id, seat: row.seat });
      throw new AppError('No se pudo recuperar la clave de la licencia.', 500, 'key_decrypt_failed', { expose: false });
    }
  }

  async rowById(id) {
    return this.db.get(
      `SELECT l.*, s.key_enc AS seat_key_enc, s.source AS seat_source
       FROM licenses l JOIN seats s ON s.seat = l.seat
       WHERE l.id = ?`,
      [String(id)],
    );
  }

  async rowByKeyHash(hash) {
    return this.db.get(
      `SELECT l.*, s.key_enc AS seat_key_enc, s.source AS seat_source
       FROM licenses l JOIN seats s ON s.seat = l.seat
       WHERE l.key_hash = ?`,
      [hash],
    );
  }

  async findLicenseByKey(input) {
    const key = normalizeLicenseKey(input);
    if (!key) return { key: '', row: null };
    let row = await this.rowByKeyHash(keyHash(this.keystore.dataKey, key));
    if (!row) {
      const legacy = normalizeLegacyLicenseKey(input);
      if (legacy && legacy !== key) row = await this.rowByKeyHash(keyHash(this.keystore.dataKey, legacy));
    }
    return { key, row };
  }

  payloadFor(row, key) {
    if (row.license_version === LICENSE_VERSION_V1) {
      return {
        licenseId: row.id,
        licenseKey: key,
        seat: row.seat,
        machineCode: row.machine_code,
        customer: row.customer_name,
        issuedAt: row.issued_at,
        expiresAt: row.expires_at || null,
      };
    }
    return {
      keyId: this.keystore.keyId,
      licenseId: row.id,
      licenseKey: key,
      seat: row.seat,
      machineCode: row.machine_code,
      customer: row.customer_name,
      product: row.product,
      plan: row.plan,
      transactionId: row.transaction_id || '',
      issuedAt: row.issued_at,
      startsAt: row.starts_at,
      expiresAt: row.expires_at,
    };
  }

  envelopeFor(row, key) {
    if (!row.machine_code) return null;
    const payload = this.payloadFor(row, key);
    const version = row.license_version === LICENSE_VERSION_V1 ? LICENSE_VERSION_V1 : LICENSE_VERSION;
    return this.signWithVersion(payload, version);
  }

  signWithVersion(payload, version) {
    if (version === LICENSE_VERSION_V1) return signLicenseV1(payload, this.keystore.privateKey);
    return signLicenseV2(payload, this.keystore.privateKey);
  }

  view(row, { effective } = {}) {
    const status = effective || effectiveStatus(row);
    return {
      id: row.id,
      seat: row.seat,
      status,
      storedStatus: row.status,
      customerName: row.customer_name,
      email: row.email || null,
      product: row.product,
      plan: row.plan,
      licenseVersion: row.license_version,
      machineCode: row.machine_code || null,
      machineName: row.machine_name || null,
      transactionId: row.transaction_id || null,
      notes: row.notes || '',
      issuedAt: row.issued_at,
      startsAt: row.starts_at,
      expiresAt: row.expires_at || null,
      activatedAt: row.activated_at || null,
      revokedAt: row.revoked_at || null,
      revokedReason: row.revoked_reason || null,
      suspendedAt: row.suspended_at || null,
      suspendedReason: row.suspended_reason || null,
      createdAt: row.created_at,
      updatedAt: row.updated_at,
    };
  }

  publicInfo(row) {
    const status = effectiveStatus(row);
    return {
      licenseId: row.id,
      seat: row.seat,
      status,
      customerName: row.customer_name,
      plan: row.plan,
      product: row.product,
      licenseVersion: row.license_version,
      machineCode: row.machine_code || null,
      issuedAt: row.issued_at,
      startsAt: row.starts_at,
      expiresAt: row.expires_at || null,
      activatedAt: row.activated_at || null,
      checkedAt: nowIso(),
    };
  }

  async findCustomer(email, name) {
    const normalized = normalizeEmail(email);
    const now = nowIso();
    await this.db.run(
      `INSERT INTO customers(id, email, name, created_at, updated_at)
       VALUES (?, ?, ?, ?, ?) ON CONFLICT DO NOTHING`,
      [crypto.randomUUID(), normalized, name || '', now, now],
    );
    const existing = await this.db.get(
      'SELECT id, name FROM customers WHERE lower(email) = lower(?)',
      [normalized],
    );
    if (!existing) throw new AppError('No se pudo registrar el cliente.', 500, 'customer_failed');
    if (name && !existing.name) {
      await this.db.run('UPDATE customers SET name = ?, updated_at = ? WHERE id = ?', [name, now, existing.id]);
    }
    return existing.id;
  }

  async machineInUse(machineCode, excludeId = null) {
    const row = await this.db.get(
      `SELECT id FROM licenses WHERE machine_code = ? AND status = 'active' AND id <> COALESCE(?, '') LIMIT 1`,
      [machineCode, excludeId],
    );
    return row ? row.id : null;
  }

  async nextLicenseId(seat) {
    const base = `PL-${String(seat).padStart(5, '0')}`;
    let candidate = base;
    let attempts = 0;
    while (await this.db.get('SELECT 1 AS found FROM licenses WHERE id = ?', [candidate])) {
      attempts += 1;
      if (attempts > 5) throw new AppError('No se pudo generar un identificador único.', 500, 'id_generation_failed');
      candidate = `${base}-${crypto.randomBytes(3).toString('hex')}`;
    }
    return candidate;
  }

  async reserveSeat(orderId) {
    return this.db.transaction(async () => {
      const seat = await this.db.get(
        `SELECT seat FROM seats
         WHERE license_id IS NULL AND reserved_order_id IS NULL
         ORDER BY seat ASC LIMIT 1`,
      );
      if (!seat) throw new AppError('No quedan licencias disponibles.', 409, 'capacity_exhausted');
      const now = nowIso();
      const result = await this.db.run(
        `UPDATE seats SET reserved_order_id = ?, reserved_at = ?
         WHERE seat = ? AND license_id IS NULL AND reserved_order_id IS NULL`,
        [String(orderId), now, seat.seat],
      );
      if (Number(result.changes) !== 1) throw new AppError('No se pudo reservar un asiento.', 409, 'seat_reservation_failed');
      return seat.seat;
    });
  }

  async releaseReservation(orderId) {
    const result = await this.db.run(
      'UPDATE seats SET reserved_order_id = NULL, reserved_at = NULL WHERE reserved_order_id = ? AND license_id IS NULL',
      [String(orderId)],
    );
    return Number(result.changes || 0);
  }

  async hasAvailableSeat() {
    return Boolean(await this.db.get(
      'SELECT 1 AS found FROM seats WHERE license_id IS NULL AND reserved_order_id IS NULL LIMIT 1',
    ));
  }

  async availableSeatCount() {
    const row = await this.db.get(
      'SELECT COUNT(*) AS n FROM seats WHERE license_id IS NULL AND reserved_order_id IS NULL',
    );
    return Number(row ? row.n : 0);
  }

  async hasReservation(orderId) {
    return Boolean(await this.db.get(
      'SELECT 1 AS found FROM seats WHERE reserved_order_id = ? AND license_id IS NULL LIMIT 1',
      [String(orderId)],
    ));
  }

  async queueEmail(row, { orderId = null, kind = 'license' } = {}) {
    if (!row.email) return null;
    const now = nowIso();
    const id = crypto.randomUUID();
    await this.db.run(
      `INSERT INTO email_outbox(id, license_id, order_id, to_email, kind, status, attempts, last_error, next_attempt_at, created_at)
       VALUES (?, ?, ?, ?, ?, 'queued', 0, NULL, ?, ?)`,
      [id, row.id, orderId, row.email, kind, now, now],
    );
    return id;
  }

  async issue(input = {}, context = {}) {
    const customerName = this.normalizeCustomerName(input.customerName || input.customer);
    const email = this.normalizeEmailInput(input.email);
    const notes = sanitizeText(input.notes, 500);
    const transactionId = this.normalizeTransactionId(input.transactionId);
    let machineCode = null;
    if (input.machineCode) {
      machineCode = normalizeMachineCode(input.machineCode);
      if (!machineCode) throw badRequest('El código de equipo no es válido.', 'invalid_machine_code');
    }
    const machineName = sanitizeText(input.machineName, 80) || null;
    const reservedOrderId = input.reservedOrderId ? String(input.reservedOrderId) : null;
    let plan = planByCode(this.config.plan) || planByCode(DEFAULT_PLAN_CODE);
    if (input.plan !== undefined && input.plan !== null && input.plan !== '') {
      plan = planByCode(input.plan);
      if (!plan) throw badRequest('El plan de la licencia no es válido.', 'invalid_plan');
    }

    try {
      return await this.db.transaction(async () => {
        await this.sweepExpired();
        if (transactionId && await this.db.get('SELECT id FROM licenses WHERE transaction_id = ?', [transactionId])) {
          throw conflict('Esa transacción ya tiene una licencia emitida.', 'transaction_already_used');
        }
        if (machineCode) {
          const used = await this.machineInUse(machineCode);
          if (used) throw conflict('Ese equipo ya tiene una licencia activa.', 'machine_in_use');
        }
        let seatRow;
        if (reservedOrderId) {
          seatRow = await this.db.get(
            `SELECT seat, key_enc FROM seats
             WHERE reserved_order_id = ? AND license_id IS NULL
             ORDER BY seat ASC LIMIT 1`,
            [reservedOrderId],
          );
        }
        if (!seatRow) {
          seatRow = await this.db.get(
            `SELECT seat, key_enc FROM seats
             WHERE license_id IS NULL AND reserved_order_id IS NULL
             ORDER BY seat ASC LIMIT 1`,
          );
        }
        if (!seatRow) throw new AppError('Las 50.000 licencias históricas ya fueron asignadas.', 409, 'capacity_exhausted');

        const key = decryptField(seatRow.key_enc, this.keystore.dataKey, `seat:${seatRow.seat}`);
        const licenseId = await this.nextLicenseId(seatRow.seat);
        const now = nowIso();
        const expiresAt = addMonthsIso(now, plan.months);
        const status = machineCode ? 'active' : 'pending';
        const customerId = email ? await this.findCustomer(email, customerName) : null;

        await this.db.run(
          `INSERT INTO licenses(
             id, seat, key_hash, customer_id, customer_name, email, product, plan, status, license_version,
             machine_code, machine_name, transaction_id, notes, issued_at, starts_at, expires_at, activated_at,
             revoked_at, revoked_reason, suspended_at, suspended_reason, created_at, updated_at
           ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 2, ?, ?, ?, ?, ?, ?, ?, ?, NULL, NULL, NULL, NULL, ?, ?)`,
          [
            licenseId,
            seatRow.seat,
            keyHash(this.keystore.dataKey, key),
            customerId,
            customerName,
            email || null,
            this.config.product,
            plan.code,
            status,
            machineCode,
            machineCode ? machineName : null,
            transactionId,
            notes,
            now,
            now,
            expiresAt,
            machineCode ? now : null,
            now,
            now,
          ],
        );
        const updated = await this.db.run(
          `UPDATE seats SET license_id = ?, allocated_at = ?, reserved_order_id = NULL, reserved_at = NULL
           WHERE seat = ? AND license_id IS NULL`,
          [licenseId, now, seatRow.seat],
        );
        if (Number(updated.changes) !== 1) throw conflict('El asiento fue asignado por otra operación.', 'seat_conflict');

        if (email && input.queueEmail !== false) {
          await this.queueEmail({ id: licenseId, email }, { orderId: input.orderId || null });
        }

        await this.audit.record({
          actorType: context.actorType || 'admin',
          actorId: context.actorId || null,
          action: 'license.issued',
          targetType: 'license',
          targetId: licenseId,
          details: {
            seat: seatRow.seat,
            customer: customerName,
            email: email || null,
            machineBound: Boolean(machineCode),
            transactionId,
            plan: plan.code,
            durationMonths: plan.months,
            source: context.source || 'manual',
          },
          ip: context.ip,
        });

        const row = await this.rowById(licenseId);
        return {
          license: this.view(row),
          licenseKey: key,
          keyMasked: maskLicenseKey(key),
          envelope: this.envelopeFor(row, key),
        };
      });
    } catch (error) {
      if (isUniqueViolation(error)) {
        const text = uniqueConflictText(error);
        if (/transaction_id/i.test(text)) throw conflict('Esa transacción ya tiene una licencia emitida.', 'transaction_already_used');
        if (/machine_code|idx_licenses_active_machine/i.test(text)) throw conflict('Ese equipo ya tiene una licencia activa.', 'machine_in_use');
        throw conflict('La operación entra en conflicto con otra licencia existente.', 'license_conflict');
      }
      throw error;
    }
  }

  async issueBatch(items, context = {}) {
    if (!Array.isArray(items) || !items.length) throw badRequest('La lista de emisiones está vacía.', 'batch_empty');
    if (items.length > this.config.maxBatchItems) {
      throw badRequest(`El lote supera el máximo de ${this.config.maxBatchItems} elementos.`, 'batch_too_large');
    }
    const results = [];
    for (let index = 0; index < items.length; index += 1) {
      try {
        const issued = await this.issue(items[index], { ...context, source: 'batch' });
        results.push({
          index,
          ok: true,
          licenseId: issued.license.id,
          licenseKey: issued.licenseKey,
          customerName: issued.license.customerName,
          email: issued.license.email,
          expiresAt: issued.license.expiresAt,
        });
      } catch (error) {
        results.push({
          index,
          ok: false,
          code: error.code || 'error',
          message: error instanceof AppError ? error.message : 'No se pudo emitir la licencia.',
        });
      }
    }
    return {
      results,
      issued: results.filter((item) => item.ok).length,
      failed: results.filter((item) => !item.ok).length,
    };
  }

  async activate({ licenseKey, machineCode, machineName, ip } = {}) {
    const machine = normalizeMachineCode(machineCode);
    if (!machine) throw badRequest('El código de equipo no es válido.', 'invalid_machine_code');
    const found = await this.findLicenseByKey(licenseKey);
    if (!found.row) throw notFound('La clave de licencia no es válida.', 'license_not_found');
    const normalizedMachineName = sanitizeText(machineName, 80) || null;
    try {
      return await this.db.transaction(async () => {
        await this.sweepExpired();
        const row = await this.rowById(found.row.id);
        if (!row) throw notFound('La clave de licencia no es válida.', 'license_not_found');
        const status = effectiveStatus(row);
        if (status === 'revoked') throw new AppError('Esta licencia está revocada.', 403, 'license_revoked');
        if (status === 'suspended') throw new AppError('Esta licencia está suspendida.', 403, 'license_suspended');
        if (status === 'expired') throw new AppError('La licencia ha caducado.', 410, 'license_expired');
        const key = this.keyForRow(row);
        if (row.license_version === LICENSE_VERSION_V1) {
          if (!row.machine_code || row.machine_code !== machine) {
            throw new AppError('La licencia pertenece a otro equipo.', 409, 'license_other_machine');
          }
          if (row.status !== 'active') {
            await this.db.run('UPDATE licenses SET status = ?, updated_at = ? WHERE id = ?', ['active', nowIso(), row.id]);
          }
          const fresh = await this.rowById(row.id);
          await this.audit.record({
            actorType: 'public', actorId: null, action: 'license.activated', targetType: 'license',
            targetId: row.id, details: { seat: row.seat, legacy: true }, ip,
          });
          return {
            license: fresh ? this.envelopeFor(fresh, key) : this.envelopeFor(row, key),
            info: this.publicInfo(fresh || row),
            keyMasked: maskLicenseKey(key),
          };
        }
        if (row.machine_code && row.machine_code !== machine) {
          throw new AppError('Esta licencia ya está vinculada a otro equipo.', 409, 'license_other_machine');
        }
        if (!row.machine_code) {
          const existing = await this.machineInUse(machine, row.id);
          if (existing) throw conflict('Este equipo ya tiene otra licencia activa.', 'machine_in_use');
          const now = nowIso();
          await this.db.run(
            `UPDATE licenses
             SET machine_code = ?, machine_name = ?, status = 'active', activated_at = ?, updated_at = ?
             WHERE id = ? AND machine_code IS NULL`,
            [machine, normalizedMachineName, now, now, row.id],
          );
        }
        const fresh = await this.rowById(row.id);
        await this.audit.record({
          actorType: 'public', actorId: null, action: 'license.activated', targetType: 'license',
          targetId: row.id, details: { seat: row.seat, legacy: false }, ip,
        });
        return {
          license: this.envelopeFor(fresh, key),
          info: this.publicInfo(fresh),
          keyMasked: maskLicenseKey(key),
        };
      });
    } catch (error) {
      if (isUniqueViolation(error)) throw conflict('Este equipo ya tiene otra licencia activa.', 'machine_in_use');
      throw error;
    }
  }

  async validate({ licenseKey, machineCode } = {}) {
    const found = await this.findLicenseByKey(licenseKey);
    if (!found.row) throw notFound('La clave de licencia no es válida.', 'license_not_found');
    await this.sweepExpired();
    const row = await this.rowById(found.row.id);
    if (!row) throw notFound('La clave de licencia no es válida.', 'license_not_found');
    const status = effectiveStatus(row);
    const machine = machineCode ? normalizeMachineCode(machineCode) : '';
    let valid = status === 'active';
    let reason = null;
    if (status === 'revoked') reason = 'La licencia está revocada.';
    else if (status === 'suspended') reason = 'La licencia está suspendida.';
    else if (status === 'expired') reason = 'La licencia ha caducado.';
    else if (status === 'pending') reason = 'La licencia aún no está activada.';
    else if (machine && row.machine_code && row.machine_code !== machine) {
      valid = false;
      reason = 'La licencia está vinculada a otro equipo.';
    } else if (machine && !row.machine_code) {
      valid = false;
      reason = 'La licencia no está vinculada a este equipo.';
    }
    return {
      valid,
      ...this.publicInfo(row),
      status: valid ? 'active' : status === 'active' ? 'other_machine' : status,
      reason,
    };
  }

  async reveal(id, context = {}) {
    const row = await this.rowById(id);
    if (!row) throw notFound('La licencia no existe.', 'license_not_found');
    const key = this.keyForRow(row);
    const emails = (await this.db.all(
      `SELECT status, attempts, last_error, created_at, sent_at FROM email_outbox
       WHERE license_id = ? ORDER BY created_at DESC LIMIT 5`,
      [row.id],
    )).map((item) => ({
      status: item.status,
      attempts: item.attempts,
      lastError: item.last_error,
      createdAt: item.created_at,
      sentAt: item.sent_at,
    }));
    const orders = await this.db.all(
      `SELECT id, status, amount_cents, currency, created_at, paid_at FROM orders
       WHERE license_id = ? ORDER BY created_at DESC`,
      [row.id],
    );
    const transactions = await this.db.all(
      `SELECT id, kind, provider_id, amount_cents, currency, status, created_at FROM transactions
       WHERE license_id = ? ORDER BY created_at DESC`,
      [row.id],
    );
    return {
      license: this.view(row),
      licenseKey: key,
      keyMasked: maskLicenseKey(key),
      envelope: this.envelopeFor(row, key),
      emails,
      orders: orders.map((order) => ({
        id: order.id,
        status: order.status,
        amountCents: order.amount_cents,
        currency: order.currency,
        createdAt: order.created_at,
        paidAt: order.paid_at,
      })),
      transactions: transactions.map((item) => ({
        id: item.id,
        kind: item.kind,
        providerId: item.provider_id,
        amountCents: item.amount_cents,
        currency: item.currency,
        status: item.status,
        createdAt: item.created_at,
      })),
    };
  }

  async list({ query = '', status = 'all', page = 1, pageSize = 25 } = {}) {
    await this.sweepExpired();
    const { where, params } = buildListFilter({ query, status }, this.keystore.dataKey);
    const totalRow = await this.db.get(`SELECT COUNT(*) AS n FROM licenses l ${where}`, params);
    const total = Number(totalRow ? totalRow.n : 0);
    const size = Math.min(Math.max(Number(pageSize) || 25, 10), 100);
    const pages = Math.max(1, Math.ceil(total / size));
    const current = Math.min(Math.max(Number(page) || 1, 1), pages);
    const rows = await this.db.all(
      `SELECT l.*, s.key_enc AS seat_key_enc, s.source AS seat_source
       FROM licenses l JOIN seats s ON s.seat = l.seat
       ${where}
       ORDER BY l.issued_at DESC
       LIMIT ? OFFSET ?`,
      [...params, size, (current - 1) * size],
    );
    return {
      items: rows.map((row) => {
        let keyMasked = '••••-••••-••••-••••';
        try {
          keyMasked = maskLicenseKey(this.keyForRow(row));
        } catch {
          keyMasked = 'error';
        }
        return { ...this.view(row), keyMasked };
      }),
      total,
      page: current,
      pages,
      pageSize: size,
    };
  }

  async exportRows({ query = '', status = 'all' } = {}) {
    await this.sweepExpired();
    const { where, params } = buildListFilter({ query, status }, this.keystore.dataKey);
    const rows = await this.db.all(
      `SELECT l.*, s.source AS seat_source
       FROM licenses l JOIN seats s ON s.seat = l.seat
       ${where}
       ORDER BY l.seat ASC`,
      params,
    );
    return rows.map((row) => this.view(row));
  }

  async summary() {
    await this.sweepExpired();
    const statusRows = await this.db.all('SELECT status, COUNT(*) AS n FROM licenses GROUP BY status');
    const counts = { pending: 0, active: 0, expired: 0, revoked: 0, suspended: 0 };
    for (const row of statusRows) counts[row.status] = Number(row.n);
    const issued = Object.values(counts).reduce((sum, value) => sum + value, 0);
    const seats = await this.db.get(
      `SELECT
        SUM(CASE WHEN license_id IS NULL AND reserved_order_id IS NULL THEN 1 ELSE 0 END) AS available,
        SUM(CASE WHEN license_id IS NULL AND reserved_order_id IS NOT NULL THEN 1 ELSE 0 END) AS reserved,
        SUM(CASE WHEN license_id IS NOT NULL THEN 1 ELSE 0 END) AS allocated
       FROM seats`,
    );
    const legacyRow = await this.db.get('SELECT COUNT(*) AS n FROM seats WHERE source = ?', ['legacy']);
    const legacy = Number(legacyRow ? legacyRow.n : 0);
    const revenue = await this.db.get(
      `SELECT
        COALESCE(SUM(CASE WHEN kind = 'payment' AND status = 'completed' THEN amount_cents ELSE 0 END), 0) AS gross,
        COALESCE(SUM(CASE WHEN kind = 'refund' AND status = 'completed' THEN amount_cents ELSE 0 END), 0) AS refunded
       FROM transactions`,
    );
    const latest = (await this.db.all(
      `SELECT l.*, s.key_enc AS seat_key_enc, s.source AS seat_source
       FROM licenses l JOIN seats s ON s.seat = l.seat
       ORDER BY l.issued_at DESC LIMIT 8`,
    )).map((row) => {
      let keyMasked = '••••-••••-••••-••••';
      try {
        keyMasked = maskLicenseKey(this.keyForRow(row));
      } catch {
        keyMasked = 'error';
      }
      return { ...this.view(row), keyMasked };
    });
    const orders = (await this.db.all(
      'SELECT status, COUNT(*) AS n FROM orders GROUP BY status',
    )).reduce((acc, row) => {
      acc[row.status] = Number(row.n);
      return acc;
    }, {});
    return {
      capacity: this.config.seatLimit,
      used: issued,
      available: Number(seats?.available || 0),
      reserved: Number(seats?.reserved || 0),
      allocated: Number(seats?.allocated || 0),
      legacySeats: legacy,
      statusCounts: counts,
      revenue: {
        grossCents: Number(revenue?.gross || 0),
        refundedCents: Number(revenue?.refunded || 0),
        netCents: Number(revenue?.gross || 0) - Number(revenue?.refunded || 0),
      },
      orders,
      latest,
      keyId: this.keystore.keyId,
      checkedAt: nowIso(),
    };
  }

  async revoke(id, { reason, actorType = 'admin', actorId = null, ip } = {}) {
    const cleanReason = reasonText(reason);
    return this.db.transaction(async () => {
      const row = await this.rowById(id);
      if (!row) throw notFound('La licencia no existe.', 'license_not_found');
      if (row.status === 'revoked') return { view: this.view(row), already: true };
      const now = nowIso();
      await this.db.run(
        `UPDATE licenses SET status = 'revoked', revoked_at = ?, revoked_reason = ?, suspended_at = NULL,
         suspended_reason = NULL, updated_at = ? WHERE id = ?`,
        [now, cleanReason, now, row.id],
      );
      await this.db.setSetting('revocation_changed_at', now, now);
      this.revocationCache = null;
      await this.audit.record({
        actorType, actorId, action: 'license.revoked', targetType: 'license', targetId: row.id,
        details: { reason: cleanReason }, ip,
      });
      return { view: this.view(await this.rowById(row.id)), already: false };
    });
  }

  async suspend(id, { reason, actorType = 'admin', actorId = null, ip } = {}) {
    const cleanReason = reasonText(reason);
    return this.db.transaction(async () => {
      const row = await this.rowById(id);
      if (!row) throw notFound('La licencia no existe.', 'license_not_found');
      if (row.status === 'revoked') throw conflict('Una licencia revocada no se puede suspender.', 'license_revoked');
      if (row.status === 'suspended') return { view: this.view(row), already: true };
      const now = nowIso();
      await this.db.run(
        `UPDATE licenses SET status = 'suspended', suspended_at = ?, suspended_reason = ?, updated_at = ? WHERE id = ?`,
        [now, cleanReason, now, row.id],
      );
      await this.audit.record({
        actorType, actorId, action: 'license.suspended', targetType: 'license', targetId: row.id,
        details: { reason: cleanReason }, ip,
      });
      return { view: this.view(await this.rowById(row.id)), already: false };
    });
  }

  async reactivate(id, { actorType = 'admin', actorId = null, ip } = {}) {
    return this.db.transaction(async () => {
      const row = await this.rowById(id);
      if (!row) throw notFound('La licencia no existe.', 'license_not_found');
      if (row.status === 'revoked') throw conflict('Una licencia revocada no se puede reactivar.', 'license_revoked_permanent');
      if (row.status !== 'suspended' && row.status !== 'expired') {
        return { view: this.view(row), already: true };
      }
      await this.sweepExpired();
      const refreshed = await this.rowById(row.id);
      let nextStatus;
      if (refreshed.expires_at && Date.parse(refreshed.expires_at) <= Date.now()) nextStatus = 'expired';
      else if (!refreshed.machine_code) nextStatus = 'pending';
      else nextStatus = 'active';
      if (nextStatus === 'active' && refreshed.machine_code) {
        const existing = await this.machineInUse(refreshed.machine_code, refreshed.id);
        if (existing) throw conflict('Otro equipo o licencia ya ocupa este código.', 'machine_in_use');
      }
      const now = nowIso();
      try {
        await this.db.run(
          `UPDATE licenses SET status = ?, suspended_at = NULL, suspended_reason = NULL, updated_at = ? WHERE id = ?`,
          [nextStatus, now, row.id],
        );
      } catch (error) {
        if (isUniqueViolation(error)) throw conflict('Otro registro activo ya usa este equipo.', 'machine_in_use');
        throw error;
      }
      await this.audit.record({
        actorType, actorId, action: 'license.reactivated', targetType: 'license', targetId: row.id,
        details: { status: nextStatus }, ip,
      });
      return { view: this.view(await this.rowById(row.id)), already: false };
    });
  }

  async renew(id, { reason, plan: requestedPlan, actorType = 'admin', actorId = null, ip } = {}) {
    const cleanReason = sanitizeText(reason, DATE_REASON_MAX);
    return this.db.transaction(async () => {
      const row = await this.rowById(id);
      if (!row) throw notFound('La licencia no existe.', 'license_not_found');
      if (row.status === 'revoked') {
        throw conflict('Una licencia revocada no se puede renovar; emite una licencia nueva.', 'license_revoked_permanent');
      }
      if (row.status === 'suspended') {
        throw conflict('Reactiva la licencia antes de renovarla.', 'license_suspended');
      }
      await this.sweepExpired();
      const refreshed = await this.rowById(row.id);
      let plan = planByCode(requestedPlan);
      if (requestedPlan !== undefined && requestedPlan !== null && requestedPlan !== '' && !plan) {
        throw badRequest('El plan de la licencia no es válido.', 'invalid_plan');
      }
      if (!plan) plan = planByCode(refreshed.plan) || planByCode(this.config.plan) || planByCode(DEFAULT_PLAN_CODE);
      const now = nowIso();
      const currentExpiry = refreshed.expires_at ? Date.parse(refreshed.expires_at) : NaN;
      const base = Number.isFinite(currentExpiry) && currentExpiry > Date.now()
        ? refreshed.expires_at
        : now;
      const expiresAt = addMonthsIso(base, plan.months);
      const nextStatus = refreshed.machine_code ? 'active' : 'pending';
      try {
        await this.db.run(
          `UPDATE licenses SET plan = ?, status = ?, expires_at = ?, updated_at = ? WHERE id = ?`,
          [plan.code, nextStatus, expiresAt, now, refreshed.id],
        );
      } catch (error) {
        if (isUniqueViolation(error)) {
          throw conflict('Otro registro activo ya usa este equipo.', 'machine_in_use');
        }
        throw error;
      }
      await this.audit.record({
        actorType,
        actorId,
        action: 'license.renewed',
        targetType: 'license',
        targetId: refreshed.id,
        details: {
          previousExpiresAt: refreshed.expires_at,
          expiresAt,
          plan: plan.code,
          months: plan.months,
          reason: cleanReason || null,
        },
        ip,
      });
      return {
        view: this.view(await this.rowById(refreshed.id)),
        renewed: true,
        previousExpiresAt: refreshed.expires_at,
        expiresAt,
      };
    });
  }

  async resetActivation(id, { reason, actorType = 'admin', actorId = null, ip } = {}) {
    const cleanReason = reasonText(reason);
    return this.db.transaction(async () => {
      const row = await this.rowById(id);
      if (!row) throw notFound('La licencia no existe.', 'license_not_found');
      if (row.status === 'revoked') throw conflict('Una licencia revocada no se puede reasignar.', 'license_revoked');
      if (!row.machine_code) return { view: this.view(row), already: true, warning: null };
      const now = nowIso();
      const expired = row.expires_at && Date.parse(row.expires_at) <= Date.now();
      const nextStatus = expired ? 'expired' : 'pending';
      await this.db.run(
        `UPDATE licenses SET machine_code = NULL, machine_name = NULL, activated_at = NULL,
         status = ?, updated_at = ? WHERE id = ?`,
        [nextStatus, now, row.id],
      );
      await this.audit.record({
        actorType, actorId, action: 'license.activation_reset', targetType: 'license', targetId: row.id,
        details: { reason: cleanReason, previousMachine: row.machine_code }, ip,
      });
      return {
        view: this.view(await this.rowById(row.id)),
        already: false,
        warning: 'El archivo de licencia ya entregado al equipo anterior sigue siendo válido sin conexión hasta su vencimiento. Revoca la licencia si necesitas invalidarlo.',
      };
    });
  }

  async queueResend(id, context = {}) {
    const row = await this.rowById(id);
    if (!row) throw notFound('La licencia no existe.', 'license_not_found');
    if (!row.email) throw badRequest('La licencia no tiene correo electrónico.', 'email_missing');
    const emailId = await this.queueEmail(row);
    await this.audit.record({
      actorType: context.actorType || 'admin',
      actorId: context.actorId || null,
      action: 'license.email_queued',
      targetType: 'license',
      targetId: row.id,
      details: { emailId },
      ip: context.ip,
    });
    return { queued: true, emailId };
  }

  async revocationList() {
    const changedAt = await this.db.getSetting('revocation_changed_at', '');
    if (this.revocationCache && this.revocationCache.changedAt === changedAt) return this.revocationCache;
    const rows = await this.db.all(
      `SELECT id, revoked_at, revoked_reason FROM licenses WHERE status = 'revoked' ORDER BY id ASC`,
    );
    const list = signRevocationList({
      revoked: rows.map((row) => ({ licenseId: row.id, revokedAt: row.revoked_at, reason: row.revoked_reason || '' })),
      issuedAt: changedAt || nowIso(),
      keyId: this.keystore.keyId,
      privateKey: this.keystore.privateKey,
    });
    const body = `${JSON.stringify(list)}\n`;
    const etag = `"${crypto.createHash('sha256').update(body).digest('hex').slice(0, 32)}"`;
    this.revocationCache = { changedAt, list, body, etag, count: rows.length };
    return this.revocationCache;
  }

  async seedKeyCount() {
    const row = await this.db.get('SELECT COUNT(*) AS n FROM seats');
    return Number(row ? row.n : 0);
  }
}

module.exports = {
  LicensesService,
  effectiveStatus,
  reasonText,
  escapeLike,
  buildListFilter,
};
