'use strict';

const { loadConfig } = require('./config');

const LOCAL_HOST = '127.0.0.1';
const LOCAL_PORT = 45900;

function loadLocalConfig(env = process.env) {
  const requestedPort = String(env.PERFILLAB_LOCAL_PORT || '').trim();
  const config = loadConfig({
    ...env,
    PERFILLAB_DATABASE_URL: '',
    DATABASE_URL: '',
    PERFILLAB_ALLOW_SQLITE: 'true',
    PERFILLAB_HOST: LOCAL_HOST,
    PERFILLAB_PORT: requestedPort || String(LOCAL_PORT),
    PERFILLAB_TRUST_PROXY: 'false',
  });
  return {
    ...config,
    host: LOCAL_HOST,
    port: requestedPort ? config.port : LOCAL_PORT,
    localMode: true,
    paymentsEnabled: false,
    missingPayments: [],
    emailEnabled: false,
    missingEmail: [],
  };
}

module.exports = { LOCAL_HOST, LOCAL_PORT, loadLocalConfig };
