'use strict';

const fs = require('node:fs');
const path = require('node:path');

const PRODUCT = 'perfillab';
const PLAN = 'annual';
const PLAN_MONTHS = 12;
const HISTORICAL_LICENSE_LIMIT = 50000;
const PAYPAL_SANDBOX = 'https://api-m.sandbox.paypal.com';
const PAYPAL_LIVE = 'https://api-m.paypal.com';
const DEFAULT_INSTALLER_NAME = 'PerfilLab-Setup.exe';

class ConfigError extends Error {
  constructor(message) {
    super(message);
    this.name = 'ConfigError';
  }
}

function clean(value) {
  return typeof value === 'string' ? value.trim() : '';
}

function isLoopbackHostname(hostname) {
  const raw = String(hostname || '').trim().toLowerCase()
    .replace(/^\[/, '')
    .replace(/\]$/, '')
    .replace(/\.$/, '');
  if (!raw) return false;
  if (raw === 'localhost' || raw === '::1') return true;
  const match = /^127\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/.exec(raw);
  return Boolean(match) && match.slice(1).every((part) => Number(part) <= 255);
}

function parseBool(value, fallback = false) {
  const raw = clean(value).toLowerCase();
  if (!raw) return fallback;
  if (['1', 'true', 'yes', 'si', 'sí', 'on'].includes(raw)) return true;
  if (['0', 'false', 'no', 'off'].includes(raw)) return false;
  throw new ConfigError(`Valor booleano no válido: ${value}`);
}

function parsePort(value, fallback) {
  if (value === undefined || value === null || value === '') return fallback;
  const port = Number(value);
  if (!Number.isInteger(port) || port < 1 || port > 65535) {
    throw new ConfigError('PERFILLAB_PORT debe ser un puerto entre 1 y 65535.');
  }
  return port;
}

function parsePublicBaseUrl(value) {
  const raw = clean(value);
  if (!raw) return { url: '', origin: '' };
  let parsed;
  try {
    parsed = new URL(raw);
  } catch {
    throw new ConfigError('PERFILLAB_PUBLIC_BASE_URL no es una URL válida.');
  }
  if (!['http:', 'https:'].includes(parsed.protocol)) {
    throw new ConfigError('PERFILLAB_PUBLIC_BASE_URL debe usar http o https.');
  }
  if (parsed.protocol === 'http:' && !isLoopbackHostname(parsed.hostname)) {
    throw new ConfigError(
      'PERFILLAB_PUBLIC_BASE_URL debe usar HTTPS cuando el servidor es remoto. HTTP solo se permite en localhost.',
    );
  }
  if (parsed.username || parsed.password) {
    throw new ConfigError('PERFILLAB_PUBLIC_BASE_URL no debe incluir credenciales.');
  }
  if (parsed.search || parsed.hash) {
    throw new ConfigError('PERFILLAB_PUBLIC_BASE_URL no debe incluir parámetros ni fragmentos.');
  }
  const url = `${parsed.origin}${parsed.pathname.replace(/\/+$/, '')}`;
  return { url, origin: parsed.origin };
}

function parsePriceCents(value) {
  const raw = clean(value);
  if (!raw) return null;
  if (!/^\d{1,7}(?:[.,]\d{1,2})?$/.test(raw)) {
    throw new ConfigError('PERFILLAB_PRICE_USD debe ser un importe positivo con hasta dos decimales.');
  }
  const normalized = raw.replace(',', '.');
  const [whole, fraction = ''] = normalized.split('.');
  const cents = Number(whole) * 100 + Number(fraction.padEnd(2, '0'));
  if (!Number.isSafeInteger(cents) || cents < 50) {
    throw new ConfigError('PERFILLAB_PRICE_USD debe ser de al menos 0,50 USD.');
  }
  return cents;
}

function parseMode(value) {
  const mode = clean(value || 'sandbox').toLowerCase();
  if (!['sandbox', 'live'].includes(mode)) {
    throw new ConfigError('PERFILLAB_PAYPAL_MODE debe ser sandbox o live.');
  }
  return mode;
}

function parseSmtpSecure(value, port, nodeEnv = 'development') {
  const raw = clean(value).toLowerCase();
  if (!raw) return port === 465 ? 'tls' : 'starttls';
  if (!['tls', 'starttls', 'none'].includes(raw)) {
    throw new ConfigError('PERFILLAB_SMTP_SECURE debe ser tls, starttls o none.');
  }
  if (raw === 'none' && clean(nodeEnv) === 'production') {
    throw new ConfigError('SMTP sin cifrar no está permitido en producción.');
  }
  return raw;
}

function parseDatabaseUrl(value) {
  const raw = clean(value);
  if (!raw) return '';
  let parsed;
  try {
    parsed = new URL(raw);
  } catch {
    throw new ConfigError('PERFILLAB_DATABASE_URL no es una URL válida.');
  }
  if (!['postgres:', 'postgresql:'].includes(parsed.protocol)) {
    throw new ConfigError('PERFILLAB_DATABASE_URL debe empezar por postgres:// o postgresql://.');
  }
  if (!parsed.hostname) throw new ConfigError('PERFILLAB_DATABASE_URL no incluye un host.');
  if (parsed.hash) throw new ConfigError('PERFILLAB_DATABASE_URL no debe incluir fragmentos.');
  return raw;
}

function parseDatabaseSsl(value) {
  const raw = clean(value).toLowerCase();
  if (!raw) return '';
  if (!['disable', 'require', 'verify-full'].includes(raw)) {
    throw new ConfigError('PERFILLAB_DATABASE_SSL debe ser disable, require o verify-full.');
  }
  return raw;
}

function parseDatabaseSchema(value) {
  const raw = clean(value) || 'public';
  if (!/^[A-Za-z_][A-Za-z0-9_]{0,62}$/.test(raw) || raw.startsWith('pg_')) {
    throw new ConfigError('PERFILLAB_DATABASE_SCHEMA no es un nombre de esquema válido.');
  }
  return raw;
}

function parseDatabasePoolMax(value) {
  const raw = clean(value);
  if (!raw) return 10;
  const number = Number(raw);
  if (!Number.isInteger(number) || number < 1 || number > 50) {
    throw new ConfigError('PERFILLAB_DATABASE_POOL_MAX debe ser un entero entre 1 y 50.');
  }
  return number;
}

function readSslCa(env) {
  const inline = String(env.PERFILLAB_DATABASE_SSL_CA || '').trim();
  const file = clean(env.PERFILLAB_DATABASE_SSL_CA_FILE);
  const base64 = clean(env.PERFILLAB_DATABASE_SSL_CA_BASE64).replace(/\s+/g, '');
  if (inline && (file || base64)) {
    throw new ConfigError('Configura solo una forma de PERFILLAB_DATABASE_SSL_CA.');
  }
  let ca = inline;
  if (file) {
    if (!fs.existsSync(file)) throw new ConfigError('No existe PERFILLAB_DATABASE_SSL_CA_FILE.');
    ca = fs.readFileSync(file, 'utf8');
  } else if (base64) {
    if (!/^[A-Za-z0-9+/]+={0,2}$/.test(base64)) {
      throw new ConfigError('PERFILLAB_DATABASE_SSL_CA_BASE64 no es base64 válido.');
    }
    ca = Buffer.from(base64, 'base64').toString('utf8');
  }
  if (!ca) return '';
  if (!ca.includes('-----BEGIN CERTIFICATE-----')) {
    throw new ConfigError('El certificado CA de PostgreSQL no tiene formato PEM.');
  }
  return ca;
}

function sanitizeDownloadName(value, fallback) {
  const raw = String(value || '').trim();
  const candidate = raw || fallback || DEFAULT_INSTALLER_NAME;
  const base = path.basename(candidate).replace(/[\u0000-\u001f\u007f"\\/:*?<>|]+/g, '-').trim();
  if (!base || base === '.' || base === '..' || base.length > 120) {
    throw new ConfigError('PERFILLAB_INSTALLER_FILENAME no es un nombre de archivo válido.');
  }
  return base;
}

function installerFallbackName(url, filePath) {
  if (filePath) return path.basename(filePath);
  if (url) {
    try {
      const segment = decodeURIComponent(new URL(url).pathname.split('/').filter(Boolean).pop() || '');
      if (segment) return segment;
    } catch {
      // La URL ya se validó; este fallback nunca debería fallar.
    }
  }
  return DEFAULT_INSTALLER_NAME;
}

function parseInstaller(env) {
  const url = clean(env.PERFILLAB_INSTALLER_URL);
  const filePath = clean(env.PERFILLAB_INSTALLER_PATH);
  if (url && filePath) {
    throw new ConfigError('Configura PERFILLAB_INSTALLER_URL o PERFILLAB_INSTALLER_PATH, no ambos.');
  }
  let normalizedUrl = '';
  if (url) {
    let parsed;
    try {
      parsed = new URL(url);
    } catch {
      throw new ConfigError('PERFILLAB_INSTALLER_URL no es una URL válida.');
    }
    if (parsed.protocol !== 'https:') {
      throw new ConfigError('PERFILLAB_INSTALLER_URL debe usar HTTPS.');
    }
    if (parsed.username || parsed.password) {
      throw new ConfigError('PERFILLAB_INSTALLER_URL no debe incluir credenciales.');
    }
    if (parsed.hash) throw new ConfigError('PERFILLAB_INSTALLER_URL no debe incluir fragmentos.');
    normalizedUrl = parsed.toString();
  }
  const absolutePath = filePath ? path.resolve(filePath) : '';
  const sha256 = clean(env.PERFILLAB_INSTALLER_SHA256).toLowerCase();
  if (sha256 && !/^[a-f0-9]{64}$/.test(sha256)) {
    throw new ConfigError('PERFILLAB_INSTALLER_SHA256 debe tener 64 caracteres hexadecimales.');
  }
  const version = clean(env.PERFILLAB_INSTALLER_VERSION);
  if (version && !/^[A-Za-z0-9._+-]{1,40}$/.test(version)) {
    throw new ConfigError('PERFILLAB_INSTALLER_VERSION no tiene un formato válido.');
  }
  const sizeRaw = clean(env.PERFILLAB_INSTALLER_SIZE);
  let sizeBytes = null;
  if (sizeRaw) {
    const number = Number(sizeRaw);
    if (!Number.isSafeInteger(number) || number < 1) {
      throw new ConfigError('PERFILLAB_INSTALLER_SIZE debe ser un número de bytes positivo.');
    }
    sizeBytes = number;
  }
  const enabled = Boolean(normalizedUrl || absolutePath);
  const filename = enabled
    ? sanitizeDownloadName(
      env.PERFILLAB_INSTALLER_FILENAME,
      installerFallbackName(normalizedUrl, absolutePath),
    )
    : '';
  return {
    enabled,
    source: normalizedUrl ? 'url' : absolutePath ? 'file' : 'none',
    url: normalizedUrl,
    path: absolutePath,
    version: version || null,
    sha256: sha256 || null,
    sizeBytes,
    filename,
  };
}

function loadConfig(env = process.env) {
  const root = path.join(__dirname, '..');
  const dataDir = path.resolve(clean(env.PERFILLAB_DATA_DIR) || path.join(root, 'data'));
  const nodeEnv = clean(env.NODE_ENV) || 'development';
  // Render (y otros hospedajes) inyectan PORT y esperan que el proceso escuche en
  // 0.0.0.0. Se respeta PERFILLAB_PORT si está definido; si no, se usa PORT.
  const port = parsePort(env.PERFILLAB_PORT || env.PORT, 45900);
  const host = clean(env.PERFILLAB_HOST) || (nodeEnv === 'production' ? '0.0.0.0' : '127.0.0.1');
  const publicBase = parsePublicBaseUrl(env.PERFILLAB_PUBLIC_BASE_URL);
  const mode = parseMode(env.PERFILLAB_PAYPAL_MODE);
  const priceCents = parsePriceCents(env.PERFILLAB_PRICE_USD);
  if (mode === 'live' && publicBase.url && !publicBase.url.startsWith('https://')) {
    throw new ConfigError('PayPal en modo live exige una PERFILLAB_PUBLIC_BASE_URL con HTTPS.');
  }
  const smtpPort = parsePort(env.PERFILLAB_SMTP_PORT, 587);
  const paypal = {
    mode,
    apiBase: mode === 'live' ? PAYPAL_LIVE : PAYPAL_SANDBOX,
    clientId: clean(env.PERFILLAB_PAYPAL_CLIENT_ID),
    clientSecret: clean(env.PERFILLAB_PAYPAL_CLIENT_SECRET),
    webhookId: clean(env.PERFILLAB_PAYPAL_WEBHOOK_ID),
    currency: 'USD',
    priceCents,
  };
  const smtp = {
    host: clean(env.PERFILLAB_SMTP_HOST),
    port: smtpPort,
    secure: parseSmtpSecure(env.PERFILLAB_SMTP_SECURE, smtpPort, nodeEnv),
    user: clean(env.PERFILLAB_SMTP_USER),
    pass: clean(env.PERFILLAB_SMTP_PASS),
    from: clean(env.PERFILLAB_MAIL_FROM),
    envelopeFrom: clean(env.PERFILLAB_MAIL_ENVELOPE_FROM),
  };
  const missingPayments = [];
  if (!paypal.priceCents) missingPayments.push('PERFILLAB_PRICE_USD');
  if (!publicBase.url) missingPayments.push('PERFILLAB_PUBLIC_BASE_URL');
  if (!paypal.clientId) missingPayments.push('PERFILLAB_PAYPAL_CLIENT_ID');
  if (!paypal.clientSecret) missingPayments.push('PERFILLAB_PAYPAL_CLIENT_SECRET');
  if (!paypal.webhookId) missingPayments.push('PERFILLAB_PAYPAL_WEBHOOK_ID');
  const missingEmail = [];
  if (!smtp.host) missingEmail.push('PERFILLAB_SMTP_HOST');
  if (!smtp.from) missingEmail.push('PERFILLAB_MAIL_FROM');

  const databaseUrl = parseDatabaseUrl(env.PERFILLAB_DATABASE_URL || env.DATABASE_URL);
  const allowSqlite = parseBool(env.PERFILLAB_ALLOW_SQLITE, false);
  if (nodeEnv === 'production' && !databaseUrl && !allowSqlite) {
    throw new ConfigError(
      'En producción se exige PERFILLAB_DATABASE_URL (PostgreSQL). '
      + 'Si de verdad quieres conservar SQLite, define PERFILLAB_ALLOW_SQLITE=true.',
    );
  }
  const databaseSsl = parseDatabaseSsl(env.PERFILLAB_DATABASE_SSL);
  const databaseSslCa = readSslCa(env);
  const databaseSchema = parseDatabaseSchema(env.PERFILLAB_DATABASE_SCHEMA);
  const databasePoolMax = parseDatabasePoolMax(env.PERFILLAB_DATABASE_POOL_MAX);
  const keystoreBase64 = String(env.PERFILLAB_KEYSTORE_BASE64 || '').replace(/\s+/g, '');
  const installer = parseInstaller(env);

  return {
    root,
    env: nodeEnv,
    dataDir,
    dbPath: path.resolve(clean(env.PERFILLAB_DB_PATH) || path.join(dataDir, 'perfillab.sqlite')),
    databaseUrl,
    databaseSsl,
    databaseSslCa,
    databaseSchema,
    databasePoolMax,
    allowSqlite,
    databaseDialect: databaseUrl ? 'postgres' : 'sqlite',
    keystorePath: path.resolve(clean(env.PERFILLAB_KEYSTORE_PATH) || path.join(dataDir, 'keystore.json')),
    keystoreBase64,
    backupDir: path.resolve(clean(env.PERFILLAB_BACKUP_DIR) || path.join(dataDir, 'backups')),
    installer,
    host,
    port,
    publicBaseUrl: publicBase.url,
    publicOrigin: publicBase.origin,
    trustProxy: parseBool(env.PERFILLAB_TRUST_PROXY, false),
    product: PRODUCT,
    productName: clean(env.PERFILLAB_PRODUCT_NAME) || 'PerfilLab',
    plan: PLAN,
    planMonths: PLAN_MONTHS,
    seatLimit: HISTORICAL_LICENSE_LIMIT,
    supportEmail: clean(env.PERFILLAB_SUPPORT_EMAIL),
    paypal,
    paymentsEnabled: missingPayments.length === 0,
    missingPayments,
    smtp,
    emailEnabled: missingEmail.length === 0,
    missingEmail,
    adminSessionHours: 12,
    maxBodyBytes: 512 * 1024,
    maxBatchItems: 100,
    loginAttempts: 6,
    loginWindowMs: 15 * 60 * 1000,
    checkoutAttemptsPerIp: 8,
    checkoutWindowMs: 60 * 60 * 1000,
    activationAttemptsPerIp: 30,
    activationWindowMs: 15 * 60 * 1000,
    version: '1.0.0',
  };
}

module.exports = {
  ConfigError,
  PAYPAL_LIVE,
  PAYPAL_SANDBOX,
  loadConfig,
  isLoopbackHostname,
  parsePriceCents,
  parsePublicBaseUrl,
  parseDatabaseUrl,
  parseDatabaseSsl,
  parseDatabaseSchema,
  parseInstaller,
};
