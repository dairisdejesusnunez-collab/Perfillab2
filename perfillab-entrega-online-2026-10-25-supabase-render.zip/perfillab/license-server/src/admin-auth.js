'use strict';

const crypto = require('node:crypto');

const { hashPassword, hashToken, nowIso, randomToken, sanitizeText, verifyPassword } = require('./security');
const { AppError, unauthorized } = require('./errors');

class AdminAuthService {
  constructor({ db, config, audit, logger }) {
    this.db = db;
    this.config = config;
    this.audit = audit;
    this.logger = logger;
    this.dummyHash = hashPassword(crypto.randomBytes(24).toString('base64url'));
  }

  async login({ username, password, ip, userAgent } = {}) {
    const user = sanitizeText(username, 64);
    const pass = String(password || '');
    if (!user || !pass || pass.length > 200) {
      throw new AppError('Usuario o contraseña incorrectos.', 401, 'invalid_credentials');
    }
    const row = await this.db.get(
      'SELECT id, username, password_hash, role, disabled FROM admin_users WHERE lower(username) = lower(?)',
      [user],
    );
    const valid = verifyPassword(pass, row ? row.password_hash : this.dummyHash);
    if (!row || !valid || Number(row.disabled) === 1) {
      await this.audit.record({
        actorType: 'public',
        actorId: null,
        action: 'admin.login_failed',
        targetType: 'admin_user',
        targetId: user,
        details: { knownUser: Boolean(row) },
        ip,
      });
      throw new AppError('Usuario o contraseña incorrectos.', 401, 'invalid_credentials');
    }
    const token = randomToken(32);
    const created = nowIso();
    const expires = new Date(Date.now() + this.config.adminSessionHours * 60 * 60 * 1000).toISOString();
    await this.db.transaction(async () => {
      await this.db.run('DELETE FROM admin_sessions WHERE expires_at <= ?', [created]);
      await this.db.run(
        `INSERT INTO admin_sessions(token_hash, user_id, created_at, last_seen_at, expires_at, ip, user_agent)
         VALUES (?, ?, ?, ?, ?, ?, ?)`,
        [hashToken(token), row.id, created, created, expires, String(ip || '').slice(0, 64), sanitizeText(userAgent, 300)],
      );
      await this.db.run('UPDATE admin_users SET last_login_at = ? WHERE id = ?', [created, row.id]);
      await this.audit.record({
        actorType: 'admin',
        actorId: row.id,
        action: 'admin.login',
        targetType: 'admin_user',
        targetId: row.id,
        details: null,
        ip,
      });
    });
    return {
      token,
      expiresAt: expires,
      user: { id: row.id, username: row.username, role: row.role },
    };
  }

  async authenticate(token) {
    if (typeof token !== 'string' || token.length < 20 || token.length > 200) {
      throw unauthorized('Sesión no válida o expirada.', 'invalid_session');
    }
    const row = await this.db.get(
      `SELECT s.token_hash, s.user_id, s.expires_at, s.last_seen_at, u.username, u.role, u.disabled
       FROM admin_sessions s JOIN admin_users u ON u.id = s.user_id
       WHERE s.token_hash = ?`,
      [hashToken(token)],
    );
    if (!row) throw unauthorized('Sesión no válida o expirada.', 'invalid_session');
    if (Number(row.disabled) === 1) {
      await this.db.run('DELETE FROM admin_sessions WHERE token_hash = ?', [row.token_hash]);
      throw unauthorized('Sesión no válida o expirada.', 'invalid_session');
    }
    const now = Date.now();
    if (Date.parse(row.expires_at) <= now) {
      await this.db.run('DELETE FROM admin_sessions WHERE token_hash = ?', [row.token_hash]);
      throw unauthorized('Sesión no válida o expirada.', 'invalid_session');
    }
    if (now - Date.parse(row.last_seen_at) > 5 * 60 * 1000) {
      await this.db.run('UPDATE admin_sessions SET last_seen_at = ? WHERE token_hash = ?', [nowIso(), row.token_hash]);
    }
    return {
      id: row.user_id,
      username: row.username,
      role: row.role,
      expiresAt: row.expires_at,
    };
  }

  async logout(token) {
    if (typeof token === 'string' && token.length <= 200) {
      await this.db.run('DELETE FROM admin_sessions WHERE token_hash = ?', [hashToken(token)]);
    }
    return { ok: true };
  }

  async session(token) {
    const user = await this.authenticate(token);
    return { user };
  }
}

module.exports = { AdminAuthService };
