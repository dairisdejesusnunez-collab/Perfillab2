'use strict';

const crypto = require('node:crypto');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { execFile, spawn } = require('node:child_process');
const { AppError, badRequest } = require('./errors');

const ACCOUNT_PREFIX = 'PL_';
const ACCOUNT_RE = /^PL_[0-9a-f]{12}$/;
const DESCRIPTION_RE = /^PerfilLab clon [0-9a-f]{8}$/;
const SID_RE = /^S-1-5-21-\d{1,12}-\d{1,12}-\d{1,12}-\d{1,12}$/;
const READY_PREFIX = 'PERFILLAB_CLONE_READY ';
const ERROR_PREFIX = 'PERFILLAB_CLONE_ERROR ';
const UAC_CANCELLED = 1223;
const LAUNCH_TIMEOUT_MS = 45000;
const CAPABILITIES_TTL_MS = 60000;
const MAX_ARGS = 4000;
const MAX_OUTPUT = 64 * 1024;

const WIN32_ERRORS = {
  2: 'No se encontró el ejecutable de la aplicación.',
  5: 'Windows denegó el acceso al ejecutable o a su carpeta.',
  32: 'El ejecutable está siendo usado por otro proceso y Windows no pudo abrirlo.',
  193: 'El archivo seleccionado no es una aplicación de Windows válida.',
  267: 'La carpeta de trabajo de la aplicación no es válida.',
  740: 'La aplicación requiere permisos de administrador. El clon usa una cuenta estándar y no puede elevarla automáticamente.',
  1326: 'No se pudo iniciar sesión con la cuenta del clon. Repara la cuenta desde Ajustes.',
  1327: 'La cuenta del clon no puede iniciar sesión en este equipo.',
  1331: 'La cuenta del clon está deshabilitada.',
  1385: 'La cuenta del clon no tiene el derecho de inicio de sesión necesario en este equipo.',
  1907: 'La cuenta del clon debe cambiar la contraseña antes de iniciar sesión. Repara la cuenta.',
  2202: 'El ejecutable requiere una ruta o unos parámetros no admitidos por el clon.',
};

function nowIso() {
  return new Date().toISOString();
}

function accountKey(profileId) {
  return crypto.createHash('sha256').update(String(profileId), 'utf8').digest('hex');
}

function accountName(profileId) {
  if (typeof profileId !== 'string' || !profileId) throw badRequest('El perfil no es válido.');
  return `${ACCOUNT_PREFIX}${accountKey(profileId).slice(0, 12)}`;
}

function accountDescription(profileId) {
  if (typeof profileId !== 'string' || !profileId) throw badRequest('El perfil no es válido.');
  return `PerfilLab clon ${accountKey(profileId).slice(0, 8)}`;
}

function generatePassword() {
  return `Pl1!${crypto.randomBytes(24).toString('base64url')}`;
}

function quoteWindowsArg(value) {
  const text = String(value === undefined || value === null ? '' : value);
  if (text.includes('\0')) throw badRequest('Los argumentos de la aplicación no son válidos.');
  if (text && !/[\s"]/.test(text)) return text;
  let output = '"';
  let backslashes = 0;
  for (const char of text) {
    if (char === '\\') {
      backslashes += 1;
      continue;
    }
    if (char === '"') {
      output += `${'\\'.repeat(backslashes * 2 + 1)}"`;
      backslashes = 0;
      continue;
    }
    output += `${'\\'.repeat(backslashes)}${char}`;
    backslashes = 0;
  }
  output += `${'\\'.repeat(backslashes * 2)}"`;
  return output;
}

function buildCommandLine(target, args) {
  const list = [String(target), ...(Array.isArray(args) ? args.map(String) : [])];
  if (list.join(' ').length > MAX_ARGS * 2) throw badRequest('Los argumentos de la aplicación son demasiado largos.');
  return list.map(quoteWindowsArg).join(' ');
}

function parseCloneLine(line) {
  const text = String(line || '').replace(/\r$/, '');
  if (text.startsWith(READY_PREFIX)) {
    const value = Number(text.slice(READY_PREFIX.length).trim());
    if (Number.isInteger(value) && value > 0) return { type: 'ready', pid: value };
    return { type: 'error', code: 0 };
  }
  if (text.startsWith(ERROR_PREFIX)) {
    const code = Number(text.slice(ERROR_PREFIX.length).trim());
    return { type: 'error', code: Number.isInteger(code) ? code : 0 };
  }
  return null;
}

function launchErrorMessage(code) {
  if (code && WIN32_ERRORS[code]) return `${WIN32_ERRORS[code]} (código ${code})`;
  if (code) return `Windows no pudo iniciar la aplicación en la cuenta del clon (código ${code}).`;
  return 'El clon no pudo iniciar la aplicación. Comprueba que la cuenta esté preparada y que la aplicación no requiera permisos de administrador.';
}

function findPowerShell(env = process.env) {
  if (env.PERFILLAB_POWERSHELL) return env.PERFILLAB_POWERSHELL;
  const root = env.SystemRoot || env.windir || 'C:\\Windows';
  const candidate = path.join(root, 'System32', 'WindowsPowerShell', 'v1.0', 'powershell.exe');
  return fs.existsSync(candidate) ? candidate : 'powershell.exe';
}

function psQuote(value) {
  return `'${String(value).replace(/'/g, "''")}'`;
}

function encodePowerShell(script) {
  return Buffer.from(String(script), 'utf16le').toString('base64');
}

function clip(text, max = 400) {
  const value = String(text || '').replace(/\s+/g, ' ').trim();
  return value.length > max ? `${value.slice(0, max)}…` : value;
}

function isInside(base, target) {
  const relative = path.relative(path.resolve(base), path.resolve(target));
  return Boolean(relative) && !relative.startsWith('..') && !path.isAbsolute(relative);
}

function validateUsername(username) {
  if (typeof username !== 'string' || !ACCOUNT_RE.test(username)) {
    throw badRequest('El nombre de la cuenta del clon no es válido.');
  }
  return username;
}

function validateSid(sid) {
  if (typeof sid !== 'string' || !SID_RE.test(sid)) throw badRequest('El identificador de la cuenta del clon no es válido.');
  return sid;
}

function buildLauncherScript() {
  return String.raw`$ErrorActionPreference = 'Stop'
[Console]::InputEncoding = New-Object System.Text.UTF8Encoding($false)
[Console]::OutputEncoding = New-Object System.Text.UTF8Encoding($false)
$source = @'
using System;
using System.Runtime.InteropServices;

public static class PerfilLabCloneHost {
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
    public struct STARTUPINFO {
        public int cb;
        public string lpReserved;
        public string lpDesktop;
        public string lpTitle;
        public int dwX;
        public int dwY;
        public int dwXSize;
        public int dwYSize;
        public int dwXCountChars;
        public int dwYCountChars;
        public int dwFillAttribute;
        public int dwFlags;
        public short wShowWindow;
        public short cbReserved2;
        public IntPtr lpReserved2;
        public IntPtr hStdInput;
        public IntPtr hStdOutput;
        public IntPtr hStdError;
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct PROCESS_INFORMATION {
        public IntPtr hProcess;
        public IntPtr hThread;
        public int dwProcessId;
        public int dwThreadId;
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct JOBOBJECT_BASIC_LIMIT_INFORMATION {
        public long PerProcessUserTimeLimit;
        public long PerJobUserTimeLimit;
        public uint LimitFlags;
        public UIntPtr MinimumWorkingSetSize;
        public UIntPtr MaximumWorkingSetSize;
        public uint ActiveProcessLimit;
        public UIntPtr Affinity;
        public uint PriorityClass;
        public uint SchedulingClass;
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct IO_COUNTERS {
        public ulong ReadOperationCount;
        public ulong WriteOperationCount;
        public ulong OtherOperationCount;
        public ulong ReadTransferCount;
        public ulong WriteTransferCount;
        public ulong OtherTransferCount;
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct JOBOBJECT_EXTENDED_LIMIT_INFORMATION {
        public JOBOBJECT_BASIC_LIMIT_INFORMATION BasicLimitInformation;
        public IO_COUNTERS IoInfo;
        public UIntPtr ProcessMemoryLimit;
        public UIntPtr JobMemoryLimit;
        public UIntPtr PeakProcessMemoryUsed;
        public UIntPtr PeakJobMemoryUsed;
    }

    [DllImport("advapi32.dll", SetLastError = true, CharSet = CharSet.Unicode)]
    private static extern bool CreateProcessWithLogonW(
        string lpUsername,
        string lpDomain,
        string lpPassword,
        uint dwLogonFlags,
        string lpApplicationName,
        string lpCommandLine,
        uint dwCreationFlags,
        IntPtr lpEnvironment,
        string lpCurrentDirectory,
        ref STARTUPINFO lpStartupInfo,
        out PROCESS_INFORMATION lpProcessInformation);

    [DllImport("kernel32.dll", SetLastError = true, CharSet = CharSet.Unicode)]
    private static extern IntPtr CreateJobObject(IntPtr lpJobAttributes, string lpName);

    [DllImport("kernel32.dll", SetLastError = true)]
    private static extern bool SetInformationJobObject(IntPtr hJob, int infoClass, IntPtr lpJobObjectInfo, uint cbJobObjectInfoLength);

    [DllImport("kernel32.dll", SetLastError = true)]
    private static extern bool AssignProcessToJobObject(IntPtr hJob, IntPtr hProcess);

    [DllImport("kernel32.dll", SetLastError = true)]
    private static extern uint WaitForSingleObject(IntPtr hHandle, uint dwMilliseconds);

    [DllImport("kernel32.dll", SetLastError = true)]
    private static extern bool GetExitCodeProcess(IntPtr hProcess, out uint lpExitCode);

    [DllImport("kernel32.dll", SetLastError = true)]
    private static extern bool CloseHandle(IntPtr hObject);

    public static int Run(string userName, string password, string target, string commandLine, string currentDirectory, bool hidden) {
        STARTUPINFO startup = new STARTUPINFO();
        startup.cb = Marshal.SizeOf(typeof(STARTUPINFO));
        // No se asigna lpDesktop: con LOGON_WITH_PROFILE, pedir "winsta0\default" explícitamente
        // hace que el hijo falle la inicialización de DLL (0xc0000142). Al dejarlo nulo, el proceso
        // hereda el escritorio interactivo del llamante y arranca correctamente con su propia cuenta.
        if (hidden) {
            startup.dwFlags = 1;
            startup.wShowWindow = 0;
        }
        PROCESS_INFORMATION process;
        bool created = CreateProcessWithLogonW(
            userName,
            ".",
            password,
            1,
            target,
            commandLine,
            0x00000400,
            IntPtr.Zero,
            String.IsNullOrEmpty(currentDirectory) ? null : currentDirectory,
            ref startup,
            out process);
        if (!created) {
            int error = Marshal.GetLastWin32Error();
            Console.Out.WriteLine("PERFILLAB_CLONE_ERROR " + error);
            Console.Out.Flush();
            return 1;
        }
        IntPtr job = IntPtr.Zero;
        try {
            job = CreateJobObject(IntPtr.Zero, null);
            if (job != IntPtr.Zero) {
                JOBOBJECT_EXTENDED_LIMIT_INFORMATION info = new JOBOBJECT_EXTENDED_LIMIT_INFORMATION();
                info.BasicLimitInformation.LimitFlags = 0x00002000;
                int length = Marshal.SizeOf(typeof(JOBOBJECT_EXTENDED_LIMIT_INFORMATION));
                IntPtr buffer = Marshal.AllocHGlobal(length);
                try {
                    Marshal.StructureToPtr(info, buffer, false);
                    SetInformationJobObject(job, 9, buffer, (uint)length);
                } finally {
                    Marshal.FreeHGlobal(buffer);
                }
                AssignProcessToJobObject(job, process.hProcess);
            }
            Console.Out.WriteLine("PERFILLAB_CLONE_READY " + process.dwProcessId);
            Console.Out.Flush();
            WaitForSingleObject(process.hProcess, 0xFFFFFFFF);
            uint exitCode;
            GetExitCodeProcess(process.hProcess, out exitCode);
            return unchecked((int)exitCode);
        } finally {
            CloseHandle(process.hThread);
            CloseHandle(process.hProcess);
            if (job != IntPtr.Zero) CloseHandle(job);
        }
    }
}
'@
try {
    Add-Type -TypeDefinition $source -Language CSharp | Out-Null
} catch {
    [Console]::Out.WriteLine('PERFILLAB_CLONE_ERROR 1')
    [Console]::Out.Flush()
    exit 1
}
$raw = [Console]::In.ReadToEnd()
if ([string]::IsNullOrWhiteSpace($raw)) {
    [Console]::Out.WriteLine('PERFILLAB_CLONE_ERROR 2')
    [Console]::Out.Flush()
    exit 1
}
try {
    $request = $raw | ConvertFrom-Json
} catch {
    [Console]::Out.WriteLine('PERFILLAB_CLONE_ERROR 2')
    [Console]::Out.Flush()
    exit 1
}
if ([string]$request.username -notmatch '^PL_[0-9a-f]{12}$') {
    [Console]::Out.WriteLine('PERFILLAB_CLONE_ERROR 2')
    [Console]::Out.Flush()
    exit 1
}
try {
    $code = [PerfilLabCloneHost]::Run(
        [string]$request.username,
        [string]$request.password,
        [string]$request.target,
        [string]$request.commandLine,
        [string]$request.cwd,
        [bool]$request.hidden)
    if ($code -eq 0) { exit 0 }
    exit 1
} catch {
    [Console]::Out.WriteLine('PERFILLAB_CLONE_ERROR 1')
    [Console]::Out.Flush()
    exit 1
}`;
}

function buildProvisionScript(requestPath, resultPath) {
  return String.raw`$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = New-Object System.Text.UTF8Encoding($false)
$requestPath = ${psQuote(requestPath)}
$resultPath = ${psQuote(resultPath)}
$result = @{ ok = $false; error = 'La preparación no terminó.' }
try {
    $request = Get-Content -LiteralPath $requestPath -Raw -Encoding UTF8 | ConvertFrom-Json
    if ([string]$request.username -notmatch '^PL_[0-9a-f]{12}$') { throw 'Nombre de cuenta no válido.' }
    if ([string]$request.description -notmatch '^PerfilLab clon [0-9a-f]{8}$') { throw 'Descripción de cuenta no válida.' }
    if ([string]::IsNullOrWhiteSpace([string]$request.password) -or ([string]$request.password).Length -lt 24) {
        throw 'La credencial temporal de la cuenta no es válida.'
    }
    $password = ConvertTo-SecureString -String ([string]$request.password) -AsPlainText -Force
    $existing = Get-LocalUser -Name ([string]$request.username) -ErrorAction SilentlyContinue
    $created = $false
    if ($existing) {
        if ([string]$existing.Description -ne [string]$request.description) {
            throw 'Ya existe una cuenta local con ese nombre y no pertenece a PerfilLab.'
        }
        Set-LocalUser -Name ([string]$request.username) -Password $password -PasswordNeverExpires $true -ErrorAction Stop
    } else {
        New-LocalUser -Name ([string]$request.username) -Password $password -Description ([string]$request.description) -PasswordNeverExpires -AccountNeverExpires -ErrorAction Stop | Out-Null
        $created = $true
    }
    $account = Get-LocalUser -Name ([string]$request.username) -ErrorAction Stop
    if (-not $account.Enabled) { Enable-LocalUser -Name ([string]$request.username) -ErrorAction Stop }
    $usersGroup = Get-LocalGroup -SID ([System.Security.Principal.SecurityIdentifier]'S-1-5-32-545') -ErrorAction Stop
    $member = Get-LocalGroupMember -Group $usersGroup -ErrorAction SilentlyContinue | Where-Object { $_.SID.Value -eq $account.SID.Value }
    if (-not $member) { Add-LocalGroupMember -Group $usersGroup -Member $account -ErrorAction Stop }
    $adminGroup = Get-LocalGroup -SID ([System.Security.Principal.SecurityIdentifier]'S-1-5-32-544') -ErrorAction Stop
    $admin = Get-LocalGroupMember -Group $adminGroup -ErrorAction SilentlyContinue | Where-Object { $_.SID.Value -eq $account.SID.Value }
    if ($admin) { throw 'La cuenta del clon no debe pertenecer al grupo Administradores.' }
    $result = @{
        ok = $true
        username = [string]$request.username
        description = [string]$request.description
        sid = [string]$account.SID.Value
        created = $created
    }
} catch {
    $result.error = [string]$_.Exception.Message
}
try {
    $json = $result | ConvertTo-Json -Compress -Depth 5
    [System.IO.File]::WriteAllText($resultPath, $json, (New-Object System.Text.UTF8Encoding($false)))
} catch {
}
if ($result.ok) { exit 0 }
exit 1`;
}

function buildReleaseScript(requestPath, resultPath) {
  return String.raw`$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = New-Object System.Text.UTF8Encoding($false)
$requestPath = ${psQuote(requestPath)}
$resultPath = ${psQuote(resultPath)}
$result = @{ ok = $false; error = 'La liberación no terminó.' }
try {
    $request = Get-Content -LiteralPath $requestPath -Raw -Encoding UTF8 | ConvertFrom-Json
    if ([string]$request.username -notmatch '^PL_[0-9a-f]{12}$') { throw 'Nombre de cuenta no válido.' }
    if ([string]$request.description -notmatch '^PerfilLab clon [0-9a-f]{8}$') { throw 'Descripción de cuenta no válida.' }
    $account = Get-LocalUser -Name ([string]$request.username) -ErrorAction SilentlyContinue
    if (-not $account) {
        $result = @{ ok = $true; username = [string]$request.username; alreadyMissing = $true; profileRemoved = $false }
    } else {
        if ([string]$account.Description -ne [string]$request.description) {
            throw 'La cuenta local no pertenece a PerfilLab y no se eliminó.'
        }
        $sid = [string]$account.SID.Value
        Remove-LocalUser -Name ([string]$request.username) -ErrorAction Stop
        $profileRemoved = $false
        $warning = $null
        try {
            $profile = Get-CimInstance Win32_UserProfile -ErrorAction SilentlyContinue | Where-Object { $_.SID -eq $sid } | Select-Object -First 1
            if ($profile) {
                Remove-CimInstance -InputObject $profile -ErrorAction Stop
                $profileRemoved = $true
            }
        } catch {
            $warning = 'La cuenta se eliminó, pero Windows no pudo borrar su carpeta de perfil. Puede quedar espacio sin usar en C:\Users.'
        }
        $result = @{
            ok = $true
            username = [string]$request.username
            alreadyMissing = $false
            profileRemoved = $profileRemoved
            warning = $warning
        }
    }
} catch {
    $result.error = [string]$_.Exception.Message
}
try {
    $json = $result | ConvertTo-Json -Compress -Depth 5
    [System.IO.File]::WriteAllText($resultPath, $json, (New-Object System.Text.UTF8Encoding($false)))
} catch {
}
if ($result.ok) { exit 0 }
exit 1`;
}

function buildElevatedLauncher(childScript, powershellPath) {
  const encoded = encodePowerShell(childScript);
  return String.raw`$ErrorActionPreference = 'Stop'
$encoded = ${psQuote(encoded)}
$psArgs = @('-NoLogo', '-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-EncodedCommand', $encoded)
try {
    $process = Start-Process -FilePath ${psQuote(powershellPath)} -ArgumentList $psArgs -Verb RunAs -Wait -PassThru -WindowStyle Hidden
    exit [int]$process.ExitCode
} catch {
    $native = 0
    try { $native = [int]$_.Exception.NativeErrorCode } catch { $native = 0 }
    if ($native -eq 1223) { exit 1223 }
    [Console]::Error.WriteLine('No se pudo completar la solicitud de permisos de Windows.')
    exit 1
}`;
}

class NativeCloneProvider {
  constructor(options = {}) {
    this.platform = options.platform || process.platform;
    this.env = options.env || process.env;
    this.baseDir = options.baseDir || path.join(os.homedir(), 'AppData', 'Local', 'PerfilLab', 'native-clone');
    this.powershellPath = options.powershellPath || findPowerShell(this.env);
    this.execFileImpl = options.execFileImpl || execFile;
    this.spawnImpl = options.spawnImpl || spawn;
    this.windows = options.windows || os.homedir();
    this.capabilitiesCache = null;
    this.capabilitiesAt = 0;
    this.cleanupStarted = false;
  }

  ensureSupported() {
    if (this.platform !== 'win32') {
      throw new AppError('Los clones nativos con cuentas de Windows solo están disponibles en Windows.', 400, 'clone_unsupported');
    }
  }

  snapshot() {
    if (this.capabilitiesCache) return { ...this.capabilitiesCache };
    return {
      available: this.platform === 'win32',
      checked: false,
      platform: this.platform,
      error: this.platform === 'win32' ? null : 'Disponible solo en Windows.',
    };
  }

  async capabilities(force = false) {
    if (this.platform !== 'win32') {
      this.capabilitiesCache = {
        available: false,
        checked: true,
        platform: this.platform,
        error: 'Los clones nativos solo están disponibles en Windows.',
        checkedAt: nowIso(),
      };
      this.capabilitiesAt = Date.now();
      return this.snapshot();
    }
    if (!force && this.capabilitiesCache && Date.now() - this.capabilitiesAt < CAPABILITIES_TTL_MS) {
      return this.snapshot();
    }
    const script = [
      '[Console]::OutputEncoding = New-Object System.Text.UTF8Encoding($false)',
      '$ErrorActionPreference = "Stop"',
      '$isAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)',
      '$localAccounts = [bool](Get-Command New-LocalUser -ErrorAction SilentlyContinue)',
      '$uac = 1',
      'try { $uac = [int](Get-ItemProperty -LiteralPath "HKLM:\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\System" -Name EnableLUA -ErrorAction Stop).EnableLUA } catch { $uac = 1 }',
      '$os = Get-CimInstance Win32_OperatingSystem -ErrorAction SilentlyContinue',
      '@{',
      '  available = $localAccounts',
      '  localAccounts = $localAccounts',
      '  elevated = $isAdmin',
      '  uac = $uac',
      '  powershell = $PSVersionTable.PSVersion.ToString()',
      '  os = if ($os) { [string]$os.Caption } else { "" }',
      '  version = if ($os) { [string]$os.Version } else { "" }',
      '} | ConvertTo-Json -Compress',
    ].join('\n');
    let result;
    try {
      const execution = await this.execFileAsync(this.powershellPath, [
        '-NoLogo',
        '-NoProfile',
        '-NonInteractive',
        '-ExecutionPolicy',
        'Bypass',
        '-OutputFormat',
        'Text',
        '-EncodedCommand',
        encodePowerShell(script),
      ], { timeout: 15000 });
      if (execution.exitCode !== 0) throw new Error(execution.stderr || 'PowerShell terminó con error.');
      const parsed = JSON.parse(execution.stdout.trim());
      result = {
        available: parsed.available === true,
        checked: true,
        platform: this.platform,
        localAccounts: parsed.localAccounts === true,
        elevated: parsed.elevated === true,
        uac: parsed.uac !== 0,
        powershell: typeof parsed.powershell === 'string' ? parsed.powershell : '',
        os: typeof parsed.os === 'string' ? parsed.os : '',
        version: typeof parsed.version === 'string' ? parsed.version : '',
        error: parsed.available === true ? null : 'Windows no expone los cmdlets de cuentas locales.',
        checkedAt: nowIso(),
      };
    } catch (error) {
      const detail = clip(error && (error.message || error.stderr), 240);
      result = {
        available: false,
        checked: true,
        platform: this.platform,
        localAccounts: false,
        elevated: false,
        uac: false,
        powershell: '',
        os: '',
        version: '',
        error: detail
          ? `No se pudo consultar Windows PowerShell para preparar clones: ${detail}`
          : 'No se pudo consultar Windows PowerShell para preparar clones.',
        checkedAt: nowIso(),
      };
    }
    this.capabilitiesCache = result;
    this.capabilitiesAt = Date.now();
    return this.snapshot();
  }

  execFileAsync(file, args, options = {}) {
    return new Promise((resolve, reject) => {
      this.execFileImpl(file, args, {
        encoding: 'utf8',
        windowsHide: true,
        maxBuffer: 4 * 1024 * 1024,
        timeout: 120000,
        ...options,
      }, (error, stdout, stderr) => {
        if (error && (error.code === 'ENOENT' || error.code === 'EACCES' || error.code === 'EPERM')) {
          reject(new AppError(`No se pudo ejecutar ${path.basename(file)}: ${error.message}`, 500, 'clone_tool_missing'));
          return;
        }
        const exitCode = error ? Number(error.code || 1) : 0;
        resolve({
          exitCode: Number.isInteger(exitCode) ? exitCode : 1,
          stdout: String(stdout || ''),
          stderr: String(stderr || ''),
          error,
        });
      });
    });
  }

  async prepare(profileId) {
    this.ensureSupported();
    const username = accountName(profileId);
    const description = accountDescription(profileId);
    const password = generatePassword();
    const result = await this.elevatedAction('provision', { username, password, description }, 240000);
    if (result.sid) validateSid(result.sid);
    return {
      username,
      description,
      sid: result.sid || null,
      password,
      preparedAt: nowIso(),
      created: Boolean(result.created),
    };
  }

  async release({ profileId, username, sid }) {
    this.ensureSupported();
    const expectedUsername = accountName(profileId);
    const description = accountDescription(profileId);
    if (validateUsername(username) !== expectedUsername) {
      throw badRequest('La cuenta del clon no corresponde a este perfil.');
    }
    if (sid) validateSid(sid);
    return await this.elevatedAction('release', { username: expectedUsername, description }, 300000);
  }

  async verify({ username, password, timeoutMs = 120000 }) {
    this.ensureSupported();
    validateUsername(username);
    if (typeof password !== 'string' || password.length < 24) {
      throw new AppError('La credencial de la cuenta del clon no está disponible. Repara la cuenta.', 400, 'clone_credential_missing');
    }
    const comspec = this.env.ComSpec || path.join(this.env.SystemRoot || 'C:\\Windows', 'System32', 'cmd.exe');
    const startedAt = Date.now();
    let started;
    try {
      started = await this.startProcess({
        username,
        password,
        target: comspec,
        args: ['/d', '/c', 'exit'],
        cwd: path.dirname(comspec),
        hidden: true,
      });
      const pid = await started.ready;
      const exit = await this.waitForExit(started.child, timeoutMs);
      if (exit.timedOut) {
        await this.killTree(pid);
        return { ok: false, error: 'La cuenta tardó demasiado en iniciar una sesión de prueba.' };
      }
      if (exit.code !== 0) {
        return { ok: false, error: `La cuenta no pudo iniciar una sesión de prueba (código ${exit.code}).` };
      }
      return { ok: true, durationMs: Date.now() - startedAt };
    } catch (error) {
      return { ok: false, error: error && error.message ? error.message : 'La cuenta no pudo iniciar sesión.' };
    }
  }

  async startProcess({ username, password, target, args = [], cwd = '', hidden = false, timeoutMs = LAUNCH_TIMEOUT_MS }) {
    this.ensureSupported();
    validateUsername(username);
    if (typeof password !== 'string' || !password) {
      throw new AppError('La credencial de la cuenta del clon no está disponible. Repara la cuenta.', 400, 'clone_credential_missing');
    }
    if (typeof target !== 'string' || !path.isAbsolute(target) || path.extname(target).toLowerCase() !== '.exe') {
      throw badRequest('El clon solo puede abrir aplicaciones .exe con una ruta absoluta.');
    }
    if (target.includes('\0') || String(cwd || '').includes('\0')) {
      throw badRequest('La ruta de la aplicación no es válida.');
    }
    if (!Array.isArray(args) || args.some((value) => typeof value !== 'string' || value.includes('\0'))) {
      throw badRequest('Los argumentos de la aplicación no son válidos.');
    }
    const commandLine = buildCommandLine(target, args);
    const request = {
      username,
      password,
      target,
      commandLine,
      cwd: cwd ? String(cwd) : '',
      hidden: Boolean(hidden),
    };
    const script = buildLauncherScript();
    const child = this.spawnImpl(this.powershellPath, [
      '-NoLogo',
      '-NoProfile',
      '-NonInteractive',
      '-ExecutionPolicy',
      'Bypass',
      '-EncodedCommand',
      encodePowerShell(script),
    ], {
      windowsHide: true,
      detached: false,
      stdio: ['pipe', 'pipe', 'pipe'],
    });

    let stdout = '';
    let stderr = '';
    let settled = false;
    let lineBuffer = '';
    let timer = null;
    const ready = new Promise((resolve, reject) => {
      const fail = (error) => {
        if (settled) return;
        settled = true;
        if (timer) clearTimeout(timer);
        reject(error);
      };
      const succeed = (pid) => {
        if (settled) return;
        settled = true;
        if (timer) clearTimeout(timer);
        resolve(pid);
      };
      const consume = (chunk) => {
        stdout += chunk;
        if (stdout.length > MAX_OUTPUT) stdout = stdout.slice(-MAX_OUTPUT);
        lineBuffer += chunk;
        if (lineBuffer.length > MAX_OUTPUT) lineBuffer = lineBuffer.slice(-MAX_OUTPUT);
        const lines = lineBuffer.split(/\r?\n/);
        lineBuffer = lines.pop() || '';
        for (const line of lines) {
          const parsed = parseCloneLine(line);
          if (!parsed) continue;
          if (parsed.type === 'ready') succeed(parsed.pid);
          else fail(new AppError(launchErrorMessage(parsed.code), 500, 'clone_launch_failed'));
        }
      };
      child.stdout?.on('data', consume);
      child.stderr?.on('data', (chunk) => {
        stderr += chunk;
        if (stderr.length > MAX_OUTPUT) stderr = stderr.slice(-MAX_OUTPUT);
      });
      child.once('error', (error) => {
        fail(new AppError(`No se pudo iniciar el lanzador nativo: ${error.message}`, 500, 'clone_launch_failed'));
      });
      child.once('exit', (code) => {
        if (!settled) {
          let win32Code = 0;
          const match = new RegExp(`${ERROR_PREFIX}(\\d+)`).exec(stdout);
          if (match) win32Code = Number(match[1]);
          const suffix = stderr.trim() && !win32Code ? ` ${clip(stderr)}` : '';
          fail(new AppError(`${launchErrorMessage(win32Code)}${suffix}`, 500, 'clone_launch_failed'));
        }
      });
      timer = setTimeout(() => {
        fail(new AppError('La cuenta aislada tardó demasiado en iniciar la aplicación. Windows puede seguir preparando su perfil; vuelve a intentarlo.', 500, 'clone_launch_timeout'));
        this.killTree(child.pid).catch(() => {});
      }, timeoutMs);
      timer.unref?.();
    });
    ready.catch(() => {});
    if (child.stdin) {
      child.stdin.on('error', () => {});
      child.stdin.end(JSON.stringify(request), 'utf8');
    }
    return { child, ready };
  }

  async waitForExit(child, timeoutMs = 120000) {
    if (child.exitCode !== null && child.exitCode !== undefined) {
      return { code: child.exitCode, timedOut: false };
    }
    return await new Promise((resolve) => {
      let timer = null;
      const finish = (code, timedOut) => {
        if (timer) clearTimeout(timer);
        child.removeListener('exit', onExit);
        resolve({ code, timedOut });
      };
      const onExit = (code) => finish(Number.isInteger(code) ? code : 1, false);
      child.once('exit', onExit);
      timer = setTimeout(() => finish(1, true), timeoutMs);
      timer.unref?.();
    });
  }

  async killTree(pid) {
    if (!Number.isInteger(pid) || pid <= 0) return;
    await this.execFileAsync('taskkill.exe', ['/PID', String(pid), '/T', '/F'], { timeout: 10000 }).catch(() => {});
  }

  async prepareAppAccess({ sid, target, cwd }) {
    this.ensureSupported();
    validateSid(sid);
    if (typeof target !== 'string' || !target) throw badRequest('La aplicación no tiene una ruta válida.');
    const dirs = [path.dirname(target)];
    if (cwd) dirs.push(path.resolve(cwd));
    const unique = [...new Set(dirs.map((dir) => path.resolve(dir)))];
    const granted = [];
    const skipped = [];
    for (const dir of unique) {
      if (path.resolve(dir).toLowerCase() === path.resolve(this.windows).toLowerCase()) {
        throw new AppError(
          'La aplicación está directamente en tu carpeta personal. Muévela a una subcarpeta para que la cuenta del clon pueda leerla.',
          400,
          'clone_access_invalid',
        );
      }
      if (!isInside(this.windows, dir)) {
        skipped.push(dir);
        continue;
      }
      const execution = await this.execFileAsync('icacls.exe', [
        dir,
        '/grant',
        `*${sid}:(OI)(CI)RX`,
        '/C',
        '/Q',
      ], { timeout: 60000 });
      if (execution.exitCode !== 0) {
        throw new AppError(
          `Windows no pudo dar acceso de lectura a la cuenta del clon para "${dir}". ${clip(execution.stderr || execution.stdout)}`,
          500,
          'clone_access_grant_failed',
        );
      }
      granted.push(dir);
    }
    return { granted, skipped };
  }

  async elevatedAction(action, payload, timeoutMs) {
    this.ensureSupported();
    this.cleanupStaleTemps();
    fs.mkdirSync(this.baseDir, { recursive: true });
    const tempDir = fs.mkdtempSync(path.join(this.baseDir, 'op-'));
    const requestPath = path.join(tempDir, 'request.json');
    const resultPath = path.join(tempDir, 'result.json');
    try {
      fs.writeFileSync(requestPath, JSON.stringify(payload), { encoding: 'utf8', mode: 0o600, flag: 'wx' });
      const childScript = action === 'provision'
        ? buildProvisionScript(requestPath, resultPath)
        : buildReleaseScript(requestPath, resultPath);
      const outerScript = buildElevatedLauncher(childScript, this.powershellPath);
      const execution = await this.execFileAsync(this.powershellPath, [
        '-NoLogo',
        '-NoProfile',
        '-NonInteractive',
        '-ExecutionPolicy',
        'Bypass',
        '-EncodedCommand',
        encodePowerShell(outerScript),
      ], { timeout: timeoutMs });
      let result = null;
      try {
        if (fs.existsSync(resultPath)) result = JSON.parse(fs.readFileSync(resultPath, 'utf8'));
      } catch {
        result = null;
      }
      if (execution.exitCode === UAC_CANCELLED) {
        throw new AppError('Cancelaste la solicitud de permisos de administrador. La operación no se realizó.', 400, 'uac_cancelled');
      }
      if (!result) {
        const detail = clip(execution.stderr);
        throw new AppError(detail || 'Windows no completó la operación con permisos de administrador.', 500, 'clone_elevation_failed');
      }
      if (result.ok !== true) {
        throw new AppError(clip(result.error, 500) || 'Windows no pudo preparar la cuenta del clon.', 500, 'clone_elevation_failed');
      }
      return result;
    } finally {
      try {
        fs.rmSync(tempDir, { recursive: true, force: true });
      } catch {
        // La credencial temporal se elimina al cerrar la aplicación si Windows aún bloquea el archivo.
      }
    }
  }

  cleanupStaleTemps() {
    if (this.cleanupStarted) return;
    this.cleanupStarted = true;
    try {
      if (!fs.existsSync(this.baseDir)) return;
      const cutoff = Date.now() - 60 * 60 * 1000;
      for (const entry of fs.readdirSync(this.baseDir, { withFileTypes: true })) {
        if (!entry.isDirectory() || !entry.name.startsWith('op-')) continue;
        const full = path.join(this.baseDir, entry.name);
        try {
          if (fs.statSync(full).mtimeMs < cutoff) fs.rmSync(full, { recursive: true, force: true });
        } catch {
          // best effort cleanup
        }
      }
    } catch {
      // best effort cleanup
    }
  }
}

module.exports = {
  NativeCloneProvider,
  accountName,
  accountDescription,
  generatePassword,
  quoteWindowsArg,
  buildCommandLine,
  parseCloneLine,
  launchErrorMessage,
  findPowerShell,
  ACCOUNT_RE,
  DESCRIPTION_RE,
  SID_RE,
  UAC_CANCELLED,
  buildLauncherScript,
  buildProvisionScript,
  buildReleaseScript,
  buildElevatedLauncher,
};
