'use strict';

const fs = require('node:fs');
const path = require('node:path');
const { app } = require('electron');

function userDataDir() {
  if (process.env.PERFILLAB_DATA_DIR) {
    return path.resolve(process.env.PERFILLAB_DATA_DIR);
  }
  return app.getPath('userData');
}

function ensureDir(dir) {
  fs.mkdirSync(dir, { recursive: true });
  return dir;
}

function dataFile() {
  return path.join(ensureDir(userDataDir()), 'data.json');
}

function defaultProfilesDir() {
  return path.join(ensureDir(userDataDir()), 'profiles');
}

function resolveProfilesDir(settings) {
  const custom = settings && typeof settings.profilesDir === 'string' ? settings.profilesDir.trim() : '';
  if (custom) return path.resolve(custom);
  return defaultProfilesDir();
}

function resolveProfileDir(settings, profileId) {
  return path.join(resolveProfilesDir(settings), profileId);
}

function isInside(base, target) {
  const rel = path.relative(path.resolve(base), path.resolve(target));
  return Boolean(rel) && !rel.startsWith('..') && !path.isAbsolute(rel);
}

module.exports = {
  userDataDir,
  ensureDir,
  dataFile,
  defaultProfilesDir,
  resolveProfilesDir,
  resolveProfileDir,
  isInside,
};
