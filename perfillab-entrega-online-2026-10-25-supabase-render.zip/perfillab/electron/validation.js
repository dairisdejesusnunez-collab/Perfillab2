'use strict';

const fs = require('node:fs');
const path = require('node:path');
const { badRequest } = require('./errors');
const { BUILTIN_BROWSER_ID } = require('./browser-launch');

const THEMES = new Set(['system', 'light', 'dark']);
const PROTOCOLS = new Set(['http', 'https', 'socks5']);
const CLONE_MODES = new Set(['none', 'data', 'account', 'vm']);
const COLOR_RE = /^#[0-9a-fA-F]{6}$/;
const TAG_LIMIT = 10;

function requireString(value, label, maxLength) {
  if (typeof value !== 'string') throw badRequest(`${label} es obligatorio.`);
  const text = value.trim();
  if (!text) throw badRequest(`${label} es obligatorio.`);
  if (text.length > maxLength) throw badRequest(`${label} no puede superar ${maxLength} caracteres.`);
  return text;
}

function optionalString(value, label, maxLength) {
  if (value === undefined || value === null) return '';
  if (typeof value !== 'string') throw badRequest(`${label} debe ser texto.`);
  const text = value.trim();
  if (text.length > maxLength) throw badRequest(`${label} no puede superar ${maxLength} caracteres.`);
  return text;
}

function optionalBool(value, label) {
  if (value === undefined) return undefined;
  if (typeof value !== 'boolean') throw badRequest(`${label} debe ser verdadero o falso.`);
  return value;
}

function normalizeColor(value, fallback) {
  if (value === undefined || value === null || value === '') return fallback;
  if (typeof value !== 'string' || !COLOR_RE.test(value.trim())) {
    throw badRequest('El color debe tener formato hexadecimal (#RRGGBB).');
  }
  return value.trim().toLowerCase();
}

function normalizeUrl(value) {
  if (typeof value !== 'string' || !value.trim()) throw badRequest('La URL no puede estar vacía.');
  let raw = value.trim();
  if (!/^[a-zA-Z][a-zA-Z0-9+.-]*:/.test(raw)) raw = `https://${raw}`;
  let url;
  try {
    url = new URL(raw);
  } catch {
    throw badRequest(`URL no válida: ${value}`);
  }
  if (url.protocol !== 'http:' && url.protocol !== 'https:') {
    throw badRequest('Solo se permiten URLs http:// o https://.');
  }
  if (!url.hostname) throw badRequest(`URL no válida: ${value}`);
  if (url.username || url.password) throw badRequest('La URL no puede incluir usuario o contraseña.');
  return url.toString();
}

function normalizeUrls(value) {
  if (value === undefined || value === null || value === '') return [];
  let list = value;
  if (typeof value === 'string') list = value.split(/\r?\n/);
  if (!Array.isArray(list)) throw badRequest('Las URLs de inicio deben ser una lista.');
  const urls = list
    .map((entry) => (typeof entry === 'string' ? entry.trim() : ''))
    .filter(Boolean)
    .map(normalizeUrl);
  if (urls.length > 8) throw badRequest('Puedes configurar como máximo 8 URLs de inicio.');
  return [...new Set(urls)];
}

function normalizeTags(value) {
  if (value === undefined || value === null) return [];
  let list = value;
  if (typeof value === 'string') list = value.split(',');
  if (!Array.isArray(list)) throw badRequest('Las etiquetas deben ser una lista.');
  const tags = [];
  const seen = new Set();
  for (const entry of list) {
    if (typeof entry !== 'string') continue;
    const tag = entry.trim().replace(/\s+/g, ' ');
    if (!tag) continue;
    if (tag.length > 24) throw badRequest('Cada etiqueta puede tener como máximo 24 caracteres.');
    const key = tag.toLowerCase();
    if (seen.has(key)) continue;
    seen.add(key);
    tags.push(tag);
    if (tags.length >= TAG_LIMIT) break;
  }
  return tags;
}

function normalizeName(value, label, maxLength) {
  return requireString(value, label, maxLength);
}

function validateProfileInput(input, context) {
  if (!input || typeof input !== 'object') throw badRequest('Datos de perfil no válidos.');
  const { workspaces, proxies, statuses = [], existing } = context;
  const workspaceId = input.workspaceId || (existing && existing.workspaceId) || (workspaces[0] && workspaces[0].id);
  if (!workspaces.some((item) => item.id === workspaceId)) throw badRequest('El espacio de trabajo no existe.');

  let proxyId = input.proxyId === undefined ? (existing ? existing.proxyId : null) : input.proxyId;
  if (proxyId === '' || proxyId === undefined) proxyId = null;
  if (proxyId !== null) {
    if (typeof proxyId !== 'string' || !proxies.some((item) => item.id === proxyId)) {
      throw badRequest('El proxy seleccionado no existe.');
    }
  }

  const name = input.name === undefined && existing ? existing.name : normalizeName(input.name, 'El nombre', 80);
  const notes = input.notes === undefined ? (existing ? existing.notes : '') : optionalString(input.notes, 'Las notas', 2000);
  const startUrls = input.startUrls === undefined ? (existing ? existing.startUrls : []) : normalizeUrls(input.startUrls);
  const tags = input.tags === undefined ? (existing ? existing.tags : []) : normalizeTags(input.tags);
  const color = normalizeColor(input.color === undefined ? (existing ? existing.color : undefined) : input.color, '#5b6cff');

  let statusId = input.statusId === undefined ? (existing ? existing.statusId || null : null) : input.statusId;
  if (statusId === '' || statusId === undefined) statusId = null;
  if (statusId !== null) {
    if (typeof statusId !== 'string' || !statuses.some((item) => item.id === statusId)) {
      throw badRequest('El estado seleccionado no existe.');
    }
  }

  return {
    name,
    workspaceId,
    browserId: BUILTIN_BROWSER_ID,
    proxyId,
    statusId,
    startUrls,
    tags,
    notes,
    color,
  };
}

function validateProxyInput(input, context = {}) {
  if (!input || typeof input !== 'object') throw badRequest('Datos de proxy no válidos.');
  const existing = context.existing || null;
  const name = input.name === undefined && existing ? existing.name : normalizeName(input.name, 'El nombre del proxy', 60);
  const protocolRaw = input.protocol === undefined ? (existing ? existing.protocol : 'http') : input.protocol;
  if (typeof protocolRaw !== 'string' || !PROTOCOLS.has(protocolRaw)) {
    throw badRequest('El protocolo del proxy debe ser http, https o socks5.');
  }
  const hostRaw = input.host === undefined && existing ? existing.host : input.host;
  const host = requireString(hostRaw, 'El host del proxy', 255)
    .replace(/^\[|\]$/g, '')
    .trim();
  if (/[\/\s@]/.test(host) || host.includes('://')) {
    throw badRequest('Escribe solo el host del proxy, sin protocolo ni ruta.');
  }
  if (!/^[a-zA-Z0-9._:-]+$/.test(host)) throw badRequest('El host del proxy contiene caracteres no válidos.');

  const portRaw = input.port === undefined && existing ? existing.port : input.port;
  const port = Number(portRaw);
  if (!Number.isInteger(port) || port < 1 || port > 65535) {
    throw badRequest('El puerto del proxy debe estar entre 1 y 65535.');
  }

  const username = input.username === undefined && existing
    ? existing.username || ''
    : optionalString(input.username, 'El usuario del proxy', 128);
  const notes = input.notes === undefined && existing
    ? existing.notes || ''
    : optionalString(input.notes, 'Las notas del proxy', 500);

  let password;
  if (input.password !== undefined) {
    if (typeof input.password !== 'string') throw badRequest('La contraseña del proxy debe ser texto.');
    if (input.password.length > 256) throw badRequest('La contraseña del proxy es demasiado larga.');
    password = input.password;
  }
  return { name, protocol: protocolRaw, host, port, username, password, notes, clearPassword: Boolean(input.clearPassword) };
}

function validateWorkspaceInput(input, context = {}) {
  if (!input || typeof input !== 'object') throw badRequest('Datos de espacio no válidos.');
  const existing = context.existing || null;
  const name = input.name === undefined && existing ? existing.name : normalizeName(input.name, 'El nombre del espacio', 40);
  const color = normalizeColor(input.color === undefined ? (existing ? existing.color : undefined) : input.color, '#5b6cff');
  const others = (context.workspaces || []).filter((item) => !existing || item.id !== existing.id);
  if (others.some((item) => item.name.toLowerCase() === name.toLowerCase())) {
    throw badRequest('Ya existe un espacio con ese nombre.');
  }
  return { name, color };
}

function validateStatusInput(input, context = {}) {
  if (!input || typeof input !== 'object') throw badRequest('Datos de estado no válidos.');
  const existing = context.existing || null;
  const name = input.name === undefined && existing ? existing.name : normalizeName(input.name, 'El nombre del estado', 32);
  const color = normalizeColor(input.color === undefined ? (existing ? existing.color : undefined) : input.color, '#5b6cff');
  const others = (context.statuses || []).filter((item) => !existing || item.id !== existing.id);
  if (others.some((item) => item.name.toLowerCase() === name.toLowerCase())) {
    throw badRequest('Ya existe un estado con ese nombre.');
  }
  return { name, color };
}

function validateAppPatch(input) {
  if (!input || typeof input !== 'object' || Array.isArray(input)) throw badRequest('Datos de aplicación no válidos.');
  const allowed = new Set(['name', 'args', 'cwd', 'cloneMode']);
  for (const key of Object.keys(input)) {
    if (!allowed.has(key)) throw badRequest(`Ajuste de aplicación desconocido: ${key}`);
  }
  const patch = {};
  if (input.name !== undefined) {
    const name = optionalString(input.name, 'El nombre de la aplicación', 100);
    if (!name) throw badRequest('El nombre de la aplicación es obligatorio.');
    patch.name = name;
  }
  if (input.args !== undefined) {
    if (typeof input.args !== 'string') throw badRequest('Los argumentos deben ser texto.');
    if (input.args.length > 4000) throw badRequest('Los argumentos son demasiado largos.');
    patch.args = input.args;
  }
  if (input.cwd !== undefined) {
    const cwd = optionalString(input.cwd, 'La carpeta de trabajo', 1000);
    if (cwd) {
      if (!path.isAbsolute(cwd)) throw badRequest('La carpeta de trabajo debe ser una ruta absoluta.');
      let stat;
      try {
        stat = fs.statSync(cwd);
      } catch {
        throw badRequest('La carpeta de trabajo no existe.');
      }
      if (!stat.isDirectory()) throw badRequest('La carpeta de trabajo no es una carpeta.');
    }
    patch.cwd = cwd;
  }
  if (input.cloneMode !== undefined) {
    if (typeof input.cloneMode !== 'string' || !CLONE_MODES.has(input.cloneMode)) {
      throw badRequest('El modo de clonación debe ser none, data, account o vm.');
    }
    patch.cloneMode = input.cloneMode;
  }
  return patch;
}

function validateAppLaunchInput(input) {
  if (!input || typeof input !== 'object' || Array.isArray(input)) throw badRequest('Datos de apertura no válidos.');
  const allowed = new Set(['args', 'cwd']);
  for (const key of Object.keys(input)) {
    if (!allowed.has(key)) throw badRequest(`Ajuste de apertura desconocido: ${key}`);
  }
  const result = {};
  if (input.args !== undefined) {
    if (typeof input.args !== 'string') throw badRequest('Los argumentos deben ser texto.');
    if (input.args.length > 4000) throw badRequest('Los argumentos son demasiado largos.');
    result.args = input.args;
  }
  if (input.cwd !== undefined) {
    const cwd = optionalString(input.cwd, 'La carpeta de trabajo', 1000);
    if (cwd) {
      if (!path.isAbsolute(cwd)) throw badRequest('La carpeta de trabajo debe ser una ruta absoluta.');
      let stat;
      try {
        stat = fs.statSync(cwd);
      } catch {
        throw badRequest('La carpeta de trabajo no existe.');
      }
      if (!stat.isDirectory()) throw badRequest('La carpeta de trabajo no es una carpeta.');
    }
    result.cwd = cwd;
  }
  return result;
}

function validateSettingsPatch(input, context = {}) {
  if (!input || typeof input !== 'object' || Array.isArray(input)) throw badRequest('Ajustes no válidos.');
  const allowed = new Set([
    'theme',
    'closeToTray',
    'profilesDir',
    'vm',
    'api',
  ]);
  for (const key of Object.keys(input)) {
    if (!allowed.has(key)) throw badRequest(`Ajuste desconocido: ${key}`);
  }
  const patch = {};
  if (input.theme !== undefined) {
    if (!THEMES.has(input.theme)) throw badRequest('Tema no válido.');
    patch.theme = input.theme;
  }
  const closeToTray = optionalBool(input.closeToTray, 'Cerrar a la bandeja');
  if (closeToTray !== undefined) patch.closeToTray = closeToTray;

  if (input.profilesDir !== undefined) {
    const profilesDir = optionalString(input.profilesDir, 'La carpeta de perfiles', 1000);
    if (profilesDir) {
      if (!path.isAbsolute(profilesDir)) throw badRequest('La carpeta de perfiles debe ser una ruta absoluta.');
      if (profilesDir.includes('\0')) throw badRequest('La carpeta de perfiles no es válida.');
    }
    patch.profilesDir = profilesDir;
  }
  if (input.vm !== undefined) {
    if (!input.vm || typeof input.vm !== 'object' || Array.isArray(input.vm)) {
      throw badRequest('Configuración de máquinas virtuales no válida.');
    }
    const vmAllowed = new Set(['baseImagePath', 'switchName', 'memoryMb', 'cpuCount', 'disksDir', 'generation']);
    for (const key of Object.keys(input.vm)) {
      if (!vmAllowed.has(key)) throw badRequest(`Ajuste de máquina virtual desconocido: ${key}`);
    }
    const vm = {};
    if (input.vm.baseImagePath !== undefined) {
      const baseImagePath = optionalString(input.vm.baseImagePath, 'La imagen base', 1000);
      if (baseImagePath) {
        if (!path.isAbsolute(baseImagePath)) throw badRequest('La imagen base debe ser una ruta absoluta.');
        if (path.extname(baseImagePath).toLowerCase() !== '.vhdx') {
          throw badRequest('La imagen base debe ser un archivo .vhdx.');
        }
        let stat;
        try {
          stat = fs.statSync(baseImagePath);
        } catch {
          throw badRequest('No se encontró la imagen base en esa ruta.');
        }
        if (!stat.isFile()) throw badRequest('La imagen base debe ser un archivo.');
      }
      vm.baseImagePath = baseImagePath;
    }
    if (input.vm.switchName !== undefined) {
      const switchName = optionalString(input.vm.switchName, 'El conmutador virtual', 100);
      if (/[\u0000-\u001f\u007f]/.test(switchName)) throw badRequest('El conmutador virtual no es válido.');
      vm.switchName = switchName;
    }
    if (input.vm.memoryMb !== undefined) {
      const memoryMb = Number(input.vm.memoryMb);
      if (!Number.isInteger(memoryMb) || memoryMb < 1024 || memoryMb > 32768) {
        throw badRequest('La memoria de la máquina virtual debe estar entre 1024 y 32768 MB.');
      }
      vm.memoryMb = memoryMb;
    }
    if (input.vm.cpuCount !== undefined) {
      const cpuCount = Number(input.vm.cpuCount);
      if (!Number.isInteger(cpuCount) || cpuCount < 1 || cpuCount > 16) {
        throw badRequest('Los procesadores de la máquina virtual deben estar entre 1 y 16.');
      }
      vm.cpuCount = cpuCount;
    }
    if (input.vm.disksDir !== undefined) {
      const disksDir = optionalString(input.vm.disksDir, 'La carpeta de discos', 1000);
      if (disksDir) {
        if (!path.isAbsolute(disksDir)) throw badRequest('La carpeta de discos debe ser una ruta absoluta.');
        if (disksDir.includes('\0')) throw badRequest('La carpeta de discos no es válida.');
      }
      vm.disksDir = disksDir;
    }
    if (input.vm.generation !== undefined) {
      const generation = Number(input.vm.generation);
      if (generation !== 1 && generation !== 2) throw badRequest('La generación de la máquina virtual debe ser 1 o 2.');
      vm.generation = generation;
    }
    patch.vm = vm;
  }
  if (input.api !== undefined) {
    if (!input.api || typeof input.api !== 'object' || Array.isArray(input.api)) {
      throw badRequest('Configuración de la API no válida.');
    }
    const apiAllowed = new Set(['enabled', 'port']);
    for (const key of Object.keys(input.api)) {
      if (!apiAllowed.has(key)) throw badRequest(`Ajuste de API desconocido: ${key}`);
    }
    const api = {};
    const enabled = optionalBool(input.api.enabled, 'La API local');
    if (enabled !== undefined) api.enabled = enabled;
    if (input.api.port !== undefined) {
      const port = Number(input.api.port);
      if (!Number.isInteger(port) || port < 1024 || port > 65535) {
        throw badRequest('El puerto de la API debe estar entre 1024 y 65535.');
      }
      api.port = port;
    }
    patch.api = api;
  }
  return patch;
}

module.exports = {
  THEMES,
  PROTOCOLS,
  normalizeUrl,
  normalizeUrls,
  normalizeTags,
  validateProfileInput,
  validateProxyInput,
  validateWorkspaceInput,
  validateStatusInput,
  validateAppPatch,
  validateAppLaunchInput,
  validateSettingsPatch,
};
