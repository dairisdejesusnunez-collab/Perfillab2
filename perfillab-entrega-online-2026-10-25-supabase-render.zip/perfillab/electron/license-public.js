'use strict';

// Generada por scripts/provision-license.js. Cambiar esta clave invalida las licencias emitidas.
module.exports = {
  publicKey: "MCowBQYDK2VwAyEAlf7ze/MC+4llRaGKQ3wpjlRmRGk556v0m6CdJD0y1q4=",
  keyId: "a31600beab3f7311",
  seatLimit: 50000,
  serverUrl: "",
  generatedAt: "2026-10-24T23:52:07.423Z",
};
