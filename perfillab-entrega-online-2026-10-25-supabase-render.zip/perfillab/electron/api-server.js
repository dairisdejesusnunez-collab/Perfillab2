'use strict';

const http = require('node:http');
const crypto = require('node:crypto');
const { app } = require('electron');
const { AppError } = require('./errors');

const MAX_BODY_BYTES = 1024 * 1024;
const API_PREFIX = '/v1';

function safeEqual(left, right) {
  const a = Buffer.from(String(left));
  const b = Buffer.from(String(right));
  if (a.length !== b.length) {
    crypto.timingSafeEqual(a, a);
    return false;
  }
  return crypto.timingSafeEqual(a, b);
}

function sendJson(res, status, payload) {
  const body = `${JSON.stringify(payload)}\n`;
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Content-Length': Buffer.byteLength(body),
    'Cache-Control': 'no-store',
    'X-Content-Type-Options': 'nosniff',
    'Referrer-Policy': 'no-referrer',
  });
  res.end(body);
}

function readJsonBody(req) {
  return new Promise((resolve, reject) => {
    const type = String(req.headers['content-type'] || '').split(';')[0].trim().toLowerCase();
    if (type && type !== 'application/json') {
      reject(new AppError('El cuerpo debe enviarse como application/json.', 415, 'unsupported_media_type'));
      return;
    }
    let size = 0;
    const chunks = [];
    req.on('data', (chunk) => {
      size += chunk.length;
      if (size > MAX_BODY_BYTES) {
        reject(new AppError('El cuerpo de la petición es demasiado grande.', 413, 'payload_too_large'));
        req.destroy();
        return;
      }
      chunks.push(chunk);
    });
    req.on('end', () => {
      if (!chunks.length) {
        resolve({});
        return;
      }
      try {
        const parsed = JSON.parse(Buffer.concat(chunks).toString('utf8'));
        if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) {
          reject(new AppError('El cuerpo debe ser un objeto JSON.', 400, 'bad_request'));
          return;
        }
        resolve(parsed);
      } catch {
        reject(new AppError('El cuerpo no es JSON válido.', 400, 'invalid_json'));
      }
    });
    req.on('error', reject);
  });
}

function sanitizeState(state) {
  const copy = { ...state, settings: { ...state.settings, api: { ...state.settings.api } } };
  delete copy.settings.api.token;
  delete copy.settings.api.tokenEnc;
  return copy;
}

class LocalApiServer {
  constructor({ service, licenseProvider }) {
    this.service = service;
    this.licenseProvider = licenseProvider || (() => ({ active: true }));
    this.server = null;
    this.port = null;
    this.error = null;
    this.queue = Promise.resolve();
  }

  config() {
    const api = this.service.state.settings.api;
    return { enabled: Boolean(api.enabled), port: api.port };
  }

  status() {
    const config = this.config();
    return {
      enabled: config.enabled,
      running: Boolean(this.server),
      port: this.server ? this.port : config.port,
      error: this.error,
    };
  }

  apply() {
    this.queue = this.queue.then(() => this.sync()).catch(() => {});
    return this.queue;
  }

  async sync() {
    const config = this.config();
    if (!config.enabled) {
      await this.close();
      return this.status();
    }
    if (this.server && this.port === config.port) return this.status();
    await this.close();
    await this.listen(config.port);
    return this.status();
  }

  async listen(port) {
    this.error = null;
    const server = http.createServer((req, res) => {
      this.handle(req, res).catch((error) => {
        if (res.headersSent) {
          res.destroy();
          return;
        }
        this.fail(res, error);
      });
    });
    server.on('clientError', (_error, socket) => {
      if (socket.writable) socket.end('HTTP/1.1 400 Bad Request\r\n\r\n');
    });

    await new Promise((resolve, reject) => {
      const onError = (error) => {
        server.removeListener('listening', onListening);
        reject(error);
      };
      const onListening = () => {
        server.removeListener('error', onError);
        resolve();
      };
      server.once('error', onError);
      server.once('listening', onListening);
      server.listen(port, '127.0.0.1');
    }).catch((error) => {
      this.server = null;
      this.port = null;
      this.error = error && error.code === 'EADDRINUSE'
        ? `El puerto ${port} ya está en uso.`
        : `No se pudo iniciar la API: ${error.message}`;
      throw new AppError(this.error, 500, 'api_listen_error');
    });

    this.server = server;
    this.port = port;
  }

  async close() {
    const server = this.server;
    this.server = null;
    this.port = null;
    if (!server) return;
    await new Promise((resolve) => {
      const timer = setTimeout(() => {
        if (typeof server.closeAllConnections === 'function') server.closeAllConnections();
        resolve();
      }, 1200);
      timer.unref();
      server.close(() => {
        clearTimeout(timer);
        resolve();
      });
    });
  }

  fail(res, error) {
    const status = error instanceof AppError ? error.status : 500;
    if (status >= 500) console.error('[api]', error);
    const headers = {};
    if (status === 401) headers['WWW-Authenticate'] = 'Bearer';
    const body = `${JSON.stringify({
      error: {
        message: error instanceof AppError ? error.message : 'Error interno.',
        code: error && error.code ? error.code : 'error',
      },
    })}\n`;
    res.writeHead(status, {
      'Content-Type': 'application/json; charset=utf-8',
      'Content-Length': Buffer.byteLength(body),
      'Cache-Control': 'no-store',
      'X-Content-Type-Options': 'nosniff',
      ...headers,
    });
    res.end(body);
  }

  async handle(req, res) {
    if (req.headers.origin) {
      throw new AppError('Las peticiones con cabecera Origin no están permitidas.', 403, 'origin_forbidden');
    }
    const authorization = String(req.headers.authorization || '');
    const match = /^Bearer\s+(.+)$/i.exec(authorization);
    if (!match || !safeEqual(match[1].trim(), this.service.getApiToken())) {
      throw new AppError('Token de API no válido.', 401, 'unauthorized');
    }
    if (!this.licenseProvider().active) {
      throw new AppError('Se requiere una licencia válida para usar la API.', 403, 'license_required');
    }

    const url = new URL(req.url, 'http://127.0.0.1');
    const segments = url.pathname.split('/').filter(Boolean);
    if (segments[0] !== 'v1') throw new AppError('Ruta no encontrada.', 404, 'not_found');

    const method = String(req.method || 'GET').toUpperCase();
    let body = {};
    if (method === 'POST' || method === 'PATCH' || method === 'PUT') {
      body = await readJsonBody(req);
    }

    const { status, payload } = await this.route(method, segments, url, body);
    sendJson(res, status, payload);
  }

  async route(method, segments, url, body) {
    const resource = segments[1] || '';

    if (resource === 'health' && segments.length === 2 && method === 'GET') {
      return {
        status: 200,
        payload: {
          ok: true,
          app: 'PerfilLab',
          version: app.getVersion(),
          uptimeSeconds: Math.round(process.uptime()),
        },
      };
    }

    if (resource === 'state' && segments.length === 2 && method === 'GET') {
      return { status: 200, payload: sanitizeState(this.service.getPublicState()) };
    }

    if (resource === 'status' && segments.length === 2 && method === 'GET') {
      return {
        status: 200,
        payload: {
          running: this.service.launcher.listRunning(),
          api: this.status(),
        },
      };
    }

    if (resource === 'activity' && segments.length === 2 && method === 'GET') {
      const limit = Number(url.searchParams.get('limit') || 50);
      const count = Number.isInteger(limit) && limit > 0 ? Math.min(limit, 200) : 50;
      return { status: 200, payload: { activity: this.service.state.activity.slice(0, count) } };
    }

    if (resource === 'profiles') {
      return this.routeProfiles(method, segments, url, body);
    }
    if (resource === 'proxies') {
      return this.routeProxies(method, segments, url, body);
    }
    if (resource === 'workspaces') {
      return this.routeWorkspaces(method, segments, body);
    }
    if (resource === 'statuses') {
      return this.routeStatuses(method, segments, body);
    }

    throw new AppError('Ruta no encontrada.', 404, 'not_found');
  }

  async routeProfiles(method, segments, url, body) {
    if (segments.length === 2) {
      if (method === 'GET') {
        const state = this.service.state;
        return {
          status: 200,
          payload: { profiles: state.profiles, running: this.service.launcher.listRunning() },
        };
      }
      if (method === 'POST') {
        return { status: 201, payload: this.service.createProfile(body) };
      }
      throw new AppError('Método no permitido.', 405, 'method_not_allowed');
    }

    const profileId = segments[2];
    const action = segments[3] || '';
    if (segments.length === 3 && profileId === 'batch' && method === 'POST') {
      return { status: 200, payload: await this.service.batchProfiles(body) };
    }
    if (segments.length === 3) {
      if (method === 'GET') {
        const profile = this.service.requireProfile(profileId);
        const running = this.service.launcher.listRunning().find((item) => item.profileId === profileId) || null;
        return { status: 200, payload: { profile, running } };
      }
      if (method === 'PATCH' || method === 'PUT') {
        return { status: 200, payload: this.service.updateProfile(profileId, body) };
      }
      if (method === 'DELETE') {
        const result = await this.service.deleteProfile(profileId, {
          deleteData: url.searchParams.get('deleteData') === 'true',
          releaseCloneAccount: url.searchParams.get('releaseCloneAccount') === 'true',
          removeVirtualMachine: url.searchParams.get('removeVirtualMachine') === 'true',
        });
        return { status: 200, payload: result };
      }
      throw new AppError('Método no permitido.', 405, 'method_not_allowed');
    }

    if (segments.length === 4 && method === 'POST') {
      if (action === 'start') return { status: 200, payload: await this.service.startProfile(profileId) };
      if (action === 'stop') return { status: 200, payload: await this.service.stopProfile(profileId) };
      if (action === 'duplicate') return { status: 201, payload: this.service.duplicateProfile(profileId) };
      throw new AppError('Ruta no encontrada.', 404, 'not_found');
    }

    throw new AppError('Ruta no encontrada.', 404, 'not_found');
  }

  async routeProxies(method, segments, url, body) {
    if (segments.length === 2) {
      if (method === 'GET') {
        return {
          status: 200,
          payload: { proxies: this.service.state.proxies.map((proxy) => this.service.publicProxy(proxy)) },
        };
      }
      if (method === 'POST') {
        return { status: 201, payload: this.service.createProxy(body) };
      }
      throw new AppError('Método no permitido.', 405, 'method_not_allowed');
    }

    const proxyId = segments[2];
    if (segments.length === 3 && proxyId === 'test' && method === 'POST') {
      return { status: 200, payload: await this.service.testProxies(body || {}) };
    }
    if (segments.length === 3) {
      if (method === 'PATCH' || method === 'PUT') {
        return { status: 200, payload: this.service.updateProxy(proxyId, body) };
      }
      if (method === 'DELETE') {
        return { status: 200, payload: this.service.deleteProxy(proxyId) };
      }
      throw new AppError('Método no permitido.', 405, 'method_not_allowed');
    }

    if (segments.length === 4 && segments[3] === 'test' && method === 'POST') {
      return { status: 200, payload: await this.service.testProxyConnection({ ...body, id: proxyId }) };
    }

    throw new AppError('Ruta no encontrada.', 404, 'not_found');
  }

  async routeWorkspaces(method, segments, body) {
    if (segments.length === 2) {
      if (method === 'GET') {
        return { status: 200, payload: { workspaces: this.service.state.workspaces } };
      }
      if (method === 'POST') {
        return { status: 201, payload: this.service.createWorkspace(body) };
      }
      throw new AppError('Método no permitido.', 405, 'method_not_allowed');
    }

    const workspaceId = segments[2];
    if (segments.length === 3) {
      if (method === 'PATCH' || method === 'PUT') {
        return { status: 200, payload: this.service.updateWorkspace(workspaceId, body) };
      }
      if (method === 'DELETE') {
        return { status: 200, payload: this.service.deleteWorkspace(workspaceId) };
      }
      throw new AppError('Método no permitido.', 405, 'method_not_allowed');
    }

    throw new AppError('Ruta no encontrada.', 404, 'not_found');
  }

  async routeStatuses(method, segments, body) {
    if (segments.length === 2) {
      if (method === 'GET') {
        return { status: 200, payload: { statuses: this.service.state.profileStatuses } };
      }
      if (method === 'POST') {
        return { status: 201, payload: this.service.createStatus(body) };
      }
      throw new AppError('Método no permitido.', 405, 'method_not_allowed');
    }

    const statusId = segments[2];
    if (segments.length === 3) {
      if (method === 'PATCH' || method === 'PUT') {
        return { status: 200, payload: this.service.updateStatus(statusId, body) };
      }
      if (method === 'DELETE') {
        return { status: 200, payload: this.service.deleteStatus(statusId) };
      }
      throw new AppError('Método no permitido.', 405, 'method_not_allowed');
    }

    throw new AppError('Ruta no encontrada.', 404, 'not_found');
  }
}

module.exports = { LocalApiServer, API_PREFIX };
