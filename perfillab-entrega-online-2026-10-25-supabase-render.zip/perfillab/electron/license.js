'use strict';

const crypto = require('node:crypto');
const { execFileSync } = require('node:child_process');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { AppError } = require('./errors');
const licensePublic = require('./license-public');
const {
  verifyLicense,
  verifyRevocationList,
  normalizeLicenseKey,
  normalizeMachineCode,
  keyIdFor,
} = require('../shared/license-format');

const MAX_LICENSE_BYTES = 128 * 1024;
const MAX_REVOCATION_BYTES = 24 * 1024 * 1024;
const MAX_SERVER_RESPONSE_BYTES = 32 * 1024 * 1024;
const MAX_CONFIG_BYTES = 16 * 1024;
const DEFAULT_SERVER_URL = typeof licensePublic.serverUrl === 'string' && licensePublic.serverUrl.trim()
  ? licensePublic.serverUrl.trim()
  : 'http://127.0.0.1:45900';
const DEFAULT_TIMEOUT_MS = 12_000;
const ALPHABET = '0123456789ABCDEFGHJKMNPQRSTVWXYZ';

function runningPackaged() {
  try {
    const electron = require('electron');
    return Boolean(electron && electron.app && electron.app.isPackaged);
  } catch {
    return false;
  }
}

function resolvePublicConfig() {
  let publicKey = licensePublic.publicKey;
  let keyId = licensePublic.keyId;
  let seatLimit = Number(licensePublic.seatLimit) || 50000;
  const devOverride = process.env.PERFILLAB_DEV === '1' && !runningPackaged();
  if (devOverride && process.env.PERFILLAB_LICENSE_PUBLIC_KEY) {
    publicKey = String(process.env.PERFILLAB_LICENSE_PUBLIC_KEY);
    keyId = '';
    seatLimit = Number(process.env.PERFILLAB_LICENSE_SEAT_LIMIT) || seatLimit;
  }
  if (typeof publicKey !== 'string' || !publicKey) {
    throw new Error('La clave pública de licencias no está configurada.');
  }
  const derived = keyIdFor(publicKey);
  if (!keyId) keyId = derived;
  if (keyId !== derived) throw new Error('La clave pública y su identificador no coinciden.');
  return { publicKey, keyId, seatLimit };
}

const PUBLIC_CONFIG = resolvePublicConfig();

function groupCode(value, size = 4) {
  const matches = String(value || '').match(new RegExp(`.{1,${size}}`, 'g'));
  return matches ? matches.join('-') : '';
}

function normalizeMachineCodeLocal(input) {
  const normalized = normalizeMachineCode(input);
  return normalized || '';
}

function normalizeLicenseKeyLocal(input) {
  return normalizeLicenseKey(input) || '';
}

function readMachineSource() {
  if (process.platform === 'win32') {
    const reg = path.join(process.env.SystemRoot || 'C:\\Windows', 'System32', 'reg.exe');
    const output = execFileSync(reg, ['query', 'HKLM\\SOFTWARE\\Microsoft\\Cryptography', '/v', 'MachineGuid'], {
      encoding: 'utf8',
      windowsHide: true,
      timeout: 5000,
    });
    const match = /MachineGuid\s+REG_\w+\s+([0-9a-fA-F-]{36})/.exec(output);
    if (!match) throw new Error('No se pudo leer el identificador del equipo.');
    return `win:${match[1].toLowerCase()}`;
  }
  if (process.platform === 'darwin') {
    const output = execFileSync('/usr/sbin/ioreg', ['-rd1', '-c', 'IOPlatformExpertDevice'], {
      encoding: 'utf8',
      timeout: 5000,
    });
    const match = /"IOPlatformUUID"\s*=\s*"([^"]+)"/.exec(output);
    if (!match) throw new Error('No se pudo leer el identificador del equipo.');
    return `mac:${match[1].toLowerCase()}`;
  }
  for (const file of ['/etc/machine-id', '/var/lib/dbus/machine-id']) {
    try {
      const value = fs.readFileSync(file, 'utf8').trim();
      if (value) return `linux:${value.toLowerCase()}`;
    } catch {
      // try the next source
    }
  }
  throw new Error('No se pudo leer el identificador del equipo.');
}

let cachedMachine = null;
let cachedMachineError = null;
let cachedMachineAttempted = false;

function machineInfo() {
  if (!cachedMachineAttempted) {
    cachedMachineAttempted = true;
    try {
      const source = readMachineSource();
      const hash = crypto.createHash('sha256').update('perfillab-machine-v1').update(source).digest();
      let bits = 0;
      let value = 0;
      let encoded = '';
      for (const byte of hash.subarray(0, 10)) {
        value = (value << 8) | byte;
        bits += 8;
        while (bits >= 5 && encoded.length < 16) {
          encoded += ALPHABET[(value >>> (bits - 5)) & 31];
          bits -= 5;
        }
        if (encoded.length >= 16) break;
      }
      cachedMachine = groupCode(encoded);
    } catch (error) {
      cachedMachineError = error.message;
    }
  }
  return { code: cachedMachine || '', error: cachedMachineError, platform: os.platform(), hostname: os.hostname() };
}

function isLoopbackHostname(hostname) {
  const raw = String(hostname || '').trim().toLowerCase()
    .replace(/^\[/, '')
    .replace(/\]$/, '')
    .replace(/\.$/, '');
  if (!raw) return false;
  if (raw === 'localhost' || raw === '::1') return true;
  const match = /^127\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/.exec(raw);
  return Boolean(match) && match.slice(1).every((part) => Number(part) <= 255);
}

function normalizeServerUrl(input) {
  const raw = String(input === undefined || input === null ? '' : input).trim();
  if (!raw) {
    throw new AppError('Escribe la dirección del servidor de licencias.', 400, 'invalid_server_url');
  }
  const candidate = /^[a-z][a-z0-9+.-]*:\/\//i.test(raw) ? raw : `http://${raw}`;
  let url;
  try {
    url = new URL(candidate);
  } catch {
    throw new AppError('La dirección del servidor no es válida.', 400, 'invalid_server_url');
  }
  if (url.protocol !== 'http:' && url.protocol !== 'https:') {
    throw new AppError('El servidor debe usar http:// o https://.', 400, 'invalid_server_url');
  }
  if (url.protocol === 'http:' && !isLoopbackHostname(url.hostname)) {
    throw new AppError(
      'Usa HTTPS para un servidor remoto. HTTP solo se permite en localhost o 127.0.0.1.',
      400,
      'invalid_server_url',
    );
  }
  if (!url.hostname) throw new AppError('La dirección del servidor no incluye un host.', 400, 'invalid_server_url');
  if (url.username || url.password) {
    throw new AppError('No incluyas credenciales dentro de la dirección del servidor.', 400, 'invalid_server_url');
  }
  if (url.search || url.hash || (url.pathname !== '/' && url.pathname !== '')) {
    throw new AppError('La dirección debe apuntar a la raíz del servidor, sin rutas ni parámetros.', 400, 'invalid_server_url');
  }
  return url.origin;
}

function readJsonFile(filePath, maxBytes) {
  if (!fs.existsSync(filePath)) return null;
  const stat = fs.statSync(filePath);
  if (stat.size > maxBytes) throw new Error('El archivo local es demasiado grande.');
  return JSON.parse(fs.readFileSync(filePath, 'utf8'));
}

function writeJsonAtomic(filePath, value) {
  fs.mkdirSync(path.dirname(filePath), { recursive: true });
  const temp = `${filePath}.${process.pid}.tmp`;
  fs.writeFileSync(temp, `${JSON.stringify(value, null, 2)}\n`, { encoding: 'utf8', mode: 0o600 });
  fs.renameSync(temp, filePath);
}

function parseLicenseInput(input) {
  let license = input;
  if (typeof input === 'string') {
    if (Buffer.byteLength(input, 'utf8') > MAX_LICENSE_BYTES) {
      throw new AppError('El archivo de licencia es demasiado grande.', 400, 'invalid_license');
    }
    try {
      license = JSON.parse(input);
    } catch {
      throw new AppError('El texto no contiene una licencia JSON válida.', 400, 'invalid_license');
    }
  }
  if (!license || typeof license !== 'object' || Array.isArray(license)) {
    throw new AppError('El archivo no contiene una licencia válida.', 400, 'invalid_license');
  }
  return license;
}

function verifyEnvelope(license) {
  try {
    const { payload } = verifyLicense(license, PUBLIC_CONFIG.publicKey, { keyId: PUBLIC_CONFIG.keyId });
    return payload;
  } catch (error) {
    throw new AppError(error.message || 'La licencia no es válida.', 400, 'invalid_license');
  }
}

class LicenseService {
  constructor({ filePath, enforced }) {
    this.filePath = filePath;
    this.revocationsPath = path.join(path.dirname(filePath), 'license-revocations.json');
    this.configPath = path.join(path.dirname(filePath), 'license-config.json');
    this.enforced = Boolean(enforced);
    this.payload = null;
    this.error = null;
    this.errorCode = null;
    this.onlineStatus = null;
    this.revocations = { revoked: new Map(), issuedAt: null, fetchedAt: null, etag: null };
    this.serverUrl = this.initialServerUrl();
    this.loadRevocations();
    this.load();
  }

  initialServerUrl() {
    let stored = '';
    try {
      const config = readJsonFile(this.configPath, MAX_CONFIG_BYTES);
      if (config && typeof config.serverUrl === 'string') stored = config.serverUrl;
    } catch {
      // La configuración local dañada no impide activar la licencia.
    }
    const candidates = [process.env.PERFILLAB_LICENSE_SERVER, stored, DEFAULT_SERVER_URL];
    for (const candidate of candidates) {
      try {
        return normalizeServerUrl(candidate);
      } catch {
        // Se prueba el siguiente candidato.
      }
    }
    return DEFAULT_SERVER_URL;
  }

  saveServerUrl(serverUrl) {
    const normalized = normalizeServerUrl(serverUrl);
    if (normalized !== this.serverUrl) {
      this.revocations = { revoked: new Map(), issuedAt: null, fetchedAt: null, etag: null };
    }
    this.serverUrl = normalized;
    writeJsonAtomic(this.configPath, { version: 1, serverUrl: normalized });
    return normalized;
  }

  machine() {
    return machineInfo();
  }

  publicKeyId() {
    return PUBLIC_CONFIG.keyId;
  }

  hasLicense() {
    return Boolean(this.payload);
  }

  seatLimit() {
    return PUBLIC_CONFIG.seatLimit;
  }

  load() {
    this.payload = null;
    this.error = null;
    this.errorCode = null;
    if (!fs.existsSync(this.filePath)) return;
    try {
      const stat = fs.statSync(this.filePath);
      if (stat.size > MAX_LICENSE_BYTES) {
        throw new AppError('El archivo de licencia guardado es demasiado grande.', 400, 'invalid_license');
      }
      const parsed = JSON.parse(fs.readFileSync(this.filePath, 'utf8'));
      this.payload = verifyEnvelope(parsed);
    } catch (error) {
      this.error = error instanceof AppError ? error.message : 'No se pudo leer la licencia guardada.';
      this.errorCode = error instanceof AppError ? error.code : 'license_read_error';
    }
  }

  loadRevocations() {
    try {
      const cached = readJsonFile(this.revocationsPath, MAX_REVOCATION_BYTES);
      if (!cached || !cached.list) return;
      const list = verifyRevocationList(cached.list, PUBLIC_CONFIG.publicKey);
      const revoked = new Map();
      for (const item of list.revoked) revoked.set(item.licenseId, item);
      this.revocations = {
        revoked,
        issuedAt: list.issuedAt || null,
        fetchedAt: typeof cached.fetchedAt === 'string' ? cached.fetchedAt : null,
        etag: typeof cached.etag === 'string' ? cached.etag : null,
      };
    } catch {
      this.revocations = { revoked: new Map(), issuedAt: null, fetchedAt: null, etag: null };
    }
  }

  currentState() {
    const machine = machineInfo();
    const payload = this.payload;
    if (!payload) {
      return {
        status: this.error ? 'invalid' : 'none',
        message: this.error,
        code: this.errorCode,
      };
    }
    const now = Date.now();
    const revoked = this.revocations.revoked.get(payload.licenseId);
    if (revoked) {
      const reason = revoked.reason ? ` Motivo: ${revoked.reason}` : '';
      return { status: 'revoked', message: `Esta licencia ha sido revocada.${reason}`, code: 'license_revoked' };
    }
    if (this.onlineStatus && this.onlineStatus.reachable && this.onlineStatus.valid === false) {
      const status = ['revoked', 'suspended', 'expired', 'other_machine', 'invalid'].includes(this.onlineStatus.status)
        ? this.onlineStatus.status
        : 'invalid';
      return {
        status,
        message: this.onlineStatus.reason || 'El servidor no reconoce esta licencia.',
        code: `license_${status}`,
      };
    }
    if (payload.startsAt && Date.parse(payload.startsAt) > now + 5 * 60 * 1000) {
      return { status: 'pending', message: 'La licencia todavía no ha comenzado.', code: 'license_not_started' };
    }
    if (payload.expiresAt && Date.parse(payload.expiresAt) <= now) {
      return { status: 'expired', message: 'La licencia ha caducado.', code: 'license_expired' };
    }
    if (!machine.code) {
      return { status: 'machine_error', message: machine.error || 'No se pudo identificar este equipo.', code: 'machine_error' };
    }
    if (payload.machineCode !== machine.code) {
      return { status: 'other_machine', message: 'La licencia pertenece a otro equipo.', code: 'license_other_machine' };
    }
    return { status: 'active', message: null, code: null };
  }

  activationCheck(payload) {
    const machine = machineInfo();
    if (!machine.code) throw new AppError(machine.error || 'No se pudo identificar este equipo.', 400, 'machine_error');
    if (payload.machineCode !== machine.code) {
      throw new AppError('Esta licencia fue emitida para otro equipo.', 400, 'license_other_machine');
    }
    if (payload.startsAt && Date.parse(payload.startsAt) > Date.now() + 5 * 60 * 1000) {
      throw new AppError('La licencia todavía no ha comenzado.', 400, 'license_not_started');
    }
    if (payload.expiresAt && Date.parse(payload.expiresAt) <= Date.now()) {
      throw new AppError('La licencia ha caducado.', 400, 'license_expired');
    }
    const revoked = this.revocations.revoked.get(payload.licenseId);
    if (revoked) {
      throw new AppError('Esta licencia ha sido revocada.', 403, 'license_revoked');
    }
  }

  persistLicense(license) {
    writeJsonAtomic(this.filePath, license);
  }

  activateFile(input) {
    const parsed = parseLicenseInput(input);
    const payload = verifyEnvelope(parsed);
    this.activationCheck(payload);
    this.persistLicense(parsed);
    this.payload = payload;
    this.error = null;
    this.errorCode = null;
    this.onlineStatus = null;
    return this.publicStatus();
  }

  async ping(serverUrl) {
    const base = serverUrl ? normalizeServerUrl(serverUrl) : this.serverUrl;
    const data = await this.requestJson(base, 'GET', '/api/health', { timeoutMs: 8000 });
    return {
      ok: data.ok === true,
      serverUrl: base,
      service: data.service || '',
      version: data.version || '',
      time: data.time || null,
    };
  }

  async activateOnline({ licenseKey, serverUrl, machineName } = {}) {
    const key = normalizeLicenseKeyLocal(licenseKey);
    if (!key) throw new AppError('La clave de licencia no es válida.', 400, 'invalid_license_key');
    const machine = machineInfo();
    if (!machine.code) throw new AppError(machine.error || 'No se pudo identificar este equipo.', 400, 'machine_error');
    const base = normalizeServerUrl(serverUrl || this.serverUrl);
    const name = String(machineName || machine.hostname || '').trim().slice(0, 80);
    const data = await this.requestJson(base, 'POST', '/api/license/activate', {
      body: { licenseKey: key, machineCode: machine.code, machineName: name },
    });
    if (!data || !data.license) {
      throw new AppError('El servidor no devolvió una licencia válida.', 502, 'invalid_server_response');
    }
    const payload = verifyEnvelope(data.license);
    if (payload.licenseKey !== key) {
      throw new AppError('El servidor devolvió una licencia que no coincide con la clave.', 502, 'invalid_server_response');
    }
    this.activationCheck(payload);
    this.saveServerUrl(base);
    this.persistLicense(data.license);
    this.payload = payload;
    this.error = null;
    this.errorCode = null;
    this.onlineStatus = {
      valid: true,
      status: 'active',
      reason: null,
      reachable: true,
      checkedAt: new Date().toISOString(),
    };
    try {
      await this.refreshRevocations();
    } catch {
      // La activación ya está firmada; la lista se reintenta en la próxima sincronización.
    }
    return this.publicStatus();
  }

  requestRaw(base, method, pathName, { body, headers = {}, timeoutMs = DEFAULT_TIMEOUT_MS } = {}) {
    return this.performRequest(base, method, pathName, { body, headers, timeoutMs, raw: true });
  }

  requestJson(base, method, pathName, { body, timeoutMs = DEFAULT_TIMEOUT_MS } = {}) {
    return this.performRequest(base, method, pathName, { body, timeoutMs, raw: false });
  }

  async performRequest(base, method, pathName, { body, headers, timeoutMs, raw }) {
    const requestHeaders = { Accept: 'application/json', ...headers };
    let payload;
    if (body !== undefined) {
      requestHeaders['Content-Type'] = 'application/json';
      payload = JSON.stringify(body);
    }
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeoutMs);
    let response;
    try {
      response = await fetch(`${base}${pathName}`, {
        method,
        headers: requestHeaders,
        body: payload,
        redirect: 'error',
        cache: 'no-store',
        signal: controller.signal,
      });
    } catch (error) {
      if (error && error.name === 'AbortError') {
        throw new AppError('El servidor tardó demasiado en responder.', 0, 'license_server_timeout');
      }
      throw new AppError(
        'No se pudo conectar con el servidor de licencias. Revisa la dirección y que el servidor esté en marcha.',
        0,
        'license_server_unreachable',
      );
    } finally {
      clearTimeout(timer);
    }

    const declared = Number(response.headers.get('content-length'));
    if (Number.isFinite(declared) && declared > MAX_SERVER_RESPONSE_BYTES) {
      throw new AppError('La respuesta del servidor es demasiado grande.', 502, 'response_too_large');
    }
    let text = '';
    try {
      const buffer = Buffer.from(await response.arrayBuffer());
      if (buffer.length > MAX_SERVER_RESPONSE_BYTES) {
        throw new AppError('La respuesta del servidor es demasiado grande.', 502, 'response_too_large');
      }
      text = buffer.toString('utf8');
    } catch (error) {
      if (error instanceof AppError) throw error;
      throw new AppError('La respuesta del servidor se interrumpió.', 0, 'license_server_interrupted');
    }

    if (raw) {
      return { status: response.status, ok: response.ok, headers: response.headers, text };
    }

    let data = null;
    if (text.trim()) {
      try {
        data = JSON.parse(text);
      } catch {
        throw new AppError('El servidor envió una respuesta que no es JSON válido.', 502, 'invalid_server_response');
      }
    }
    if (!response.ok) {
      const detail = data && data.error && typeof data.error === 'object' ? data.error : {};
      throw new AppError(
        detail.message || `El servidor respondió con HTTP ${response.status}.`,
        response.status,
        detail.code || 'license_server_error',
      );
    }
    return data || {};
  }

  async refreshRevocations({ force = false } = {}) {
    if (!this.serverUrl) throw new AppError('No hay un servidor configurado.', 400, 'invalid_server_url');
    const headers = {};
    if (!force && this.revocations.etag) headers['If-None-Match'] = this.revocations.etag;
    const response = await this.requestRaw(this.serverUrl, 'GET', '/api/license/revocations', { headers });
    if (response.status === 304) {
      this.revocations.fetchedAt = new Date().toISOString();
      return { updated: false, count: this.revocations.revoked.size, issuedAt: this.revocations.issuedAt };
    }
    if (!response.ok) {
      let detail = {};
      try {
        const parsed = JSON.parse(response.text);
        detail = parsed && parsed.error && typeof parsed.error === 'object' ? parsed.error : {};
      } catch {
        detail = {};
      }
      throw new AppError(
        detail.message || `El servidor respondió con HTTP ${response.status}.`,
        response.status,
        detail.code || 'revocation_list_error',
      );
    }
    let list;
    try {
      list = JSON.parse(response.text);
    } catch {
      throw new AppError('La lista de revocaciones no es JSON válido.', 502, 'invalid_revocation_list');
    }
    try {
      verifyRevocationList(list, PUBLIC_CONFIG.publicKey);
    } catch (error) {
      throw new AppError(error.message || 'La lista de revocaciones no es válida.', 502, 'invalid_revocation_list');
    }
    if (list.keyId !== PUBLIC_CONFIG.keyId) {
      throw new AppError('La lista de revocaciones usa otra clave de firma.', 502, 'invalid_revocation_list');
    }
    const revoked = new Map();
    for (const item of list.revoked) revoked.set(item.licenseId, item);
    const etag = response.headers.get('etag') || '';
    const fetchedAt = new Date().toISOString();
    this.revocations = { revoked, issuedAt: list.issuedAt || null, fetchedAt, etag };
    writeJsonAtomic(this.revocationsPath, { version: 1, fetchedAt, etag, list });
    return { updated: true, count: revoked.size, issuedAt: list.issuedAt };
  }

  async validateOnline() {
    if (!this.payload) return { skipped: true, reachable: false };
    const machine = machineInfo();
    const checkedAt = new Date().toISOString();
    try {
      const data = await this.requestJson(this.serverUrl, 'POST', '/api/license/validate', {
        body: { licenseKey: this.payload.licenseKey, machineCode: machine.code || '' },
      });
      const valid = data.valid === true;
      const status = typeof data.status === 'string' ? data.status : (valid ? 'active' : 'invalid');
      this.onlineStatus = {
        valid,
        status,
        reason: typeof data.reason === 'string' ? data.reason : null,
        reachable: true,
        checkedAt,
      };
      return { reachable: true, valid, status, reason: this.onlineStatus.reason };
    } catch (error) {
      if (error instanceof AppError && error.status >= 400 && error.status < 500) {
        this.onlineStatus = {
          valid: false,
          status: error.code === 'license_expired' ? 'expired' : 'invalid',
          reason: error.message,
          reachable: true,
          checkedAt,
        };
        return { reachable: true, valid: false, status: this.onlineStatus.status, reason: error.message };
      }
      this.onlineStatus = {
        reachable: false,
        valid: null,
        status: 'unreachable',
        reason: error.message,
        checkedAt,
      };
      return { reachable: false, error: error.message };
    }
  }

  async sync() {
    const result = { revocations: null, validation: null, errors: [] };
    if (!this.payload) return result;
    try {
      result.revocations = await this.refreshRevocations();
    } catch (error) {
      result.errors.push(error.message);
    }
    try {
      result.validation = await this.validateOnline();
    } catch (error) {
      result.errors.push(error.message);
    }
    return result;
  }

  licensed() {
    return this.currentState().status === 'active';
  }

  isActive() {
    return this.enforced ? this.licensed() : true;
  }

  publicStatus() {
    const machine = machineInfo();
    const state = this.currentState();
    const payload = this.payload;
    const licensed = state.status === 'active';
    const active = this.enforced ? licensed : true;
    return {
      required: this.enforced,
      active,
      licensed,
      status: state.status,
      statusMessage: state.message,
      error: state.message || (!payload && machine.error ? machine.error : null),
      machineCode: machine.code,
      machineError: machine.error,
      serverUrl: this.serverUrl,
      offline: Boolean(this.onlineStatus && this.onlineStatus.reachable === false),
      lastCheckedAt: this.onlineStatus ? this.onlineStatus.checkedAt || null : null,
      revocationsUpdatedAt: this.revocations.fetchedAt,
      revokedCount: this.revocations.revoked.size,
      licenseId: payload ? payload.licenseId : null,
      licenseKey: payload ? payload.licenseKey : null,
      seat: payload ? payload.seat : null,
      customer: payload ? payload.customer : null,
      product: payload ? payload.product || 'perfillab' : null,
      plan: payload ? payload.plan || 'annual' : null,
      transactionId: payload ? payload.transactionId || null : null,
      issuedAt: payload ? payload.issuedAt : null,
      startsAt: payload ? payload.startsAt || null : null,
      expiresAt: payload ? payload.expiresAt || null : null,
      checkedAt: new Date().toISOString(),
    };
  }
}

module.exports = {
  LicenseService,
  machineInfo,
  isLoopbackHostname,
  normalizeMachineCode: normalizeMachineCodeLocal,
  normalizeServerUrl,
  PUBLIC_CONFIG,
};
