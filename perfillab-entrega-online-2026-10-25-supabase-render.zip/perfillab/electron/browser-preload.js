'use strict';

const { contextBridge, ipcRenderer } = require('electron');

const invoke = (channel, payload) => ipcRenderer.invoke(`browser:${channel}`, payload);

contextBridge.exposeInMainWorld('perfilabBrowser', {
  getState: () => invoke('get-state'),
  navigate: (input) => invoke('navigate', String(input === undefined || input === null ? '' : input).slice(0, 4096)),
  back: () => invoke('back'),
  forward: () => invoke('forward'),
  reload: () => invoke('reload'),
  stop: () => invoke('stop'),
  home: () => invoke('home'),
  newTab: (url = '') => invoke('new-tab', { url: String(url).slice(0, 4096) }),
  closeTab: (id) => invoke('close-tab', { id: String(id) }),
  selectTab: (id) => invoke('select-tab', { id: String(id) }),
  findOpen: () => invoke('find-open'),
  find: (text, options = {}) => invoke('find', {
    text: String(text === undefined || text === null ? '' : text).slice(0, 200),
    forward: options.forward !== false,
    findNext: options.findNext === true,
  }),
  findStop: () => invoke('find-stop'),
  findClose: () => invoke('find-close'),
  zoom: (direction) => invoke('zoom', { direction: Number(direction) || 0 }),
  openDownloads: () => invoke('open-downloads'),
  openDownload: (id) => invoke('open-download', { id: String(id) }),
  onEvent: (callback) => {
    if (typeof callback !== 'function') return () => {};
    const handler = (_event, payload) => callback(payload);
    ipcRenderer.on('browser:event', handler);
    return () => ipcRenderer.removeListener('browser:event', handler);
  },
  platform: process.platform,
});
