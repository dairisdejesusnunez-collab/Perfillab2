'use strict';

const fs = require('node:fs');
const path = require('node:path');
const { pathToFileURL } = require('node:url');
const {
  app,
  BrowserWindow,
  WebContentsView,
  Menu,
  dialog,
  shell,
  session,
  clipboard,
  ipcMain,
} = require('electron');
const { LicenseService } = require('./license');
const {
  BROWSER_CHROME_HEIGHT,
  isAllowedPageUrl,
  isHomeUrl,
  isHttpUrl,
  resolveAddressInput,
} = require('./browser-launch');

const RENDERER_DIR = path.join(__dirname, '..', 'renderer');
const SHELL_HTML = path.join(RENDERER_DIR, 'browser.html');
const SHELL_PRELOAD = path.join(__dirname, 'browser-preload.js');
const HOME_HTML = path.join(RENDERER_DIR, 'browser-home.html');
const ERROR_HTML = path.join(RENDERER_DIR, 'browser-error.html');
const BLOCKED_HTML = path.join(RENDERER_DIR, 'browser-blocked.html');
const ICON = path.join(__dirname, '..', 'assets', 'icon.png');
const FIND_ROW_HEIGHT = 44;
const NOTICE_ROW_HEIGHT = 36;
const FIND_FALLBACK_DELAY = 450;
const FIND_WORLD_ID = 999;
const DOWNLOAD_LIMIT = 12;
const PERMISSION_ALLOWED = new Set(['fullscreen', 'clipboard-sanitized-write']);
const PERMISSION_PROMPTED = new Set([
  'media',
  'geolocation',
  'notifications',
  'clipboard-read',
  'display-capture',
  'midi',
  'midiSysex',
]);
const EXTERNAL_PROTOCOLS = new Set(['mailto:', 'tel:']);

let win = null;
let args = null;
let version = '';
let homeHref = '';
let errorHref = '';
let tabs = new Map();
let activeTabId = null;
let tabSeq = 0;
let downloads = new Map();
let downloadSeq = 0;
let downloadsDir = '';
let fullscreen = false;
let findOpen = false;
let findSession = null;
let noticeOpen = false;
let noticeTimer = null;
let decisions = new Map();
let broadcastHandle = null;

function platformToken() {
  if (process.platform === 'win32') return 'Windows NT 10.0; Win64; x64';
  if (process.platform === 'darwin') return 'Macintosh; Intel Mac OS X 10_15_7';
  return 'X11; Linux x86_64';
}

function sanitizeText(value, max = 200) {
  return String(value || '')
    .replace(/[\u0000-\u001f\u007f]/g, ' ')
    .trim()
    .slice(0, max);
}

function isLocalPage(url, fileHref) {
  return isHomeUrl(url, fileHref);
}

function isSafeFavicon(url) {
  if (typeof url !== 'string' || !url || url.length > 2048) return false;
  return /^data:image\//i.test(url) || isHttpUrl(url);
}

function activeTab() {
  return activeTabId ? tabs.get(activeTabId) || null : null;
}

function publicDownloads() {
  return [...downloads.values()].slice(-DOWNLOAD_LIMIT).reverse().map((item) => ({
    id: item.id,
    filename: item.filename,
    state: item.state,
    receivedBytes: item.receivedBytes,
    totalBytes: item.totalBytes,
    path: item.path,
  }));
}

function publicTab(tab) {
  const wc = tab.view.webContents;
  const current = wc.getURL();
  const home = !tab.error && isLocalPage(current, homeHref);
  const failed = tab.error;
  const url = failed ? failed.url : (home ? '' : current);
  const title = tab.title || (home ? 'Nueva pestaña' : '');
  return {
    id: tab.id,
    title,
    url,
    home,
    secure: /^https:/i.test(url),
    loading: Boolean(tab.loading) && !failed,
    canGoBack: tab.canGoBack,
    canGoForward: tab.canGoForward,
    favicon: tab.favicon || '',
    error: Boolean(failed),
    errorCode: failed ? failed.code : 0,
  };
}

function publicState() {
  return {
    profile: {
      id: args ? args.profileId : '',
      name: args ? args.profileName : 'Perfil',
    },
    proxyLabel: args ? args.proxyLabel : 'Sin proxy',
    version,
    engine: process.versions.chrome,
    fullscreen,
    findOpen,
    activeTabId,
    tabs: [...tabs.values()].map(publicTab),
    downloads: publicDownloads(),
    downloadsDir,
  };
}

function sendEvent(payload) {
  if (!win || win.isDestroyed()) return;
  try {
    win.webContents.send('browser:event', payload);
  } catch {
    // La ventana puede cerrarse mientras llega un evento.
  }
}

function scheduleBroadcast() {
  if (broadcastHandle) return;
  broadcastHandle = setTimeout(() => {
    broadcastHandle = null;
    sendEvent({ type: 'state', state: publicState() });
  }, 16);
}

function syncTab(tab) {
  const wc = tab.view.webContents;
  try {
    tab.canGoBack = wc.navigationHistory.canGoBack();
    tab.canGoForward = wc.navigationHistory.canGoForward();
  } catch {
    tab.canGoBack = false;
    tab.canGoForward = false;
  }
  scheduleBroadcast();
}

function updateWindowTitle() {
  if (!win || win.isDestroyed()) return;
  const tab = activeTab();
  const title = tab && tab.title ? `${tab.title} · PerfilLab Browser` : 'PerfilLab Browser';
  win.setTitle(title);
}

function chromeHeight() {
  if (fullscreen) return 0;
  return BROWSER_CHROME_HEIGHT + (findOpen ? FIND_ROW_HEIGHT : 0) + (noticeOpen ? NOTICE_ROW_HEIGHT : 0);
}

function layout() {
  if (!win || win.isDestroyed()) return;
  const bounds = win.getContentBounds();
  const top = chromeHeight();
  const width = Math.max(0, bounds.width);
  const height = Math.max(0, bounds.height - top);
  for (const tab of tabs.values()) {
    tab.view.setBounds({ x: 0, y: top, width, height });
  }
}

function clearNotice() {
  if (!noticeOpen) return;
  noticeOpen = false;
  layout();
  sendEvent({ type: 'notice-clear' });
}

function showNotice(text, level = 'info') {
  const message = sanitizeText(text, 200);
  if (!message) return;
  noticeOpen = true;
  layout();
  sendEvent({ type: 'notice', text: message, level });
  if (noticeTimer) clearTimeout(noticeTimer);
  noticeTimer = setTimeout(clearNotice, 5000);
}

function setFindOpen(open) {
  const next = Boolean(open);
  if (findOpen === next) return;
  findOpen = next;
  layout();
}

function openExternal(url) {
  let parsed;
  try {
    parsed = new URL(url);
  } catch {
    return;
  }
  if (!EXTERNAL_PROTOCOLS.has(parsed.protocol)) {
    showNotice('Se bloqueó un enlace con un protocolo no permitido.', 'warn');
    return;
  }
  shell.openExternal(parsed.href).catch(() => {
    showNotice('No se pudo abrir el enlace externo.', 'warn');
  });
}

function domFindScript(query, forward, restart) {
  return `(() => {
    const needle = ${JSON.stringify(query)}.toLocaleLowerCase();
    const forward = ${forward ? 'true' : 'false'};
    const restart = ${restart ? 'true' : 'false'};
    const root = document.body || document.documentElement;
    if (!root || !needle) return { matches: 0, active: 0 };
    const matches = [];
    const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
      acceptNode(node) {
        const parent = node.parentElement;
        if (!parent) return NodeFilter.FILTER_REJECT;
        const tag = parent.tagName;
        if (tag === 'SCRIPT' || tag === 'STYLE' || tag === 'NOSCRIPT' || tag === 'TEMPLATE') {
          return NodeFilter.FILTER_REJECT;
        }
        return NodeFilter.FILTER_ACCEPT;
      },
    });
    let node = null;
    while ((node = walker.nextNode())) {
      const value = node.nodeValue ? node.nodeValue.toLocaleLowerCase() : '';
      if (!value) continue;
      let index = value.indexOf(needle);
      while (index !== -1) {
        matches.push({ node, start: index, end: index + needle.length });
        index = value.indexOf(needle, index + needle.length);
      }
    }
    const selection = window.getSelection();
    if (restart && selection) selection.removeAllRanges();
    const found = matches.length > 0
      && window.find(${JSON.stringify(query)}, false, !forward, true, false, false, false);
    let active = 0;
    if (found && selection && selection.rangeCount) {
      const range = selection.getRangeAt(0);
      for (let i = 0; i < matches.length; i += 1) {
        const item = matches[i];
        if (item.node === range.startContainer
          && range.startOffset >= item.start
          && range.startOffset < item.end) {
          active = i + 1;
          break;
        }
      }
    }
    if (!found && selection) selection.removeAllRanges();
    return { matches: matches.length, active };
  })()`;
}

function runDomFind(tab, session) {
  if (findSession !== session || session.source === 'native') return;
  session.timer = null;
  const wc = tab.view.webContents;
  wc.executeJavaScriptInIsolatedWorld(FIND_WORLD_ID, [{
    code: domFindScript(session.query, session.forward, session.restart),
  }], true).then((result) => {
    if (findSession !== session || session.source === 'native') return;
    session.source = 'dom';
    sendEvent({
      type: 'find-result',
      matches: result ? Number(result.matches) || 0 : 0,
      activeMatchOrdinal: result ? Number(result.active) || 0 : 0,
      finalUpdate: true,
    });
  }).catch(() => {
    if (findSession !== session || session.source === 'native') return;
    session.source = 'dom';
    sendEvent({ type: 'find-result', matches: 0, activeMatchOrdinal: 0, finalUpdate: true });
  });
}

function stopFind() {
  const session = findSession;
  findSession = null;
  if (session && session.timer) clearTimeout(session.timer);
  const tab = (session && tabs.get(session.tabId)) || activeTab();
  if (!tab) return;
  try {
    tab.view.webContents.stopFindInPage('clearSelection');
  } catch {
    // La pestaña pudo cerrarse.
  }
  if (session && session.source === 'dom') {
    tab.view.webContents.executeJavaScriptInIsolatedWorld(FIND_WORLD_ID, [{
      code: 'window.getSelection() && window.getSelection().removeAllRanges()',
    }]).catch(() => {
      // La pestaña pudo cerrarse.
    });
  }
}

function resetFind() {
  if (findSession && findSession.timer) clearTimeout(findSession.timer);
  findSession = null;
}

function closeFindFromMain() {
  if (!findOpen) return;
  setFindOpen(false);
  stopFind();
  sendEvent({ type: 'close-find' });
}

function loadHome(tab) {
  tab.error = null;
  const query = {
    profile: args.profileName,
    proxy: args.proxyLabel,
  };
  tab.view.webContents.loadFile(HOME_HTML, { query }).catch(() => {
    // did-fail-load gestiona el error de la página local.
  });
}

function loadErrorPage(tab, error) {
  const params = new URLSearchParams({
    url: error.url,
    code: String(error.code),
    desc: error.description || 'No se pudo cargar la página',
  });
  tab.view.webContents.loadFile(ERROR_HTML, { query: Object.fromEntries(params) }).catch(() => {
    // Si la página de error tampoco carga, se conserva el estado de error.
  });
}

function loadTarget(tab, target) {
  if (!target || target === 'home') {
    loadHome(tab);
    return;
  }
  const resolved = resolveAddressInput(target);
  if (!resolved) {
    loadHome(tab);
    return;
  }
  tab.error = null;
  tab.view.webContents.loadURL(resolved).catch(() => {
    // did-fail-load informa el resultado real.
  });
}

function createTab({ url = '', activate = true } = {}) {
  if (!win || win.isDestroyed()) return null;
  const view = new WebContentsView({
    webPreferences: {
      contextIsolation: true,
      sandbox: true,
      nodeIntegration: false,
      webSecurity: true,
      allowRunningInsecureContent: false,
      spellcheck: true,
    },
  });
  view.setBackgroundColor('#0b1020');
  const tab = {
    id: `tab-${++tabSeq}`,
    view,
    title: '',
    favicon: '',
    loading: true,
    canGoBack: false,
    canGoForward: false,
    error: null,
  };
  tabs.set(tab.id, tab);
  wireTab(tab);
  win.contentView.addChildView(view);
  view.setVisible(false);
  if (activate) activateTab(tab.id);
  loadTarget(tab, url);
  layout();
  if (activate) {
    view.setVisible(true);
    if (!url) sendEvent({ type: 'focus-address' });
  }
  scheduleBroadcast();
  return tab;
}

function activateTab(tabId) {
  const tab = tabs.get(tabId);
  if (!tab) return;
  resetFind();
  activeTabId = tab.id;
  for (const [id, item] of tabs) {
    item.view.setVisible(id === tab.id);
  }
  updateWindowTitle();
  layout();
  try {
    tab.view.webContents.focus();
  } catch {
    // La vista puede estar cargando.
  }
  scheduleBroadcast();
}

function closeTab(tabId) {
  const tab = tabs.get(tabId);
  if (!tab) return;
  if (findSession && findSession.tabId === tabId) resetFind();
  tabs.delete(tabId);
  try {
    if (win && !win.isDestroyed()) win.contentView.removeChildView(tab.view);
  } catch {
    // La ventana pudo cerrarse.
  }
  try {
    tab.view.webContents.close();
  } catch {
    // La vista ya estaba cerrada.
  }
  if (activeTabId === tabId) {
    activeTabId = null;
    const next = [...tabs.values()].pop();
    if (next) {
      activateTab(next.id);
    } else if (win && !win.isDestroyed()) {
      win.close();
      return;
    }
  }
  updateWindowTitle();
  scheduleBroadcast();
}

function cycleTabs(step) {
  const list = [...tabs.keys()];
  if (list.length < 2) return;
  const index = Math.max(0, list.indexOf(activeTabId));
  const next = list[(index + step + list.length) % list.length];
  activateTab(next);
}

function adjustZoom(delta) {
  const tab = activeTab();
  if (!tab) return;
  const wc = tab.view.webContents;
  if (delta === 0) {
    wc.setZoomLevel(0);
  } else {
    const next = Math.max(-5, Math.min(6, wc.getZoomLevel() + delta));
    wc.setZoomLevel(next);
  }
  showNotice(`Zoom: ${Math.round(Math.pow(1.2, wc.getZoomLevel()) * 100)}%`, 'info');
}

function handleShortcut(tab, input) {
  if (input.type !== 'keyDown') return false;
  const key = String(input.key || '').toLowerCase();
  const ctrl = Boolean(input.control || input.meta);
  if (ctrl && key === 't') {
    createTab({ url: '' });
    return true;
  }
  if (ctrl && key === 'w') {
    closeTab(tab.id);
    return true;
  }
  if (ctrl && key === 'n') {
    createTab({ url: '' });
    return true;
  }
  if (ctrl && key === 'l') {
    sendEvent({ type: 'focus-address' });
    return true;
  }
  if (ctrl && key === 'f') {
    sendEvent({ type: 'focus-find' });
    return true;
  }
  if (ctrl && (key === 'r' || input.key === 'F5')) {
    if (tab.error) tab.view.webContents.loadURL(tab.error.url).catch(() => {});
    else tab.view.webContents.reload();
    return true;
  }
  if (input.key === 'F5') {
    tab.view.webContents.reload();
    return true;
  }
  if (ctrl && key === 'tab') {
    cycleTabs(input.shift ? -1 : 1);
    return true;
  }
  if (ctrl && (key === '=' || key === '+')) {
    adjustZoom(1);
    return true;
  }
  if (ctrl && key === '-') {
    adjustZoom(-1);
    return true;
  }
  if (ctrl && key === '0') {
    adjustZoom(0);
    return true;
  }
  if (input.alt && input.key === 'ArrowLeft') {
    if (tab.canGoBack) tab.view.webContents.navigationHistory.goBack();
    return true;
  }
  if (input.alt && input.key === 'ArrowRight') {
    if (tab.canGoForward) tab.view.webContents.navigationHistory.goForward();
    return true;
  }
  if (input.key === 'Escape' && findOpen) {
    closeFindFromMain();
    return true;
  }
  if (input.key === 'F12' && !app.isPackaged) {
    tab.view.webContents.toggleDevTools();
    return true;
  }
  return false;
}

function buildContextMenu(tab, params) {
  const wc = tab.view.webContents;
  const template = [];
  if (params.linkURL && isHttpUrl(params.linkURL)) {
    template.push({
      label: 'Abrir enlace en una pestaña nueva',
      click: () => createTab({ url: params.linkURL }),
    });
    template.push({
      label: 'Copiar dirección del enlace',
      click: () => clipboard.writeText(params.linkURL.slice(0, 4096)),
    });
    template.push({ type: 'separator' });
  }
  if (params.isEditable) {
    template.push(
      { label: 'Deshacer', enabled: params.editFlags.canUndo, click: () => wc.undo() },
      { label: 'Rehacer', enabled: params.editFlags.canRedo, click: () => wc.redo() },
      { type: 'separator' },
      { label: 'Cortar', enabled: params.editFlags.canCut, click: () => wc.cut() },
      { label: 'Copiar', enabled: params.editFlags.canCopy, click: () => wc.copy() },
      { label: 'Pegar', enabled: params.editFlags.canPaste, click: () => wc.paste() },
      { label: 'Seleccionar todo', enabled: params.editFlags.canSelectAll, click: () => wc.selectAll() },
    );
  } else if (params.selectionText) {
    template.push({
      label: 'Copiar',
      click: () => clipboard.writeText(String(params.selectionText).slice(0, 16384)),
    });
  }
  if (template.length) template.push({ type: 'separator' });
  template.push(
    { label: 'Atrás', enabled: tab.canGoBack, click: () => wc.navigationHistory.goBack() },
    { label: 'Adelante', enabled: tab.canGoForward, click: () => wc.navigationHistory.goForward() },
    { label: 'Recargar', click: () => wc.reload() },
  );
  if (!app.isPackaged) {
    template.push({ type: 'separator' }, { label: 'Herramientas de desarrollo', click: () => wc.toggleDevTools() });
  }
  return Menu.buildFromTemplate(template);
}

function wireTab(tab) {
  const wc = tab.view.webContents;

  wc.setWindowOpenHandler(({ url, disposition }) => {
    if (isHttpUrl(url)) {
      createTab({ url, activate: disposition !== 'background-tab' });
    } else if (/^(mailto|tel):/i.test(url)) {
      openExternal(url);
    }
    return { action: 'deny' };
  });

  wc.on('will-navigate', (event, url) => {
    if (isAllowedPageUrl(url, homeHref) || isLocalPage(url, errorHref)) return;
    event.preventDefault();
    openExternal(url);
  });

  wc.on('will-redirect', (event, url) => {
    if (isAllowedPageUrl(url, homeHref) || isLocalPage(url, errorHref)) return;
    event.preventDefault();
  });

  wc.on('did-start-loading', () => {
    resetFind();
    tab.loading = true;
    if (!tab.error) tab.error = null;
    scheduleBroadcast();
  });

  wc.on('did-stop-loading', () => {
    tab.loading = false;
    syncTab(tab);
  });

  wc.on('did-navigate', (event, url) => {
    if (isLocalPage(url, errorHref)) {
      tab.favicon = '';
    } else {
      tab.error = null;
    }
    syncTab(tab);
  });

  wc.on('did-navigate-in-page', (event, url, isMainFrame) => {
    if (!isMainFrame) return;
    if (!isLocalPage(url, errorHref)) tab.error = null;
    syncTab(tab);
  });

  wc.on('did-fail-load', (event, errorCode, errorDescription, validatedURL, isMainFrame) => {
    if (!isMainFrame) return;
    if (errorCode === -3) return;
    if (!validatedURL || /^(file|data|about):/i.test(validatedURL)) return;
    tab.loading = false;
    tab.error = {
      url: validatedURL,
      code: errorCode,
      description: sanitizeText(errorDescription, 160) || 'No se pudo cargar la página',
    };
    loadErrorPage(tab, tab.error);
    scheduleBroadcast();
  });

  wc.on('page-title-updated', (event, title) => {
    event.preventDefault();
    tab.title = sanitizeText(title, 160);
    updateWindowTitle();
    scheduleBroadcast();
  });

  wc.on('page-favicon-updated', (event, favicons) => {
    const found = (Array.isArray(favicons) ? favicons : []).find(isSafeFavicon);
    if (found) {
      tab.favicon = found;
      scheduleBroadcast();
    }
  });

  wc.on('context-menu', (event, params) => {
    if (!win || win.isDestroyed()) return;
    buildContextMenu(tab, params).popup({ window: win });
  });

  wc.on('before-input-event', (event, input) => {
    if (handleShortcut(tab, input)) event.preventDefault();
  });

  wc.on('enter-html-full-screen', () => {
    fullscreen = true;
    if (win && !win.isDestroyed()) win.setFullScreen(true);
    layout();
    sendEvent({ type: 'fullscreen', active: true });
  });

  wc.on('leave-html-full-screen', () => {
    fullscreen = false;
    if (win && !win.isDestroyed()) win.setFullScreen(false);
    layout();
    sendEvent({ type: 'fullscreen', active: false });
  });

  wc.on('found-in-page', (event, result) => {
    if (!findSession || tab.id !== findSession.tabId || findSession.source === 'dom') return;
    if (findSession.requestId && result.requestId !== findSession.requestId) return;
    findSession.source = 'native';
    if (findSession.timer) {
      clearTimeout(findSession.timer);
      findSession.timer = null;
    }
    sendEvent({
      type: 'find-result',
      matches: result.matches || 0,
      activeMatchOrdinal: result.activeMatchOrdinal || 0,
      finalUpdate: Boolean(result.finalUpdate),
    });
  });

  wc.on('render-process-gone', () => {
    showNotice('La página dejó de responder. Puedes recargarla con Ctrl+R.', 'warn');
  });
}

function sanitizeDownloadName(name) {
  const base = path.basename(String(name || 'descarga').trim() || 'descarga');
  const clean = base.replace(/[<>:"/\\|?*\u0000-\u001f]/g, '_').replace(/\.+$/, '').slice(0, 140);
  return clean || 'descarga';
}

function uniqueDownloadPath(filename) {
  fs.mkdirSync(downloadsDir, { recursive: true });
  const parsed = path.parse(filename);
  let candidate = path.join(downloadsDir, filename);
  let index = 1;
  while (fs.existsSync(candidate)) {
    candidate = path.join(downloadsDir, `${parsed.name} (${index})${parsed.ext}`);
    index += 1;
    if (index > 999) break;
  }
  return candidate;
}

function setupDownloads(ses) {
  fs.mkdirSync(downloadsDir, { recursive: true });
  ses.on('will-download', (event, item) => {
    const id = `download-${++downloadSeq}`;
    let savePath;
    try {
      savePath = uniqueDownloadPath(sanitizeDownloadName(item.getFilename()));
      item.setSavePath(savePath);
    } catch {
      item.cancel();
      showNotice('No se pudo preparar la carpeta de descargas.', 'warn');
      return;
    }
    const record = {
      id,
      filename: path.basename(savePath),
      path: savePath,
      state: 'progressing',
      receivedBytes: 0,
      totalBytes: item.getTotalBytes(),
    };
    downloads.set(id, record);
    if (downloads.size > 50) {
      const oldest = downloads.keys().next().value;
      if (oldest !== id) downloads.delete(oldest);
    }
    scheduleBroadcast();
    item.on('updated', () => {
      record.receivedBytes = item.getReceivedBytes();
      record.totalBytes = item.getTotalBytes();
      scheduleBroadcast();
    });
    item.once('done', (doneEvent, state) => {
      record.state = state;
      record.receivedBytes = item.getReceivedBytes();
      record.totalBytes = item.getTotalBytes();
      if (state === 'completed') {
        showNotice(`Descarga completada: ${record.filename}`, 'info');
      } else if (state === 'interrupted') {
        showNotice(`La descarga se interrumpió: ${record.filename}`, 'warn');
      }
      scheduleBroadcast();
    });
  });
}

function setupPermissions(ses) {
  ses.setPermissionRequestHandler(async (wc, permission, callback) => {
    const done = typeof callback === 'function' ? callback : () => {};
    if (PERMISSION_ALLOWED.has(permission)) {
      done(true);
      return;
    }
    if (!PERMISSION_PROMPTED.has(permission)) {
      done(false);
      return;
    }
    let origin = '';
    try {
      const target = new URL(wc.getURL());
      if (target.protocol !== 'http:' && target.protocol !== 'https:') {
        done(false);
        return;
      }
      origin = target.origin;
    } catch {
      done(false);
      return;
    }
    const key = `${origin}|${permission}`;
    if (decisions.has(key)) {
      done(decisions.get(key));
      return;
    }
    try {
      const labels = {
        media: 'usar la cámara o el micrófono',
        geolocation: 'conocer tu ubicación',
        notifications: 'mostrar notificaciones',
        'clipboard-read': 'leer el portapapeles',
        'display-capture': 'capturar la pantalla',
        midi: 'usar dispositivos MIDI',
        midiSysex: 'usar dispositivos MIDI',
      };
      const { response } = await dialog.showMessageBox(win, {
        type: 'question',
        buttons: ['Permitir', 'Bloquear'],
        defaultId: 1,
        cancelId: 1,
        title: 'Permiso del sitio',
        message: `${origin} quiere ${labels[permission] || permission}.`,
        detail: 'Este permiso se recordará solo durante esta sesión del navegador.',
        noLink: true,
      });
      const granted = response === 0;
      decisions.set(key, granted);
      done(granted);
    } catch {
      done(false);
    }
  });
  ses.setPermissionCheckHandler((wc, permission, requestingOrigin) => {
    if (PERMISSION_ALLOWED.has(permission)) return true;
    const key = `${requestingOrigin}|${permission}`;
    return decisions.get(key) === true;
  });
  ses.setDevicePermissionHandler(() => false);
  ses.setBluetoothPairingHandler((details, callback) => callback({ confirmed: false }));
  ses.webRequest.onHeadersReceived((details, callback) => {
    callback({
      responseHeaders: {
        ...details.responseHeaders,
        'X-Content-Type-Options': ['nosniff'],
      },
    });
  });
}

function setupIpc() {
  const fromShell = (event) => Boolean(win && !win.isDestroyed() && event.sender === win.webContents);

  const handle = (channel, handler) => {
    ipcMain.handle(`browser:${channel}`, async (event, payload) => {
      if (!fromShell(event)) throw new Error('Origen no permitido.');
      return handler(payload);
    });
  };

  handle('get-state', () => publicState());

  handle('navigate', (input) => {
    const tab = activeTab();
    if (!tab || typeof input !== 'string') return null;
    loadTarget(tab, input.slice(0, 4096));
    return null;
  });

  handle('back', () => {
    const tab = activeTab();
    if (tab && tab.canGoBack) tab.view.webContents.navigationHistory.goBack();
    return null;
  });

  handle('forward', () => {
    const tab = activeTab();
    if (tab && tab.canGoForward) tab.view.webContents.navigationHistory.goForward();
    return null;
  });

  handle('reload', () => {
    const tab = activeTab();
    if (!tab) return null;
    if (tab.error) tab.view.webContents.loadURL(tab.error.url).catch(() => {});
    else tab.view.webContents.reload();
    return null;
  });

  handle('stop', () => {
    const tab = activeTab();
    if (tab) tab.view.webContents.stop();
    return null;
  });

  handle('home', () => {
    const tab = activeTab();
    if (tab) loadHome(tab);
    return null;
  });

  handle('new-tab', (payload) => {
    const input = payload && typeof payload === 'object' ? payload.url : '';
    const tab = createTab({ url: typeof input === 'string' ? input.slice(0, 4096) : '' });
    return tab ? tab.id : null;
  });

  handle('close-tab', (payload) => {
    const id = payload && typeof payload === 'object' ? String(payload.id || '') : '';
    if (/^tab-\d{1,6}$/.test(id)) closeTab(id);
    return null;
  });

  handle('select-tab', (payload) => {
    const id = payload && typeof payload === 'object' ? String(payload.id || '') : '';
    if (/^tab-\d{1,6}$/.test(id) && tabs.has(id)) activateTab(id);
    return null;
  });

  handle('find-open', () => {
    setFindOpen(true);
    return null;
  });

  handle('find', (payload) => {
    const tab = activeTab();
    const data = payload && typeof payload === 'object' ? payload : {};
    if (!tab) return null;
    setFindOpen(true);
    const text = typeof data.text === 'string' ? data.text.slice(0, 200) : '';
    if (!text) {
      stopFind();
      return null;
    }
    if (findSession && findSession.timer) clearTimeout(findSession.timer);
    const forward = data.forward !== false;
    const restart = data.findNext !== true;
    const session = {
      tabId: tab.id,
      query: text,
      forward,
      restart,
      requestId: 0,
      source: null,
      timer: null,
    };
    findSession = session;
    try {
      tab.view.webContents.focus();
    } catch {
      // La vista puede estar cargando.
    }
    try {
      session.requestId = tab.view.webContents.findInPage(text, {
        forward,
        findNext: !restart,
        matchCase: false,
      });
    } catch {
      // El fallback busca en el DOM si el motor nativo no responde.
    }
    if (session.source !== 'native') {
      session.timer = setTimeout(() => runDomFind(tab, session), FIND_FALLBACK_DELAY);
    }
    return null;
  });

  handle('find-stop', () => {
    stopFind();
    return null;
  });

  handle('find-close', () => {
    setFindOpen(false);
    stopFind();
    return null;
  });

  handle('zoom', (payload) => {
    const direction = payload && typeof payload === 'object' ? Number(payload.direction) : 0;
    adjustZoom(direction > 0 ? 1 : direction < 0 ? -1 : 0);
    return null;
  });

  handle('open-downloads', async () => {
    fs.mkdirSync(downloadsDir, { recursive: true });
    const error = await shell.openPath(downloadsDir);
    if (error) showNotice('No se pudo abrir la carpeta de descargas.', 'warn');
    return null;
  });

  handle('open-download', async (payload) => {
    const id = payload && typeof payload === 'object' ? String(payload.id || '') : '';
    const item = downloads.get(id);
    if (!item || !item.path) return null;
    const relative = path.relative(downloadsDir, item.path);
    if (relative.startsWith('..') || path.isAbsolute(relative)) return null;
    const error = await shell.openPath(item.path);
    if (error) showNotice('El archivo ya no está disponible.', 'warn');
    return null;
  });
}

function removeIpc() {
  const channels = [
    'get-state', 'navigate', 'back', 'forward', 'reload', 'stop', 'home', 'new-tab',
    'close-tab', 'select-tab', 'find-open', 'find', 'find-stop', 'find-close', 'zoom',
    'open-downloads', 'open-download',
  ];
  for (const channel of channels) ipcMain.removeHandler(`browser:${channel}`);
}

async function licenseAllowsBrowser(appDataDir) {
  const enforced = app.isPackaged || process.env.PERFILLAB_REQUIRE_LICENSE === '1';
  if (!enforced) return { allowed: true, status: null };
  let license = null;
  try {
    license = new LicenseService({ filePath: path.join(appDataDir, 'license.json'), enforced: true });
  } catch {
    return { allowed: false, status: null };
  }
  return { allowed: license.isActive(), status: license.publicStatus() };
}

async function startBrowserMode(options) {
  args = options.args;
  version = options.version || app.getVersion();
  downloadsDir = args.downloadsDir || path.join(args.dataDir, 'downloads');
  if (!args.downloadsDir) fs.mkdirSync(downloadsDir, { recursive: true });
  homeHref = pathToFileURL(HOME_HTML).href;
  errorHref = pathToFileURL(ERROR_HTML).href;

  app.setName('PerfilLab Browser');
  app.userAgentFallback = `Mozilla/5.0 (${platformToken()}) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/${process.versions.chrome} Safari/537.36 PerfilLab/${version}`;

  const ses = session.defaultSession;
  ses.setUserAgent(app.userAgentFallback);
  setupPermissions(ses);
  setupDownloads(ses);
  setupIpc();

  win = new BrowserWindow({
    width: 1280,
    height: 840,
    minWidth: 940,
    minHeight: 560,
    show: false,
    backgroundColor: '#080c16',
    title: 'PerfilLab Browser',
    icon: fs.existsSync(ICON) ? ICON : undefined,
    titleBarStyle: 'hidden',
    ...(process.platform === 'win32'
      ? {
          titleBarOverlay: {
            color: '#080c16',
            symbolColor: '#dbe4f8',
            height: 44,
          },
        }
      : {}),
    webPreferences: {
      preload: SHELL_PRELOAD,
      contextIsolation: true,
      sandbox: true,
      nodeIntegration: false,
      spellcheck: false,
    },
  });
  win.setMenuBarVisibility(false);
  win.on('resize', layout);
  win.on('maximize', layout);
  win.on('unmaximize', layout);
  win.on('enter-full-screen', layout);
  win.on('leave-full-screen', layout);
  win.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));
  win.webContents.on('will-navigate', (event) => {
    event.preventDefault();
  });

  const access = await licenseAllowsBrowser(options.appDataDir);
  if (!access.allowed) {
    await win.loadFile(BLOCKED_HTML, {
      query: {
        message: sanitizeText(access.status && access.status.statusMessage, 180) || 'La licencia de PerfilLab no está activa.',
      },
    });
    win.show();
    win.on('closed', () => {
      win = null;
      removeIpc();
    });
    return;
  }

  win.on('closed', () => {
    if (noticeTimer) clearTimeout(noticeTimer);
    if (broadcastHandle) clearTimeout(broadcastHandle);
    for (const tab of tabs.values()) {
      try {
        tab.view.webContents.close();
      } catch {
        // Se cierra junto con la ventana.
      }
    }
    tabs = new Map();
    activeTabId = null;
    removeIpc();
    win = null;
  });

  await win.loadFile(SHELL_HTML);
  win.show();

  const startUrls = Array.isArray(args.startUrls) ? args.startUrls.filter(isHttpUrl).slice(0, 8) : [];
  if (startUrls.length) {
    startUrls.forEach((url, index) => {
      createTab({ url, activate: index === 0 });
    });
  } else {
    createTab({ url: '', activate: true });
  }
  layout();
}

module.exports = { startBrowserMode };
