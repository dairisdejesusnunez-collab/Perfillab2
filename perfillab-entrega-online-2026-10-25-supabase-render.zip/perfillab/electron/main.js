'use strict';

const fs = require('node:fs');
const path = require('node:path');
const {
  app,
  BrowserWindow,
  Tray,
  Menu,
  nativeImage,
  nativeTheme,
  dialog,
  ipcMain,
  session,
  shell,
  clipboard,
} = require('electron');

const { Store } = require('./store');
const { ProfileLauncher } = require('./launcher');
const { AppLauncher } = require('./app-launcher');
const { NativeCloneProvider } = require('./native-clone');
const { HyperVProvider } = require('./hyperv');
const { AppService } = require('./app-service');
const { LocalApiServer } = require('./api-server');
const { AppError, badRequest } = require('./errors');
const { encryptionAvailable } = require('./secrets');
const { LicenseService } = require('./license');
const { parseBrowserArgs } = require('./browser-launch');

const browserArgs = parseBrowserArgs(process.argv);
const IS_BROWSER_MODE = Boolean(browserArgs);
const DEFAULT_DATA_DIR = path.join(process.env.LOCALAPPDATA || app.getPath('appData'), 'PerfilLab');
const DATA_DIR = process.env.PERFILLAB_DATA_DIR ? path.resolve(process.env.PERFILLAB_DATA_DIR) : DEFAULT_DATA_DIR;
if (IS_BROWSER_MODE) {
  if (!browserArgs.dataDir) {
    dialog.showErrorBox('PerfilLab Browser', 'No se indicó una carpeta de datos válida para el perfil.');
    app.exit(1);
  }
  fs.mkdirSync(browserArgs.dataDir, { recursive: true });
  app.setPath('userData', browserArgs.dataDir);
  app.setPath('sessionData', browserArgs.dataDir);
} else {
  fs.mkdirSync(DATA_DIR, { recursive: true });
  app.setPath('userData', DATA_DIR);
}

const ASSETS = path.join(__dirname, '..', 'assets');
const RENDERER = path.join(__dirname, '..', 'renderer', 'index.html');
const LICENSE_RENDERER = path.join(__dirname, '..', 'renderer', 'license.html');
const APP_ID = 'com.perfillab.app';
const LICENSE_EXEMPT_ACTIONS = new Set([
  'license:info',
  'license:activate',
  'license:activate-key',
  'license:import',
  'license:refresh',
  'license:ping',
  'license:launch',
  'app:copy',
  'app:quit',
]);
const LICENSE_SYNC_INTERVAL_MS = 15 * 60 * 1000;

let mainWindow = null;
let tray = null;
let trayMenuTimer = null;
let isQuitting = false;
let quitPromptOpen = false;
let service = null;
let apiServer = null;
let store = null;
let launcher = null;
let appLauncher = null;
let licenseService = null;
let licenseWasActive = false;
let licenseWatchTimer = null;

app.setAppUserModelId(IS_BROWSER_MODE ? 'com.perfillab.browser' : APP_ID);

if (!app.isPackaged && process.env.PERFILLAB_DEBUG_PORT) {
  app.commandLine.appendSwitch('remote-debugging-port', process.env.PERFILLAB_DEBUG_PORT);
}

function broadcastState(state) {
  for (const win of BrowserWindow.getAllWindows()) {
    if (!win.isDestroyed()) win.webContents.send('perfillab:event', state);
  }
}

function currentSettings() {
  return service.state.settings;
}

function applyTheme() {
  nativeTheme.themeSource = currentSettings().theme;
  if (process.platform === 'win32' && mainWindow && !mainWindow.isDestroyed()) {
    const dark = licensePageRequired() || nativeTheme.shouldUseDarkColors;
    mainWindow.setTitleBarOverlay({
      color: dark ? '#0a0e17' : '#f7f9fd',
      symbolColor: dark ? '#dfe7f8' : '#25324a',
      height: 70,
    });
  }
}

function licensePageRequired() {
  return Boolean(licenseService && !licenseService.isActive());
}

function showWindow() {
  if (!mainWindow || mainWindow.isDestroyed()) {
    createWindow();
    return;
  }
  if (mainWindow.isMinimized()) mainWindow.restore();
  mainWindow.show();
  mainWindow.focus();
}

function createWindow() {
  const overlayOptions = process.platform === 'win32'
    ? {
      titleBarStyle: 'hidden',
      titleBarOverlay: {
        color: '#0a0e17',
        symbolColor: '#dfe7f8',
        height: 70,
      },
    }
    : process.platform === 'darwin'
      ? { titleBarStyle: 'hiddenInset' }
      : {};

  mainWindow = new BrowserWindow({
    width: 1360,
    height: 860,
    minWidth: 1040,
    minHeight: 680,
    show: false,
    backgroundColor: '#0a0e17',
    title: licensePageRequired() ? 'PerfilLab · Activación' : 'PerfilLab',
    icon: path.join(ASSETS, 'icon.png'),
    autoHideMenuBar: true,
    ...overlayOptions,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      sandbox: true,
      nodeIntegration: false,
      webSecurity: true,
      spellcheck: false,
      devTools: !app.isPackaged && process.env.PERFILLAB_DEV === '1',
    },
  });

  mainWindow.loadFile(licensePageRequired() ? LICENSE_RENDERER : RENDERER);
  mainWindow.once('ready-to-show', () => {
    mainWindow.show();
  });

  mainWindow.on('close', (event) => {
    if (isQuitting) return;
    if (currentSettings().closeToTray) {
      event.preventDefault();
      mainWindow.hide();
    }
  });

  mainWindow.on('closed', () => {
    mainWindow = null;
  });

  mainWindow.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));
  mainWindow.webContents.on('will-navigate', (event) => {
    event.preventDefault();
  });
  mainWindow.webContents.on('will-attach-webview', (event) => {
    event.preventDefault();
  });
  mainWindow.webContents.on('render-process-gone', (_event, details) => {
    console.error('[renderer]', details.reason);
  });
  mainWindow.webContents.on('console-message', (...args) => {
    const details = args[1] && typeof args[1] === 'object' ? args[1] : null;
    const message = details ? details.message : args[2];
    const level = details ? details.level : args[1];
    console.log(`[renderer:${level}] ${message}`);
  });
}

function buildTrayMenu() {
  if (!tray) return;
  if (licensePageRequired()) {
    tray.setContextMenu(Menu.buildFromTemplate([
      { label: 'Activar PerfilLab', click: showWindow },
      { type: 'separator' },
      { label: 'Salir', click: () => requestQuit() },
    ]));
    return;
  }
  const state = service.getPublicState();
  const runningIds = new Set(state.statuses.map((item) => item.profileId));
  const profileItems = state.profiles.slice(0, 30).map((profile) => ({
    label: `${runningIds.has(profile.id) ? '● ' : ''}${profile.name}`,
    enabled: !runningIds.has(profile.id),
    click: async () => {
      try {
        await service.startProfile(profile.id);
      } catch (error) {
        dialog.showErrorBox('No se pudo iniciar el perfil', error.message);
      }
    },
  }));

  tray.setContextMenu(Menu.buildFromTemplate([
    { label: 'Abrir PerfilLab', click: showWindow },
    { type: 'separator' },
    {
      label: 'Iniciar perfil',
      enabled: profileItems.length > 0,
      submenu: profileItems.length ? profileItems : [{ label: 'No hay perfiles', enabled: false }],
    },
    {
      label: `Detener todos (${state.statuses.length})`,
      enabled: state.statuses.length > 0,
      click: async () => {
        for (const status of service.launcher.listRunning()) {
          try {
            await service.stopProfile(status.profileId);
          } catch {
            // continue stopping the rest
          }
        }
      },
    },
    { type: 'separator' },
    {
      label: state.settings.api.running
        ? `API local: 127.0.0.1:${state.settings.api.port}`
        : 'API local desactivada',
      enabled: false,
    },
    { label: 'Salir', click: () => requestQuit() },
  ]));
}

function scheduleTrayMenu() {
  if (trayMenuTimer) clearTimeout(trayMenuTimer);
  trayMenuTimer = setTimeout(() => {
    trayMenuTimer = null;
    buildTrayMenu();
  }, 250);
}

function createTray() {
  const icon = nativeImage.createFromPath(path.join(ASSETS, 'tray.png'));
  tray = new Tray(icon.isEmpty() ? nativeImage.createFromPath(path.join(ASSETS, 'icon.png')).resize({ width: 16, height: 16 }) : icon);
  tray.setToolTip('PerfilLab');
  tray.on('click', showWindow);
  tray.on('double-click', showWindow);
  buildTrayMenu();
}

async function requestQuit() {
  if (quitPromptOpen) return;
  const browsersRunning = service.launcher.listRunning().length;
  const appRunning = appLauncher ? appLauncher.listRunning() : [];
  const vmRunning = appRunning.filter((item) => item.isolation === 'vm').length;
  const appsRunning = appRunning.length - vmRunning;
  if (browsersRunning || appRunning.length) {
    quitPromptOpen = true;
    const details = [];
    if (browsersRunning) details.push(`${browsersRunning} navegador(es) de perfiles`);
    if (appsRunning) details.push(`${appsRunning} aplicación(es) supervisada(s)`);
    if (vmRunning) details.push(`${vmRunning} máquina(s) virtual(es)`);
    const { response } = await dialog.showMessageBox(mainWindow && !mainWindow.isDestroyed() ? mainWindow : null, {
      type: 'warning',
      title: 'Sesiones en ejecución',
      message: 'PerfilLab tiene sesiones abiertas.',
      detail: `Se cerrarán ${details.join(' y ')} antes de salir. Las máquinas virtuales se guardarán apagadas. Las aplicaciones abiertas desde el menú Inicio de Windows no se pueden cerrar desde aquí.`,
      buttons: ['Cancelar', 'Detener y salir'],
      defaultId: 0,
      cancelId: 0,
      noLink: true,
    });
    quitPromptOpen = false;
    if (response !== 1) return;
  }
  isQuitting = true;
  if (appLauncher && vmRunning) {
    try {
      await appLauncher.stopAllVms();
    } catch (error) {
      const { response } = await dialog.showMessageBox(mainWindow && !mainWindow.isDestroyed() ? mainWindow : null, {
        type: 'error',
        title: 'Máquinas virtuales encendidas',
        message: 'No se pudieron detener las máquinas virtuales.',
        detail: `${error.message}\n\nSi sales de PerfilLab ahora, las máquinas virtuales seguirán encendidas hasta que las apagues desde Hyper-V.`,
        buttons: ['Cancelar', 'Salir de todos modos'],
        defaultId: 0,
        cancelId: 0,
        noLink: true,
      });
      if (response !== 1) {
        isQuitting = false;
        return;
      }
    }
  }
  appLauncher?.stopAllSync();
  app.quit();
}

function formatDateForFile(date = new Date()) {
  const pad = (value) => String(value).padStart(2, '0');
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}-${pad(date.getHours())}${pad(date.getMinutes())}`;
}

async function pickImportFile(parent, format = 'json') {
  const isCsv = format === 'csv';
  const { canceled, filePaths } = await dialog.showOpenDialog(parent, {
    title: isCsv ? 'Importar perfiles desde CSV' : 'Importar perfiles',
    properties: ['openFile'],
    filters: isCsv
      ? [
        { name: 'Hoja de cálculo CSV', extensions: ['csv'] },
        { name: 'Todos los archivos', extensions: ['*'] },
      ]
      : [{ name: 'Exportación de PerfilLab', extensions: ['json'] }],
  });
  if (canceled || !filePaths[0]) return { canceled: true };
  const file = filePaths[0];
  const stat = fs.statSync(file);
  const maxBytes = isCsv ? 5 * 1024 * 1024 : 10 * 1024 * 1024;
  if (stat.size > maxBytes) throw badRequest(`El archivo supera los ${isCsv ? 5 : 10} MB.`);
  if (isCsv) {
    const result = service.importCsv(fs.readFileSync(file, 'utf8'));
    return { canceled: false, file, format: 'csv', ...result };
  }
  let parsed;
  try {
    parsed = JSON.parse(fs.readFileSync(file, 'utf8'));
  } catch (error) {
    throw badRequest(`No se pudo leer el archivo JSON: ${error.message}`);
  }
  const result = service.importData(parsed);
  service.addActivity('success', `Importados ${result.profiles} perfil(es) desde ${path.basename(file)}.`);
  service.saveAndEmit();
  return { canceled: false, file, format: 'json', ...result };
}

async function saveExportFile(parent, payload) {
  const format = payload && payload.format === 'csv' ? 'csv' : 'json';
  const profileIds = payload && payload.profileIds ? payload.profileIds : null;
  if (format === 'csv') {
    const content = service.buildCsv(profileIds);
    const { canceled, filePath } = await dialog.showSaveDialog(parent, {
      title: 'Exportar perfiles a CSV',
      defaultPath: path.join(app.getPath('documents'), `perfillab-${formatDateForFile()}.csv`),
      filters: [{ name: 'Hoja de cálculo CSV', extensions: ['csv'] }],
    });
    if (canceled || !filePath) return { canceled: true };
    fs.writeFileSync(filePath, content, 'utf8');
    const ids = Array.isArray(profileIds) && profileIds.length ? profileIds : null;
    const count = ids ? service.state.profiles.filter((profile) => ids.includes(profile.id)).length : service.state.profiles.length;
    service.addActivity('success', `Exportados ${count} perfil(es) a ${path.basename(filePath)} (CSV).`);
    service.saveAndEmit();
    return { canceled: false, path: filePath, profiles: count, format };
  }
  const exportData = service.buildExport(profileIds);
  const { canceled, filePath } = await dialog.showSaveDialog(parent, {
    title: 'Exportar perfiles',
    defaultPath: path.join(app.getPath('documents'), `perfillab-${formatDateForFile()}.json`),
    filters: [{ name: 'JSON', extensions: ['json'] }],
  });
  if (canceled || !filePath) return { canceled: true };
  fs.writeFileSync(filePath, `${JSON.stringify(exportData, null, 2)}\n`, 'utf8');
  service.addActivity('success', `Exportados ${exportData.profiles.length} perfil(es) a ${path.basename(filePath)}.`);
  service.saveAndEmit();
  return { canceled: false, path: filePath, profiles: exportData.profiles.length, format };
}

async function pickApplicationExecutable(parent) {
  const filters = process.platform === 'win32'
    ? [{ name: 'Aplicaciones de Windows', extensions: ['exe'] }]
    : [{ name: 'Todos los archivos', extensions: ['*'] }];
  const { canceled, filePaths } = await dialog.showOpenDialog(parent, {
    title: 'Agregar una aplicación .exe a PerfilLab',
    properties: ['openFile'],
    filters,
  });
  if (canceled || !filePaths[0]) return { canceled: true };
  const app = service.addExecutableApp(filePaths[0]);
  return { canceled: false, app };
}

async function pickVmBaseImage(parent) {
  if (process.platform !== 'win32') {
    throw badRequest('Las máquinas virtuales solo están disponibles en Windows.');
  }
  const { canceled, filePaths } = await dialog.showOpenDialog(parent, {
    title: 'Seleccionar imagen base de Hyper-V (.vhdx)',
    properties: ['openFile'],
    filters: [{ name: 'Disco virtual de Hyper-V', extensions: ['vhdx'] }],
  });
  if (canceled || !filePaths[0]) return { canceled: true };
  const file = filePaths[0];
  let stat;
  try {
    stat = fs.statSync(file);
  } catch {
    throw badRequest('No se encontró la imagen base seleccionada.');
  }
  if (!stat.isFile()) throw badRequest('La imagen base debe ser un archivo .vhdx.');
  return {
    canceled: false,
    path: file,
    sizeGb: Math.round((stat.size / (1024 ** 3)) * 10) / 10,
  };
}

async function activateLicenseFromPayload(payload) {
  if (!payload || typeof payload !== 'object' || Array.isArray(payload)) {
    throw badRequest('Escribe la clave de licencia o carga el archivo.');
  }
  const hasKey = Object.prototype.hasOwnProperty.call(payload, 'licenseKey');
  const input = Object.prototype.hasOwnProperty.call(payload, 'text') ? payload.text : payload.license;
  if (!hasKey && (input === undefined || input === null)) {
    throw badRequest('Escribe la clave de licencia o carga el archivo.');
  }
  const wasLicensed = licenseService.licensed();
  const status = hasKey
    ? await licenseService.activateOnline({
      licenseKey: payload.licenseKey,
      serverUrl: payload.serverUrl,
      machineName: payload.machineName,
    })
    : licenseService.activateFile(input);
  if (!wasLicensed && status.licensed) {
    service.addActivity('success', `Licencia ${status.licenseId} activada (${status.customer}).`);
    service.saveAndEmit();
  }
  licenseWasActive = licenseService.isActive();
  scheduleTrayMenu();
  return status;
}

async function importLicenseFile(parent) {
  const { canceled, filePaths } = await dialog.showOpenDialog(parent, {
    title: 'Seleccionar licencia de PerfilLab',
    properties: ['openFile'],
    filters: [
      { name: 'Licencia de PerfilLab', extensions: ['perfillab-license', 'json'] },
      { name: 'Todos los archivos', extensions: ['*'] },
    ],
  });
  if (canceled || !filePaths[0]) return { canceled: true };
  const file = filePaths[0];
  const stat = fs.statSync(file);
  if (stat.size > 128 * 1024) throw badRequest('El archivo de licencia es demasiado grande.');
  let text;
  try {
    text = fs.readFileSync(file, 'utf8');
  } catch (error) {
    throw badRequest(`No se pudo leer la licencia: ${error.message}`);
  }
  const status = await activateLicenseFromPayload({ text });
  return { canceled: false, path: file, ...status };
}

async function openLicensedApp() {
  if (!licenseService.isActive()) {
    throw new AppError('Se requiere una licencia válida para usar PerfilLab.', 403, 'license_required');
  }
  await apiServer.apply();
  licenseWasActive = true;
  if (!mainWindow || mainWindow.isDestroyed()) {
    createWindow();
  } else {
    await mainWindow.loadFile(RENDERER);
  }
  applyTheme();
  buildTrayMenu();
  service.emitState();
  syncLicense({ force: true }).catch((error) => console.error('[license]', error.message));
  return { launched: true };
}

async function handleLicenseLost() {
  if (!licenseService.enforced || licenseService.isActive()) return;
  try {
    await apiServer.close();
  } catch {
    // the app is already locked even if the listener could not be closed cleanly
  }
  for (const running of launcher.listRunning()) {
    try {
      await service.stopProfile(running.profileId);
    } catch {
      // continue stopping the remaining sessions
    }
  }
  if (appLauncher) {
    try {
      await appLauncher.stopAllVms();
    } catch {
      // La licencia se bloquea aunque alguna máquina virtual no se haya podido detener.
    }
    appLauncher.stopAllSync();
  }
  service.addActivity('warn', 'La licencia ya no es válida. Se cerraron las sesiones y la API local.');
  service.saveAndEmit();
  if (mainWindow && !mainWindow.isDestroyed()) {
    await mainWindow.loadFile(LICENSE_RENDERER);
  }
  applyTheme();
  buildTrayMenu();
}

let licenseSyncRunning = false;
let lastLicenseSyncAt = 0;

async function syncLicense({ force = false } = {}) {
  if (licenseSyncRunning || !licenseService) return null;
  if (!licenseService.hasLicense()) return null;
  if (!force && Date.now() - lastLicenseSyncAt < LICENSE_SYNC_INTERVAL_MS) return null;
  licenseSyncRunning = true;
  try {
    const result = await licenseService.sync();
    lastLicenseSyncAt = Date.now();
    const active = licenseService.isActive();
    if (licenseWasActive && !active) await handleLicenseLost();
    licenseWasActive = active;
    if (mainWindow && !mainWindow.isDestroyed() && !licensePageRequired()) {
      buildTrayMenu();
    }
    return result;
  } finally {
    licenseSyncRunning = false;
  }
}

function startLicenseWatch() {
  licenseWasActive = licenseService.isActive();
  licenseWatchTimer = setInterval(async () => {
    const active = licenseService.isActive();
    if (licenseWasActive && !active) await handleLicenseLost();
    licenseWasActive = active;
    if (licenseService.payload) await syncLicense();
  }, 60000);
  licenseWatchTimer.unref();
  if (licenseService.hasLicense()) {
    setTimeout(() => {
      syncLicense({ force: true }).catch((error) => console.error('[license]', error.message));
    }, 4000).unref();
  }
}

function buildActions() {
  return {
    'license:info': () => licenseService.publicStatus(),
    'license:activate': (payload) => activateLicenseFromPayload(payload || {}),
    'license:activate-key': (payload) => activateLicenseFromPayload({
      licenseKey: (payload || {}).licenseKey,
      serverUrl: (payload || {}).serverUrl,
      machineName: (payload || {}).machineName,
    }),
    'license:import': (payload, event) => importLicenseFile(BrowserWindow.fromWebContents(event.sender)),
    'license:refresh': async () => {
      const sync = await syncLicense({ force: true });
      return { ...licenseService.publicStatus(), sync };
    },
    'license:ping': (payload) => licenseService.ping(payload && payload.serverUrl),
    'license:launch': () => openLicensedApp(),
    'state:get': () => service.getPublicState(),
    'profile:create': (payload) => service.createProfile(payload || {}),
    'profile:update': (payload) => service.updateProfile(payload.id, payload.patch || {}),
    'profile:delete': (payload) => service.deleteProfile(payload.id, {
      deleteData: Boolean(payload.deleteData),
      releaseCloneAccount: Boolean(payload.releaseCloneAccount),
      removeVirtualMachine: Boolean(payload.removeVirtualMachine),
    }),
    'profile:duplicate': (payload) => service.duplicateProfile(payload.id),
    'profile:start': (payload) => service.startProfile(payload.id),
    'profile:stop': (payload) => service.stopProfile(payload.id),
    'profile:batch': (payload) => service.batchProfiles(payload || {}),
    'profile:folder': (payload) => service.openProfileFolder(payload.id),
    'apps:discover': (payload) => service.discoverApps(Boolean(payload.force)),
    'apps:add': (payload) => service.addDiscoveredApp(payload.target),
    'apps:add-exe': (payload, event) => pickApplicationExecutable(BrowserWindow.fromWebContents(event.sender)),
    'apps:update': (payload) => service.updateApp(payload.id, payload.patch || {}),
    'apps:favorite': (payload) => service.toggleAppFavorite(payload.id),
    'apps:delete': (payload) => service.deleteApp(payload.id),
    'apps:launch': (payload) => service.launchApp(payload.profileId, payload.appId, payload.options || {}),
    'apps:stop': (payload) => service.stopApp(payload.instanceId),
    'clone:status': (payload) => service.refreshCloneCapabilities(Boolean(payload && payload.force)),
    'clone:prepare': (payload) => service.prepareCloneAccount(payload.profileId),
    'clone:verify': (payload) => service.verifyCloneAccount(payload.profileId),
    'clone:release': (payload) => service.releaseCloneAccount(payload.profileId),
    'vm:status': (payload) => service.refreshVmCapabilities(Boolean(payload && payload.force)),
    'vm:switches': () => service.listVmSwitches(),
    'vm:pick-base': (payload, event) => pickVmBaseImage(BrowserWindow.fromWebContents(event.sender)),
    'vm:prepare': (payload) => service.prepareVm(payload.profileId),
    'vm:start': (payload) => service.startVm(payload.profileId),
    'vm:stop': (payload) => service.stopVm(payload.profileId),
    'vm:remove': (payload) => service.removeVm(payload.profileId),
    'apps:folder': async (payload) => {
      const result = service.openAppFolder(payload.profileId, payload.appId);
      const error = await shell.openPath(result.path);
      if (error) throw new AppError(`No se pudo abrir la carpeta: ${error}`, 500, 'open_folder_error');
      return result;
    },
    'proxy:create': (payload) => service.createProxy(payload || {}),
    'proxy:update': (payload) => service.updateProxy(payload.id, payload.patch || {}),
    'proxy:delete': (payload) => service.deleteProxy(payload.id),
    'proxy:test': (payload) => service.testProxyConnection(payload || {}),
    'proxy:test-many': (payload) => service.testProxies(payload || {}),
    'workspace:create': (payload) => service.createWorkspace(payload || {}),
    'workspace:update': (payload) => service.updateWorkspace(payload.id, payload.patch || {}),
    'workspace:delete': (payload) => service.deleteWorkspace(payload.id),
    'status:create': (payload) => service.createStatus(payload || {}),
    'status:update': (payload) => service.updateStatus(payload.id, payload.patch || {}),
    'status:delete': (payload) => service.deleteStatus(payload.id),
    'settings:update': async (payload) => {
      const settings = service.updateSettings(payload || {});
      await apiServer.apply();
      service.emitState();
      return settings;
    },
    'api:regenerate': () => {
      const result = service.regenerateApiToken();
      return result;
    },
    'activity:clear': () => service.clearActivity(),
    'profiles:dir:open': async () => {
      const dir = service.openProfilesDir();
      const error = await shell.openPath(dir);
      if (error) throw new AppError(`No se pudo abrir la carpeta: ${error}`, 500, 'open_folder_error');
      return { path: dir };
    },
    'data:import': (payload, event) => pickImportFile(
      BrowserWindow.fromWebContents(event.sender),
      payload && payload.format === 'csv' ? 'csv' : 'json',
    ),
    'data:export': (payload, event) => saveExportFile(BrowserWindow.fromWebContents(event.sender), payload || {}),
    'app:quit': () => requestQuit(),
    'app:data-dir': () => ({ path: DATA_DIR }),
    'app:copy': (payload) => {
      clipboard.writeText(String(payload.text || '').slice(0, 8192));
      return { copied: true };
    },
  };
}

function registerIpc() {
  const actions = buildActions();
  ipcMain.handle('perfillab:action', async (event, name, payload) => {
    try {
      if (!mainWindow || mainWindow.isDestroyed() || event.sender !== mainWindow.webContents) {
        throw badRequest('Origen no permitido.');
      }
      if (typeof name !== 'string' || !Object.prototype.hasOwnProperty.call(actions, name)) {
        throw badRequest('Acción no permitida.');
      }
      if (!licenseService.isActive() && !LICENSE_EXEMPT_ACTIONS.has(name)) {
        throw new AppError('Activa una licencia para usar PerfilLab.', 403, 'license_required');
      }
      if (payload !== undefined && payload !== null && typeof payload !== 'object') {
        throw badRequest('Datos de acción no válidos.');
      }
      const data = await actions[name](payload, event);
      return { ok: true, data };
    } catch (error) {
      const status = error instanceof AppError ? error.status : 500;
      if (status >= 500) console.error('[action]', name, error);
      return {
        ok: false,
        error: {
          message: error && error.message ? error.message : 'Ocurrió un error inesperado.',
          code: error && error.code ? error.code : 'error',
          status,
        },
      };
    }
  });
}

function protectSession() {
  const ses = session.defaultSession;
  ses.setPermissionRequestHandler((_contents, _permission, callback) => callback(false));
  ses.setPermissionCheckHandler(() => false);
  ses.setDevicePermissionHandler(() => false);
  ses.setBluetoothPairingHandler((_details, callback) => callback({ confirmed: false }));
  ses.webRequest.onHeadersReceived((details, callback) => {
    callback({
      responseHeaders: {
        ...details.responseHeaders,
        'X-Content-Type-Options': ['nosniff'],
      },
    });
  });
}

function bootstrap() {
  licenseService = new LicenseService({
    filePath: path.join(DATA_DIR, 'license.json'),
    enforced: app.isPackaged || process.env.PERFILLAB_REQUIRE_LICENSE === '1',
  });

  store = new Store();
  store.load();
  launcher = new ProfileLauncher(store, {
    execPath: process.execPath,
    appPath: app.getAppPath(),
    packaged: app.isPackaged,
    appDataDir: DATA_DIR,
  });
  const nativeClone = new NativeCloneProvider({ baseDir: path.join(DATA_DIR, 'native-clone') });
  const hyperV = new HyperVProvider({ baseDir: path.join(DATA_DIR, 'hyperv-operations') });
  appLauncher = new AppLauncher(store, { nativeClone, hyperV });
  service = new AppService({ store, launcher, appLauncher, nativeClone, hyperV });
  apiServer = new LocalApiServer({
    service,
    licenseProvider: () => licenseService.publicStatus(),
  });
  service.setApiStatusProvider(() => apiServer.status());
  service.setLicenseStatusProvider(() => licenseService.publicStatus());

  applyTheme();
  protectSession();
  registerIpc();
  createWindow();
  applyTheme();
  createTray();
  startLicenseWatch();

  service.on('state', (state) => {
    broadcastState(state);
    scheduleTrayMenu();
  });

  if (licenseService.isActive()) {
    apiServer.apply().then(() => {
      service.emitState();
    });
  } else {
    service.emitState();
  }

  service.refreshCloneCapabilities().catch(() => {
    // El diagnóstico se muestra en Ajustes > Clonador nativo.
  });
  service.refreshVmCapabilities().catch(() => {
    // El diagnóstico se muestra en Ajustes > Máquinas virtuales.
  });

  if (!encryptionAvailable()) {
    service.addActivity('warn', 'El cifrado del sistema no está disponible; las contraseñas de proxy se guardan ofuscadas y el clonador nativo no podrá preparar cuentas hasta que Windows lo habilite.');
    service.saveAndEmit();
  }
}

if (IS_BROWSER_MODE) {
  app.whenReady()
    .then(async () => {
      const { startBrowserMode } = require('./browser-mode');
      await startBrowserMode({
        args: browserArgs,
        appDataDir: browserArgs.appDataDir || DATA_DIR,
        version: app.getVersion(),
      });
    })
    .catch((error) => {
      dialog.showErrorBox('PerfilLab Browser no pudo iniciar', error.stack || error.message);
      app.quit();
    });

  app.on('window-all-closed', () => {
    app.quit();
  });
} else {
  const gotLock = app.requestSingleInstanceLock();
  if (!gotLock) {
    app.quit();
  } else {
    app.on('second-instance', () => {
      showWindow();
    });

    app.whenReady().then(bootstrap).catch((error) => {
      dialog.showErrorBox('PerfilLab no pudo iniciar', error.stack || error.message);
      app.quit();
    });

    app.on('activate', () => {
      if (BrowserWindow.getAllWindows().length === 0) createWindow();
      else showWindow();
    });

    app.on('before-quit', () => {
      isQuitting = true;
    });

    app.on('will-quit', () => {
      if (licenseWatchTimer) clearInterval(licenseWatchTimer);
      if (launcher) launcher.stopAllSync();
      if (appLauncher) appLauncher.stopAllSync();
      if (apiServer) apiServer.close();
      if (tray) {
        tray.destroy();
        tray = null;
      }
    });

    app.on('window-all-closed', () => {
      if (process.platform !== 'darwin' && (!service || !currentSettings().closeToTray)) app.quit();
    });
  }
}
