'use strict';

const path = require('node:path');

const BUILTIN_BROWSER_ID = 'perfillab';
const BUILTIN_BROWSER_NAME = 'PerfilLab Browser';
const BROWSER_FLAG = '--perfillab-browser';
const BROWSER_CHROME_HEIGHT = 96;
const SEARCH_URL = 'https://www.google.com/search?q=';
const FLAG = {
  profileId: '--perfillab-profile-id=',
  profileName: '--perfillab-profile-name=',
  browserData: '--perfillab-browser-data=',
  downloads: '--perfillab-downloads=',
  appData: '--perfillab-app-data=',
  proxyLabel: '--perfillab-proxy-label=',
};

function isHttpUrl(value) {
  try {
    const url = new URL(String(value));
    return url.protocol === 'http:' || url.protocol === 'https:';
  } catch {
    return false;
  }
}

function builtinBrowser({ chromiumVersion = process.versions.chrome } = {}) {
  return {
    id: BUILTIN_BROWSER_ID,
    name: BUILTIN_BROWSER_NAME,
    path: process.execPath,
    custom: false,
    builtin: true,
    engineVersion: String(chromiumVersion || ''),
  };
}

function decodeFlag(value) {
  try {
    return decodeURIComponent(value);
  } catch {
    return '';
  }
}

function readFlag(argv, prefix) {
  const entry = argv.find((arg) => typeof arg === 'string' && arg.startsWith(prefix));
  return entry ? entry.slice(prefix.length) : '';
}

function parseBrowserArgs(argv) {
  const list = Array.isArray(argv) ? argv : [];
  if (!list.includes(BROWSER_FLAG)) return null;
  const rawDataDir = readFlag(list, FLAG.browserData);
  const dataDir = rawDataDir && path.isAbsolute(rawDataDir) ? path.resolve(rawDataDir) : '';
  const rawDownloads = readFlag(list, FLAG.downloads);
  const downloadsDir = rawDownloads && path.isAbsolute(rawDownloads)
    ? path.resolve(rawDownloads)
    : (dataDir ? path.join(dataDir, 'downloads') : '');
  const rawAppData = readFlag(list, FLAG.appData);
  const profileName = decodeFlag(readFlag(list, FLAG.profileName))
    .replace(/[\u0000-\u001f\u007f]/g, ' ')
    .trim()
    .slice(0, 120) || 'Perfil';
  const proxyLabel = decodeFlag(readFlag(list, FLAG.proxyLabel)).slice(0, 80).trim() || 'Sin proxy';
  const startUrls = [];
  for (const arg of list) {
    if (typeof arg !== 'string' || arg.startsWith('-') || !isHttpUrl(arg)) continue;
    if (startUrls.includes(arg)) continue;
    startUrls.push(arg);
    if (startUrls.length === 8) break;
  }
  return {
    dataDir,
    downloadsDir,
    appDataDir: rawAppData && path.isAbsolute(rawAppData) ? path.resolve(rawAppData) : '',
    profileId: readFlag(list, FLAG.profileId).slice(0, 100),
    profileName,
    proxyLabel,
    startUrls,
  };
}

function buildBrowserArgs({
  profile,
  profileDir,
  appDataDir = '',
  proxyArgs = [],
  proxyLabel = '',
  startUrls = [],
  appPath = '',
  packaged = true,
}) {
  if (!profile || !profile.id) throw new Error('Falta el perfil para abrir el navegador.');
  if (!profileDir) throw new Error('Falta la carpeta de datos del perfil.');
  const dataDir = path.join(profileDir, 'browser');
  const downloadsDir = path.join(profileDir, 'downloads');
  const args = [];
  if (!packaged) {
    if (!appPath) throw new Error('Falta la ruta de la aplicación para abrir el navegador en desarrollo.');
    args.push(appPath);
  }
  args.push(
    BROWSER_FLAG,
    `${FLAG.profileId}${profile.id}`,
    `${FLAG.profileName}${encodeURIComponent(profile.name || 'Perfil')}`,
    `${FLAG.browserData}${dataDir}`,
    `${FLAG.downloads}${downloadsDir}`,
    `${FLAG.proxyLabel}${encodeURIComponent(proxyLabel || 'Sin proxy')}`,
  );
  if (appDataDir) args.push(`${FLAG.appData}${path.resolve(appDataDir)}`);
  if (Array.isArray(proxyArgs) && proxyArgs.length) args.push(...proxyArgs);
  for (const url of (Array.isArray(startUrls) ? startUrls : []).slice(0, 8)) {
    if (isHttpUrl(url)) args.push(url);
  }
  return { args, dataDir, downloadsDir };
}

function searchUrl(text) {
  return `${SEARCH_URL}${encodeURIComponent(text)}`;
}

function resolveAddressInput(value) {
  const text = String(value || '').trim();
  if (!text) return '';
  if (/^https?:\/\//i.test(text)) {
    try {
      const url = new URL(text);
      if (url.protocol === 'http:' || url.protocol === 'https:') return url.href;
    } catch {
      return searchUrl(text);
    }
    return searchUrl(text);
  }
  try {
    if (/^(localhost|127(?:\.\d{1,3}){3}|\[::1\])(?::\d+)?(?:[/?#]|$)/i.test(text)) {
      return new URL(`http://${text}`).href;
    }
    if (/^\d{1,3}(?:\.\d{1,3}){3}(?::\d+)?(?:[/?#]|$)/.test(text)) {
      return new URL(`http://${text}`).href;
    }
    if (/^[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)+:\d{1,5}(?:[/?#]|$)/.test(text)) {
      return new URL(`https://${text}`).href;
    }
    if (/^[a-zA-Z][a-zA-Z0-9+.-]*:/.test(text)) return searchUrl(text);
    if (!/\s/.test(text) && /^[^\s/?#]+\.[^\s/?#]+(?:[/?#].*)?$/.test(text)) {
      return new URL(`https://${text}`).href;
    }
  } catch {
    return searchUrl(text);
  }
  return searchUrl(text);
}

function isHomeUrl(value, homeHref = '') {
  if (!value || !homeHref) return false;
  if (value === homeHref) return true;
  return value.startsWith(homeHref) && (value[homeHref.length] === '?' || value[homeHref.length] === '#');
}

function isAllowedPageUrl(value, homeHref = '') {
  if (!value) return false;
  if (value === 'about:blank') return true;
  if (isHomeUrl(value, homeHref)) return true;
  return isHttpUrl(value);
}

module.exports = {
  BUILTIN_BROWSER_ID,
  BUILTIN_BROWSER_NAME,
  BROWSER_CHROME_HEIGHT,
  BROWSER_FLAG,
  FLAG,
  builtinBrowser,
  buildBrowserArgs,
  isAllowedPageUrl,
  isHomeUrl,
  isHttpUrl,
  parseBrowserArgs,
  resolveAddressInput,
};
