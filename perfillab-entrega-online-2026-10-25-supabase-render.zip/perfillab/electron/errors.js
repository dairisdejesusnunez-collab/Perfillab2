'use strict';

class AppError extends Error {
  constructor(message, status = 400, code = 'bad_request') {
    super(message);
    this.name = 'AppError';
    this.status = status;
    this.code = code;
  }
}

function badRequest(message) {
  return new AppError(message, 400, 'bad_request');
}

function notFound(message) {
  return new AppError(message, 404, 'not_found');
}

function conflict(message) {
  return new AppError(message, 409, 'conflict');
}

module.exports = { AppError, badRequest, notFound, conflict };
