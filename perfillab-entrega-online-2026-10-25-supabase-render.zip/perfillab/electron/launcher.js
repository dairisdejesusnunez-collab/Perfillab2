'use strict';

const EventEmitter = require('node:events');
const fs = require('node:fs');
const path = require('node:path');
const { spawn, spawnSync } = require('node:child_process');
const ProxyChain = require('proxy-chain');
const paths = require('./paths');
const secrets = require('./secrets');
const browsers = require('./browsers');
const { buildBrowserArgs } = require('./browser-launch');
const { buildProxyUrl } = require('./proxy-test');
const { AppError, notFound, conflict } = require('./errors');

function delay(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function runTaskkill(pid, force) {
  return new Promise((resolve) => {
    const args = ['/PID', String(pid), '/T'];
    if (force) args.push('/F');
    const child = spawn('taskkill', args, { windowsHide: true, stdio: 'ignore' });
    child.once('error', () => resolve());
    child.once('close', () => resolve());
  });
}

class ProfileLauncher extends EventEmitter {
  constructor(store, runtime = {}) {
    super();
    this.store = store;
    this.runtime = runtime && typeof runtime === 'object' ? runtime : {};
    this.running = new Map();
  }

  resolveRuntime() {
    if (this.runtime.execPath) return this.runtime;
    try {
      const electron = require('electron');
      if (electron && electron.app && typeof electron.app.getAppPath === 'function') {
        return {
          execPath: process.execPath,
          appPath: electron.app.getAppPath(),
          packaged: Boolean(electron.app.isPackaged),
          appDataDir: process.env.PERFILLAB_DATA_DIR || '',
        };
      }
    } catch {
      // Se usa el ejecutable actual y la carpeta del proyecto como respaldo.
    }
    return {
      execPath: process.execPath,
      packaged: false,
      appPath: path.join(__dirname, '..'),
      appDataDir: process.env.PERFILLAB_DATA_DIR || '',
    };
  }

  get settings() {
    return this.store.getState().settings;
  }

  getProfile(profileId) {
    return this.store.getState().profiles.find((item) => item.id === profileId) || null;
  }

  getProxy(proxyId) {
    if (!proxyId) return null;
    return this.store.getState().proxies.find((item) => item.id === proxyId) || null;
  }

  listRunning() {
    return [...this.running.entries()].map(([profileId, entry]) => ({
      profileId,
      pid: entry.child.pid,
      browserName: entry.browserName,
      startedAt: entry.startedAt,
      proxyMode: entry.proxyMode,
    }));
  }

  isRunning(profileId) {
    return this.running.has(profileId);
  }

  async startProxyRelay(proxy, password) {
    const upstreamProxyUrl = buildProxyUrl({ ...proxy, password });
    const server = new ProxyChain.Server({
      port: 0,
      host: '127.0.0.1',
      verbose: false,
      prepareRequestFunction: () => ({ upstreamProxyUrl }),
    });
    server.on('requestFailed', ({ error }) => {
      this.emit('log', { level: 'warn', message: `Proxy local: ${error && error.message ? error.message : 'error de conexión'}` });
    });
    try {
      await server.listen();
    } catch (error) {
      throw new AppError(`No se pudo iniciar el relay del proxy: ${error.message}`, 500, 'proxy_relay_error');
    }
    return server;
  }

  async start(profileId) {
    const profile = this.getProfile(profileId);
    if (!profile) throw notFound('El perfil no existe.');
    if (this.running.has(profileId)) throw conflict('El perfil ya se está ejecutando.');

    const browser = browsers.findBrowser();
    const runtime = this.resolveRuntime();

    const profileDir = paths.resolveProfileDir(this.settings, profile.id);
    try {
      paths.ensureDir(profileDir);
      paths.ensureDir(path.join(profileDir, 'browser'));
      paths.ensureDir(path.join(profileDir, 'downloads'));
    } catch (error) {
      throw new AppError(`No se pudo preparar la carpeta del perfil: ${error.message}`, 500, 'profile_dir_error');
    }

    const proxy = this.getProxy(profile.proxyId);
    let relay = null;
    let proxyMode = 'none';
    let proxyArgs = ['--no-proxy-server'];
    let proxyLabel = 'Sin proxy';
    if (proxy) {
      proxyLabel = proxy.name || `${proxy.host}:${proxy.port}`;
      const password = secrets.open(proxy.passwordEnc);
      const usesCredentials = Boolean(proxy.username || password);
      if (usesCredentials) {
        relay = await this.startProxyRelay(proxy, password);
        proxyMode = 'relay';
      } else {
        proxyMode = 'direct';
      }
      if (relay) {
        proxyArgs = [`--proxy-server=http://127.0.0.1:${relay.port}`];
      } else {
        const host = proxy.host.includes(':') && !proxy.host.startsWith('[') ? `[${proxy.host}]` : proxy.host;
        proxyArgs = [`--proxy-server=${proxy.protocol}://${host}:${proxy.port}`];
      }
    }

    const urls = Array.isArray(profile.startUrls) ? profile.startUrls.filter(Boolean).slice(0, 8) : [];
    let built;
    try {
      built = buildBrowserArgs({
        profile,
        profileDir,
        appDataDir: runtime.appDataDir,
        proxyArgs,
        proxyLabel,
        startUrls: urls,
        appPath: runtime.appPath,
        packaged: runtime.packaged !== false,
      });
    } catch (error) {
      if (relay) await relay.close(true).catch(() => {});
      throw new AppError(`No se pudo preparar el navegador integrado: ${error.message}`, 500, 'browser_args_error');
    }
    const command = runtime.execPath;
    const args = built.args;
    const cwd = runtime.packaged === false ? runtime.appPath : path.dirname(runtime.execPath);

    let child;
    try {
      child = spawn(command, args, {
        cwd,
        detached: false,
        stdio: 'ignore',
        windowsHide: false,
      });
    } catch (error) {
      if (relay) await relay.close(true).catch(() => {});
      throw new AppError(`No se pudo iniciar el navegador: ${error.message}`, 500, 'browser_spawn_error');
    }

    const entry = {
      profileId,
      child,
      browserName: browser.name,
      startedAt: new Date().toISOString(),
      relay,
      proxyMode,
      stopRequested: false,
      finalized: false,
      error: null,
    };
    entry.finished = new Promise((resolve) => {
      entry.resolveFinished = resolve;
    });
    this.running.set(profileId, entry);

    child.once('error', (error) => {
      entry.error = error;
      this.finalize(entry, 'error', null, null);
    });
    child.once('exit', (code, signal) => {
      this.finalize(entry, entry.stopRequested ? 'manual' : 'exited', code, signal);
    });

    return {
      profileId,
      pid: child.pid,
      browserName: browser.name,
      startedAt: entry.startedAt,
      proxyMode,
    };
  }

  finalize(entry, reason, code, signal) {
    if (entry.finalized) return;
    entry.finalized = true;
    if (this.running.get(entry.profileId) === entry) this.running.delete(entry.profileId);
    if (entry.relay) {
      entry.relay.close(true).catch(() => {});
      entry.relay = null;
    }
    if (entry.resolveFinished) entry.resolveFinished();
    this.emit('exit', {
      profileId: entry.profileId,
      reason,
      code,
      signal,
      error: entry.error ? entry.error.message : null,
    });
  }

  async stop(profileId) {
    const entry = this.running.get(profileId);
    if (!entry) return { profileId, alreadyStopped: true };

    entry.stopRequested = true;
    if (entry.child.exitCode === null) {
      await runTaskkill(entry.child.pid, false);
      await Promise.race([entry.finished, delay(2500)]);
    }
    if (!entry.finalized) {
      await runTaskkill(entry.child.pid, true);
      await Promise.race([entry.finished, delay(1500)]);
    }
    if (!entry.finalized) this.finalize(entry, 'manual', entry.child.exitCode, entry.child.signalCode);
    return { profileId, alreadyStopped: false };
  }

  stopAllSync() {
    const entries = [...this.running.values()];
    this.running.clear();
    for (const entry of entries) {
      entry.stopRequested = true;
      entry.finalized = true;
      try {
        if (entry.child.pid) {
          spawnSync('taskkill', ['/PID', String(entry.child.pid), '/T', '/F'], {
            windowsHide: true,
            stdio: 'ignore',
          });
        }
      } catch {
        // best effort during shutdown
      }
      if (entry.relay) {
        entry.relay.close(true).catch(() => {});
        entry.relay = null;
      }
      if (entry.resolveFinished) entry.resolveFinished();
    }
  }

  removeProfileData(profile) {
    const base = paths.resolveProfilesDir(this.settings);
    const dir = paths.resolveProfileDir(this.settings, profile.id);
    if (!paths.isInside(base, dir)) {
      throw new AppError('Se rechazó la eliminación de datos fuera de la carpeta de perfiles.', 400, 'unsafe_path');
    }
    try {
      fs.rmSync(dir, { recursive: true, force: true });
    } catch (error) {
      throw new AppError(`No se pudieron eliminar los datos del perfil: ${error.message}`, 500, 'delete_data_error');
    }
  }
}

module.exports = { ProfileLauncher };
