'use strict';

const { builtinBrowser, BUILTIN_BROWSER_ID } = require('./browser-launch');

function detectBrowsers() {
  return [builtinBrowser({ chromiumVersion: process.versions.chrome })];
}

function findBrowser() {
  return detectBrowsers()[0];
}

function pickDefaultBrowser() {
  return BUILTIN_BROWSER_ID;
}

module.exports = { detectBrowsers, findBrowser, pickDefaultBrowser };
