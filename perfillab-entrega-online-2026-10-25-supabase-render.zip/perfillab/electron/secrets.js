'use strict';

const crypto = require('node:crypto');
const { safeStorage } = require('electron');

const ENC_PREFIX = 'enc1:';
const PLAIN_PREFIX = 'plain1:';

function encryptionAvailable() {
  try {
    return safeStorage.isEncryptionAvailable();
  } catch {
    return false;
  }
}

function seal(value) {
  if (value === undefined || value === null || value === '') return '';
  const text = String(value);
  if (encryptionAvailable()) {
    return ENC_PREFIX + safeStorage.encryptString(text).toString('base64');
  }
  return PLAIN_PREFIX + Buffer.from(text, 'utf8').toString('base64');
}

function open(blob) {
  if (!blob) return '';
  const text = String(blob);
  try {
    if (text.startsWith(ENC_PREFIX)) {
      if (!encryptionAvailable()) return '';
      return safeStorage.decryptString(Buffer.from(text.slice(ENC_PREFIX.length), 'base64'));
    }
    if (text.startsWith(PLAIN_PREFIX)) {
      return Buffer.from(text.slice(PLAIN_PREFIX.length), 'base64').toString('utf8');
    }
  } catch {
    return '';
  }
  return '';
}

function randomToken() {
  return crypto.randomBytes(32).toString('hex');
}

module.exports = { seal, open, randomToken, encryptionAvailable };
