'use strict';

const EventEmitter = require('node:events');
const crypto = require('node:crypto');
const fs = require('node:fs');
const path = require('node:path');
const { spawn, spawnSync, execFile } = require('node:child_process');
const { AppError, badRequest, notFound, conflict } = require('./errors');
const paths = require('./paths');
const secrets = require('./secrets');
const { NativeCloneProvider } = require('./native-clone');

const MAX_APPS = 500;
const MAX_ARGS = 4000;
const MAX_CWD = 1000;
const CLONE_MODES = new Set(['none', 'data', 'account', 'vm']);

function delay(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function runTaskkill(pid, force) {
  return new Promise((resolve) => {
    if (!Number.isInteger(pid) || pid <= 0) return resolve();
    const args = ['/PID', String(pid), '/T'];
    if (force) args.push('/F');
    const child = spawn('taskkill', args, { windowsHide: true, stdio: 'ignore' });
    child.once('error', () => resolve());
    child.once('close', () => resolve());
  });
}

function parseStartApps(output) {
  const text = String(output || '').trim();
  if (!text) return [];
  let data;
  try {
    data = JSON.parse(text);
  } catch {
    throw new AppError('Windows devolvió una lista de aplicaciones no válida.', 500, 'app_detection_failed');
  }
  const list = Array.isArray(data) ? data : [data];
  const seen = new Set();
  const apps = [];
  for (const item of list) {
    if (!item || typeof item !== 'object') continue;
    const target = String(item.AppID || '').trim();
    const name = String(item.Name || '').trim();
    if (!target || !name || target.length > 200 || seen.has(target)) continue;
    if (/[\u0000-\u001f\u007f]/.test(target)) continue;
    seen.add(target);
    apps.push({ name: name.slice(0, 100), target, kind: 'startapp', source: 'start-menu' });
  }
  return apps.sort((a, b) => a.name.localeCompare(b.name, 'es', { sensitivity: 'base' })).slice(0, 1000);
}

function splitWindowsArgs(input) {
  const text = String(input === undefined || input === null ? '' : input);
  if (text.length > MAX_ARGS) throw badRequest('Los argumentos de la aplicación son demasiado largos.');
  if (text.includes('\0')) throw badRequest('Los argumentos de la aplicación no son válidos.');
  const args = [];
  let current = '';
  let quoting = false;
  let started = false;
  let index = 0;
  while (index < text.length) {
    const char = text[index];
    if (char === '\\') {
      let count = 0;
      while (text[index] === '\\') {
        count += 1;
        index += 1;
      }
      if (text[index] === '"') {
        current += '\\'.repeat(Math.floor(count / 2));
        if (count % 2 === 1) {
          current += '"';
          index += 1;
        }
      } else {
        current += '\\'.repeat(count);
      }
      started = true;
      continue;
    }
    if (char === '"') {
      quoting = !quoting;
      started = true;
      index += 1;
      continue;
    }
    if (!quoting && /\s/.test(char)) {
      if (started || current) {
        args.push(current);
        current = '';
        started = false;
      }
      index += 1;
      continue;
    }
    current += char;
    started = true;
    index += 1;
  }
  if (quoting) throw badRequest('Los argumentos contienen comillas sin cerrar.');
  if (started || current) args.push(current);
  if (args.some((arg) => arg.includes('\0'))) throw badRequest('Los argumentos de la aplicación no son válidos.');
  return args;
}

function normalizeCwd(value, baseDir) {
  const raw = String(value || '').trim();
  if (raw.length > MAX_CWD) throw badRequest('La carpeta de trabajo es demasiado larga.');
  if (!raw) return baseDir;
  if (!path.isAbsolute(raw)) throw badRequest('La carpeta de trabajo debe ser una ruta absoluta.');
  if (raw.includes('\0')) throw badRequest('La carpeta de trabajo no es válida.');
  let stat;
  try {
    stat = fs.statSync(raw);
  } catch {
    throw badRequest('La carpeta de trabajo no existe.');
  }
  if (!stat.isDirectory()) throw badRequest('La carpeta de trabajo no es una carpeta.');
  return raw;
}

function validateTarget(target, kind) {
  const value = String(target || '');
  if (!value || value.length > 1000) throw badRequest('La aplicación no tiene un destino válido.');
  if (kind === 'startapp') {
    if (!/^[A-Za-z0-9_.!{}@#$%&()+,;=~\-]+$/.test(value)) {
      throw badRequest('El identificador de la aplicación de Windows no es válido.');
    }
    return value;
  }
  if (!path.isAbsolute(value)) throw badRequest('La ruta del ejecutable debe ser absoluta.');
  if (value.includes('\0') || path.extname(value).toLowerCase() !== '.exe') {
    throw badRequest('Solo se pueden agregar archivos .exe como aplicaciones.');
  }
  let stat;
  try {
    stat = fs.statSync(value);
  } catch {
    throw badRequest('No se encontró el ejecutable seleccionado.');
  }
  if (!stat.isFile()) throw badRequest('La ruta seleccionada no es un archivo ejecutable.');
  return value;
}

class AppLauncher extends EventEmitter {
  constructor(store, options = {}) {
    super();
    this.store = store;
    this.nativeClone = options.nativeClone || new NativeCloneProvider();
    this.hyperV = options.hyperV || null;
    this.spawnImpl = options.spawnImpl || spawn;
    this.running = new Map();
    this.vmSessions = new Map();
    this.detectedAt = 0;
    this.detected = [];
    if (this.hyperV) {
      this.hyperV.on('window-exit', (event) => this.handleVmWindowExit(event));
      this.hyperV.on('window-error', (event) => this.handleVmWindowError(event));
    }
  }

  get state() {
    return this.store.getState();
  }

  getProfile(profileId) {
    return this.state.profiles.find((item) => item.id === profileId) || null;
  }

  getApp(appId) {
    return this.state.apps.find((item) => item.id === appId) || null;
  }

  getCloneAccount(profileId) {
    return (this.state.cloneAccounts || []).find((item) => item.profileId === profileId) || null;
  }

  listRunning(profileId = null) {
    const entries = [...this.running.values()]
      .filter((entry) => !profileId || entry.profileId === profileId)
      .map((entry) => ({
        instanceId: entry.instanceId,
        appId: entry.appId,
        appName: entry.appName,
        profileId: entry.profileId,
        profileName: entry.profileName,
        pid: entry.appPid || entry.child.pid,
        startedAt: entry.startedAt,
        tracked: true,
        isolated: entry.isolated,
        isolation: entry.isolation || 'none',
        accountName: entry.accountName || null,
        cloneMode: entry.isolation || 'none',
      }));
    for (const session of this.vmSessions.values()) {
      if (profileId && session.profileId !== profileId) continue;
      entries.push({
        instanceId: `vm:${session.profileId}`,
        appId: session.appId,
        appName: session.appName || 'Máquina virtual',
        profileId: session.profileId,
        profileName: session.profileName,
        pid: session.pid,
        startedAt: session.startedAt,
        tracked: true,
        isolated: true,
        isolation: 'vm',
        accountName: null,
        cloneMode: 'vm',
        vmName: session.vmName,
      });
    }
    return entries;
  }

  async detect(force = false) {
    if (!force && this.detected.length && Date.now() - this.detectedAt < 120000) return this.detected;
    if (process.platform !== 'win32') {
      this.detected = [];
      this.detectedAt = Date.now();
      return [];
    }
    const script = [
      '[Console]::OutputEncoding = [System.Text.Encoding]::UTF8',
      '$ErrorActionPreference = "Stop"',
      '$apps = Get-StartApps | Select-Object Name, AppID | Sort-Object Name',
      '$apps | ConvertTo-Json -Compress -Depth 3',
    ].join('; ');
    const output = await new Promise((resolve, reject) => {
      execFile(
        'powershell.exe',
        ['-NoLogo', '-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-Command', script],
        { encoding: 'utf8', windowsHide: true, timeout: 15000, maxBuffer: 2 * 1024 * 1024 },
        (error, stdout) => {
          if (error) reject(new AppError(`No se pudieron detectar las aplicaciones instaladas: ${error.message}`, 500, 'app_detection_failed'));
          else resolve(stdout);
        },
      );
    });
    this.detected = parseStartApps(output);
    this.detectedAt = Date.now();
    return this.detected;
  }

  profileAppDir(profile) {
    const base = paths.resolveProfileDir(this.state.settings, profile.id);
    const dir = path.join(base, 'applications');
    paths.ensureDir(dir);
    return dir;
  }

  appDataDir(profile, appId) {
    const dir = path.join(this.profileAppDir(profile), appId);
    for (const child of ['Roaming', 'Local', 'Temp']) paths.ensureDir(path.join(dir, child));
    return dir;
  }

  async launch(profileId, appId, options = {}) {
    if (process.platform !== 'win32') {
      throw badRequest('La apertura de aplicaciones de Windows solo está disponible en Windows.');
    }
    const profile = this.getProfile(profileId);
    if (!profile) throw notFound('El perfil seleccionado no existe.');
    const app = this.getApp(appId);
    if (!app) throw notFound('La aplicación seleccionada no está en tu biblioteca.');

    if (app.kind === 'startapp') {
      const target = validateTarget(app.target, app.kind);
      const child = this.spawnImpl('explorer.exe', [`shell:AppsFolder\\${target}`], {
        windowsHide: false,
        detached: false,
        stdio: 'ignore',
      });
      child.once('error', (error) => {
        this.emit('error', { appId: app.id, profileId, message: error.message });
      });
      child.once('spawn', () => {
        this.emit('launched', {
          appId: app.id,
          appName: app.name,
          profileId,
          profileName: profile.name,
          tracked: false,
        });
      });
      return {
        tracked: false,
        appId: app.id,
        appName: app.name,
        profileId,
        profileName: profile.name,
        isolation: 'none',
        message: 'Windows abrió la aplicación. El proceso lo administra el sistema y no se puede cerrar desde PerfilLab.',
      };
    }

    const cloneMode = CLONE_MODES.has(app.cloneMode) ? app.cloneMode : 'account';
    if (cloneMode === 'vm') {
      return await this.launchInVm(profile, app);
    }
    const target = validateTarget(app.target, app.kind);
    const args = splitWindowsArgs(options.arguments !== undefined ? options.arguments : app.args);
    if (cloneMode === 'account') {
      return await this.launchInAccount(profile, app, { target, args, cwdInput: options.cwd });
    }

    const appBase = this.profileAppDir(profile);
    const cwd = normalizeCwd(options.cwd !== undefined && String(options.cwd).trim() ? options.cwd : app.cwd, appBase);
    const environment = {
      ...process.env,
      PERFILLAB_PROFILE_ID: profile.id,
      PERFILLAB_PROFILE_NAME: profile.name,
      PERFILLAB_APPLICATION_ID: app.id,
    };
    let isolatedBase = null;
    if (cloneMode === 'data') {
      isolatedBase = this.appDataDir(profile, app.id);
      environment.APPDATA = path.join(isolatedBase, 'Roaming');
      environment.LOCALAPPDATA = path.join(isolatedBase, 'Local');
      environment.TEMP = path.join(isolatedBase, 'Temp');
      environment.TMP = path.join(isolatedBase, 'Temp');
    }

    const child = this.spawnImpl(target, args, {
      cwd,
      env: environment,
      windowsHide: false,
      detached: false,
      stdio: 'ignore',
    });
    const entry = this.track(child, profile, app, {
      isolated: cloneMode === 'data',
      isolation: cloneMode,
      accountName: null,
    });
    await this.waitReady(entry, app);
    return {
      instanceId: entry.instanceId,
      tracked: true,
      appId: app.id,
      appName: app.name,
      profileId: profile.id,
      profileName: profile.name,
      pid: child.pid,
      startedAt: entry.startedAt,
      isolated: cloneMode === 'data',
      isolation: cloneMode,
      accountName: null,
    };
  }

  async launchInAccount(profile, app, { target, args, cwdInput }) {
    if (!this.nativeClone) {
      throw new AppError('El clonador nativo no está disponible en esta instalación.', 500, 'clone_unavailable');
    }
    const existing = [...this.running.values()].find((entry) => (
      entry.profileId === profile.id
      && entry.appId === app.id
      && entry.isolation === 'account'
    ));
    if (existing) {
      throw conflict('Ya hay un clon de esta aplicación abierto para el perfil. Cierra esa instancia antes de abrir otra.');
    }
    const account = this.getCloneAccount(profile.id);
    if (!account) {
      throw new AppError(
        'Este perfil todavía no tiene su cuenta de Windows. Prepárala desde el lanzador o desde Ajustes > Clonador nativo.',
        409,
        'clone_account_missing',
      );
    }
    if (!account.sid) {
      throw new AppError('La cuenta del clon está incompleta. Repárala desde Ajustes > Clonador nativo.', 409, 'clone_account_incomplete');
    }
    const password = secrets.open(account.passwordEnc);
    if (!password) {
      throw new AppError('No se pudo leer la credencial de la cuenta del clon. Repárala desde Ajustes > Clonador nativo.', 409, 'clone_credential_missing');
    }
    const baseDir = path.dirname(target);
    const cwd = normalizeCwd(cwdInput !== undefined && String(cwdInput).trim() ? cwdInput : app.cwd, baseDir);
    await this.nativeClone.prepareAppAccess({ sid: account.sid, target, cwd });
    const started = await this.nativeClone.startProcess({
      username: account.username,
      password,
      target,
      args,
      cwd,
    });
    const entry = this.trackNative(started.child, started.ready, profile, app, {
      accountName: account.username,
    });
    await this.waitReady(entry, app);
    this.emit('launched', this.listRunning().find((item) => item.instanceId === entry.instanceId));
    return {
      instanceId: entry.instanceId,
      tracked: true,
      appId: app.id,
      appName: app.name,
      profileId: profile.id,
      profileName: profile.name,
      pid: entry.appPid,
      startedAt: entry.startedAt,
      isolated: true,
      isolation: 'account',
      accountName: account.username,
    };
  }

  track(child, profile, app, { isolated, isolation, accountName }) {
    const entry = {
      instanceId: crypto.randomUUID(),
      appId: app.id,
      appName: app.name,
      profileId: profile.id,
      profileName: profile.name,
      child,
      appPid: null,
      startedAt: new Date().toISOString(),
      isolated,
      isolation,
      accountName,
      stopRequested: false,
      finalized: false,
      error: null,
    };
    entry.finished = new Promise((resolve) => {
      entry.resolveFinished = resolve;
    });
    entry.ready = new Promise((resolve, reject) => {
      child.once('spawn', () => resolve(child.pid));
      child.once('error', reject);
    });
    entry.ready.catch(() => {});
    this.running.set(entry.instanceId, entry);
    child.once('spawn', () => {
      this.emit('launched', this.listRunning().find((item) => item.instanceId === entry.instanceId));
    });
    child.once('error', (error) => {
      entry.error = error;
      this.finalize(entry, 'error', null, null);
    });
    child.once('exit', (code, signal) => {
      this.finalize(entry, entry.stopRequested ? 'manual' : 'exited', code, signal);
    });
    return entry;
  }

  trackNative(child, readyPromise, profile, app, { accountName }) {
    const entry = {
      instanceId: crypto.randomUUID(),
      appId: app.id,
      appName: app.name,
      profileId: profile.id,
      profileName: profile.name,
      child,
      appPid: null,
      startedAt: new Date().toISOString(),
      isolated: true,
      isolation: 'account',
      accountName,
      stopRequested: false,
      finalized: false,
      error: null,
    };
    entry.finished = new Promise((resolve) => {
      entry.resolveFinished = resolve;
    });
    entry.ready = readyPromise.then((pid) => {
      entry.appPid = pid;
      return pid;
    });
    entry.ready.catch(() => {});
    this.running.set(entry.instanceId, entry);
    child.once('error', (error) => {
      entry.error = error;
      this.finalize(entry, 'error', null, null);
    });
    child.once('exit', (code, signal) => {
      this.finalize(entry, entry.stopRequested ? 'manual' : 'exited', code, signal);
    });
    return entry;
  }

  async waitReady(entry, app) {
    try {
      await entry.ready;
    } catch (error) {
      await this.stop(entry.instanceId);
      if (error instanceof AppError) throw error;
      throw new AppError(
        `No se pudo iniciar "${app.name}": ${error && error.message ? error.message : 'el proceso no arrancó'}`,
        500,
        'app_launch_failed',
      );
    }
  }

  finalize(entry, reason, code, signal) {
    if (entry.finalized) return;
    entry.finalized = true;
    if (this.running.get(entry.instanceId) === entry) this.running.delete(entry.instanceId);
    if (entry.resolveFinished) entry.resolveFinished();
    this.emit('exit', {
      instanceId: entry.instanceId,
      appId: entry.appId,
      appName: entry.appName,
      profileId: entry.profileId,
      profileName: entry.profileName,
      reason,
      code,
      signal,
      error: entry.error ? entry.error.message : null,
    });
  }

  async launchInVm(profile, app) {
    const session = await this.startVm(profile.id, app);
    return {
      instanceId: `vm:${profile.id}`,
      tracked: true,
      appId: app.id,
      appName: app.name,
      profileId: profile.id,
      profileName: profile.name,
      pid: session.pid,
      startedAt: session.startedAt,
      isolated: true,
      isolation: 'vm',
      accountName: null,
      vmName: session.vmName,
      message: `La máquina virtual ${session.vmName} está encendida. Abre "${app.name}" dentro de su ventana.`,
    };
  }

  requireHyperV() {
    if (!this.hyperV) {
      throw new AppError('El modo de máquina virtual no está disponible en esta instalación.', 500, 'vm_unavailable');
    }
    return this.hyperV;
  }

  async prepareVm(profileId) {
    const hyperV = this.requireHyperV();
    const profile = this.getProfile(profileId);
    if (!profile) throw notFound('El perfil seleccionado no existe.');
    const settings = this.state.settings.vm || {};
    const ensured = await hyperV.run(profileId, () => hyperV.ensure(profileId, settings, { start: false }));
    const event = {
      profileId,
      profileName: profile.name,
      vmName: ensured.vmName,
      diskPath: ensured.diskPath || '',
      state: ensured.state || '',
      created: Boolean(ensured.created),
      warning: ensured.warning || null,
    };
    this.emit('vm-prepared', event);
    return event;
  }

  async startVm(profileId, app = null) {
    const hyperV = this.requireHyperV();
    const profile = this.getProfile(profileId);
    if (!profile) throw notFound('El perfil seleccionado no existe.');
    if (this.vmSessions.has(profileId)) {
      throw conflict('La máquina virtual de este perfil ya está encendida. Cierra su ventana o detenla antes de abrirla otra vez.');
    }
    const settings = this.state.settings.vm || {};
    let started;
    try {
      started = await hyperV.run(profileId, async () => {
        const ensured = await hyperV.ensure(profileId, settings, { start: true });
        const window = hyperV.openWindow(profileId, profile.name, ensured.vmName);
        return { ensured, window };
      });
    } catch (error) {
      this.emit('vm-error', {
        appId: app ? app.id : null,
        appName: app ? app.name : null,
        profileId,
        profileName: profile.name,
        message: error.message,
      });
      throw error;
    }
    const session = {
      profileId,
      profileName: profile.name,
      appId: app ? app.id : null,
      appName: app ? app.name : null,
      vmName: started.ensured.vmName,
      diskPath: started.ensured.diskPath || '',
      pid: started.window.pid,
      startedAt: started.window.startedAt || new Date().toISOString(),
    };
    this.vmSessions.set(profileId, session);
    this.emit('vm-launched', session);
    return session;
  }

  vmSession(profileId) {
    const session = this.vmSessions.get(profileId);
    return session ? { ...session } : null;
  }

  handleVmWindowExit(event) {
    const session = this.vmSessions.get(event.profileId);
    if (!session) return;
    this.vmSessions.delete(event.profileId);
    this.emit('vm-exit', { ...session, reason: 'window', code: event.code, signal: event.signal });
  }

  handleVmWindowError(event) {
    const session = this.vmSessions.get(event.profileId);
    if (!session) return;
    this.vmSessions.delete(event.profileId);
    this.emit('vm-exit', { ...session, reason: 'error', error: event.message });
  }

  async removeVm(profileId) {
    const hyperV = this.requireHyperV();
    const profile = this.getProfile(profileId);
    if (!profile) throw notFound('El perfil seleccionado no existe.');
    const record = (this.state.virtualMachines || []).find((item) => item.profileId === profileId);
    const session = this.vmSessions.get(profileId);
    if (session) {
      this.vmSessions.delete(profileId);
      hyperV.closeWindow(profileId);
      this.emit('vm-exit', { ...session, reason: 'manual' });
    }
    const result = await hyperV.remove(profileId, record ? record.diskPath : '');
    this.emit('vm-removed', { profileId, profileName: profile.name, result });
    return result;
  }

  async stop(instanceId) {
    if (typeof instanceId === 'string' && instanceId.startsWith('vm:')) {
      const profileId = instanceId.slice(3);
      const session = this.vmSessions.get(profileId);
      if (!session) return { instanceId, alreadyStopped: true };
      this.vmSessions.delete(profileId);
      try {
        await this.requireHyperV().stop(profileId);
      } catch (error) {
        this.vmSessions.set(profileId, session);
        throw error;
      }
      this.emit('vm-exit', { ...session, reason: 'manual' });
      return { instanceId, alreadyStopped: false };
    }
    const entry = this.running.get(instanceId);
    if (!entry) return { instanceId, alreadyStopped: true };
    entry.stopRequested = true;
    const pids = [];
    if (entry.appPid) pids.push(entry.appPid);
    if (entry.child.pid) pids.push(entry.child.pid);
    for (const pid of pids) {
      if (entry.finalized) break;
      await runTaskkill(pid, false);
      await Promise.race([entry.finished, delay(2000)]);
    }
    for (const pid of pids) {
      if (entry.finalized) break;
      await runTaskkill(pid, true);
      await Promise.race([entry.finished, delay(1200)]);
    }
    if (!entry.finalized) this.finalize(entry, 'manual', entry.child.exitCode, entry.child.signalCode);
    return { instanceId, alreadyStopped: false };
  }

  async stopForProfile(profileId) {
    const entries = [...this.running.values()].filter((entry) => entry.profileId === profileId);
    for (const entry of entries) await this.stop(entry.instanceId);
    let stoppedVms = 0;
    if (this.vmSessions.has(profileId)) {
      await this.stop(`vm:${profileId}`);
      stoppedVms = 1;
    }
    return { stopped: entries.length + stoppedVms };
  }

  async stopForApp(appId) {
    const entries = [...this.running.values()].filter((entry) => entry.appId === appId);
    for (const entry of entries) await this.stop(entry.instanceId);
    return { stopped: entries.length };
  }

  async stopAllVms() {
    if (!this.vmSessions.size) return { stopped: 0 };
    const hyperV = this.requireHyperV();
    const sessions = [...this.vmSessions.values()];
    this.vmSessions.clear();
    try {
      const result = await hyperV.stopAll(sessions.map((session) => session.profileId));
      for (const session of sessions) this.emit('vm-exit', { ...session, reason: 'manual' });
      return result;
    } catch (error) {
      for (const session of sessions) this.vmSessions.set(session.profileId, session);
      throw error;
    }
  }

  stopAllSync() {
    if (this.hyperV) {
      try {
        this.hyperV.closeAllWindows();
      } catch {
        // best effort during shutdown
      }
    }
    this.vmSessions.clear();
    const entries = [...this.running.values()];
    this.running.clear();
    for (const entry of entries) {
      entry.stopRequested = true;
      entry.finalized = true;
      try {
        for (const pid of [entry.appPid, entry.child.pid]) {
          if (!Number.isInteger(pid) || pid <= 0) continue;
          spawnSync('taskkill', ['/PID', String(pid), '/T', '/F'], {
            windowsHide: true,
            stdio: 'ignore',
          });
        }
      } catch {
        // best effort during shutdown
      }
      if (entry.resolveFinished) entry.resolveFinished();
    }
  }

  validateAppDraft(input, existing = null) {
    if (!input || typeof input !== 'object' || Array.isArray(input)) throw badRequest('Datos de aplicación no válidos.');
    const kind = existing ? existing.kind : input.kind;
    if (kind !== 'startapp' && kind !== 'executable') throw badRequest('El tipo de aplicación no es válido.');
    const target = existing ? existing.target : validateTarget(input.target, kind);
    const nameRaw = input.name !== undefined ? input.name : (existing ? existing.name : '');
    if (typeof nameRaw !== 'string' || !nameRaw.trim()) throw badRequest('El nombre de la aplicación es obligatorio.');
    const name = nameRaw.trim().slice(0, 100);
    const args = input.args !== undefined ? String(input.args) : (existing ? existing.args : '');
    if (args.length > MAX_ARGS || args.includes('\0')) throw badRequest('Los argumentos de la aplicación no son válidos.');
    splitWindowsArgs(args);
    let cwd = input.cwd !== undefined ? String(input.cwd).trim() : (existing ? existing.cwd : '');
    if (cwd) cwd = normalizeCwd(cwd, null);
    let cloneMode = input.cloneMode !== undefined
      ? input.cloneMode
      : (existing ? existing.cloneMode : '');
    if (kind === 'startapp') {
      if (cloneMode && cloneMode !== 'none') {
        throw badRequest('Las aplicaciones del menú Inicio no se pueden abrir en una cuenta clon.');
      }
      cloneMode = 'none';
    } else {
      if (!cloneMode) cloneMode = 'account';
      if (!CLONE_MODES.has(cloneMode)) throw badRequest('El modo de clonación debe ser none, data, account o vm.');
    }
    return { name, target, kind, args, cwd, cloneMode };
  }
}

module.exports = {
  AppLauncher,
  parseStartApps,
  splitWindowsArgs,
  normalizeCwd,
  validateTarget,
  MAX_APPS,
};
