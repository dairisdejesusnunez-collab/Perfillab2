'use strict';

const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('perfillab', {
  action: (name, payload) => ipcRenderer.invoke('perfillab:action', String(name), payload),
  onEvent: (callback) => {
    if (typeof callback !== 'function') return () => {};
    const handler = (_event, state) => callback(state);
    ipcRenderer.on('perfillab:event', handler);
    return () => ipcRenderer.removeListener('perfillab:event', handler);
  },
  platform: process.platform,
});
