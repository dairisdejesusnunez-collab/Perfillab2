'use strict';

const EventEmitter = require('node:events');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { app, shell } = require('electron');
const paths = require('./paths');
const secrets = require('./secrets');
const browsers = require('./browsers');
const validation = require('./validation');
const csv = require('./csv');
const { testProxy } = require('./proxy-test');
const { PALETTE, ACTIVITY_LIMIT, nowIso } = require('./store');
const { AppError, badRequest, notFound, conflict } = require('./errors');

const EXPORT_FORMAT = 'perfillab-export';
const STATUS_LIMIT = 30;

class AppService extends EventEmitter {
  constructor({ store, launcher, appLauncher = null, nativeClone = null, hyperV = null }) {
    super();
    this.store = store;
    this.launcher = launcher;
    this.appLauncher = appLauncher;
    this.nativeClone = nativeClone;
    this.hyperV = hyperV;
    this.apiStatusProvider = () => ({ enabled: false, running: false, port: null, error: null });
    this.licenseStatusProvider = () => ({ required: false, active: true, licensed: false });
    this.launcher.on('exit', (event) => this.handleLauncherExit(event));
    this.launcher.on('log', ({ level, message }) => {
      this.addActivity(level, message);
      this.store.save();
      this.emitState();
    });
    if (this.appLauncher) {
      this.appLauncher.on('launched', (event) => {
        if (!event || !event.appName) return;
        const clone = event.isolation === 'account'
          ? ` en su cuenta de Windows aislada${event.accountName ? ` (${event.accountName})` : ''}`
          : event.isolation === 'data'
            ? ' con datos aislados'
            : '';
        this.addActivity('success', `Aplicación "${event.appName}" abierta en el perfil "${event.profileName}"${clone}.`, event.profileId);
        this.saveAndEmit();
      });
      this.appLauncher.on('error', (event) => {
        this.addActivity('error', `No se pudo abrir "${event.appName || 'la aplicación'}": ${event.message}`, event.profileId);
        this.saveAndEmit();
      });
      this.appLauncher.on('exit', (event) => {
        const detail = event.reason === 'error'
          ? `falló${event.error ? `: ${event.error}` : '.'}`
          : event.reason === 'manual'
            ? 'se cerró manualmente.'
            : 'se cerró.';
        this.addActivity('info', `La aplicación "${event.appName}" ${detail}`, event.profileId);
        this.saveAndEmit();
      });
      this.appLauncher.on('vm-launched', (event) => this.handleVmLaunched(event));
      this.appLauncher.on('vm-prepared', (event) => {
        this.recordVirtualMachine(event);
        const warning = event.warning ? ` ${event.warning}` : '';
        this.addActivity(
          event.created ? 'success' : 'info',
          event.created
            ? `Máquina virtual preparada para el perfil "${event.profileName}" (${event.vmName}).${warning}`
            : `La máquina virtual del perfil "${event.profileName}" ya estaba preparada (${event.vmName}).${warning}`,
          event.profileId,
        );
        this.saveAndEmit();
      });
      this.appLauncher.on('vm-error', (event) => {
        const label = event.appName ? ` para "${event.appName}"` : '';
        this.addActivity('error', `No se pudo encender la máquina virtual del perfil "${event.profileName}"${label}: ${event.message}`, event.profileId);
        this.saveAndEmit();
      });
      this.appLauncher.on('vm-exit', (event) => {
        let detail;
        if (event.reason === 'manual') detail = 'se detuvo desde PerfilLab.';
        else if (event.reason === 'error') detail = `perdió la ventana de conexión (${event.error || 'error desconocido'}). La máquina virtual sigue encendida en segundo plano.`;
        else detail = 'cerró su ventana de conexión. La máquina virtual sigue encendida en segundo plano; vuelve a encenderla para reconectarte.';
        this.addActivity('info', `La máquina virtual del perfil "${event.profileName}" ${detail}`, event.profileId);
        this.saveAndEmit();
      });
      this.appLauncher.on('vm-removed', (event) => {
        this.state.virtualMachines = (this.state.virtualMachines || []).filter((item) => item.profileId !== event.profileId);
        this.addActivity('warn', `Máquina virtual y disco del perfil "${event.profileName}" eliminados.`, event.profileId);
        this.saveAndEmit();
      });
    }
  }

  handleVmLaunched(event) {
    this.recordVirtualMachine(event);
    const detail = event.appName
      ? ` Abre "${event.appName}" dentro de la ventana de la máquina.`
      : '';
    this.addActivity('success', `Máquina virtual del perfil "${event.profileName}" encendida (${event.vmName}).${detail}`, event.profileId);
    this.saveAndEmit();
  }

  recordVirtualMachine(event) {
    const existing = (this.state.virtualMachines || []).find((item) => item.profileId === event.profileId);
    const record = {
      profileId: event.profileId,
      vmName: event.vmName,
      diskPath: event.diskPath || '',
      createdAt: existing ? existing.createdAt : nowIso(),
      updatedAt: nowIso(),
    };
    if (existing) Object.assign(existing, record);
    else this.state.virtualMachines.push(record);
  }

  setApiStatusProvider(provider) {
    this.apiStatusProvider = provider;
  }

  setLicenseStatusProvider(provider) {
    this.licenseStatusProvider = provider;
  }

  get state() {
    return this.store.getState();
  }

  getPublicState() {
    const state = this.store;
    const settings = state.getState().settings;
    const apiStatus = this.apiStatusProvider() || {};
    return {
      app: { name: 'PerfilLab', version: app.getVersion() },
      settings: {
        ...settings,
        api: {
          ...settings.api,
          ...apiStatus,
          enabled: Boolean(settings.api.enabled),
          token: this.getApiToken(),
        },
      },
      workspaces: state.getState().workspaces,
      profileStatuses: state.getState().profileStatuses,
      proxies: state.getState().proxies.map((proxy) => this.publicProxy(proxy)),
      profiles: state.getState().profiles,
      apps: state.getState().apps,
      appProfileConfigs: state.getState().appProfileConfigs,
      browsers: browsers.detectBrowsers(settings),
      statuses: this.launcher.listRunning(),
      appStatuses: this.appLauncher ? this.appLauncher.listRunning() : [],
      activity: state.getState().activity,
      clone: this.cloneStatus(),
      vm: this.vmStatus(),
      license: this.licenseStatusProvider(),
    };
  }

  publicCloneAccount(account) {
    return {
      profileId: account.profileId,
      username: account.username,
      sid: account.sid || null,
      hasCredential: Boolean(account.passwordEnc),
      preparedAt: account.preparedAt || null,
      verifiedAt: account.verifiedAt || null,
      updatedAt: account.updatedAt || null,
    };
  }

  cloneStatus() {
    const accounts = (this.state.cloneAccounts || []).map((account) => this.publicCloneAccount(account));
    if (!this.nativeClone) {
      return {
        available: false,
        checked: true,
        platform: process.platform,
        error: 'El clonador nativo no está disponible en esta instalación.',
        encryption: secrets.encryptionAvailable(),
        accounts,
      };
    }
    return {
      ...this.nativeClone.snapshot(),
      encryption: secrets.encryptionAvailable(),
      accounts,
    };
  }

  async refreshCloneCapabilities(force = false) {
    if (!this.nativeClone) return this.cloneStatus();
    try {
      await this.nativeClone.capabilities(Boolean(force));
    } catch {
      // El estado se informa a través de las capacidades con su propio error.
    }
    this.emitState();
    return this.cloneStatus();
  }

  publicVirtualMachine(record) {
    return {
      profileId: record.profileId,
      vmName: record.vmName,
      diskPath: record.diskPath || '',
      createdAt: record.createdAt || null,
      updatedAt: record.updatedAt || null,
      running: Boolean(this.appLauncher && this.appLauncher.vmSession(record.profileId)),
    };
  }

  vmStatus() {
    const settings = this.state.settings.vm || {};
    const machines = (this.state.virtualMachines || []).map((record) => this.publicVirtualMachine(record));
    if (!this.hyperV) {
      return {
        available: false,
        checked: true,
        platform: process.platform,
        error: 'El proveedor de máquinas virtuales no está disponible en esta instalación.',
        settings,
        machines,
      };
    }
    return { ...this.hyperV.snapshot(), settings, machines };
  }

  async refreshVmCapabilities(force = false) {
    if (!this.hyperV) return this.vmStatus();
    try {
      await this.hyperV.capabilities(Boolean(force));
    } catch {
      // El estado se informa a través de las capacidades con su propio error.
    }
    this.emitState();
    return this.vmStatus();
  }

  async prepareVm(profileId) {
    if (!this.appLauncher) throw notFound('El lanzador de aplicaciones no está disponible.');
    const profile = this.requireProfile(profileId);
    await this.appLauncher.prepareVm(profile.id);
    this.saveAndEmit();
    return this.vmStatus();
  }

  async startVm(profileId) {
    if (!this.appLauncher) throw notFound('El lanzador de aplicaciones no está disponible.');
    const profile = this.requireProfile(profileId);
    await this.appLauncher.startVm(profile.id);
    this.saveAndEmit();
    return this.vmStatus();
  }

  async stopVm(profileId) {
    if (!this.appLauncher) throw notFound('El lanzador de aplicaciones no está disponible.');
    const profile = this.requireProfile(profileId);
    await this.appLauncher.stop(`vm:${profile.id}`);
    this.saveAndEmit();
    return this.vmStatus();
  }

  async removeVm(profileId) {
    if (!this.appLauncher) throw notFound('El lanzador de aplicaciones no está disponible.');
    const profile = this.requireProfile(profileId);
    await this.appLauncher.removeVm(profile.id);
    this.saveAndEmit();
    return this.vmStatus();
  }

  async listVmSwitches() {
    if (!this.hyperV) throw notFound('El proveedor de máquinas virtuales no está disponible.');
    const items = await this.hyperV.listSwitches();
    return { items };
  }

  requireCloneAccount(profileId) {
    const account = (this.state.cloneAccounts || []).find((item) => item.profileId === profileId);
    if (!account) {
      throw notFound('Este perfil todavía no tiene una cuenta de Windows preparada.');
    }
    return account;
  }

  async prepareCloneAccount(profileId) {
    const profile = this.requireProfile(profileId);
    if (!this.nativeClone) throw notFound('El clonador nativo no está disponible.');
    if (!secrets.encryptionAvailable()) {
      throw new AppError(
        'Windows no ofrece almacenamiento cifrado para la credencial del clon. Inicia sesión con tu usuario normal y vuelve a intentarlo.',
        400,
        'clone_encryption_unavailable',
      );
    }
    const capabilities = await this.nativeClone.capabilities();
    if (!capabilities.available) {
      throw new AppError(capabilities.error || 'Este equipo no puede preparar cuentas de Windows para clones.', 400, 'clone_unavailable');
    }
    if (this.appLauncher) await this.appLauncher.stopForProfile(profileId);
    let prepared;
    try {
      prepared = await this.nativeClone.prepare(profileId);
    } catch (error) {
      this.addActivity('error', `No se pudo preparar la cuenta del clon para "${profile.name}": ${error.message}`, profileId);
      this.store.save();
      this.emitState();
      throw error;
    }
    const passwordEnc = secrets.seal(prepared.password);
    if (!passwordEnc) {
      throw new AppError('No se pudo cifrar la credencial de la cuenta del clon.', 500, 'clone_encryption_failed');
    }
    const timestamp = nowIso();
    const record = {
      profileId,
      username: prepared.username,
      description: prepared.description,
      sid: prepared.sid,
      passwordEnc,
      preparedAt: prepared.preparedAt || timestamp,
      verifiedAt: null,
      updatedAt: timestamp,
    };
    const existing = (this.state.cloneAccounts || []).find((item) => item.profileId === profileId);
    if (existing) Object.assign(existing, record);
    else this.state.cloneAccounts.push(record);
    this.addActivity('success', `Cuenta de Windows preparada para el perfil "${profile.name}" (${prepared.username}).`, profileId);
    this.saveAndEmit();
    const verification = await this.nativeClone.verify({ username: prepared.username, password: prepared.password });
    if (verification.ok) {
      record.verifiedAt = nowIso();
      this.addActivity('success', `La cuenta del clon de "${profile.name}" inició sesión correctamente.`, profileId);
    } else {
      this.addActivity('warn', `La cuenta del clon de "${profile.name}" se creó, pero la prueba de inicio de sesión falló: ${verification.error}`, profileId);
    }
    record.updatedAt = nowIso();
    this.saveAndEmit();
    return {
      account: this.publicCloneAccount(record),
      verified: Boolean(verification.ok),
      verification,
    };
  }

  async verifyCloneAccount(profileId) {
    const profile = this.requireProfile(profileId);
    if (!this.nativeClone) throw notFound('El clonador nativo no está disponible.');
    const account = this.requireCloneAccount(profileId);
    const password = secrets.open(account.passwordEnc);
    if (!password) {
      throw new AppError('No se pudo leer la credencial de la cuenta. Repara la cuenta del clon.', 409, 'clone_credential_missing');
    }
    const verification = await this.nativeClone.verify({ username: account.username, password });
    if (verification.ok) {
      account.verifiedAt = nowIso();
      account.updatedAt = nowIso();
      this.addActivity('info', `Cuenta del clon de "${profile.name}" verificada.`, profileId);
      this.saveAndEmit();
    } else {
      this.addActivity('warn', `La verificación de la cuenta del clon de "${profile.name}" falló: ${verification.error}`, profileId);
      this.store.save();
      this.emitState();
    }
    return { ...verification, account: this.publicCloneAccount(account) };
  }

  async releaseCloneAccount(profileId) {
    const profile = this.requireProfile(profileId);
    if (!this.nativeClone) throw notFound('El clonador nativo no está disponible.');
    const account = this.requireCloneAccount(profileId);
    if (this.appLauncher) await this.appLauncher.stopForProfile(profileId);
    const result = await this.nativeClone.release({
      profileId,
      username: account.username,
      sid: account.sid,
    });
    this.state.cloneAccounts = this.state.cloneAccounts.filter((item) => item.profileId !== profileId);
    this.addActivity('warn', `Cuenta de Windows del perfil "${profile.name}" eliminada.`, profileId);
    this.saveAndEmit();
    return { ...result, profileId };
  }

  publicProxy(proxy) {
    return {
      id: proxy.id,
      name: proxy.name,
      protocol: proxy.protocol,
      host: proxy.host,
      port: proxy.port,
      username: proxy.username,
      hasPassword: Boolean(proxy.passwordEnc),
      notes: proxy.notes,
      createdAt: proxy.createdAt,
      updatedAt: proxy.updatedAt,
    };
  }

  emitState() {
    this.emit('state', this.getPublicState());
  }

  saveAndEmit() {
    this.store.save();
    this.emitState();
  }

  addActivity(level, message, profileId = null) {
    const state = this.state;
    state.activity.unshift({
      id: crypto.randomUUID(),
      ts: nowIso(),
      level,
      message: String(message).slice(0, 500),
      profileId,
    });
    state.activity = state.activity.slice(0, ACTIVITY_LIMIT);
  }

  requireProfile(profileId) {
    const profile = this.state.profiles.find((item) => item.id === profileId);
    if (!profile) throw notFound('El perfil no existe.');
    return profile;
  }

  requireProxy(proxyId) {
    const proxy = this.state.proxies.find((item) => item.id === proxyId);
    if (!proxy) throw notFound('El proxy no existe.');
    return proxy;
  }

  requireWorkspace(workspaceId) {
    const workspace = this.state.workspaces.find((item) => item.id === workspaceId);
    if (!workspace) throw notFound('El espacio de trabajo no existe.');
    return workspace;
  }

  profileContext() {
    return {
      workspaces: this.state.workspaces,
      proxies: this.state.proxies,
      statuses: this.state.profileStatuses,
      browsers: browsers.detectBrowsers(this.state.settings),
    };
  }

  createProfile(input = {}) {
    const context = this.profileContext();
    const draft = {
      ...input,
      color: input.color || PALETTE[this.state.profiles.length % PALETTE.length],
      browserId: browsers.pickDefaultBrowser(),
    };
    const fields = validation.validateProfileInput(draft, { ...context, isNew: true });
    const timestamp = nowIso();
    const profile = {
      id: crypto.randomUUID(),
      ...fields,
      createdAt: timestamp,
      updatedAt: timestamp,
      lastStartedAt: null,
      lastStoppedAt: null,
    };
    this.state.profiles.push(profile);
    this.addActivity('success', `Perfil "${profile.name}" creado.`, profile.id);
    this.saveAndEmit();
    return profile;
  }

  updateProfile(profileId, input = {}) {
    const profile = this.requireProfile(profileId);
    const context = this.profileContext();
    const fields = validation.validateProfileInput(input, { ...context, existing: profile });
    Object.assign(profile, fields, { updatedAt: nowIso() });
    this.addActivity('info', `Perfil "${profile.name}" actualizado.`, profile.id);
    this.saveAndEmit();
    return profile;
  }

  requireStatus(statusId) {
    const status = this.state.profileStatuses.find((item) => item.id === statusId);
    if (!status) throw notFound('El estado no existe.');
    return status;
  }

  async deleteProfile(profileId, options = {}) {
    const profile = this.requireProfile(profileId);
    const result = await this.removeProfileRecord(profile, options);
    this.addActivity('warn', `Perfil "${profile.name}" eliminado${result.deletedData ? ' con sus datos' : ''}.`, null);
    this.saveAndEmit();
    return result;
  }

  async removeProfileRecord(profile, options = {}) {
    const cloneAccount = (this.state.cloneAccounts || []).find((item) => item.profileId === profile.id);
    if (cloneAccount && !options.releaseCloneAccount) {
      throw conflict('Este perfil tiene una cuenta de Windows para clones. Confirma que también quieres eliminarla para borrar el perfil.');
    }
    const vmRecord = (this.state.virtualMachines || []).find((item) => item.profileId === profile.id);
    if (vmRecord && !options.removeVirtualMachine) {
      throw conflict('Este perfil tiene una máquina virtual. Confirma que también quieres eliminarla y borrar su disco para borrar el perfil.');
    }
    if (this.launcher.isRunning(profile.id)) {
      await this.launcher.stop(profile.id);
    }
    if (this.appLauncher) {
      if (vmRecord) await this.appLauncher.removeVm(profile.id);
      await this.appLauncher.stopForProfile(profile.id);
    }
    if (cloneAccount) await this.releaseCloneAccount(profile.id);
    const index = this.state.profiles.findIndex((item) => item.id === profile.id);
    if (index === -1) throw notFound('El perfil no existe.');
    this.state.profiles.splice(index, 1);
    this.state.appProfileConfigs = this.state.appProfileConfigs.filter((item) => item.profileId !== profile.id);
    if (options.deleteData) {
      this.launcher.removeProfileData(profile);
    }
    return {
      id: profile.id,
      deletedData: Boolean(options.deleteData),
      cloneAccountReleased: Boolean(cloneAccount),
      virtualMachineRemoved: Boolean(vmRecord),
    };
  }

  uniqueProfileName(base) {
    const names = new Set(this.state.profiles.map((profile) => profile.name.toLowerCase()));
    const trimmed = base.slice(0, 80);
    let candidate = trimmed;
    let counter = 2;
    while (names.has(candidate.toLowerCase())) {
      const suffix = ` (${counter})`;
      candidate = `${trimmed.slice(0, 80 - suffix.length)}${suffix}`;
      counter += 1;
    }
    return candidate;
  }

  duplicateProfileRecord(source) {
    const timestamp = nowIso();
    const copy = {
      ...source,
      id: crypto.randomUUID(),
      name: this.uniqueProfileName(`Copia de ${source.name}`),
      createdAt: timestamp,
      updatedAt: timestamp,
      lastStartedAt: null,
      lastStoppedAt: null,
    };
    this.state.profiles.push(copy);
    return copy;
  }

  duplicateProfile(profileId) {
    const source = this.requireProfile(profileId);
    const copy = this.duplicateProfileRecord(source);
    this.addActivity('info', `Perfil "${source.name}" duplicado.`, copy.id);
    this.saveAndEmit();
    return copy;
  }

  async startProfile(profileId) {
    const profile = this.requireProfile(profileId);
    try {
      const status = await this.launcher.start(profileId);
      const proxy = profile.proxyId ? this.state.proxies.find((item) => item.id === profile.proxyId) : null;
      profile.lastStartedAt = status.startedAt;
      profile.updatedAt = nowIso();
      const proxyLabel = !proxy ? 'sin proxy' : status.proxyMode === 'relay' ? `proxy ${proxy.name} (con auth)` : `proxy ${proxy.name}`;
      this.addActivity('success', `Perfil "${profile.name}" iniciado con ${status.browserName} (${proxyLabel}).`, profile.id);
      this.saveAndEmit();
      return status;
    } catch (error) {
      this.addActivity('error', `No se pudo iniciar "${profile.name}": ${error.message}`, profile.id);
      this.store.save();
      this.emitState();
      throw error;
    }
  }

  async stopProfile(profileId) {
    const profile = this.requireProfile(profileId);
    if (!this.launcher.isRunning(profileId)) {
      return { profileId, alreadyStopped: true };
    }
    await this.launcher.stop(profileId);
    profile.lastStoppedAt = nowIso();
    profile.updatedAt = nowIso();
    this.addActivity('info', `Perfil "${profile.name}" detenido.`, profile.id);
    this.saveAndEmit();
    return { profileId, alreadyStopped: false };
  }

  normalizeIdList(value, max = 50) {
    if (!Array.isArray(value)) throw badRequest('Debes indicar una lista de identificadores.');
    const ids = [];
    const seen = new Set();
    for (const item of value) {
      if (typeof item !== 'string' || !item.trim()) throw badRequest('La lista contiene un identificador no válido.');
      const id = item.trim();
      if (id.length > 100) throw badRequest('La lista contiene un identificador no válido.');
      if (seen.has(id)) continue;
      seen.add(id);
      ids.push(id);
    }
    if (!ids.length) throw badRequest('Debes seleccionar al menos un elemento.');
    if (ids.length > max) throw badRequest(`Puedes operar sobre un máximo de ${max} elementos a la vez.`);
    return ids;
  }

  async batchProfiles(input = {}) {
    const action = input.action;
    const actions = new Set([
      'start', 'stop', 'move',
      'add-tags', 'remove-tags', 'set-tags',
      'set-status', 'set-proxy',
      'duplicate', 'delete',
    ]);
    if (!actions.has(action)) {
      throw badRequest('La acción masiva no es válida.');
    }
    const ids = this.normalizeIdList(input.profileIds);
    let workspace = null;
    let tags = null;
    let statusId;
    let proxyId;
    if (action === 'move') {
      if (typeof input.workspaceId !== 'string' || !input.workspaceId.trim()) {
        throw badRequest('Selecciona el espacio de destino.');
      }
      workspace = this.requireWorkspace(input.workspaceId.trim());
    }
    if (action === 'add-tags' || action === 'remove-tags' || action === 'set-tags') {
      tags = validation.normalizeTags(input.tags);
      if (!tags.length) throw badRequest('Escribe al menos una etiqueta.');
    }
    if (action === 'set-status') {
      if (input.statusId === undefined) throw badRequest('Indica el estado que quieres asignar.');
      statusId = input.statusId === '' || input.statusId === null ? null : String(input.statusId).trim();
      if (statusId !== null) {
        if (!statusId) statusId = null;
        else this.requireStatus(statusId);
      }
    }
    if (action === 'set-proxy') {
      if (input.proxyId === undefined) throw badRequest('Indica el proxy que quieres asignar.');
      proxyId = input.proxyId === '' || input.proxyId === null ? null : String(input.proxyId).trim();
      if (proxyId !== null) {
        if (!proxyId) proxyId = null;
        else this.requireProxy(proxyId);
      }
    }

    const results = [];
    let changed = false;
    for (const profileId of ids) {
      const profile = this.state.profiles.find((item) => item.id === profileId);
      if (!profile) {
        results.push({ profileId, name: null, ok: false, error: 'El perfil no existe.' });
        continue;
      }
      try {
        if (action === 'move') {
          if (profile.workspaceId === workspace.id) {
            results.push({ profileId, name: profile.name, ok: true, skipped: true, reason: 'already_in_workspace' });
            continue;
          }
          profile.workspaceId = workspace.id;
          profile.updatedAt = nowIso();
          changed = true;
          results.push({ profileId, name: profile.name, ok: true });
        } else if (action === 'start') {
          if (this.launcher.isRunning(profileId)) {
            results.push({ profileId, name: profile.name, ok: true, skipped: true, reason: 'already_running' });
            continue;
          }
          const status = await this.launcher.start(profileId);
          profile.lastStartedAt = status.startedAt;
          profile.updatedAt = nowIso();
          changed = true;
          results.push({ profileId, name: profile.name, ok: true });
        } else if (action === 'stop') {
          if (!this.launcher.isRunning(profileId)) {
            results.push({ profileId, name: profile.name, ok: true, skipped: true, reason: 'already_stopped' });
            continue;
          }
          await this.launcher.stop(profileId);
          profile.lastStoppedAt = nowIso();
          profile.updatedAt = nowIso();
          changed = true;
          results.push({ profileId, name: profile.name, ok: true });
        } else if (action === 'add-tags') {
          const next = profile.tags.slice();
          const seen = new Set(next.map((tag) => tag.toLowerCase()));
          let added = 0;
          for (const tag of tags) {
            if (next.length >= 10) break;
            const key = tag.toLowerCase();
            if (seen.has(key)) continue;
            seen.add(key);
            next.push(tag);
            added += 1;
          }
          if (!added) {
            results.push({ profileId, name: profile.name, ok: true, skipped: true, reason: 'no_changes' });
            continue;
          }
          profile.tags = next;
          profile.updatedAt = nowIso();
          changed = true;
          results.push({ profileId, name: profile.name, ok: true });
        } else if (action === 'remove-tags') {
          const keys = new Set(tags.map((tag) => tag.toLowerCase()));
          const next = profile.tags.filter((tag) => !keys.has(tag.toLowerCase()));
          if (next.length === profile.tags.length) {
            results.push({ profileId, name: profile.name, ok: true, skipped: true, reason: 'no_changes' });
            continue;
          }
          profile.tags = next;
          profile.updatedAt = nowIso();
          changed = true;
          results.push({ profileId, name: profile.name, ok: true });
        } else if (action === 'set-tags') {
          if (profile.tags.length === tags.length && profile.tags.every((tag, index) => tag === tags[index])) {
            results.push({ profileId, name: profile.name, ok: true, skipped: true, reason: 'no_changes' });
            continue;
          }
          profile.tags = tags.slice();
          profile.updatedAt = nowIso();
          changed = true;
          results.push({ profileId, name: profile.name, ok: true });
        } else if (action === 'set-status') {
          if ((profile.statusId || null) === statusId) {
            results.push({ profileId, name: profile.name, ok: true, skipped: true, reason: 'no_changes' });
            continue;
          }
          profile.statusId = statusId;
          profile.updatedAt = nowIso();
          changed = true;
          results.push({ profileId, name: profile.name, ok: true });
        } else if (action === 'set-proxy') {
          if ((profile.proxyId || null) === proxyId) {
            results.push({ profileId, name: profile.name, ok: true, skipped: true, reason: 'no_changes' });
            continue;
          }
          profile.proxyId = proxyId;
          profile.updatedAt = nowIso();
          changed = true;
          results.push({ profileId, name: profile.name, ok: true });
        } else if (action === 'duplicate') {
          const copy = this.duplicateProfileRecord(profile);
          changed = true;
          results.push({ profileId, name: profile.name, copyId: copy.id, copyName: copy.name, ok: true });
        } else {
          const deleted = await this.removeProfileRecord(profile, {
            deleteData: Boolean(input.deleteData),
            releaseCloneAccount: Boolean(input.releaseCloneAccount),
            removeVirtualMachine: Boolean(input.removeVirtualMachine),
          });
          changed = true;
          results.push({
            profileId,
            name: profile.name,
            ok: true,
            deletedData: deleted.deletedData,
            cloneAccountReleased: deleted.cloneAccountReleased,
            virtualMachineRemoved: deleted.virtualMachineRemoved,
          });
        }
      } catch (error) {
        results.push({ profileId, name: profile.name, ok: false, error: error.message || 'Error inesperado.' });
      }
    }

    const succeeded = results.filter((item) => item.ok && !item.skipped).length;
    const skipped = results.filter((item) => item.skipped).length;
    const failed = results.filter((item) => !item.ok).length;
    const summaries = {
      start: `${succeeded} perfil(es) iniciado(s)`,
      stop: `${succeeded} perfil(es) detenido(s)`,
      move: `${succeeded} perfil(es) movido(s) a "${workspace ? workspace.name : ''}"`,
      'add-tags': `${succeeded} perfil(es) con etiquetas añadidas`,
      'remove-tags': `${succeeded} perfil(es) con etiquetas quitadas`,
      'set-tags': `${succeeded} perfil(es) con etiquetas actualizadas`,
      'set-status': `${succeeded} perfil(es) con estado actualizado`,
      'set-proxy': `${succeeded} perfil(es) con proxy actualizado`,
      duplicate: `${succeeded} perfil(es) duplicado(s)`,
      delete: `${succeeded} perfil(es) eliminado(s)`,
    };
    const level = failed || action === 'delete' ? 'warn' : 'success';
    this.addActivity(level, `Acción masiva: ${summaries[action]}, ${skipped} sin cambios, ${failed} con error.`);
    if (changed) this.saveAndEmit();
    else this.emitState();
    return {
      action,
      results,
      succeeded,
      skipped,
      failed,
      workspaceId: workspace ? workspace.id : null,
      statusId: action === 'set-status' ? statusId : null,
      proxyId: action === 'set-proxy' ? proxyId : null,
      tags: tags || null,
    };
  }

  handleLauncherExit({ profileId, reason, code, signal, error }) {
    const profile = this.state.profiles.find((item) => item.id === profileId);
    if (!profile) {
      this.emitState();
      return;
    }
    profile.lastStoppedAt = nowIso();
    if (reason === 'error') {
      this.addActivity('error', `El navegador de "${profile.name}" falló${error ? `: ${error}` : '.'}`, profile.id);
    } else if (reason === 'exited') {
      const detail = typeof code === 'number' ? `código ${code}` : signal || 'sin código';
      this.addActivity('info', `El navegador de "${profile.name}" se cerró (${detail}).`, profile.id);
    }
    this.saveAndEmit();
  }

  async openProfileFolder(profileId) {
    const profile = this.requireProfile(profileId);
    const dir = paths.resolveProfileDir(this.state.settings, profile.id);
    paths.ensureDir(dir);
    const error = await shell.openPath(dir);
    if (error) throw new AppError(`No se pudo abrir la carpeta: ${error}`, 500, 'open_folder_error');
    return { path: dir };
  }

  requireApp(appId) {
    const app = this.state.apps.find((item) => item.id === appId);
    if (!app) throw notFound('La aplicación no existe en tu biblioteca.');
    return app;
  }

  async discoverApps(force = false) {
    if (!this.appLauncher) return [];
    const detected = await this.appLauncher.detect(Boolean(force));
    const saved = new Set(this.state.apps.map((item) => `${item.kind}:${item.target.toLowerCase()}`));
    return detected.map((item) => ({
      ...item,
      added: saved.has(`${item.kind}:${item.target.toLowerCase()}`),
    }));
  }

  async addDiscoveredApp(target) {
    if (!this.appLauncher) throw notFound('La detección de aplicaciones no está disponible.');
    if (this.state.apps.length >= 500) throw conflict('La biblioteca alcanzó el máximo de 500 aplicaciones.');
    const detected = await this.appLauncher.detect(false);
    const found = detected.find((item) => item.target === target);
    if (!found) throw badRequest('Esa aplicación ya no está disponible en el menú Inicio de Windows.');
    if (this.state.apps.some((item) => item.kind === 'startapp' && item.target === found.target)) {
      throw conflict('Esa aplicación ya está en tu biblioteca.');
    }
    const fields = this.appLauncher.validateAppDraft({
      name: found.name,
      kind: 'startapp',
      target: found.target,
    });
    const timestamp = nowIso();
    const app = {
      id: crypto.randomUUID(),
      ...fields,
      favorite: false,
      source: 'start-menu',
      createdAt: timestamp,
      updatedAt: timestamp,
    };
    this.state.apps.push(app);
    this.addActivity('info', `Aplicación "${app.name}" agregada a la biblioteca.`);
    this.saveAndEmit();
    return app;
  }

  addExecutableApp(filePath, name = '') {
    if (!this.appLauncher) throw notFound('El lanzador de aplicaciones no está disponible.');
    if (this.state.apps.length >= 500) throw conflict('La biblioteca alcanzó el máximo de 500 aplicaciones.');
    const fields = this.appLauncher.validateAppDraft({
      name: String(name || path.basename(filePath, path.extname(filePath))).slice(0, 100),
      kind: 'executable',
      target: filePath,
      cloneMode: 'account',
    });
    if (this.state.apps.some((item) => item.kind === 'executable' && item.target.toLowerCase() === fields.target.toLowerCase())) {
      throw conflict('Ese ejecutable ya está en tu biblioteca.');
    }
    const timestamp = nowIso();
    const app = {
      id: crypto.randomUUID(),
      ...fields,
      favorite: false,
      source: 'manual',
      createdAt: timestamp,
      updatedAt: timestamp,
    };
    this.state.apps.push(app);
    this.addActivity('info', `Aplicación "${app.name}" agregada a la biblioteca.`);
    this.saveAndEmit();
    return app;
  }

  updateApp(appId, input = {}) {
    const app = this.requireApp(appId);
    if (!this.appLauncher) throw notFound('El lanzador de aplicaciones no está disponible.');
    const patch = validation.validateAppPatch(input);
    const fields = this.appLauncher.validateAppDraft(patch, app);
    Object.assign(app, fields, { updatedAt: nowIso() });
    this.addActivity('info', `Aplicación "${app.name}" actualizada.`);
    this.saveAndEmit();
    return app;
  }

  toggleAppFavorite(appId) {
    const app = this.requireApp(appId);
    app.favorite = !app.favorite;
    app.updatedAt = nowIso();
    this.saveAndEmit();
    return app;
  }

  async deleteApp(appId) {
    const app = this.requireApp(appId);
    if (this.appLauncher) await this.appLauncher.stopForApp(app.id);
    this.state.apps = this.state.apps.filter((item) => item.id !== app.id);
    this.state.appProfileConfigs = this.state.appProfileConfigs.filter((item) => item.appId !== app.id);
    this.addActivity('warn', `Aplicación "${app.name}" eliminada de la biblioteca.`);
    this.saveAndEmit();
    return { id: app.id };
  }

  async launchApp(profileId, appId, input = {}) {
    if (!this.appLauncher) throw notFound('El lanzador de aplicaciones no está disponible.');
    const profile = this.requireProfile(profileId);
    const app = this.requireApp(appId);
    const options = validation.validateAppLaunchInput(input);
    const previous = this.state.appProfileConfigs.find((item) => item.profileId === profileId && item.appId === appId);
    const config = {
      profileId,
      appId,
      args: options.args !== undefined ? options.args : (previous ? previous.args : app.args),
      cwd: options.cwd !== undefined ? options.cwd : (previous ? previous.cwd : app.cwd),
      updatedAt: nowIso(),
    };
    if (previous) Object.assign(previous, config);
    else this.state.appProfileConfigs.push(config);
    if (app.kind === 'executable' && app.cloneMode === 'account') {
      const account = (this.state.cloneAccounts || []).find((item) => item.profileId === profileId);
      if (!account) await this.prepareCloneAccount(profileId);
    }
    const result = await this.appLauncher.launch(profileId, appId, {
      arguments: config.args,
      cwd: config.cwd,
    });
    this.saveAndEmit();
    return result;
  }

  async stopApp(instanceId) {
    if (!this.appLauncher) throw notFound('El lanzador de aplicaciones no está disponible.');
    const result = await this.appLauncher.stop(instanceId);
    this.saveAndEmit();
    return result;
  }

  openAppFolder(profileId, appId) {
    const profile = this.requireProfile(profileId);
    const app = this.requireApp(appId);
    if (!this.appLauncher) throw notFound('El lanzador de aplicaciones no está disponible.');
    const dir = this.appLauncher.appDataDir(profile, app.id);
    return { path: dir };
  }

  createProxy(input = {}) {
    const fields = validation.validateProxyInput(input);
    const timestamp = nowIso();
    const proxy = {
      id: crypto.randomUUID(),
      name: fields.name,
      protocol: fields.protocol,
      host: fields.host,
      port: fields.port,
      username: fields.username,
      passwordEnc: fields.password ? secrets.seal(fields.password) : '',
      notes: fields.notes,
      createdAt: timestamp,
      updatedAt: timestamp,
    };
    this.state.proxies.push(proxy);
    this.addActivity('success', `Proxy "${proxy.name}" creado.`);
    this.saveAndEmit();
    return this.publicProxy(proxy);
  }

  updateProxy(proxyId, input = {}) {
    const proxy = this.requireProxy(proxyId);
    const fields = validation.validateProxyInput(input, { existing: proxy });
    let passwordEnc = proxy.passwordEnc;
    if (fields.clearPassword) {
      passwordEnc = '';
    } else if (typeof fields.password === 'string' && fields.password.length > 0) {
      passwordEnc = secrets.seal(fields.password);
    }
    Object.assign(proxy, {
      name: fields.name,
      protocol: fields.protocol,
      host: fields.host,
      port: fields.port,
      username: fields.username,
      notes: fields.notes,
      passwordEnc,
      updatedAt: nowIso(),
    });
    this.addActivity('info', `Proxy "${proxy.name}" actualizado.`);
    this.saveAndEmit();
    return this.publicProxy(proxy);
  }

  deleteProxy(proxyId) {
    const proxy = this.requireProxy(proxyId);
    let updatedProfiles = 0;
    for (const profile of this.state.profiles) {
      if (profile.proxyId === proxyId) {
        profile.proxyId = null;
        profile.updatedAt = nowIso();
        updatedProfiles += 1;
      }
    }
    this.state.proxies = this.state.proxies.filter((item) => item.id !== proxyId);
    this.addActivity('warn', `Proxy "${proxy.name}" eliminado. ${updatedProfiles} perfil(es) quedaron sin proxy.`);
    this.saveAndEmit();
    return { id: proxyId, updatedProfiles };
  }

  async testProxyConnection(input = {}) {
    let stored = null;
    if (input.id) stored = this.requireProxy(input.id);
    const base = stored || {};
    const config = {
      name: input.name || base.name || 'Prueba',
      protocol: input.protocol || base.protocol || 'http',
      host: input.host || base.host,
      port: input.port || base.port,
      username: input.username !== undefined ? input.username : base.username || '',
      notes: '',
    };
    const validated = validation.validateProxyInput(config, { existing: null });
    let password = '';
    if (input.clearPassword) password = '';
    else if (typeof input.password === 'string' && input.password) password = input.password;
    else if (stored) password = secrets.open(stored.passwordEnc);
    const result = await testProxy({ ...validated, password });
    return result;
  }

  async testProxies(input = {}) {
    const requested = input.ids === undefined || input.ids === null
      ? this.state.proxies.map((proxy) => proxy.id)
      : this.normalizeIdList(input.ids);
    if (!requested.length) throw badRequest('No hay proxies para probar.');
    if (requested.length > 50) throw badRequest('Puedes probar un máximo de 50 proxies a la vez.');

    const results = new Array(requested.length);
    const pending = [];
    requested.forEach((proxyId, index) => {
      const proxy = this.state.proxies.find((item) => item.id === proxyId);
      if (!proxy) {
        results[index] = { proxyId, name: null, ok: false, ip: null, latencyMs: null, error: 'El proxy no existe.' };
        return;
      }
      pending.push({ index, proxy });
    });

    let cursor = 0;
    const worker = async () => {
      while (cursor < pending.length) {
        const item = pending[cursor];
        cursor += 1;
        try {
          const result = await this.testProxyConnection({ id: item.proxy.id });
          results[item.index] = {
            proxyId: item.proxy.id,
            name: item.proxy.name,
            ok: Boolean(result.ok),
            ip: result.ip || null,
            latencyMs: Number.isFinite(result.latencyMs) ? result.latencyMs : null,
            error: result.ok ? null : result.error || 'No se pudo conectar.',
          };
        } catch (error) {
          results[item.index] = {
            proxyId: item.proxy.id,
            name: item.proxy.name,
            ok: false,
            ip: null,
            latencyMs: null,
            error: error.message || 'Error inesperado.',
          };
        }
      }
    };
    await Promise.all(Array.from({ length: Math.min(4, pending.length) }, worker));

    const ok = results.filter((item) => item.ok).length;
    this.addActivity(ok === results.length ? 'success' : 'warn', `Prueba de proxies: ${ok} de ${results.length} disponibles.`);
    this.saveAndEmit();
    return { results, total: results.length, ok, failed: results.length - ok };
  }

  listWorkspaces() {
    return this.state.workspaces;
  }

  createWorkspace(input = {}) {
    const fields = validation.validateWorkspaceInput(input, { workspaces: this.state.workspaces });
    const timestamp = nowIso();
    const workspace = { id: crypto.randomUUID(), ...fields, createdAt: timestamp, updatedAt: timestamp };
    this.state.workspaces.push(workspace);
    this.addActivity('info', `Espacio "${workspace.name}" creado.`);
    this.saveAndEmit();
    return workspace;
  }

  updateWorkspace(workspaceId, input = {}) {
    const workspace = this.requireWorkspace(workspaceId);
    const fields = validation.validateWorkspaceInput(input, {
      existing: workspace,
      workspaces: this.state.workspaces,
    });
    Object.assign(workspace, fields, { updatedAt: nowIso() });
    this.addActivity('info', `Espacio "${workspace.name}" actualizado.`);
    this.saveAndEmit();
    return workspace;
  }

  deleteWorkspace(workspaceId) {
    const workspace = this.requireWorkspace(workspaceId);
    if (this.state.workspaces.length <= 1) {
      throw conflict('Debe existir al menos un espacio de trabajo.');
    }
    const count = this.state.profiles.filter((profile) => profile.workspaceId === workspaceId).length;
    if (count > 0) {
      throw conflict(`No se puede eliminar "${workspace.name}" porque contiene ${count} perfil(es). Muévelos primero.`);
    }
    this.state.workspaces = this.state.workspaces.filter((item) => item.id !== workspaceId);
    this.addActivity('warn', `Espacio "${workspace.name}" eliminado.`);
    this.saveAndEmit();
    return { id: workspaceId };
  }

  listStatuses() {
    return this.state.profileStatuses;
  }

  createStatus(input = {}) {
    if (this.state.profileStatuses.length >= STATUS_LIMIT) {
      throw conflict(`Puedes crear un máximo de ${STATUS_LIMIT} estados.`);
    }
    const fields = validation.validateStatusInput(input, { statuses: this.state.profileStatuses });
    const timestamp = nowIso();
    const status = { id: crypto.randomUUID(), ...fields, createdAt: timestamp, updatedAt: timestamp };
    this.state.profileStatuses.push(status);
    this.addActivity('info', `Estado "${status.name}" creado.`);
    this.saveAndEmit();
    return status;
  }

  updateStatus(statusId, input = {}) {
    const status = this.requireStatus(statusId);
    const fields = validation.validateStatusInput(input, {
      existing: status,
      statuses: this.state.profileStatuses,
    });
    Object.assign(status, fields, { updatedAt: nowIso() });
    this.addActivity('info', `Estado "${status.name}" actualizado.`);
    this.saveAndEmit();
    return status;
  }

  deleteStatus(statusId) {
    const status = this.requireStatus(statusId);
    let updatedProfiles = 0;
    for (const profile of this.state.profiles) {
      if (profile.statusId === statusId) {
        profile.statusId = null;
        profile.updatedAt = nowIso();
        updatedProfiles += 1;
      }
    }
    this.state.profileStatuses = this.state.profileStatuses.filter((item) => item.id !== statusId);
    this.addActivity('warn', `Estado "${status.name}" eliminado. ${updatedProfiles} perfil(es) quedaron sin estado.`);
    this.saveAndEmit();
    return { id: statusId, updatedProfiles };
  }

  updateSettings(patch = {}) {
    const validated = validation.validateSettingsPatch(patch, {});
    const settings = this.state.settings;
    const next = {
      ...settings,
      ...validated,
      vm: { ...settings.vm, ...(validated.vm || {}) },
      api: { ...settings.api, ...(validated.api || {}) },
    };
    if (validated.profilesDir) {
      try {
        paths.ensureDir(validated.profilesDir);
        if (!fs.statSync(validated.profilesDir).isDirectory()) throw new Error('no es una carpeta');
      } catch (error) {
        throw badRequest(`No se pudo usar la carpeta de perfiles: ${error.message}`);
      }
    }
    Object.assign(settings, validated, { vm: next.vm, api: next.api });
    this.saveAndEmit();
    return this.getPublicState().settings;
  }

  getApiToken() {
    const settings = this.state.settings;
    let token = secrets.open(settings.api.tokenEnc);
    if (!token) {
      token = secrets.randomToken();
      settings.api.tokenEnc = secrets.seal(token);
      this.store.save();
    }
    return token;
  }

  regenerateApiToken() {
    const token = secrets.randomToken();
    this.state.settings.api.tokenEnc = secrets.seal(token);
    this.addActivity('warn', 'Token de la API local regenerado.');
    this.saveAndEmit();
    return { token };
  }

  clearActivity() {
    this.state.activity = [];
    this.saveAndEmit();
    return { ok: true };
  }

  openProfilesDir() {
    const dir = paths.resolveProfilesDir(this.state.settings);
    paths.ensureDir(dir);
    return dir;
  }

  buildExport(profileIds = null) {
    const selected = Array.isArray(profileIds) && profileIds.length
      ? this.state.profiles.filter((profile) => profileIds.includes(profile.id))
      : this.state.profiles.slice();
    if (!selected.length) throw badRequest('No hay perfiles para exportar.');
    const workspaceIds = new Set(selected.map((profile) => profile.workspaceId));
    const proxyIds = new Set(selected.map((profile) => profile.proxyId).filter(Boolean));
    const statusIds = new Set(selected.map((profile) => profile.statusId).filter(Boolean));
    return {
      format: EXPORT_FORMAT,
      version: 1,
      app: 'PerfilLab',
      exportedAt: nowIso(),
      workspaces: this.state.workspaces
        .filter((workspace) => workspaceIds.has(workspace.id))
        .map((workspace) => ({ name: workspace.name, color: workspace.color })),
      statuses: this.state.profileStatuses
        .filter((status) => statusIds.has(status.id))
        .map((status) => ({ name: status.name, color: status.color })),
      proxies: this.state.proxies
        .filter((proxy) => proxyIds.has(proxy.id))
        .map((proxy) => ({
          name: proxy.name,
          protocol: proxy.protocol,
          host: proxy.host,
          port: proxy.port,
          username: proxy.username,
          notes: proxy.notes,
          requiresPassword: Boolean(proxy.passwordEnc),
        })),
      profiles: selected.map((profile) => {
        const workspace = this.state.workspaces.find((item) => item.id === profile.workspaceId);
        const proxy = profile.proxyId ? this.state.proxies.find((item) => item.id === profile.proxyId) : null;
        const status = profile.statusId ? this.state.profileStatuses.find((item) => item.id === profile.statusId) : null;
        return {
          name: profile.name,
          workspace: workspace ? workspace.name : null,
          status: status ? status.name : null,
          browserId: profile.browserId,
          proxy: proxy ? proxy.name : null,
          startUrls: profile.startUrls,
          tags: profile.tags,
          notes: profile.notes,
          color: profile.color,
        };
      }),
    };
  }

  importData(payload) {
    if (!payload || typeof payload !== 'object') throw badRequest('El archivo no contiene datos válidos.');
    if (payload.format !== EXPORT_FORMAT) throw badRequest('El archivo no es una exportación de PerfilLab.');
    if (Number(payload.version) !== 1) throw badRequest('La versión del archivo no es compatible.');
    if (!Array.isArray(payload.profiles)) throw badRequest('El archivo no contiene perfiles.');
    if (payload.profiles.length > 500) throw badRequest('El archivo contiene demasiados perfiles (máximo 500).');
    if (!payload.profiles.length) throw badRequest('El archivo no contiene perfiles.');

    const availableBrowsers = browsers.detectBrowsers(this.state.settings);
    const fallbackBrowser = browsers.pickDefaultBrowser();
    let workspacesCreated = 0;
    let proxiesCreated = 0;
    let profilesCreated = 0;
    let statusesCreated = 0;

    const workspaceMap = new Map(this.state.workspaces.map((workspace) => [workspace.name.toLowerCase(), workspace.id]));
    for (const item of Array.isArray(payload.workspaces) ? payload.workspaces.slice(0, 200) : []) {
      if (!item || typeof item.name !== 'string' || !item.name.trim()) continue;
      const name = item.name.trim().slice(0, 40);
      const key = name.toLowerCase();
      if (workspaceMap.has(key)) continue;
      const fields = validation.validateWorkspaceInput(
        { name, color: item.color },
        { workspaces: this.state.workspaces },
      );
      const timestamp = nowIso();
      const workspace = { id: crypto.randomUUID(), ...fields, createdAt: timestamp, updatedAt: timestamp };
      this.state.workspaces.push(workspace);
      workspaceMap.set(key, workspace.id);
      workspacesCreated += 1;
    }

    const statusMap = new Map(this.state.profileStatuses.map((status) => [status.name.toLowerCase(), status.id]));
    const ensureStatus = (rawName, rawColor) => {
      const name = typeof rawName === 'string' ? rawName.trim().slice(0, 32) : '';
      if (!name) return null;
      const key = name.toLowerCase();
      if (statusMap.has(key)) return statusMap.get(key);
      if (this.state.profileStatuses.length >= STATUS_LIMIT) return null;
      let fields;
      try {
        fields = validation.validateStatusInput({ name, color: rawColor }, { statuses: this.state.profileStatuses });
      } catch {
        return null;
      }
      const timestamp = nowIso();
      const status = { id: crypto.randomUUID(), ...fields, createdAt: timestamp, updatedAt: timestamp };
      this.state.profileStatuses.push(status);
      statusMap.set(key, status.id);
      statusesCreated += 1;
      return status.id;
    };
    for (const item of Array.isArray(payload.statuses) ? payload.statuses.slice(0, STATUS_LIMIT) : []) {
      if (!item || typeof item.name !== 'string') continue;
      ensureStatus(item.name, item.color);
    }

    const proxyMap = new Map(this.state.proxies.map((proxy) => [proxy.name.toLowerCase(), proxy.id]));
    for (const item of Array.isArray(payload.proxies) ? payload.proxies.slice(0, 200) : []) {
      if (!item || typeof item.name !== 'string' || !item.name.trim()) continue;
      const key = item.name.trim().toLowerCase();
      if (proxyMap.has(key)) continue;
      const fields = validation.validateProxyInput({
        name: item.name,
        protocol: item.protocol,
        host: item.host,
        port: item.port,
        username: item.username,
        notes: item.notes,
      });
      const timestamp = nowIso();
      const proxy = {
        id: crypto.randomUUID(),
        name: fields.name,
        protocol: fields.protocol,
        host: fields.host,
        port: fields.port,
        username: fields.username,
        passwordEnc: '',
        notes: fields.notes,
        createdAt: timestamp,
        updatedAt: timestamp,
      };
      this.state.proxies.push(proxy);
      proxyMap.set(key, proxy.id);
      proxiesCreated += 1;
    }

    for (const item of payload.profiles) {
      if (!item || typeof item !== 'object') continue;
      const name = typeof item.name === 'string' && item.name.trim() ? item.name.trim().slice(0, 80) : 'Perfil importado';
      const workspaceKey = typeof item.workspace === 'string' ? item.workspace.trim().toLowerCase() : '';
      const workspaceId = workspaceMap.get(workspaceKey) || this.state.workspaces[0].id;
      const proxyKey = typeof item.proxy === 'string' ? item.proxy.trim().toLowerCase() : '';
      const proxyId = proxyKey ? proxyMap.get(proxyKey) || null : null;
      const browserId = availableBrowsers.some((browser) => browser.id === item.browserId)
        ? item.browserId
        : fallbackBrowser;
      const timestamp = nowIso();
      const startUrls = validation.normalizeUrls(item.startUrls || []);
      const tags = validation.normalizeTags(item.tags || []);
      const statusId = ensureStatus(item.status);
      const color = /^#[0-9a-fA-F]{6}$/.test(item.color || '') ? item.color.toLowerCase() : PALETTE[this.state.profiles.length % PALETTE.length];
      const profile = {
        id: crypto.randomUUID(),
        name,
        workspaceId,
        browserId,
        proxyId,
        statusId,
        startUrls,
        tags,
        notes: typeof item.notes === 'string' ? item.notes.slice(0, 2000) : '',
        color,
        createdAt: timestamp,
        updatedAt: timestamp,
        lastStartedAt: null,
        lastStoppedAt: null,
      };
      this.state.profiles.push(profile);
      profilesCreated += 1;
    }

    this.addActivity('success', `Importación completada: ${profilesCreated} perfil(es), ${workspacesCreated} espacio(s), ${proxiesCreated} proxy(s), ${statusesCreated} estado(s).`);
    this.saveAndEmit();
    return { profiles: profilesCreated, workspaces: workspacesCreated, proxies: proxiesCreated, statuses: statusesCreated };
  }

  buildCsv(profileIds = null) {
    const selected = Array.isArray(profileIds) && profileIds.length
      ? this.state.profiles.filter((profile) => profileIds.includes(profile.id))
      : this.state.profiles.slice();
    if (!selected.length) throw badRequest('No hay perfiles para exportar.');
    const available = browsers.detectBrowsers(this.state.settings);
    const rows = selected.map((profile) => {
      const workspace = this.state.workspaces.find((item) => item.id === profile.workspaceId);
      const proxy = profile.proxyId ? this.state.proxies.find((item) => item.id === profile.proxyId) : null;
      const status = profile.statusId ? this.state.profileStatuses.find((item) => item.id === profile.statusId) : null;
      const browser = available.find((item) => item.id === profile.browserId);
      return {
        name: profile.name,
        workspace: workspace ? workspace.name : '',
        status: status ? status.name : '',
        browser: browser ? browser.name : profile.browserId || '',
        proxy: proxy ? proxy.name : '',
        startUrls: profile.startUrls,
        tags: profile.tags,
        notes: profile.notes,
        color: profile.color,
      };
    });
    return csv.buildProfilesCsv(rows);
  }

  importCsv(text) {
    const parsed = csv.parseProfilesCsv(text);
    if (!parsed.rows.length) throw badRequest('El CSV no contiene perfiles.');
    const available = browsers.detectBrowsers(this.state.settings);
    const fallbackBrowser = browsers.pickDefaultBrowser();
    if (!fallbackBrowser) throw badRequest('No hay ningún navegador disponible en este equipo.');
    const fallbackBrowserName = (available.find((item) => item.id === fallbackBrowser) || {}).name || fallbackBrowser;

    const workspaceMap = new Map(this.state.workspaces.map((workspace) => [workspace.name.toLowerCase(), workspace.id]));
    const proxyMap = new Map();
    const ambiguousProxyNames = new Set();
    for (const proxy of this.state.proxies) {
      const key = proxy.name.toLowerCase();
      if (proxyMap.has(key)) ambiguousProxyNames.add(key);
      else proxyMap.set(key, proxy.id);
    }
    const errors = [];
    const warnings = [];
    let profilesCreated = 0;
    let workspacesCreated = 0;
    let statusesCreated = 0;
    let skippedProxies = 0;

    const statusMap = new Map(this.state.profileStatuses.map((status) => [status.name.toLowerCase(), status.id]));
    const ensureStatus = (rawName) => {
      const name = String(rawName || '').trim().slice(0, 32);
      if (!name) return null;
      const key = name.toLowerCase();
      if (statusMap.has(key)) return statusMap.get(key);
      if (this.state.profileStatuses.length >= STATUS_LIMIT) return null;
      try {
        const fields = validation.validateStatusInput(
          { name, color: PALETTE[this.state.profileStatuses.length % PALETTE.length] },
          { statuses: this.state.profileStatuses },
        );
        const timestamp = nowIso();
        const status = { id: crypto.randomUUID(), ...fields, createdAt: timestamp, updatedAt: timestamp };
        this.state.profileStatuses.push(status);
        statusMap.set(key, status.id);
        statusesCreated += 1;
        return status.id;
      } catch {
        return null;
      }
    };

    for (const row of parsed.rows) {
      const fail = (message) => {
        if (errors.length < 50) errors.push(`Fila ${row.line}: ${message}`);
      };
      const warn = (message) => {
        if (warnings.length < 50) warnings.push(`Fila ${row.line}: ${message}`);
      };
      try {
        const name = String(row.name || '').trim();
        if (!name) {
          fail('el nombre es obligatorio.');
          continue;
        }
        if (name.length > 80) {
          fail('el nombre supera los 80 caracteres.');
          continue;
        }
        const startUrls = validation.normalizeUrls(csv.splitList(row.startUrls || '', /[\r\n|]+/));
        const tags = validation.normalizeTags(csv.splitList(row.tags || '', /[,;|]+/));

        let color = PALETTE[this.state.profiles.length % PALETTE.length];
        const rawColor = String(row.color || '').trim();
        if (rawColor) {
          if (/^#[0-9a-fA-F]{6}$/.test(rawColor)) color = rawColor.toLowerCase();
          else warn(`el color "${rawColor.slice(0, 20)}" no es válido; se usó el color por defecto.`);
        }

        let workspaceId = this.state.workspaces[0].id;
        const rawWorkspace = String(row.workspace || '').trim().slice(0, 40);
        if (rawWorkspace) {
          const key = rawWorkspace.toLowerCase();
          if (workspaceMap.has(key)) {
            workspaceId = workspaceMap.get(key);
          } else {
            const fields = validation.validateWorkspaceInput({ name: rawWorkspace }, { workspaces: this.state.workspaces });
            const timestamp = nowIso();
            const workspace = { id: crypto.randomUUID(), ...fields, createdAt: timestamp, updatedAt: timestamp };
            this.state.workspaces.push(workspace);
            workspaceMap.set(key, workspace.id);
            workspaceId = workspace.id;
            workspacesCreated += 1;
          }
        }

        let browserId = fallbackBrowser;
        const rawBrowser = String(row.browser || '').trim();
        if (rawBrowser) {
          const key = rawBrowser.toLowerCase();
          const match = available.find((item) => item.id.toLowerCase() === key || item.name.toLowerCase() === key);
          if (match) browserId = match.id;
          else warn(`el navegador "${rawBrowser.slice(0, 40)}" no está disponible; se usó ${fallbackBrowserName}.`);
        }

        let proxyId = null;
        const rawProxy = String(row.proxy || '').trim();
        if (rawProxy) {
          const key = rawProxy.toLowerCase();
          if (ambiguousProxyNames.has(key)) {
            skippedProxies += 1;
            warn(`hay varios proxies llamados "${rawProxy.slice(0, 60)}"; el perfil se importó sin proxy.`);
          } else {
            proxyId = proxyMap.get(key) || null;
            if (!proxyId) {
              skippedProxies += 1;
              warn(`el proxy "${rawProxy.slice(0, 60)}" no existe en este equipo; el perfil se importó sin proxy.`);
            }
          }
        }

        let statusId = null;
        const rawStatus = String(row.status || '').trim();
        if (rawStatus) {
          statusId = ensureStatus(rawStatus);
          if (!statusId) {
            warn(`no se pudo asignar el estado "${rawStatus.slice(0, 32)}"; se alcanzó el límite de ${STATUS_LIMIT} estados.`);
          }
        }

        const fields = validation.validateProfileInput(
          {
            name,
            workspaceId,
            browserId,
            proxyId,
            statusId,
            startUrls,
            tags,
            notes: String(row.notes || '').slice(0, 2000),
            color,
          },
          {
            workspaces: this.state.workspaces,
            proxies: this.state.proxies,
            statuses: this.state.profileStatuses,
            browsers: available,
            isNew: true,
          },
        );
        const timestamp = nowIso();
        this.state.profiles.push({
          id: crypto.randomUUID(),
          ...fields,
          createdAt: timestamp,
          updatedAt: timestamp,
          lastStartedAt: null,
          lastStoppedAt: null,
        });
        profilesCreated += 1;
      } catch (error) {
        fail(error.message || 'no se pudo importar la fila.');
      }
    }

    if (parsed.unknownColumns.length) {
      warnings.push(`Columnas ignoradas: ${parsed.unknownColumns.join(', ')}.`);
    }
    this.addActivity(
      profilesCreated ? 'success' : 'warn',
      `Importación CSV: ${profilesCreated} perfil(es), ${workspacesCreated} espacio(s), ${statusesCreated} estado(s), ${skippedProxies} proxy(s) no encontrados, ${errors.length} fila(s) con error.`,
    );
    this.saveAndEmit();
    return {
      profiles: profilesCreated,
      workspaces: workspacesCreated,
      statuses: statusesCreated,
      skippedProxies,
      warnings,
      errors,
    };
  }
}

module.exports = { AppService, EXPORT_FORMAT };
