'use strict';

const https = require('node:https');
const { HttpsProxyAgent } = require('https-proxy-agent');
const { SocksProxyAgent } = require('socks-proxy-agent');

const TEST_URL = 'https://api.ipify.org?format=json';
const TIMEOUT_MS = 12000;

function formatHost(host) {
  const value = String(host || '').trim();
  if (value.includes(':') && !value.startsWith('[')) return `[${value}]`;
  return value;
}

function buildProxyUrl(proxy) {
  const user = proxy.username ? encodeURIComponent(proxy.username) : '';
  const pass = proxy.password ? encodeURIComponent(proxy.password) : '';
  const auth = user || pass ? `${user}:${pass}@` : '';
  return `${proxy.protocol}://${auth}${formatHost(proxy.host)}:${proxy.port}`;
}

function scrub(message, proxy) {
  let text = String(message || 'Error de conexión.');
  if (proxy && proxy.password) {
    text = text.split(proxy.password).join('***');
    text = text.split(encodeURIComponent(proxy.password)).join('***');
  }
  text = text.replace(/\/\/[^/@\s]+:[^/@\s]+@/g, '//***:***@');
  return text;
}

function friendlyError(error, proxy) {
  const code = error && error.code;
  if (code === 'ETIMEDOUT' || /timeout/i.test(error.message || '')) return 'El proxy no respondió a tiempo.';
  if (code === 'ENOTFOUND') return 'No se pudo resolver el host del proxy.';
  if (code === 'ECONNREFUSED') return 'El proxy rechazó la conexión.';
  if (code === 'ECONNRESET') return 'La conexión con el proxy se interrumpió.';
  if (code === 'CERT_HAS_EXPIRED' || code === 'UNABLE_TO_VERIFY_LEAF_SIGNATURE') return 'El certificado TLS del proxy no es válido.';
  return scrub(error && error.message ? error.message : 'No se pudo conectar con el proxy.', proxy);
}

function testProxy(proxy) {
  return new Promise((resolve) => {
    const started = Date.now();
    let settled = false;
    const finish = (value) => {
      if (settled) return;
      settled = true;
      resolve(value);
    };

    let agent;
    try {
      const url = buildProxyUrl(proxy);
      agent = proxy.protocol === 'socks5'
        ? new SocksProxyAgent(url, { timeout: TIMEOUT_MS })
        : new HttpsProxyAgent(url, { timeout: TIMEOUT_MS });
    } catch (error) {
      finish({ ok: false, error: friendlyError(error, proxy) });
      return;
    }

    let request;
    try {
      request = https.get(TEST_URL, {
        agent,
        timeout: TIMEOUT_MS,
        headers: {
          'User-Agent': 'PerfilLab/1.0',
          Accept: 'application/json',
        },
      }, (response) => {
        let body = '';
        response.setEncoding('utf8');
        response.on('data', (chunk) => {
          body += chunk;
          if (body.length > 20000) {
            request.destroy(new Error('Respuesta del proxy demasiado grande.'));
          }
        });
        response.on('end', () => {
          if (response.statusCode !== 200) {
            finish({ ok: false, error: `El proxy respondió con HTTP ${response.statusCode}.` });
            return;
          }
          try {
            const parsed = JSON.parse(body);
            const ip = typeof parsed.ip === 'string' ? parsed.ip.trim() : '';
            if (!/^[0-9a-fA-F:.]{3,45}$/.test(ip)) {
              finish({ ok: false, error: 'El proxy respondió, pero no devolvió una IP válida.' });
              return;
            }
            finish({ ok: true, ip, latencyMs: Date.now() - started });
          } catch {
            finish({ ok: false, error: 'La respuesta del proxy no es JSON válido.' });
          }
        });
      });
    } catch (error) {
      finish({ ok: false, error: friendlyError(error, proxy) });
      return;
    }

    request.on('timeout', () => {
      request.destroy(new Error('timeout'));
    });
    request.on('error', (error) => {
      finish({ ok: false, error: friendlyError(error, proxy) });
    });
  });
}

module.exports = { testProxy, buildProxyUrl };
