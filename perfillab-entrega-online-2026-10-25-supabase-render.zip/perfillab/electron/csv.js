'use strict';

const { badRequest } = require('./errors');

const MAX_CSV_CHARS = 5 * 1024 * 1024;
const MAX_CSV_ROWS = 500;
const MAX_CSV_COLUMNS = 40;
const BOM = '\uFEFF';

const PROFILE_COLUMNS = [
  { key: 'name', label: 'Nombre', aliases: ['nombre', 'name', 'perfil', 'profile'] },
  { key: 'workspace', label: 'Espacio', aliases: ['espacio', 'espacio de trabajo', 'grupo', 'group', 'workspace'] },
  { key: 'status', label: 'Estado', aliases: ['estado', 'status'] },
  { key: 'browser', label: 'Navegador', aliases: ['navegador', 'browser'] },
  { key: 'proxy', label: 'Proxy', aliases: ['proxy'] },
  { key: 'startUrls', label: 'URLs', aliases: ['urls', 'urls de inicio', 'start urls', 'start_urls', 'starturls'] },
  { key: 'tags', label: 'Etiquetas', aliases: ['etiquetas', 'tags'] },
  { key: 'notes', label: 'Notas', aliases: ['notas', 'notes'] },
  { key: 'color', label: 'Color', aliases: ['color', 'colour'] },
];

function normalizeHeader(value) {
  return String(value)
    .replace(/^\uFEFF/, '')
    .trim()
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/\s+/g, ' ');
}

const ALIAS_MAP = new Map();
for (const column of PROFILE_COLUMNS) {
  for (const alias of [column.label, ...column.aliases]) {
    ALIAS_MAP.set(normalizeHeader(alias), column.key);
  }
}

const FORMULA_PREFIX = /^[=+\-@\t\r]/;

function escapeField(value) {
  let text = value === undefined || value === null ? '' : String(value);
  if (FORMULA_PREFIX.test(text)) text = `'${text}`;
  if (/[",\r\n]/.test(text) || text !== text.trim()) {
    return `"${text.replace(/"/g, '""')}"`;
  }
  return text;
}

function parseCsv(text) {
  if (typeof text !== 'string' || !text.trim()) throw badRequest('El archivo CSV está vacío.');
  if (text.length > MAX_CSV_CHARS) throw badRequest('El archivo CSV supera los 5 MB.');
  const source = text.charCodeAt(0) === 0xfeff ? text.slice(1) : text;
  const rows = [];
  let fields = [];
  let field = '';
  let cellStarted = false;
  let inQuotes = false;
  let line = 1;
  let rowLine = 1;
  let i = 0;

  const endRow = () => {
    fields.push(field);
    rows.push({ line: rowLine, values: fields });
    fields = [];
    field = '';
    cellStarted = false;
    rowLine = line;
  };

  while (i < source.length) {
    const ch = source[i];
    if (inQuotes) {
      if (ch === '"') {
        if (source[i + 1] === '"') {
          field += '"';
          i += 2;
          continue;
        }
        inQuotes = false;
        i += 1;
        continue;
      }
      if (ch === '\r' || ch === '\n') {
        if (ch === '\r' && source[i + 1] === '\n') i += 1;
        field += '\n';
        line += 1;
        i += 1;
        continue;
      }
      field += ch;
      i += 1;
      continue;
    }
    if (ch === '"' && !cellStarted) {
      inQuotes = true;
      cellStarted = true;
      i += 1;
      continue;
    }
    if (ch === ',') {
      fields.push(field);
      field = '';
      cellStarted = false;
      i += 1;
      continue;
    }
    if (ch === '\r' || ch === '\n') {
      if (ch === '\r' && source[i + 1] === '\n') i += 1;
      endRow();
      line += 1;
      rowLine = line;
      i += 1;
      continue;
    }
    field += ch;
    cellStarted = true;
    i += 1;
  }
  if (inQuotes) throw badRequest('El CSV tiene comillas sin cerrar.');
  if (cellStarted || field !== '' || fields.length) endRow();
  return rows.filter((row) => row.values.some((value) => value.trim() !== ''));
}

function parseProfilesCsv(text) {
  const rows = parseCsv(text);
  if (rows.length < 1) throw badRequest('El archivo CSV está vacío.');
  if (rows.length > MAX_CSV_ROWS + 1) throw badRequest(`El CSV supera el máximo de ${MAX_CSV_ROWS} perfiles.`);
  const header = rows[0];
  if (header.values.length > MAX_CSV_COLUMNS) throw badRequest('El CSV tiene demasiadas columnas.');
  const mapping = [];
  const unknownColumns = [];
  const seen = new Set();
  header.values.forEach((raw, index) => {
    const key = ALIAS_MAP.get(normalizeHeader(raw));
    if (!key) {
      const name = String(raw).trim();
      if (name) unknownColumns.push(name.slice(0, 60));
      return;
    }
    if (seen.has(key)) throw badRequest(`La columna "${PROFILE_COLUMNS.find((item) => item.key === key).label}" está repetida.`);
    seen.add(key);
    mapping.push({ index, key });
  });
  if (!seen.has('name')) throw badRequest('El CSV debe incluir una columna "Nombre".');

  const records = rows.slice(1).map((row) => {
    const record = { line: row.line };
    for (const { index, key } of mapping) {
      const raw = row.values[index] === undefined ? '' : row.values[index];
      record[key] = raw.startsWith("'") && FORMULA_PREFIX.test(raw.slice(1)) ? raw.slice(1) : raw;
    }
    return record;
  });
  return { rows: records, unknownColumns, columns: mapping.map((item) => item.key) };
}

function buildProfilesCsv(profiles) {
  if (!Array.isArray(profiles) || !profiles.length) throw badRequest('No hay perfiles para exportar.');
  const lines = [PROFILE_COLUMNS.map((column) => escapeField(column.label)).join(',')];
  for (const profile of profiles) {
    const values = PROFILE_COLUMNS.map((column) => {
      const value = profile[column.key];
      if (column.key === 'startUrls') return escapeField(Array.isArray(value) ? value.join(' | ') : value);
      if (column.key === 'tags') return escapeField(Array.isArray(value) ? value.join(', ') : value);
      return escapeField(value);
    });
    lines.push(values.join(','));
  }
  return `${BOM}${lines.join('\r\n')}\r\n`;
}

function splitList(value, separator) {
  if (typeof value !== 'string') return [];
  return value.split(separator).map((entry) => entry.trim()).filter(Boolean);
}

module.exports = {
  MAX_CSV_ROWS,
  PROFILE_COLUMNS,
  parseCsv,
  parseProfilesCsv,
  buildProfilesCsv,
  splitList,
  escapeField,
};
