'use strict';

const crypto = require('node:crypto');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { EventEmitter } = require('node:events');
const { execFile, spawn } = require('node:child_process');
const { AppError, badRequest } = require('./errors');
const { buildElevatedLauncher, findPowerShell, UAC_CANCELLED } = require('./native-clone');

const VM_PREFIX = 'PL-';
const VM_RE = /^PL-[0-9a-f]{12}$/;
const CAPABILITIES_TTL_MS = 60000;
const MAX_OUTPUT = 4 * 1024 * 1024;
const DEFAULT_SWITCH = 'Default Switch';
const DEFAULT_MEMORY_MB = 4096;
const DEFAULT_CPU = 2;
const MIN_MEMORY_MB = 1024;
const MAX_MEMORY_MB = 32768;
const MIN_CPU = 1;
const MAX_CPU = 16;

function nowIso() {
  return new Date().toISOString();
}

function vmName(profileId) {
  if (typeof profileId !== 'string' || !profileId) throw badRequest('El perfil no es válido.');
  const hash = crypto.createHash('sha256').update(profileId, 'utf8').digest('hex');
  return `${VM_PREFIX}${hash.slice(0, 12)}`;
}

function encodePowerShell(script) {
  return Buffer.from(String(script), 'utf16le').toString('base64');
}

function psQuote(value) {
  return `'${String(value).replace(/'/g, "''")}'`;
}

function defaultBaseDir(env = process.env) {
  const local = env.LOCALAPPDATA || path.join(os.homedir(), 'AppData', 'Local');
  return path.join(local, 'PerfilLab', 'hyperv');
}

function defaultDisksDir(env = process.env) {
  return path.join(path.dirname(defaultBaseDir(env)), 'vms');
}

function requireAbsolute(value, label) {
  const text = String(value || '').trim();
  if (!text || !path.isAbsolute(text) || text.includes('\0')) {
    throw badRequest(`${label} debe ser una ruta absoluta válida.`);
  }
  return text;
}

function clampInt(value, fallback, min, max) {
  const number = Number(value);
  if (!Number.isInteger(number)) return fallback;
  return Math.min(max, Math.max(min, number));
}

function buildVmScript(requestPath, resultPath) {
  return String.raw`$ErrorActionPreference = 'Stop'
$request = Get-Content -LiteralPath ${psQuote(requestPath)} -Raw -Encoding UTF8 | ConvertFrom-Json
$resultPath = ${psQuote(resultPath)}
$result = @{ ok = $false }
try {
    Import-Module Hyper-V -ErrorAction Stop
    $name = [string]$request.vmName
    if (-not $name) { throw 'El nombre de la maquina virtual no es valido.' }
    $action = [string]$request.action
    if ($action -eq 'ensure') {
        $vm = Get-VM -Name $name -ErrorAction SilentlyContinue
        $created = $false
        if (-not $vm) {
            $base = [string]$request.baseImage
            if (-not (Test-Path -LiteralPath $base)) { throw "No se encontro la imagen base: $base" }
            $disk = [string]$request.diskPath
            $diskDir = Split-Path -Parent $disk
            if (-not (Test-Path -LiteralPath $diskDir)) { New-Item -ItemType Directory -Path $diskDir -Force | Out-Null }
            if (-not (Test-Path -LiteralPath $disk)) { New-VHD -Path $disk -ParentPath $base -Differencing | Out-Null }
            $vmDir = [string]$request.vmDir
            if (-not (Test-Path -LiteralPath $vmDir)) { New-Item -ItemType Directory -Path $vmDir -Force | Out-Null }
            $memory = [int64]$request.memoryMb * 1MB
            $minimum = [int64]($request.memoryMb / 2) * 1MB
            New-VM -Name $name -MemoryStartupBytes $memory -VHDPath $disk -Path $vmDir -Generation ([int]$request.generation) | Out-Null
            Set-VMProcessor -VMName $name -Count ([int]$request.cpuCount)
            Set-VMMemory -VMName $name -DynamicMemoryEnabled $true -MinimumBytes $minimum -MaximumBytes $memory
            Set-VM -Name $name -AutomaticCheckpointsEnabled $false
            if ($request.switchName) {
                $sw = Get-VMSwitch -Name ([string]$request.switchName) -ErrorAction SilentlyContinue
                if ($sw) { Connect-VMNetworkAdapter -VMName $name -SwitchName $sw.Name }
                else { $result.warning = "El conmutador virtual no existe; la maquina quedo sin red." }
            }
            $created = $true
        }
        $vm = Get-VM -Name $name
        if ($request.start -and $vm.State -ne 'Running') {
            Start-VM -Name $name
            $vm = Get-VM -Name $name
            $result.started = $true
        }
        $result.vmName = $name
        $result.state = [string]$vm.State
        $result.created = $created
        $result.ok = $true
    } elseif ($action -eq 'start') {
        $vm = Get-VM -Name $name -ErrorAction SilentlyContinue
        if (-not $vm) { throw "La maquina virtual no existe." }
        if ($vm.State -ne 'Running') { Start-VM -Name $name }
        $result.vmName = $name
        $result.state = 'Running'
        $result.ok = $true
    } elseif ($action -eq 'stop') {
        $vm = Get-VM -Name $name -ErrorAction SilentlyContinue
        if ($vm) {
            if ($vm.State -ne 'Off') {
                $saved = $false
                try { Stop-VM -Name $name -Save -ErrorAction Stop; $saved = $true }
                catch { Stop-VM -Name $name -TurnOff -ErrorAction SilentlyContinue }
                $result.saved = $saved
            }
            $result.state = 'Off'
        } else { $result.state = 'Missing' }
        $result.vmName = $name
        $result.ok = $true
    } elseif ($action -eq 'stopall') {
        $stopped = 0
        foreach ($item in @($request.vmNames)) {
            $target = [string]$item
            if (-not $target) { continue }
            $vm = Get-VM -Name $target -ErrorAction SilentlyContinue
            if (-not $vm) { continue }
            if ($vm.State -ne 'Off') {
                try { Stop-VM -Name $target -Save -ErrorAction Stop }
                catch { Stop-VM -Name $target -TurnOff -ErrorAction SilentlyContinue }
                $stopped += 1
            }
        }
        $result.stopped = $stopped
        $result.ok = $true
    } elseif ($action -eq 'remove') {
        $vm = Get-VM -Name $name -ErrorAction SilentlyContinue
        if ($vm) {
            if ($vm.State -ne 'Off') { Stop-VM -Name $name -Force -ErrorAction SilentlyContinue }
            Remove-VM -Name $name -Force
        }
        $disk = [string]$request.diskPath
        if ($disk -and (Test-Path -LiteralPath $disk)) { Remove-Item -LiteralPath $disk -Force -ErrorAction SilentlyContinue }
        $result.vmName = $name
        $result.state = 'Removed'
        $result.ok = $true
    } elseif ($action -eq 'list') {
        $items = @()
        foreach ($vm in (Get-VM)) {
            $items += @{ name = [string]$vm.Name; state = [string]$vm.State }
        }
        $result.items = $items
        $result.ok = $true
    } elseif ($action -eq 'switches') {
        $items = @()
        foreach ($sw in (Get-VMSwitch)) {
            $items += @{ name = [string]$sw.Name; type = [string]$sw.SwitchType }
        }
        $result.items = $items
        $result.ok = $true
    } else {
        throw "Accion no reconocida."
    }
} catch {
    $result.ok = $false
    $result.error = $_.Exception.Message
}
$result | ConvertTo-Json -Compress -Depth 6 | Set-Content -LiteralPath $resultPath -Encoding UTF8
if (-not $result.ok) { exit 1 }`;
}

function readJsonFile(file) {
  try {
    const text = fs.readFileSync(file, 'utf8').replace(/^\uFEFF/, '');
    return JSON.parse(text);
  } catch {
    return null;
  }
}

class HyperVProvider extends EventEmitter {
  constructor(options = {}) {
    super();
    this.platform = options.platform || process.platform;
    this.env = options.env || process.env;
    this.baseDir = options.baseDir || defaultBaseDir(this.env);
    this.powershellPath = options.powershellPath || findPowerShell(this.env);
    this.execFileImpl = options.execFileImpl || execFile;
    this.spawnImpl = options.spawnImpl || spawn;
    this.capabilitiesCache = null;
    this.capabilitiesAt = 0;
    this.windows = new Map();
    this.tasks = new Map();
    this.cleanupStarted = false;
  }

  ensureSupported() {
    if (this.platform !== 'win32') {
      throw new AppError('Las máquinas virtuales solo están disponibles en Windows.', 400, 'vm_unsupported');
    }
  }

  snapshot() {
    if (this.capabilitiesCache) return { ...this.capabilitiesCache };
    return {
      available: false,
      checked: false,
      platform: this.platform,
      error: this.platform === 'win32' ? null : 'Disponible solo en Windows.',
      windows: this.listWindows(),
    };
  }

  async capabilities(force = false) {
    if (this.platform !== 'win32') {
      this.capabilitiesCache = {
        available: false,
        checked: true,
        platform: this.platform,
        hypervisor: false,
        vmms: '',
        module: false,
        ramGb: 0,
        windows: this.listWindows(),
        error: 'Las máquinas virtuales solo están disponibles en Windows.',
        checkedAt: nowIso(),
      };
      this.capabilitiesAt = Date.now();
      return this.snapshot();
    }
    if (!force && this.capabilitiesCache && Date.now() - this.capabilitiesAt < CAPABILITIES_TTL_MS) {
      return this.snapshot();
    }
    const script = [
      '[Console]::OutputEncoding = New-Object System.Text.UTF8Encoding($false)',
      '$ErrorActionPreference = "Stop"',
      '$module = [bool](Get-Command Get-VM -ErrorAction SilentlyContinue)',
      '$vmms = Get-Service -Name vmms -ErrorAction SilentlyContinue',
      '$cs = Get-CimInstance Win32_ComputerSystem -ErrorAction SilentlyContinue',
      '$os = Get-CimInstance Win32_OperatingSystem -ErrorAction SilentlyContinue',
      '$admin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)',
      '@{',
      '  module = $module',
      '  vmms = if ($vmms) { [string]$vmms.Status } else { "" }',
      '  hypervisor = if ($cs) { [bool]$cs.HypervisorPresent } else { $false }',
      '  admin = $admin',
      '  os = if ($os) { [string]$os.Caption } else { "" }',
      '  version = if ($os) { [string]$os.Version } else { "" }',
      '  ramGb = if ($cs) { [math]::Round($cs.TotalPhysicalMemory / 1GB, 1) } else { 0 }',
      '} | ConvertTo-Json -Compress',
    ].join('\n');
    let parsed;
    try {
      const execution = await this.execFileAsync(this.powershellPath, [
        '-NoLogo',
        '-NoProfile',
        '-NonInteractive',
        '-ExecutionPolicy',
        'Bypass',
        '-EncodedCommand',
        encodePowerShell(script),
      ], { timeout: 15000 });
      if (execution.exitCode !== 0) throw new Error(execution.stderr || 'PowerShell terminó con error.');
      parsed = JSON.parse(execution.stdout.replace(/^\uFEFF/, '').trim());
    } catch (error) {
      this.capabilitiesCache = {
        available: false,
        checked: true,
        platform: this.platform,
        hypervisor: false,
        vmms: '',
        module: false,
        ramGb: 0,
        windows: this.listWindows(),
        error: `No se pudo consultar Hyper-V: ${error.message}`,
        checkedAt: nowIso(),
      };
      this.capabilitiesAt = Date.now();
      return this.snapshot();
    }
    const available = parsed.module === true
      && parsed.hypervisor === true
      && String(parsed.vmms || '').toLowerCase() === 'running';
    let error = null;
    if (!parsed.module) error = 'La característica Hyper-V no está habilitada en este equipo.';
    else if (!parsed.hypervisor) error = 'El hipervisor no está activo. Activa Hyper-V y reinicia Windows.';
    else if (String(parsed.vmms || '').toLowerCase() !== 'running') error = 'El servicio de Hyper-V (vmms) no está en ejecución.';
    this.capabilitiesCache = {
      available,
      checked: true,
      platform: this.platform,
      module: parsed.module === true,
      hypervisor: parsed.hypervisor === true,
      vmms: typeof parsed.vmms === 'string' ? parsed.vmms : '',
      elevated: parsed.admin === true,
      os: typeof parsed.os === 'string' ? parsed.os : '',
      version: typeof parsed.version === 'string' ? parsed.version : '',
      ramGb: Number(parsed.ramGb) || 0,
      windows: this.listWindows(),
      error,
      checkedAt: nowIso(),
    };
    this.capabilitiesAt = Date.now();
    return this.snapshot();
  }

  async listSwitches() {
    const result = await this.elevatedAction('switches', {}, 45000);
    return Array.isArray(result.items) ? result.items : [];
  }

  async listMachines() {
    const result = await this.elevatedAction('list', {}, 45000);
    return Array.isArray(result.items) ? result.items : [];
  }

  resolvePaths(profileId, settings = {}) {
    const name = vmName(profileId);
    const disksDir = settings.disksDir ? requireAbsolute(settings.disksDir, 'La carpeta de discos') : defaultDisksDir(this.env);
    return {
      vmName: name,
      diskPath: path.join(disksDir, `${name}.vhdx`),
      vmDir: path.join(disksDir, name),
    };
  }

  async ensure(profileId, settings = {}, options = {}) {
    this.ensureSupported();
    const capabilities = await this.capabilities();
    if (!capabilities.available) {
      throw new AppError(capabilities.error || 'Hyper-V no está disponible en este equipo.', 400, 'vm_unavailable');
    }
    const baseImage = requireAbsolute(settings.baseImagePath, 'La imagen base');
    if (path.extname(baseImage).toLowerCase() !== '.vhdx') {
      throw badRequest('La imagen base debe ser un archivo .vhdx.');
    }
    if (!fs.existsSync(baseImage) || !fs.statSync(baseImage).isFile()) {
      throw badRequest('No se encontró la imagen base de la máquina virtual.');
    }
    const paths = this.resolvePaths(profileId, settings);
    const payload = {
      vmName: paths.vmName,
      baseImage,
      diskPath: paths.diskPath,
      vmDir: paths.vmDir,
      switchName: String(settings.switchName || DEFAULT_SWITCH).slice(0, 100),
      memoryMb: clampInt(settings.memoryMb, DEFAULT_MEMORY_MB, MIN_MEMORY_MB, MAX_MEMORY_MB),
      cpuCount: clampInt(settings.cpuCount, DEFAULT_CPU, MIN_CPU, MAX_CPU),
      generation: Number(settings.generation) === 1 ? 1 : 2,
      start: Boolean(options.start),
    };
    const result = await this.elevatedAction('ensure', payload, 180000);
    return { ...result, diskPath: paths.diskPath, vmName: paths.vmName };
  }

  async start(profileId) {
    this.ensureSupported();
    const name = vmName(profileId);
    return this.elevatedAction('start', { vmName: name }, 120000);
  }

  async stop(profileId) {
    this.ensureSupported();
    const name = vmName(profileId);
    const result = await this.elevatedAction('stop', { vmName: name }, 90000);
    this.closeWindow(profileId);
    return result;
  }

  async remove(profileId, diskPath) {
    this.ensureSupported();
    const name = vmName(profileId);
    const result = await this.elevatedAction('remove', {
      vmName: name,
      diskPath: diskPath ? requireAbsolute(diskPath, 'La ruta del disco') : '',
    }, 120000);
    this.closeWindow(profileId);
    return result;
  }

  async stopAll(profileIds = []) {
    this.ensureSupported();
    const vmNames = profileIds.map((profileId) => vmName(profileId));
    if (!vmNames.length) return { stopped: 0 };
    const result = await this.elevatedAction('stopall', { vmNames }, 180000);
    for (const profileId of profileIds) this.closeWindow(profileId);
    return result;
  }

  openWindow(profileId, profileName, name) {
    this.ensureSupported();
    const existing = this.windows.get(profileId);
    if (existing) return { pid: existing.pid, startedAt: existing.startedAt, reused: true };
    const root = this.env.SystemRoot || this.env.windir || 'C:\\Windows';
    const executable = path.join(root, 'System32', 'vmconnect.exe');
    if (!fs.existsSync(executable)) {
      throw new AppError('No se encontró vmconnect.exe en este equipo.', 500, 'vm_window_missing');
    }
    const child = this.spawnImpl(executable, ['localhost', name], {
      windowsHide: false,
      detached: false,
      stdio: 'ignore',
    });
    const entry = {
      profileId,
      profileName,
      vmName: name,
      pid: child.pid,
      startedAt: nowIso(),
    };
    this.windows.set(profileId, entry);
    child.once('error', (error) => {
      if (this.windows.get(profileId) === entry) this.windows.delete(profileId);
      this.emit('window-error', { ...entry, message: error.message });
    });
    child.once('exit', (code, signal) => {
      if (this.windows.get(profileId) !== entry) return;
      this.windows.delete(profileId);
      this.emit('window-exit', { ...entry, code, signal });
    });
    this.emit('window-open', entry);
    return { pid: child.pid, startedAt: entry.startedAt, reused: false };
  }

  hasWindow(profileId) {
    return this.windows.has(profileId);
  }

  closeWindow(profileId) {
    const entry = this.windows.get(profileId);
    if (!entry) return;
    this.windows.delete(profileId);
    if (!Number.isInteger(entry.pid) || entry.pid <= 0) return;
    try {
      this.spawnImpl('taskkill', ['/PID', String(entry.pid), '/T', '/F'], { windowsHide: true, stdio: 'ignore' });
    } catch {
      // best effort al cerrar la ventana
    }
  }

  closeAllWindows() {
    for (const profileId of [...this.windows.keys()]) this.closeWindow(profileId);
  }

  listWindows() {
    return [...this.windows.values()].map((entry) => ({ ...entry }));
  }

  async run(profileId, task) {
    const previous = this.tasks.get(profileId) || Promise.resolve();
    const next = previous.catch(() => {}).then(task);
    this.tasks.set(profileId, next);
    try {
      return await next;
    } finally {
      if (this.tasks.get(profileId) === next) this.tasks.delete(profileId);
    }
  }

  async elevatedAction(action, payload, timeoutMs = 90000) {
    this.ensureSupported();
    this.cleanupStaleTemps();
    fs.mkdirSync(this.baseDir, { recursive: true });
    const tempDir = fs.mkdtempSync(path.join(this.baseDir, 'op-'));
    const requestPath = path.join(tempDir, 'request.json');
    const resultPath = path.join(tempDir, 'result.json');
    try {
      fs.writeFileSync(requestPath, JSON.stringify({ ...payload, action }), { encoding: 'utf8', mode: 0o600, flag: 'wx' });
      const childScript = buildVmScript(requestPath, resultPath);
      const outerScript = buildElevatedLauncher(childScript, this.powershellPath);
      const execution = await this.execFileAsync(this.powershellPath, [
        '-NoLogo',
        '-NoProfile',
        '-NonInteractive',
        '-ExecutionPolicy',
        'Bypass',
        '-EncodedCommand',
        encodePowerShell(outerScript),
      ], { timeout: timeoutMs });
      const result = readJsonFile(resultPath);
      if (execution.exitCode === UAC_CANCELLED) {
        throw new AppError('Cancelaste la solicitud de permisos de administrador. La operación no se realizó.', 400, 'uac_cancelled');
      }
      if (execution.timedOut) {
        throw new AppError('Windows tardó demasiado en completar la operación de Hyper-V.', 504, 'vm_timeout');
      }
      if (!result) {
        const detail = String(execution.stderr || '').replace(/\s+/g, ' ').trim();
        throw new AppError(detail.slice(0, 400) || 'Windows no completó la operación de Hyper-V con permisos de administrador.', 500, 'vm_elevation_failed');
      }
      if (result.ok !== true) {
        throw new AppError(String(result.error || 'Windows no pudo completar la operación de Hyper-V.').slice(0, 500), 500, 'vm_operation_failed');
      }
      return result;
    } finally {
      try {
        fs.rmSync(tempDir, { recursive: true, force: true });
      } catch {
        // Windows puede mantener el archivo abierto; se limpia en la próxima ejecución.
      }
    }
  }

  cleanupStaleTemps() {
    if (this.cleanupStarted) return;
    this.cleanupStarted = true;
    try {
      if (!fs.existsSync(this.baseDir)) return;
      const cutoff = Date.now() - 60 * 60 * 1000;
      for (const entry of fs.readdirSync(this.baseDir, { withFileTypes: true })) {
        if (!entry.isDirectory() || !entry.name.startsWith('op-')) continue;
        const full = path.join(this.baseDir, entry.name);
        try {
          if (fs.statSync(full).mtimeMs < cutoff) fs.rmSync(full, { recursive: true, force: true });
        } catch {
          // best effort
        }
      }
    } catch {
      // best effort
    }
  }

  execFileAsync(file, args, options = {}) {
    return new Promise((resolve, reject) => {
      this.execFileImpl(file, args, {
        windowsHide: true,
        maxBuffer: MAX_OUTPUT,
        encoding: 'utf8',
        ...options,
      }, (error, stdout, stderr) => {
        if (error && typeof error.code !== 'number') {
          reject(error);
          return;
        }
        resolve({
          exitCode: error && typeof error.code === 'number' ? error.code : 0,
          timedOut: Boolean(error && error.killed),
          stdout: String(stdout || ''),
          stderr: String(stderr || ''),
        });
      });
    });
  }
}

module.exports = {
  HyperVProvider,
  vmName,
  buildVmScript,
  defaultBaseDir,
  defaultDisksDir,
  VM_RE,
  VM_PREFIX,
  DEFAULT_SWITCH,
  DEFAULT_MEMORY_MB,
  DEFAULT_CPU,
  MIN_MEMORY_MB,
  MAX_MEMORY_MB,
  MIN_CPU,
  MAX_CPU,
};
