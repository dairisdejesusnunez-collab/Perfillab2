'use strict';

const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const paths = require('./paths');
const secrets = require('./secrets');
const { accountName, accountDescription, ACCOUNT_RE, SID_RE } = require('./native-clone');
const {
  vmName,
  DEFAULT_SWITCH,
  DEFAULT_MEMORY_MB,
  DEFAULT_CPU,
  MIN_MEMORY_MB,
  MAX_MEMORY_MB,
  MIN_CPU,
  MAX_CPU,
} = require('./hyperv');
const { AppError } = require('./errors');
const { BUILTIN_BROWSER_ID } = require('./browser-launch');

const SCHEMA_VERSION = 7;
// Desde el esquema v5 el modo por defecto de una aplicación .exe es "account".
const MIGRATION_ACCOUNT_SINCE = 5;
const DEFAULT_API_PORT = 45800;
const ACTIVITY_LIMIT = 200;
const APP_LIMIT = 500;
const STATUS_LIMIT = 30;
const PALETTE = ['#5b6cff', '#8b5cf6', '#0ea5e9', '#14b8a6', '#f59e0b', '#ef4444', '#ec4899', '#22c55e'];
const DEFAULT_STATUSES = [
  { name: 'Nuevo', color: '#5b6cff' },
  { name: 'En uso', color: '#22c55e' },
  { name: 'Pausado', color: '#f59e0b' },
];

function nowIso() {
  return new Date().toISOString();
}

function defaultSettings() {
  return {
    theme: 'system',
    closeToTray: true,
    profilesDir: '',
    vm: {
      baseImagePath: '',
      switchName: DEFAULT_SWITCH,
      memoryMb: DEFAULT_MEMORY_MB,
      cpuCount: DEFAULT_CPU,
      disksDir: '',
      generation: 2,
    },
    api: {
      enabled: false,
      port: DEFAULT_API_PORT,
      tokenEnc: secrets.seal(secrets.randomToken()),
    },
  };
}

function defaultStatuses() {
  const timestamp = nowIso();
  return DEFAULT_STATUSES.map((item) => ({
    id: crypto.randomUUID(),
    name: item.name,
    color: item.color,
    createdAt: timestamp,
    updatedAt: timestamp,
  }));
}

function defaultState() {
  const createdAt = nowIso();
  return {
    schemaVersion: SCHEMA_VERSION,
    settings: defaultSettings(),
    workspaces: [
      { id: crypto.randomUUID(), name: 'General', color: '#5b6cff', createdAt, updatedAt: createdAt },
    ],
    profileStatuses: defaultStatuses(),
    proxies: [],
    profiles: [],
    apps: [],
    appProfileConfigs: [],
    cloneAccounts: [],
    virtualMachines: [],
    activity: [],
  };
}

function cleanActivity(list) {
  if (!Array.isArray(list)) return [];
  return list
    .filter((entry) => entry && typeof entry === 'object' && typeof entry.message === 'string')
    .slice(0, ACTIVITY_LIMIT)
    .map((entry) => ({
      id: typeof entry.id === 'string' ? entry.id : crypto.randomUUID(),
      ts: typeof entry.ts === 'string' ? entry.ts : nowIso(),
      level: ['info', 'warn', 'error', 'success'].includes(entry.level) ? entry.level : 'info',
      message: entry.message.slice(0, 500),
      profileId: typeof entry.profileId === 'string' ? entry.profileId : null,
    }));
}

class Store {
  constructor() {
    this.file = paths.dataFile();
    this.state = null;
  }

  load() {
    let raw = null;
    let corrupt = false;
    try {
      if (fs.existsSync(this.file)) {
        raw = JSON.parse(fs.readFileSync(this.file, 'utf8'));
      }
    } catch (error) {
      corrupt = true;
      try {
        const backup = path.join(path.dirname(this.file), `data.corrupt-${Date.now()}.json`);
        fs.copyFileSync(this.file, backup);
      } catch {
        // best effort backup
      }
    }
    this.state = this.normalize(raw, corrupt);
    this.save();
    return this.state;
  }

  normalize(raw, corrupt) {
    const base = defaultState();
    if (!raw || typeof raw !== 'object' || Array.isArray(raw) || corrupt) return base;

    // Antes del esquema v5 el modo por defecto era "data", que solo redirige variables
    // de entorno y no duplica la aplicación. Se migra a "account" para que cada perfil
    // sea de verdad un dispositivo nuevo.
    const legacyIsolation = !(Number.isInteger(raw.schemaVersion) && raw.schemaVersion >= MIGRATION_ACCOUNT_SINCE);

    const rawSettings = raw.settings && typeof raw.settings === 'object' ? raw.settings : {};
    const settings = { ...base.settings };
    settings.theme = ['system', 'light', 'dark'].includes(rawSettings.theme) ? rawSettings.theme : 'system';
    settings.closeToTray = typeof rawSettings.closeToTray === 'boolean' ? rawSettings.closeToTray : true;
    settings.profilesDir = typeof rawSettings.profilesDir === 'string' ? rawSettings.profilesDir : '';
    const rawVm = rawSettings.vm && typeof rawSettings.vm === 'object' && !Array.isArray(rawSettings.vm)
      ? rawSettings.vm
      : {};
    const vmMemory = Number(rawVm.memoryMb);
    const vmCpu = Number(rawVm.cpuCount);
    settings.vm = {
      baseImagePath: typeof rawVm.baseImagePath === 'string' ? rawVm.baseImagePath : '',
      switchName: typeof rawVm.switchName === 'string' && rawVm.switchName.trim()
        ? rawVm.switchName.trim().slice(0, 100)
        : DEFAULT_SWITCH,
      memoryMb: Number.isInteger(vmMemory) ? Math.min(MAX_MEMORY_MB, Math.max(MIN_MEMORY_MB, vmMemory)) : DEFAULT_MEMORY_MB,
      cpuCount: Number.isInteger(vmCpu) ? Math.min(MAX_CPU, Math.max(MIN_CPU, vmCpu)) : DEFAULT_CPU,
      disksDir: typeof rawVm.disksDir === 'string' ? rawVm.disksDir : '',
      generation: Number(rawVm.generation) === 1 ? 1 : 2,
    };
    const rawApi = rawSettings.api && typeof rawSettings.api === 'object' ? rawSettings.api : {};
    const api = { ...base.settings.api, ...rawApi };
    api.enabled = typeof api.enabled === 'boolean' ? api.enabled : false;
    api.port = Number.isInteger(Number(api.port)) && Number(api.port) >= 1024 && Number(api.port) <= 65535
      ? Number(api.port)
      : DEFAULT_API_PORT;
    api.tokenEnc = typeof api.tokenEnc === 'string' && api.tokenEnc ? api.tokenEnc : secrets.seal(secrets.randomToken());
    delete api.token;
    settings.api = api;

    const workspaces = [];
    const workspaceIds = new Set();
    if (Array.isArray(raw.workspaces)) {
      for (const item of raw.workspaces) {
        if (!item || typeof item !== 'object') continue;
        const id = typeof item.id === 'string' && item.id ? item.id : crypto.randomUUID();
        if (workspaceIds.has(id)) continue;
        const name = typeof item.name === 'string' && item.name.trim() ? item.name.trim().slice(0, 40) : 'Espacio';
        workspaceIds.add(id);
        workspaces.push({
          id,
          name,
          color: /^#[0-9a-fA-F]{6}$/.test(item.color || '') ? item.color : '#5b6cff',
          createdAt: typeof item.createdAt === 'string' ? item.createdAt : nowIso(),
          updatedAt: typeof item.updatedAt === 'string' ? item.updatedAt : nowIso(),
        });
      }
    }
    if (!workspaces.length) workspaces.push(...base.workspaces);
    const fallbackWorkspaceId = workspaces[0].id;

    const profileStatuses = [];
    const statusIds = new Set();
    const statusNames = new Set();
    if (Array.isArray(raw.profileStatuses)) {
      for (const item of raw.profileStatuses) {
        if (!item || typeof item !== 'object' || profileStatuses.length >= STATUS_LIMIT) continue;
        const id = typeof item.id === 'string' && item.id ? item.id : crypto.randomUUID();
        if (statusIds.has(id)) continue;
        const name = typeof item.name === 'string' && item.name.trim() ? item.name.trim().slice(0, 32) : '';
        if (!name || statusNames.has(name.toLowerCase())) continue;
        statusIds.add(id);
        statusNames.add(name.toLowerCase());
        profileStatuses.push({
          id,
          name,
          color: /^#[0-9a-fA-F]{6}$/.test(item.color || '') ? item.color : '#5b6cff',
          createdAt: typeof item.createdAt === 'string' ? item.createdAt : nowIso(),
          updatedAt: typeof item.updatedAt === 'string' ? item.updatedAt : nowIso(),
        });
      }
    } else {
      profileStatuses.push(...defaultStatuses());
      for (const item of profileStatuses) {
        statusIds.add(item.id);
        statusNames.add(item.name.toLowerCase());
      }
    }

    const proxies = [];
    const proxyIds = new Set();
    if (Array.isArray(raw.proxies)) {
      for (const item of raw.proxies) {
        if (!item || typeof item !== 'object') continue;
        const id = typeof item.id === 'string' && item.id ? item.id : crypto.randomUUID();
        if (proxyIds.has(id)) continue;
        const protocol = ['http', 'https', 'socks5'].includes(item.protocol) ? item.protocol : 'http';
        const host = typeof item.host === 'string' ? item.host.trim().slice(0, 255) : '';
        const port = Number(item.port);
        if (!host || !Number.isInteger(port) || port < 1 || port > 65535) continue;
        let passwordEnc = typeof item.passwordEnc === 'string' ? item.passwordEnc : '';
        if (!passwordEnc && typeof item.password === 'string' && item.password) {
          passwordEnc = secrets.seal(item.password);
        }
        proxyIds.add(id);
        proxies.push({
          id,
          name: typeof item.name === 'string' && item.name.trim() ? item.name.trim().slice(0, 60) : `${host}:${port}`,
          protocol,
          host,
          port,
          username: typeof item.username === 'string' ? item.username.slice(0, 128) : '',
          passwordEnc,
          notes: typeof item.notes === 'string' ? item.notes.slice(0, 500) : '',
          createdAt: typeof item.createdAt === 'string' ? item.createdAt : nowIso(),
          updatedAt: typeof item.updatedAt === 'string' ? item.updatedAt : nowIso(),
        });
      }
    }

    const profiles = [];
    const profileIds = new Set();
    if (Array.isArray(raw.profiles)) {
      for (const item of raw.profiles) {
        if (!item || typeof item !== 'object') continue;
        const id = typeof item.id === 'string' && item.id ? item.id : crypto.randomUUID();
        if (profileIds.has(id)) continue;
        const name = typeof item.name === 'string' && item.name.trim() ? item.name.trim().slice(0, 80) : 'Perfil';
        const workspaceId = workspaceIds.has(item.workspaceId) ? item.workspaceId : fallbackWorkspaceId;
        const proxyId = proxyIds.has(item.proxyId) ? item.proxyId : null;
        const statusId = statusIds.has(item.statusId) ? item.statusId : null;
        profileIds.add(id);
        profiles.push({
          id,
          name,
          workspaceId,
          // Todos los perfiles usan el navegador integrado; los valores heredados se descartan.
          browserId: BUILTIN_BROWSER_ID,
          proxyId,
          statusId,
          startUrls: Array.isArray(item.startUrls) ? item.startUrls.filter((url) => typeof url === 'string').slice(0, 8) : [],
          tags: Array.isArray(item.tags) ? item.tags.filter((tag) => typeof tag === 'string').slice(0, 10) : [],
          notes: typeof item.notes === 'string' ? item.notes.slice(0, 2000) : '',
          color: /^#[0-9a-fA-F]{6}$/.test(item.color || '') ? item.color : PALETTE[profiles.length % PALETTE.length],
          createdAt: typeof item.createdAt === 'string' ? item.createdAt : nowIso(),
          updatedAt: typeof item.updatedAt === 'string' ? item.updatedAt : nowIso(),
          lastStartedAt: typeof item.lastStartedAt === 'string' ? item.lastStartedAt : null,
          lastStoppedAt: typeof item.lastStoppedAt === 'string' ? item.lastStoppedAt : null,
        });
      }
    }

    const apps = [];
    const appIds = new Set();
    if (Array.isArray(raw.apps)) {
      for (const item of raw.apps) {
        if (!item || typeof item !== 'object' || apps.length >= APP_LIMIT) continue;
        const id = typeof item.id === 'string' && item.id ? item.id : crypto.randomUUID();
        if (appIds.has(id)) continue;
        const kind = item.kind === 'startapp' || item.kind === 'executable' ? item.kind : '';
        const target = typeof item.target === 'string' ? item.target.trim() : '';
        if (!kind || !target || target.length > 1000) continue;
        if (kind === 'executable' && (!path.isAbsolute(target) || path.extname(target).toLowerCase() !== '.exe')) continue;
        if (kind === 'startapp' && /[\u0000-\u001f\u007f]/.test(target)) continue;
        const name = typeof item.name === 'string' && item.name.trim() ? item.name.trim().slice(0, 100) : path.basename(target).slice(0, 100);
        let cloneMode = kind === 'startapp' ? 'none' : '';
        if (kind === 'executable') {
          if (item.cloneMode === 'none' || item.isolateData === false) {
            cloneMode = 'none';
          } else if (item.cloneMode === 'data' && !legacyIsolation) {
            cloneMode = 'data';
          } else if (item.cloneMode === 'vm' || item.cloneMode === 'account') {
            cloneMode = item.cloneMode;
          } else {
            cloneMode = 'account';
          }
        }
        appIds.add(id);
        apps.push({
          id,
          name,
          kind,
          target,
          args: typeof item.args === 'string' ? item.args.slice(0, 4000) : '',
          cwd: typeof item.cwd === 'string' ? item.cwd.slice(0, 1000) : '',
          cloneMode,
          favorite: Boolean(item.favorite),
          source: kind === 'startapp' ? 'start-menu' : 'manual',
          createdAt: typeof item.createdAt === 'string' ? item.createdAt : nowIso(),
          updatedAt: typeof item.updatedAt === 'string' ? item.updatedAt : nowIso(),
        });
      }
    }

    const appProfileConfigs = [];
    if (Array.isArray(raw.appProfileConfigs)) {
      for (const item of raw.appProfileConfigs) {
        if (!item || typeof item !== 'object') continue;
        if (!profileIds.has(item.profileId) || !appIds.has(item.appId)) continue;
        if (appProfileConfigs.some((entry) => entry.profileId === item.profileId && entry.appId === item.appId)) continue;
        appProfileConfigs.push({
          profileId: item.profileId,
          appId: item.appId,
          args: typeof item.args === 'string' ? item.args.slice(0, 4000) : '',
          cwd: typeof item.cwd === 'string' ? item.cwd.slice(0, 1000) : '',
          updatedAt: typeof item.updatedAt === 'string' ? item.updatedAt : nowIso(),
        });
      }
    }

    const cloneAccounts = [];
    const cloneProfileIds = new Set();
    if (Array.isArray(raw.cloneAccounts)) {
      for (const item of raw.cloneAccounts) {
        if (!item || typeof item !== 'object') continue;
        if (!profileIds.has(item.profileId) || cloneProfileIds.has(item.profileId)) continue;
        const expectedUsername = accountName(item.profileId);
        if (item.username !== expectedUsername || !ACCOUNT_RE.test(item.username)) continue;
        if (typeof item.passwordEnc !== 'string' || !/^(enc1|plain1):/.test(item.passwordEnc)) continue;
        const sid = typeof item.sid === 'string' && SID_RE.test(item.sid) ? item.sid : null;
        cloneProfileIds.add(item.profileId);
        cloneAccounts.push({
          profileId: item.profileId,
          username: expectedUsername,
          description: accountDescription(item.profileId),
          sid,
          passwordEnc: item.passwordEnc,
          preparedAt: typeof item.preparedAt === 'string' ? item.preparedAt : nowIso(),
          verifiedAt: typeof item.verifiedAt === 'string' ? item.verifiedAt : null,
          updatedAt: typeof item.updatedAt === 'string' ? item.updatedAt : nowIso(),
        });
      }
    }

    const virtualMachines = [];
    const vmProfileIds = new Set();
    if (Array.isArray(raw.virtualMachines)) {
      for (const item of raw.virtualMachines) {
        if (!item || typeof item !== 'object') continue;
        if (!profileIds.has(item.profileId) || vmProfileIds.has(item.profileId)) continue;
        let expectedName;
        try {
          expectedName = vmName(item.profileId);
        } catch {
          continue;
        }
        if (item.vmName !== expectedName) continue;
        const diskPath = typeof item.diskPath === 'string' && path.isAbsolute(item.diskPath) && !item.diskPath.includes('\0')
          ? item.diskPath
          : '';
        vmProfileIds.add(item.profileId);
        virtualMachines.push({
          profileId: item.profileId,
          vmName: expectedName,
          diskPath,
          createdAt: typeof item.createdAt === 'string' ? item.createdAt : nowIso(),
          updatedAt: typeof item.updatedAt === 'string' ? item.updatedAt : nowIso(),
        });
      }
    }

    return {
      schemaVersion: SCHEMA_VERSION,
      settings,
      workspaces,
      profileStatuses,
      proxies,
      profiles,
      apps,
      appProfileConfigs,
      cloneAccounts,
      virtualMachines,
      activity: cleanActivity(raw.activity),
    };
  }

  save() {
    try {
      const dir = path.dirname(this.file);
      paths.ensureDir(dir);
      const tmp = `${this.file}.${process.pid}.tmp`;
      fs.writeFileSync(tmp, `${JSON.stringify(this.state, null, 2)}\n`, 'utf8');
      fs.renameSync(tmp, this.file);
    } catch (error) {
      throw new AppError(`No se pudieron guardar los datos: ${error.message}`, 500, 'storage_error');
    }
  }

  getState() {
    return this.state;
  }

  static palette() {
    return PALETTE;
  }
}

module.exports = { Store, PALETTE, ACTIVITY_LIMIT, DEFAULT_API_PORT, nowIso };
