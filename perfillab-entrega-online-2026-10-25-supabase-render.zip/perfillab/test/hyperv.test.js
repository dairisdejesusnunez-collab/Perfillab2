'use strict';

const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const test = require('node:test');

const {
  HyperVProvider,
  vmName,
  buildVmScript,
  VM_RE,
  DEFAULT_SWITCH,
  DEFAULT_MEMORY_MB,
  DEFAULT_CPU,
} = require('../electron/hyperv');

const PROFILE_ID = 'profile-1';

function fakeCapabilities(payload) {
  return (file, args, options, callback) => {
    setImmediate(() => callback(null, JSON.stringify(payload), ''));
  };
}

function elevatedResponder(baseDir, resultFactory) {
  return (file, args, options, callback) => {
    const entries = fs.readdirSync(baseDir).filter((name) => name.startsWith('op-')).sort();
    const opDir = path.join(baseDir, entries.at(-1));
    const request = JSON.parse(fs.readFileSync(path.join(opDir, 'request.json'), 'utf8'));
    fs.writeFileSync(path.join(opDir, 'result.json'), JSON.stringify(resultFactory(request)));
    setImmediate(() => callback(null, '', ''));
  };
}

function makeProvider(root, execFileImpl, overrides = {}) {
  return new HyperVProvider({
    platform: 'win32',
    baseDir: path.join(root, 'ops'),
    powershellPath: 'powershell.exe',
    execFileImpl,
    ...overrides,
  });
}

test('vmName es determinista, corto y seguro para Hyper-V', () => {
  const name = vmName(PROFILE_ID);
  assert.equal(name, vmName(PROFILE_ID));
  assert.match(name, VM_RE);
  assert.equal(name.length, 15);
  assert.notEqual(vmName('profile-2'), name);
  assert.throws(() => vmName(''), /perfil no es válido/);
  assert.throws(() => vmName(null), /perfil no es válido/);
});

test('el script de Hyper-V escapa rutas y cubre todas las acciones', () => {
  const script = buildVmScript("C:\\tmp\\O'Brien\\request.json", 'C:\\tmp\\result.json');
  assert.ok(script.includes("O''Brien"));
  assert.ok(script.includes("'C:\\tmp\\result.json'"));
  for (const action of ['ensure', 'start', 'stop', 'stopall', 'remove', 'list', 'switches']) {
    assert.ok(script.includes(`$action -eq '${action}'`), `falta la acción ${action}`);
  }
  assert.ok(script.includes('New-VHD -Path $disk -ParentPath $base -Differencing'));
  assert.ok(script.includes('Start-VM -Name $name'));
  assert.ok(script.includes('Stop-VM -Name $target -Save -ErrorAction Stop'));
  assert.ok(script.includes('Remove-VM -Name $name -Force'));
  assert.ok(script.includes('Connect-VMNetworkAdapter'));
});

test('Hyper-V solo está disponible en Windows', async () => {
  const provider = new HyperVProvider({ platform: 'linux', powershellPath: 'pwsh' });
  const status = await provider.capabilities(true);
  assert.equal(status.available, false);
  assert.equal(status.checked, true);
  assert.match(status.error, /solo están disponibles en Windows/);
  assert.throws(() => provider.ensureSupported(), (error) => error.code === 'vm_unsupported');
});

test('las capacidades detectan Hyper-V disponible, detenido o dañado', async (t) => {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'perfillab-hyperv-caps-'));
  t.after(() => fs.rmSync(root, { recursive: true, force: true }));

  const available = makeProvider(root, fakeCapabilities({
    module: true,
    vmms: 'Running',
    hypervisor: true,
    admin: false,
    os: 'Windows 11 Pro',
    version: '10.0.26100',
    ramGb: 64,
  }));
  const status = await available.capabilities(true);
  assert.equal(status.available, true);
  assert.equal(status.vmms, 'Running');
  assert.equal(status.ramGb, 64);
  assert.equal(status.elevated, false);
  assert.equal(status.error, null);
  assert.deepEqual(status.windows, []);

  const stopped = makeProvider(root, fakeCapabilities({
    module: true, vmms: 'Stopped', hypervisor: true,
  }));
  const stoppedStatus = await stopped.capabilities(true);
  assert.equal(stoppedStatus.available, false);
  assert.match(stoppedStatus.error, /vmms/);

  const broken = makeProvider(root, (file, args, options, callback) => {
    setImmediate(() => callback(new Error('PowerShell no disponible'), '', ''));
  });
  const brokenStatus = await broken.capabilities(true);
  assert.equal(brokenStatus.available, false);
  assert.match(brokenStatus.error, /No se pudo consultar Hyper-V/);
});

test('ensure exige una imagen base .vhdx existente antes de elevar permisos', async (t) => {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'perfillab-hyperv-base-'));
  t.after(() => fs.rmSync(root, { recursive: true, force: true }));
  fs.mkdirSync(path.join(root, 'ops'), { recursive: true });
  let elevated = 0;
  const provider = makeProvider(root, fakeCapabilities({
    module: true, vmms: 'Running', hypervisor: true,
  }));
  await provider.capabilities(true);
  provider.execFileImpl = (file, args, options, callback) => {
    elevated += 1;
    setImmediate(() => callback(null, '', ''));
  };

  await assert.rejects(
    provider.ensure(PROFILE_ID, { baseImagePath: '' }),
    (error) => error.code === 'bad_request' && /imagen base/.test(error.message),
  );
  await assert.rejects(
    provider.ensure(PROFILE_ID, { baseImagePath: path.join(root, 'base.iso') }),
    (error) => error.code === 'bad_request' && /\.vhdx/.test(error.message),
  );
  await assert.rejects(
    provider.ensure(PROFILE_ID, { baseImagePath: path.join(root, 'no-existe.vhdx') }),
    (error) => error.code === 'bad_request' && /No se encontró la imagen base/.test(error.message),
  );
  assert.equal(elevated, 0);
});

test('ensure envía límites normalizados y devuelve la máquina creada', async (t) => {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'perfillab-hyperv-ensure-'));
  t.after(() => fs.rmSync(root, { recursive: true, force: true }));
  const baseImage = path.join(root, 'Windows 11.vhdx');
  fs.writeFileSync(baseImage, '');
  const disksDir = path.join(root, 'vms');
  const baseDir = path.join(root, 'ops');
  fs.mkdirSync(baseDir, { recursive: true });
  const provider = makeProvider(root, fakeCapabilities({
    module: true, vmms: 'Running', hypervisor: true,
  }));
  await provider.capabilities(true);

  let seen = null;
  provider.execFileImpl = elevatedResponder(baseDir, (request) => {
    seen = request;
    return {
      ok: true,
      vmName: request.vmName,
      state: 'Running',
      created: true,
      started: request.start,
    };
  });

  const result = await provider.ensure(PROFILE_ID, {
    baseImagePath: baseImage,
    switchName: '  Default Switch  ',
    memoryMb: 999999,
    cpuCount: 0,
    generation: 1,
    disksDir,
  }, { start: true });

  assert.equal(seen.action, 'ensure');
  assert.equal(seen.baseImage, baseImage);
  assert.equal(seen.diskPath, path.join(disksDir, `${vmName(PROFILE_ID)}.vhdx`));
  assert.equal(seen.memoryMb, 32768);
  assert.equal(seen.cpuCount, 1);
  assert.equal(seen.generation, 1);
  assert.equal(seen.start, true);
  assert.equal(seen.vmName, vmName(PROFILE_ID));
  assert.equal(result.vmName, vmName(PROFILE_ID));
  assert.equal(result.diskPath, path.join(disksDir, `${vmName(PROFILE_ID)}.vhdx`));
  assert.equal(result.created, true);
});

test('stopAll detiene únicamente las máquinas de los perfiles indicados', async (t) => {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'perfillab-hyperv-stop-'));
  t.after(() => fs.rmSync(root, { recursive: true, force: true }));
  const baseDir = path.join(root, 'ops');
  fs.mkdirSync(baseDir, { recursive: true });
  const provider = makeProvider(root, fakeCapabilities({
    module: true, vmms: 'Running', hypervisor: true,
  }));
  await provider.capabilities(true);

  let seen = null;
  provider.execFileImpl = elevatedResponder(baseDir, (request) => {
    seen = request;
    return { ok: true, stopped: request.vmNames.length };
  });

  assert.deepEqual(await provider.stopAll([]), { stopped: 0 });
  assert.equal(seen, null);

  const result = await provider.stopAll(['p1', 'p2']);
  assert.equal(result.stopped, 2);
  assert.equal(seen.action, 'stopall');
  assert.deepEqual(seen.vmNames, [vmName('p1'), vmName('p2')]);
});

test('cancelar el UAC se informa como cancelación y no como fallo de Hyper-V', async (t) => {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'perfillab-hyperv-uac-'));
  t.after(() => fs.rmSync(root, { recursive: true, force: true }));
  const provider = makeProvider(root, (file, args, options, callback) => {
    const error = new Error('cancelado por el usuario');
    error.code = 1223;
    setImmediate(() => callback(error, '', ''));
  });
  await assert.rejects(
    provider.start(PROFILE_ID),
    (error) => error.code === 'uac_cancelled',
  );
});

test('si se cancela el UAC al salir, las ventanas de las VM permanecen abiertas', async (t) => {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'perfillab-hyperv-stopall-uac-'));
  t.after(() => fs.rmSync(root, { recursive: true, force: true }));
  const provider = makeProvider(root, (file, args, options, callback) => {
    const error = new Error('cancelado por el usuario');
    error.code = 1223;
    setImmediate(() => callback(error, '', ''));
  });
  provider.windows.set(PROFILE_ID, {
    profileId: PROFILE_ID,
    profileName: 'Perfil 1',
    vmName: vmName(PROFILE_ID),
    pid: 4321,
    startedAt: '2026-10-25T00:00:00.000Z',
  });
  await assert.rejects(
    provider.stopAll([PROFILE_ID]),
    (error) => error.code === 'uac_cancelled',
  );
  assert.equal(provider.hasWindow(PROFILE_ID), true);
});

test('resolvePaths deriva carpetas seguras desde los ajustes', () => {
  assert.equal(DEFAULT_SWITCH, 'Default Switch');
  assert.equal(DEFAULT_MEMORY_MB, 4096);
  assert.equal(DEFAULT_CPU, 2);
  const provider = new HyperVProvider({
    platform: 'win32',
    env: { LOCALAPPDATA: 'C:\\Users\\Ejemplo\\AppData\\Local' },
  });
  const paths = provider.resolvePaths(PROFILE_ID, {});
  const base = path.join('C:\\Users\\Ejemplo\\AppData\\Local', 'PerfilLab', 'vms');
  assert.equal(paths.vmName, vmName(PROFILE_ID));
  assert.equal(paths.diskPath, path.join(base, `${paths.vmName}.vhdx`));
  assert.equal(paths.vmDir, path.join(base, paths.vmName));
  assert.throws(
    () => provider.resolvePaths(PROFILE_ID, { disksDir: 'relativa' }),
    /carpeta de discos/,
  );
});
