'use strict';

const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const test = require('node:test');

const dataRoot = fs.mkdtempSync(path.join(os.tmpdir(), 'perfillab-browser-'));
process.env.PERFILLAB_DATA_DIR = dataRoot;

const {
  BUILTIN_BROWSER_ID,
  BROWSER_CHROME_HEIGHT,
  BROWSER_FLAG,
  FLAG,
  builtinBrowser,
  buildBrowserArgs,
  isAllowedPageUrl,
  isHomeUrl,
  parseBrowserArgs,
  resolveAddressInput,
} = require('../electron/browser-launch');
const browsers = require('../electron/browsers');
const { Store } = require('../electron/store');

const HOME = 'file:///C:/PerfilLab/renderer/browser-home.html';

test.after(() => {
  fs.rmSync(dataRoot, { recursive: true, force: true });
});

test('el navegador integrado usa el ejecutable actual y se identifica como PerfilLab', () => {
  const builtin = builtinBrowser({ chromiumVersion: '140.0.0.0' });
  assert.equal(builtin.id, BUILTIN_BROWSER_ID);
  assert.equal(builtin.name, 'PerfilLab Browser');
  assert.equal(builtin.path, process.execPath);
  assert.equal(builtin.builtin, true);
  assert.equal(builtin.custom, false);
  assert.equal(builtin.engineVersion, '140.0.0.0');
});

test('detectBrowsers solo devuelve el navegador integrado', () => {
  const list = browsers.detectBrowsers({});
  assert.equal(list.length, 1);
  assert.equal(list[0].id, BUILTIN_BROWSER_ID);
  assert.equal(list[0].builtin, true);
  assert.equal(browsers.findBrowser({}, BUILTIN_BROWSER_ID).builtin, true);
  assert.equal(browsers.findBrowser({}, 'chrome').id, BUILTIN_BROWSER_ID);
  assert.equal(browsers.findBrowser({}, 'custom').id, BUILTIN_BROWSER_ID);
  assert.equal(browsers.pickDefaultBrowser(), BUILTIN_BROWSER_ID);
});

test('los perfiles heredados se migran al navegador integrado', () => {
  const store = new Store();
  const state = store.normalize({
    schemaVersion: 7,
    settings: {
      defaultBrowserId: 'chrome',
      customBrowserName: 'Navegador de prueba',
      customBrowserPath: 'C:\\navegadores\\chrome.exe',
    },
    workspaces: [],
    proxies: [],
    profiles: [
      { id: 'p1', name: 'Perfil heredado', browserId: 'edge' },
      { id: 'p2', name: 'Perfil personalizado', browserId: 'custom' },
    ],
    apps: [],
  });
  assert.equal(state.profiles[0].browserId, BUILTIN_BROWSER_ID);
  assert.equal(state.profiles[1].browserId, BUILTIN_BROWSER_ID);
  assert.equal(Object.hasOwn(state.settings, 'defaultBrowserId'), false);
  assert.equal(Object.hasOwn(state.settings, 'customBrowserPath'), false);
});

test('parseBrowserArgs ignora una ejecución normal de PerfilLab', () => {
  assert.equal(parseBrowserArgs([process.execPath, '.']), null);
  assert.equal(parseBrowserArgs([process.execPath, '--perfillab-browser=false']), null);
});

test('parseBrowserArgs extrae y valida los datos del perfil', () => {
  const dataDir = path.join(dataRoot, 'profile', 'browser');
  const args = [
    process.execPath,
    BROWSER_FLAG,
    `${FLAG.profileId}abc123`,
    `${FLAG.profileName}${encodeURIComponent('Cuenta & Ventas')}`,
    `${FLAG.browserData}${dataDir}`,
    `${FLAG.downloads}${path.join(dataRoot, 'profile', 'downloads')}`,
    `${FLAG.appData}${dataRoot}`,
    `${FLAG.proxyLabel}${encodeURIComponent('Proxy Madrid')}`,
    'https://example.com/',
    'https://example.com/',
    'http://segundo.example/path',
    'ftp://ignorado.example',
    'javascript:alert(1)',
  ];
  const parsed = parseBrowserArgs(args);
  assert.equal(parsed.profileId, 'abc123');
  assert.equal(parsed.profileName, 'Cuenta & Ventas');
  assert.equal(parsed.dataDir, path.resolve(dataDir));
  assert.equal(parsed.downloadsDir, path.resolve(path.join(dataRoot, 'profile', 'downloads')));
  assert.equal(parsed.appDataDir, path.resolve(dataRoot));
  assert.equal(parsed.proxyLabel, 'Proxy Madrid');
  assert.deepEqual(parsed.startUrls, ['https://example.com/', 'http://segundo.example/path']);
});

test('parseBrowserArgs descarta carpetas relativas y limita el nombre del perfil', () => {
  const parsed = parseBrowserArgs([
    BROWSER_FLAG,
    `${FLAG.browserData}relative-dir`,
    `${FLAG.profileName}${encodeURIComponent(`${'A'.repeat(200)}\u0000x`)}`,
  ]);
  assert.equal(parsed.dataDir, '');
  assert.equal(parsed.downloadsDir, '');
  assert.equal(parsed.profileName.length, 120);
  assert.equal(parsed.profileName.includes('\u0000'), false);
});

test('buildBrowserArgs prepara el ejecutable empaquetado con datos aislados', () => {
  const profile = { id: 'p1', name: 'Perfil & Uno' };
  const profileDir = path.join(dataRoot, 'profiles', 'p1');
  const built = buildBrowserArgs({
    profile,
    profileDir,
    appDataDir: dataRoot,
    proxyArgs: ['--proxy-server=http://127.0.0.1:5555'],
    proxyLabel: 'Proxy Uno',
    startUrls: ['https://example.com/', 'file:///C:/bloqueado', 'https://ejemplo.es/'],
    packaged: true,
  });
  assert.equal(built.dataDir, path.join(profileDir, 'browser'));
  assert.equal(built.downloadsDir, path.join(profileDir, 'downloads'));
  assert.equal(built.args[0], BROWSER_FLAG);
  assert.ok(built.args.includes(`${FLAG.profileName}${encodeURIComponent('Perfil & Uno')}`));
  assert.ok(built.args.includes(`${FLAG.browserData}${path.join(profileDir, 'browser')}`));
  assert.ok(built.args.includes(`${FLAG.proxyLabel}${encodeURIComponent('Proxy Uno')}`));
  assert.ok(built.args.includes('--proxy-server=http://127.0.0.1:5555'));
  assert.ok(built.args.includes('https://example.com/'));
  assert.ok(built.args.includes('https://ejemplo.es/'));
  assert.equal(built.args.includes('file:///C:/bloqueado'), false);
  assert.equal(built.args.filter((arg) => arg === 'https://example.com/').length, 1);
});

test('buildBrowserArgs incluye la ruta de la aplicación solo en desarrollo', () => {
  const profile = { id: 'p1', name: 'Perfil' };
  const profileDir = path.join(dataRoot, 'profiles', 'p1');
  const dev = buildBrowserArgs({
    profile,
    profileDir,
    appPath: path.join(dataRoot, 'app'),
    packaged: false,
  });
  assert.equal(dev.args[0], path.join(dataRoot, 'app'));
  assert.equal(dev.args[1], BROWSER_FLAG);
  assert.throws(() => buildBrowserArgs({ profile, profileDir, packaged: false }), /ruta de la aplicación/);
  assert.throws(() => buildBrowserArgs({ profile: null, profileDir, packaged: true }), /Falta el perfil/);
});

test('resolveAddressInput distingue direcciones, hosts locales y búsquedas', () => {
  assert.equal(resolveAddressInput(''), '');
  assert.equal(resolveAddressInput('https://example.com'), 'https://example.com/');
  assert.equal(resolveAddressInput('example.com'), 'https://example.com/');
  assert.equal(resolveAddressInput('es.wikipedia.org/wiki/Prueba'), 'https://es.wikipedia.org/wiki/Prueba');
  assert.equal(resolveAddressInput('localhost:3000'), 'http://localhost:3000/');
  assert.equal(resolveAddressInput('127.0.0.1:8080/x'), 'http://127.0.0.1:8080/x');
  assert.equal(resolveAddressInput('buscar algo'), 'https://www.google.com/search?q=buscar%20algo');
  assert.ok(resolveAddressInput('javascript:alert(1)').startsWith('https://www.google.com/search?q='));
  assert.ok(resolveAddressInput('file:///C:/Windows/win.ini').startsWith('https://www.google.com/search?q='));
});

test('la lista de navegación permite HTTP, HTTPS y las páginas locales', () => {
  assert.equal(isAllowedPageUrl('https://example.com/', HOME), true);
  assert.equal(isAllowedPageUrl('http://example.com/', HOME), true);
  assert.equal(isAllowedPageUrl(`${HOME}?profile=Uno`, HOME), true);
  assert.equal(isAllowedPageUrl(`${HOME}#top`, HOME), true);
  assert.equal(isAllowedPageUrl('about:blank', HOME), true);
  assert.equal(isAllowedPageUrl('file:///C:/Windows/win.ini', HOME), false);
  assert.equal(isAllowedPageUrl(`${HOME}.malicioso`, HOME), false);
  assert.equal(isAllowedPageUrl('javascript:alert(1)', HOME), false);
  assert.equal(isAllowedPageUrl('data:text/html,<h1>x</h1>', HOME), false);
  assert.equal(isAllowedPageUrl('', HOME), false);
});

test('isHomeUrl acepta solo la página de inicio con consulta o ancla', () => {
  assert.equal(isHomeUrl(HOME, HOME), true);
  assert.equal(isHomeUrl(`${HOME}?a=1`, HOME), true);
  assert.equal(isHomeUrl(`${HOME}#x`, HOME), true);
  assert.equal(isHomeUrl(`${HOME}/otra`, HOME), false);
  assert.equal(isHomeUrl('https://example.com/', HOME), false);
  assert.equal(isHomeUrl('', HOME), false);
});

test('la altura del cromo del navegador es estable para las vistas', () => {
  assert.equal(BROWSER_CHROME_HEIGHT, 96);
});
