'use strict';

const assert = require('node:assert/strict');
const { EventEmitter } = require('node:events');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const test = require('node:test');

const {
  NativeCloneProvider,
  accountName,
  accountDescription,
  generatePassword,
  quoteWindowsArg,
  buildCommandLine,
  parseCloneLine,
  launchErrorMessage,
  buildLauncherScript,
  buildProvisionScript,
  buildReleaseScript,
  buildElevatedLauncher,
  ACCOUNT_RE,
  SID_RE,
} = require('../electron/native-clone');

const SID = 'S-1-5-21-111111111-222222222-333333333-1001';

function fakeChild(pid = 990001) {
  const child = new EventEmitter();
  child.pid = pid;
  child.exitCode = null;
  child.signalCode = null;
  child.stdout = new EventEmitter();
  child.stderr = new EventEmitter();
  const written = [];
  child.stdin = {
    on() {},
    end(chunk) { written.push(String(chunk)); },
  };
  child.written = written;
  return child;
}

function makeProvider(overrides = {}) {
  return new NativeCloneProvider({
    platform: 'win32',
    env: {},
    powershellPath: 'C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe',
    windows: 'C:\\Users\\Tester',
    ...overrides,
  });
}

test('los nombres de cuenta son deterministas, válidos y propios de cada perfil', () => {
  const first = accountName('profile-1');
  assert.match(first, ACCOUNT_RE);
  assert.equal(first, accountName('profile-1'));
  assert.notEqual(first, accountName('profile-2'));
  assert.match(accountDescription('profile-1'), /^PerfilLab clon [0-9a-f]{8}$/);
  assert.notEqual(accountDescription('profile-1'), accountDescription('profile-2'));
  assert.throws(() => accountName(''), /perfil no es válido/);
  assert.throws(() => accountName(null), /perfil no es válido/);
  assert.match(SID, SID_RE);
});

test('las contraseñas generadas cumplen longitud y complejidad local', () => {
  const password = generatePassword();
  assert.match(password, /^Pl1!/);
  assert.ok(password.length >= 24);
  assert.match(password, /[A-Z]/);
  assert.match(password, /[a-z]/);
  assert.match(password, /[0-9]/);
  assert.match(password, /[^A-Za-z0-9]/);
  assert.notEqual(password, generatePassword());
});

test('quoteWindowsArg y buildCommandLine usan las reglas de Windows', () => {
  assert.equal(quoteWindowsArg('plain'), 'plain');
  assert.equal(quoteWindowsArg('C:\\Program Files\\App.exe'), '"C:\\Program Files\\App.exe"');
  assert.equal(quoteWindowsArg('a"b'), '"a\\"b"');
  assert.equal(quoteWindowsArg('C:\\dir\\'), 'C:\\dir\\');
  assert.equal(quoteWindowsArg('C:\\My Dir\\'), '"C:\\My Dir\\\\"');
  assert.equal(buildCommandLine('C:\\Apps\\App.exe', ['--flag', 'a b']), 'C:\\Apps\\App.exe --flag "a b"');
  assert.throws(() => quoteWindowsArg('bad\0arg'), /no son válidos/);
});

test('parseCloneLine reconoce el handshake y descarta líneas ajenas', () => {
  assert.deepEqual(parseCloneLine('PERFILLAB_CLONE_READY 4321\r'), { type: 'ready', pid: 4321 });
  assert.deepEqual(parseCloneLine('PERFILLAB_CLONE_ERROR 1326'), { type: 'error', code: 1326 });
  assert.deepEqual(parseCloneLine('PERFILLAB_CLONE_READY nope'), { type: 'error', code: 0 });
  assert.equal(parseCloneLine('ruido de PowerShell'), null);
  assert.equal(parseCloneLine(''), null);
});

test('launchErrorMessage traduce errores de Windows habituales', () => {
  assert.match(launchErrorMessage(740), /permisos de administrador/);
  assert.match(launchErrorMessage(1326), /iniciar sesión/);
  assert.match(launchErrorMessage(1331), /deshabilitada/);
  assert.match(launchErrorMessage(9999), /código 9999/);
  assert.match(launchErrorMessage(0), /no pudo iniciar la aplicación/);
});

test('el lanzador nativo usa CreateProcessWithLogonW, perfil y trabajo supervisado', () => {
  const script = buildLauncherScript();
  assert.match(script, /CreateProcessWithLogonW/);
  // No debe fijarse lpDesktop: hacerlo provoca el fallo 0xc0000142 en el proceso hijo.
  assert.doesNotMatch(script, /lpDesktop\s*=\s*@/);
  assert.match(script, /PERFILLAB_CLONE_READY/);
  assert.match(script, /PERFILLAB_CLONE_ERROR/);
  assert.match(script, /0x00000400/);
  assert.match(script, /LOGON_WITH_PROFILE|0x00002000/);
  assert.match(script, /AssignProcessToJobObject/);
  assert.match(script, /WaitForSingleObject/);
});

test('los scripts elevados validan la identidad y nunca incrustan la contraseña', () => {
  const requestPath = "C:\\Temp\\O'Brien\\request.json";
  const provision = buildProvisionScript(requestPath, 'C:\\Temp\\op\\result.json');
  assert.match(provision, /Get-LocalUser/);
  assert.match(provision, /New-LocalUser/);
  assert.match(provision, /Set-LocalUser/);
  assert.match(provision, /S-1-5-32-545/);
  assert.match(provision, /S-1-5-32-544/);
  assert.match(provision, /\^PL_\[0-9a-f\]\{12\}\$/);
  assert.match(provision, /Length -lt 24/);
  assert.match(provision, /'C:\\Temp\\O''Brien\\request\.json'/);
  assert.doesNotMatch(provision, /Pl1!/);

  const release = buildReleaseScript('C:\\Temp\\op\\request.json', 'C:\\Temp\\op\\result.json');
  assert.match(release, /Remove-LocalUser/);
  assert.match(release, /Win32_UserProfile/);
  assert.match(release, /pertenece a PerfilLab/);

  const elevated = buildElevatedLauncher('Write-Output ok', 'C:\\PowerShell\\powershell.exe');
  assert.match(elevated, /Start-Process/);
  assert.match(elevated, /-Verb RunAs/);
  assert.match(elevated, /-EncodedCommand/);
  assert.match(elevated, /1223/);
});

test('en plataformas no Windows el motor se declara no disponible', async () => {
  const provider = new NativeCloneProvider({ platform: 'linux', env: {}, windows: '/home/tester' });
  assert.equal(provider.snapshot().available, false);
  const status = await provider.capabilities();
  assert.equal(status.checked, true);
  assert.equal(status.available, false);
  await assert.rejects(provider.prepare('profile-1'), (error) => error.code === 'clone_unsupported');
  await assert.rejects(
    provider.startProcess({ username: accountName('profile-1'), password: 'x'.repeat(24), target: '/bin/true' }),
    (error) => error.code === 'clone_unsupported',
  );
});

test('capabilities consulta Windows PowerShell una vez y cachea el resultado', async () => {
  const calls = [];
  const provider = makeProvider({
    execFileImpl(file, args, options, callback) {
      calls.push({ file, args, options });
      callback(null, JSON.stringify({
        available: true,
        localAccounts: true,
        elevated: false,
        uac: 1,
        powershell: '5.1.22621.1',
        os: 'Microsoft Windows 11 Pro',
        version: '10.0.22621',
      }), '');
    },
  });
  const first = await provider.capabilities();
  assert.equal(first.available, true);
  assert.equal(first.uac, true);
  assert.equal(first.localAccounts, true);
  assert.equal(first.checked, true);
  assert.equal(first.os, 'Microsoft Windows 11 Pro');
  assert.equal(calls.length, 1);
  await provider.capabilities();
  assert.equal(calls.length, 1);
  await provider.capabilities(true);
  assert.equal(calls.length, 2);
});

test('capabilities informa un error claro si PowerShell falla', async () => {
  const provider = makeProvider({
    execFileImpl(file, args, options, callback) {
      callback(Object.assign(new Error('operación cancelada'), { code: 1 }), '', 'cancelada');
    },
  });
  const status = await provider.capabilities();
  assert.equal(status.available, false);
  assert.equal(status.checked, true);
  assert.match(status.error, /No se pudo consultar Windows PowerShell/);
});

test('prepare genera credencial, nombre y SID a partir del perfil', async () => {
  const provider = makeProvider();
  provider.elevatedAction = async (action, payload) => {
    assert.equal(action, 'provision');
    assert.equal(payload.username, accountName('profile-7'));
    assert.equal(payload.description, accountDescription('profile-7'));
    assert.match(payload.password, /^Pl1!/);
    return {
      ok: true,
      username: payload.username,
      description: payload.description,
      sid: SID,
      created: true,
    };
  };
  const prepared = await provider.prepare('profile-7');
  assert.equal(prepared.username, accountName('profile-7'));
  assert.equal(prepared.description, accountDescription('profile-7'));
  assert.equal(prepared.sid, SID);
  assert.equal(prepared.created, true);
  assert.match(prepared.password, /^Pl1!/);
  assert.ok(prepared.password.length >= 24);
});

test('release rechaza una cuenta que no pertenece al perfil', async () => {
  const provider = makeProvider();
  let called = false;
  provider.elevatedAction = async () => { called = true; return { ok: true }; };
  await assert.rejects(
    provider.release({ profileId: 'profile-1', username: accountName('profile-2') }),
    /no corresponde a este perfil/,
  );
  assert.equal(called, false);
});

test('startProcess entrega la contraseña por stdin y no por la línea de comandos', async () => {
  const child = fakeChild(990002);
  let spawned = null;
  const provider = makeProvider({
    spawnImpl(file, args, options) {
      spawned = { file, args, options };
      return child;
    },
  });
  const password = generatePassword();
  const started = await provider.startProcess({
    username: accountName('profile-1'),
    password,
    target: 'C:\\Apps\\App.exe',
    args: ['--flag', 'a b'],
    cwd: 'C:\\Apps',
  });
  setImmediate(() => child.stdout.emit('data', 'ruido\r\nPERFILLAB_CLONE_READY 4321\r\n'));
  assert.equal(await started.ready, 4321);
  assert.equal(spawned.file, 'C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe');
  assert.ok(spawned.args.includes('-EncodedCommand'));
  assert.ok(!spawned.args.join(' ').includes(password));
  assert.ok(!spawned.args.join(' ').includes('--flag'));
  const request = JSON.parse(child.written.join(''));
  assert.equal(request.username, accountName('profile-1'));
  assert.equal(request.password, password);
  assert.equal(request.commandLine, 'C:\\Apps\\App.exe --flag "a b"');
  assert.equal(request.cwd, 'C:\\Apps');
  assert.equal(request.hidden, false);
});

test('startProcess propaga el código Win32 del handshake', async () => {
  const child = fakeChild(990003);
  const provider = makeProvider({ spawnImpl: () => child });
  const started = await provider.startProcess({
    username: accountName('profile-1'),
    password: generatePassword(),
    target: 'C:\\Apps\\App.exe',
  });
  setImmediate(() => child.stdout.emit('data', 'PERFILLAB_CLONE_ERROR 1326\r\n'));
  await assert.rejects(started.ready, (error) => (
    error.code === 'clone_launch_failed' && /iniciar sesión/.test(error.message)
  ));
});

test('startProcess falla con un mensaje accionable si vence el tiempo', async () => {
  const child = fakeChild(999999);
  const provider = makeProvider({
    spawnImpl: () => child,
    execFileImpl(file, args, options, callback) { callback(null, '', ''); },
  });
  const started = await provider.startProcess({
    username: accountName('profile-1'),
    password: generatePassword(),
    target: 'C:\\Apps\\App.exe',
    timeoutMs: 25,
  });
  await assert.rejects(started.ready, (error) => (
    error.code === 'clone_launch_timeout' && /tardó demasiado/.test(error.message)
  ));
});

test('el lanzador C# real compila y Windows informa el fallo de inicio de sesión', {
  skip: process.platform !== 'win32',
  timeout: 90000,
}, async () => {
  const provider = new NativeCloneProvider();
  const comspec = path.join(process.env.SystemRoot || 'C:\\Windows', 'System32', 'cmd.exe');
  const started = await provider.startProcess({
    username: accountName(`diagnostico-${Date.now()}`),
    password: generatePassword(),
    target: comspec,
    args: ['/d', '/c', 'exit'],
    cwd: path.dirname(comspec),
    hidden: true,
  });
  await assert.rejects(started.ready, (error) => (
    error.code === 'clone_launch_failed' && /1326/.test(error.message)
  ));
});

test('startProcess valida rutas, argumentos y credencial', async () => {
  const provider = makeProvider();
  await assert.rejects(provider.startProcess({
    username: accountName('profile-1'),
    password: generatePassword(),
    target: 'App.exe',
  }), /ruta absoluta/);
  await assert.rejects(provider.startProcess({
    username: accountName('profile-1'),
    password: generatePassword(),
    target: 'C:\\Apps\\App.exe',
    args: [1],
  }), /argumentos/);
  await assert.rejects(provider.startProcess({
    username: 'PL_invalid',
    password: generatePassword(),
    target: 'C:\\Apps\\App.exe',
  }), /nombre de la cuenta/);
});

test('prepareAppAccess concede lectura solo dentro de la carpeta del usuario', async () => {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'perfillab-clone-access-'));
  const appDir = path.join(root, 'Apps');
  const workDir = path.join(root, 'Work');
  fs.mkdirSync(appDir);
  fs.mkdirSync(workDir);
  fs.writeFileSync(path.join(appDir, 'App.exe'), '');
  const calls = [];
  const provider = makeProvider({
    windows: root,
    execFileImpl(file, args, options, callback) {
      calls.push({ file, args });
      callback(null, 'procesado', '');
    },
  });
  const result = await provider.prepareAppAccess({
    sid: SID,
    target: path.join(appDir, 'App.exe'),
    cwd: workDir,
  });
  assert.equal(calls.length, 2);
  assert.equal(calls[0].file, 'icacls.exe');
  assert.deepEqual(calls[0].args, [appDir, '/grant', `*${SID}:(OI)(CI)RX`, '/C', '/Q']);
  assert.deepEqual(result.granted.sort(), [appDir, workDir].sort());
  assert.deepEqual(result.skipped, []);

  const outside = path.join(os.tmpdir(), 'PerfilLab-ProgramFiles', 'App.exe');
  const skipped = await provider.prepareAppAccess({ sid: SID, target: outside });
  assert.deepEqual(skipped.granted, []);
  assert.equal(skipped.skipped.length, 1);

  await assert.rejects(
    provider.prepareAppAccess({ sid: SID, target: path.join(root, 'App.exe') }),
    (error) => error.code === 'clone_access_invalid',
  );
  await assert.rejects(
    provider.prepareAppAccess({ sid: 'not-a-sid', target: path.join(appDir, 'App.exe') }),
    /identificador de la cuenta/,
  );
  fs.rmSync(root, { recursive: true, force: true });
});

test('prepareAppAccess falla si Windows no puede aplicar la ACL', async () => {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'perfillab-clone-denied-'));
  const appDir = path.join(root, 'Apps');
  fs.mkdirSync(appDir);
  fs.writeFileSync(path.join(appDir, 'App.exe'), '');
  const provider = makeProvider({
    windows: root,
    execFileImpl(file, args, options, callback) {
      callback(Object.assign(new Error('acceso denegado'), { code: 5 }), '', 'acceso denegado');
    },
  });
  await assert.rejects(
    provider.prepareAppAccess({ sid: SID, target: path.join(appDir, 'App.exe') }),
    (error) => error.code === 'clone_access_grant_failed' && /lectura/.test(error.message),
  );
  fs.rmSync(root, { recursive: true, force: true });
});
