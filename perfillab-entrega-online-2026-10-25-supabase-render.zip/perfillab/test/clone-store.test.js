'use strict';

const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const test = require('node:test');

const dataRoot = fs.mkdtempSync(path.join(os.tmpdir(), 'perfillab-clone-store-'));
process.env.PERFILLAB_DATA_DIR = dataRoot;

const { Store } = require('../electron/store');
const { accountName, accountDescription } = require('../electron/native-clone');
const { vmName } = require('../electron/hyperv');

const EXE = path.join(dataRoot, 'App.exe');

test('el esquema v5 migra a cuenta de Windows, descarta Sandboxie y normaliza cuentas clon', (t) => {
  t.after(() => fs.rmSync(dataRoot, { recursive: true, force: true }));
  fs.writeFileSync(EXE, '');
  const store = new Store();
  const state = store.normalize({
    schemaVersion: 3,
    settings: { sandboxieDir: 'C:\\Sandboxie', theme: 'dark' },
    workspaces: [],
    proxies: [],
    profiles: [
      { id: 'p1', name: 'Perfil 1' },
      { id: 'p2', name: 'Perfil 2' },
      { id: 'p3', name: 'Perfil 3' },
    ],
    apps: [
      { id: 'a1', name: 'Heredada', kind: 'executable', target: EXE, isolateData: true },
      { id: 'a2', name: 'Sin aislamiento', kind: 'executable', target: EXE, isolateData: false },
      { id: 'a3', name: 'Antigua caja', kind: 'executable', target: EXE, sandboxie: true, sandboxConfig: 'Template=Edge_Fix' },
      { id: 'a4', name: 'Datos', kind: 'executable', target: EXE, cloneMode: 'data' },
      { id: 'a5', name: 'Cuenta', kind: 'executable', target: EXE, cloneMode: 'account' },
      { id: 'a6', name: 'Calculadora', kind: 'startapp', target: 'Microsoft.WindowsCalculator_8wekyb3d8bbwe!App', sandboxie: true },
    ],
    cloneAccounts: [
      {
        profileId: 'p1',
        username: accountName('p1'),
        description: 'texto alterado',
        sid: 'S-1-5-21-111111111-222222222-333333333-1001',
        passwordEnc: 'plain1:UExfVEVTVA==',
        preparedAt: '2026-01-01T00:00:00.000Z',
        verifiedAt: null,
      },
      {
        profileId: 'p1',
        username: accountName('p1'),
        sid: 'S-1-5-21-111111111-222222222-333333333-1001',
        passwordEnc: 'plain1:RFVQTElDQURP',
      },
      {
        profileId: 'p2',
        username: accountName('p3'),
        sid: 'S-1-5-21-111111111-222222222-333333333-1002',
        passwordEnc: 'plain1:SU5WQUxJRE8=',
      },
      {
        profileId: 'p2',
        username: accountName('p2'),
        sid: 'S-1-5-21-111111111-222222222-333333333-1002',
        passwordEnc: 'sin-prefijo',
      },
      {
        profileId: 'p3',
        username: accountName('p3'),
        sid: 'no-es-un-sid',
        passwordEnc: 'plain1:U0lO',
      },
      {
        profileId: 'p3',
        username: accountName('p3'),
        sid: 'S-1-5-21-111111111-222222222-333333333-1003',
        passwordEnc: 'plain1:RFVQTElDQURP',
      },
      {
        profileId: 'fantasma',
        username: accountName('fantasma'),
        sid: 'S-1-5-21-111111111-222222222-333333333-1004',
        passwordEnc: 'plain1:RkFOVEFTTUE=',
      },
    ],
    appProfileConfigs: [],
    activity: [],
  }, false);

  assert.equal(state.schemaVersion, 7);
  assert.equal(state.settings.sandboxieDir, undefined);
  assert.equal(state.settings.theme, 'dark');

  const byId = Object.fromEntries(state.apps.map((app) => [app.id, app]));
  assert.equal(byId.a1.cloneMode, 'account');
  assert.equal(byId.a2.cloneMode, 'none');
  assert.equal(byId.a3.cloneMode, 'account');
  assert.equal(byId.a4.cloneMode, 'account');
  assert.equal(byId.a5.cloneMode, 'account');
  assert.equal(byId.a6.cloneMode, 'none');
  for (const app of state.apps) {
    assert.equal(Object.hasOwn(app, 'sandboxie'), false);
    assert.equal(Object.hasOwn(app, 'sandboxConfig'), false);
    assert.equal(Object.hasOwn(app, 'isolateData'), false);
  }

  assert.equal(state.cloneAccounts.length, 2);
  const first = state.cloneAccounts.find((item) => item.profileId === 'p1');
  assert.equal(first.username, accountName('p1'));
  assert.equal(first.description, accountDescription('p1'));
  assert.equal(first.passwordEnc, 'plain1:UExfVEVTVA==');
  assert.equal(first.preparedAt, '2026-01-01T00:00:00.000Z');
  const third = state.cloneAccounts.find((item) => item.profileId === 'p3');
  assert.equal(third.sid, null);
  assert.equal(third.description, accountDescription('p3'));
});

test('el esquema v5 conserva el modo Datos aislados elegido explícitamente', (t) => {
  t.after(() => fs.rmSync(dataRoot, { recursive: true, force: true }));
  fs.mkdirSync(dataRoot, { recursive: true });
  fs.writeFileSync(EXE, '');
  const store = new Store();
  const state = store.normalize({
    schemaVersion: 5,
    settings: {},
    workspaces: [],
    proxies: [],
    profiles: [{ id: 'p1', name: 'Perfil 1' }],
    apps: [
      { id: 'a1', name: 'Datos', kind: 'executable', target: EXE, cloneMode: 'data' },
      { id: 'a2', name: 'Cuenta', kind: 'executable', target: EXE, cloneMode: 'account' },
      { id: 'a3', name: 'Sin', kind: 'executable', target: EXE, cloneMode: 'none' },
    ],
    cloneAccounts: [],
    appProfileConfigs: [],
    activity: [],
  }, false);
  const byId = Object.fromEntries(state.apps.map((app) => [app.id, app]));
  assert.equal(byId.a1.cloneMode, 'data');
  assert.equal(byId.a2.cloneMode, 'account');
  assert.equal(byId.a3.cloneMode, 'none');
});

test('el esquema v6 conserva los modos previos, acepta vm y normaliza las máquinas', (t) => {
  t.after(() => fs.rmSync(dataRoot, { recursive: true, force: true }));
  fs.mkdirSync(dataRoot, { recursive: true });
  fs.writeFileSync(EXE, '');
  const store = new Store();
  const validDisk = path.join(dataRoot, 'PL-aaaaaaaaaaaa.vhdx');
  const state = store.normalize({
    schemaVersion: 5,
    settings: {
      vm: {
        baseImagePath: 'C:\\vms\\base.vhdx',
        switchName: '  LAN  ',
        memoryMb: 512,
        cpuCount: 99,
        generation: 3,
      },
    },
    workspaces: [],
    proxies: [],
    profiles: [{ id: 'p1', name: 'Perfil 1' }, { id: 'p2', name: 'Perfil 2' }],
    apps: [
      { id: 'a1', name: 'Datos', kind: 'executable', target: EXE, cloneMode: 'data' },
      { id: 'a2', name: 'Cuenta', kind: 'executable', target: EXE, cloneMode: 'account' },
      { id: 'a3', name: 'Máquina', kind: 'executable', target: EXE, cloneMode: 'vm' },
    ],
    cloneAccounts: [],
    virtualMachines: [
      { profileId: 'p1', vmName: vmName('p1'), diskPath: validDisk },
      { profileId: 'p1', vmName: vmName('p1'), diskPath: validDisk },
      { profileId: 'p2', vmName: 'PL-000000000000', diskPath: '' },
      { profileId: 'fantasma', vmName: vmName('fantasma'), diskPath: '' },
    ],
    appProfileConfigs: [],
    activity: [],
  }, false);
  assert.equal(state.schemaVersion, 7);
  const byId = Object.fromEntries(state.apps.map((app) => [app.id, app]));
  assert.equal(byId.a1.cloneMode, 'data');
  assert.equal(byId.a2.cloneMode, 'account');
  assert.equal(byId.a3.cloneMode, 'vm');
  assert.equal(state.settings.vm.baseImagePath, 'C:\\vms\\base.vhdx');
  assert.equal(state.settings.vm.switchName, 'LAN');
  assert.equal(state.settings.vm.memoryMb, 1024);
  assert.equal(state.settings.vm.cpuCount, 16);
  assert.equal(state.settings.vm.generation, 2);
  assert.equal(state.virtualMachines.length, 1);
  assert.equal(state.virtualMachines[0].profileId, 'p1');
  assert.equal(state.virtualMachines[0].vmName, vmName('p1'));
  assert.equal(state.virtualMachines[0].diskPath, validDisk);
});

test('un estado nuevo incluye cuentas clon vacías y no expone ajustes de Sandboxie', () => {
  const store = new Store();
  const state = store.normalize(null, false);
  assert.equal(state.schemaVersion, 7);
  assert.equal(state.profileStatuses.length, 3);
  assert.deepEqual(state.profileStatuses.map((status) => status.name), ['Nuevo', 'En uso', 'Pausado']);
  assert.deepEqual(state.cloneAccounts, []);
  assert.deepEqual(state.virtualMachines, []);
  assert.equal(state.settings.vm.switchName, 'Default Switch');
  assert.equal(state.settings.vm.memoryMb, 4096);
  assert.equal(state.settings.vm.generation, 2);
  assert.equal(Object.hasOwn(state.settings, 'sandboxieDir'), false);
  assert.equal(state.apps.length, 0);
});

test('el esquema v7 normaliza estados, limita duplicados y limpia statusId inválidos', (t) => {
  t.after(() => fs.rmSync(dataRoot, { recursive: true, force: true }));
  fs.mkdirSync(dataRoot, { recursive: true });
  const store = new Store();
  const filler = Array.from({ length: 35 }, (_, index) => ({ id: `sx${index}`, name: `Estado ${index}` }));
  const state = store.normalize({
    schemaVersion: 6,
    settings: {},
    workspaces: [],
    profileStatuses: [
      { id: 's1', name: '  En uso  ', color: '#22c55e' },
      { id: 's1', name: 'Duplicado por identificador' },
      { id: 's2', name: 'en uso', color: '#000000' },
      { id: 's3', name: 'Sin color válido', color: 'rojo' },
      ...filler,
    ],
    proxies: [],
    profiles: [
      { id: 'p1', name: 'Uno', statusId: 's1' },
      { id: 'p2', name: 'Dos', statusId: 'fantasma' },
    ],
    apps: [],
    cloneAccounts: [],
    appProfileConfigs: [],
    activity: [],
  }, false);
  assert.equal(state.schemaVersion, 7);
  assert.equal(state.profileStatuses.length, 30);
  assert.equal(state.profileStatuses[0].id, 's1');
  assert.equal(state.profileStatuses[0].name, 'En uso');
  assert.equal(state.profileStatuses[0].color, '#22c55e');
  assert.equal(state.profileStatuses[1].id, 's3');
  assert.equal(state.profileStatuses[1].color, '#5b6cff');
  assert.equal(state.profiles.find((profile) => profile.id === 'p1').statusId, 's1');
  assert.equal(state.profiles.find((profile) => profile.id === 'p2').statusId, null);

  const empty = store.normalize({
    schemaVersion: 7,
    settings: {},
    workspaces: [],
    profileStatuses: [],
    proxies: [],
    profiles: [],
    apps: [],
    cloneAccounts: [],
    appProfileConfigs: [],
    activity: [],
  }, false);
  assert.equal(empty.profileStatuses.length, 0);
});

test('las cuentas preparadas sobreviven a una recarga del almacén', (t) => {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'perfillab-clone-reload-'));
  const previous = process.env.PERFILLAB_DATA_DIR;
  process.env.PERFILLAB_DATA_DIR = root;
  t.after(() => {
    process.env.PERFILLAB_DATA_DIR = previous;
    fs.rmSync(root, { recursive: true, force: true });
  });
  const store = new Store();
  fs.writeFileSync(path.join(root, 'App.exe'), '');
  store.state = store.normalize({
    settings: { profilesDir: path.join(root, 'profiles') },
    profiles: [{ id: 'p1', name: 'Perfil 1' }],
    apps: [{ id: 'a1', name: 'App', kind: 'executable', target: path.join(root, 'App.exe'), cloneMode: 'account' }],
    cloneAccounts: [{
      profileId: 'p1',
      username: accountName('p1'),
      sid: 'S-1-5-21-111111111-222222222-333333333-1001',
      passwordEnc: 'enc1:QUJD',
      verifiedAt: '2026-02-01T00:00:00.000Z',
    }],
  }, false);
  store.save();

  const reloaded = new Store();
  reloaded.load();
  assert.equal(reloaded.state.cloneAccounts.length, 1);
  assert.equal(reloaded.state.cloneAccounts[0].username, accountName('p1'));
  assert.equal(reloaded.state.cloneAccounts[0].passwordEnc, 'enc1:QUJD');
  assert.equal(reloaded.state.apps[0].cloneMode, 'account');
});
