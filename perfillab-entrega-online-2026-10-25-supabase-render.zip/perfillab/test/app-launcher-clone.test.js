'use strict';

const assert = require('node:assert/strict');
const { EventEmitter } = require('node:events');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const test = require('node:test');

const { AppLauncher } = require('../electron/app-launcher');
const { accountName } = require('../electron/native-clone');
const { vmName } = require('../electron/hyperv');

const SID = 'S-1-5-21-111111111-222222222-333333333-1001';
const PASSWORD = 'Pl1!abcdefghijklmnopqrstuvwx';

function fakeChild(pid) {
  const child = new EventEmitter();
  child.pid = pid;
  child.exitCode = null;
  child.signalCode = null;
  setImmediate(() => child.emit('spawn'));
  return child;
}

function makeRoot(t) {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'perfillab-clone-launcher-'));
  fs.mkdirSync(path.join(root, 'profiles'), { recursive: true });
  fs.writeFileSync(path.join(root, 'App.exe'), '');
  t.after(() => fs.rmSync(root, { recursive: true, force: true }));
  return root;
}

function makeHarness(root, { account = true, hyperV = null } = {}) {
  const calls = { access: [], start: [], spawn: [] };
  let nextPid = 910000;
  const state = {
    settings: { profilesDir: path.join(root, 'profiles') },
    profiles: [{ id: 'profile-1', name: 'Perfil 1' }],
    apps: [
      {
        id: 'app-account',
        name: 'App cuenta',
        kind: 'executable',
        target: path.join(root, 'App.exe'),
        args: '',
        cwd: '',
        cloneMode: 'account',
      },
      {
        id: 'app-data',
        name: 'App datos',
        kind: 'executable',
        target: path.join(root, 'App.exe'),
        args: '',
        cwd: '',
        cloneMode: 'data',
      },
      {
        id: 'app-none',
        name: 'App normal',
        kind: 'executable',
        target: path.join(root, 'App.exe'),
        args: '',
        cwd: '',
        cloneMode: 'none',
      },
      {
        id: 'app-start',
        name: 'Calculadora',
        kind: 'startapp',
        target: 'Microsoft.WindowsCalculator_8wekyb3d8bbwe!App',
        args: '',
        cwd: '',
        cloneMode: 'none',
      },
      {
        id: 'app-vm',
        name: 'App máquina',
        kind: 'executable',
        target: 'C:\\Program Files\\Ejemplo\\app.exe',
        args: '',
        cwd: '',
        cloneMode: 'vm',
      },
    ],
    cloneAccounts: account
      ? [{
        profileId: 'profile-1',
        username: accountName('profile-1'),
        description: 'PerfilLab clon 00000000',
        sid: SID,
        passwordEnc: `plain1:${Buffer.from(PASSWORD, 'utf8').toString('base64')}`,
        preparedAt: new Date().toISOString(),
        verifiedAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      }]
      : [],
    appProfileConfigs: [],
  };
  const nativeClone = {
    calls,
    async prepareAppAccess(input) {
      calls.access.push(input);
      return { granted: [], skipped: [path.dirname(input.target)] };
    },
    async startProcess(input) {
      calls.start.push(input);
      const child = fakeChild(nextPid);
      nextPid += 1;
      return { child, ready: Promise.resolve(5252) };
    },
  };
  const spawnImpl = (file, args, options) => {
    calls.spawn.push({ file, args, options });
    const child = fakeChild(nextPid);
    nextPid += 1;
    return child;
  };
  const launcher = new AppLauncher({ getState: () => state }, { nativeClone, spawnImpl, hyperV });
  return { launcher, state, calls, nativeClone };
}

function emitExit(child, code = 0) {
  child.emit('exit', code, null);
  return new Promise((resolve) => setImmediate(resolve));
}

test('launch en modo cuenta usa la cuenta del perfil y su credencial descifrada', async (t) => {
  const root = makeRoot(t);
  const { launcher, state, calls } = makeHarness(root);
  const launched = new Promise((resolve) => launcher.once('launched', resolve));
  const result = await launcher.launch('profile-1', 'app-account', { arguments: '--flag' });
  const event = await launched;

  assert.equal(result.isolation, 'account');
  assert.equal(result.isolated, true);
  assert.equal(result.accountName, accountName('profile-1'));
  assert.equal(result.pid, 5252);
  assert.equal(event.accountName, accountName('profile-1'));
  assert.equal(calls.access.length, 1);
  assert.equal(calls.access[0].sid, SID);
  assert.equal(calls.start.length, 1);
  assert.equal(calls.start[0].username, accountName('profile-1'));
  assert.equal(calls.start[0].password, PASSWORD);
  assert.deepEqual(calls.start[0].args, ['--flag']);
  assert.equal(calls.start[0].cwd, path.dirname(path.join(root, 'App.exe')));

  const running = launcher.listRunning();
  assert.equal(running.length, 1);
  assert.equal(running[0].isolation, 'account');
  assert.equal(running[0].cloneMode, 'account');
  assert.equal(running[0].accountName, accountName('profile-1'));
  assert.equal(running[0].pid, 5252);

  await assert.rejects(
    launcher.launch('profile-1', 'app-account', {}),
    (error) => error.code === 'conflict' && /Ya hay un clon/.test(error.message),
  );

  assert.equal(state.cloneAccounts.length, 1);
  await emitExit(launcher.running.values().next().value.child);
  assert.equal(launcher.listRunning().length, 0);
});

test('el modo cuenta exige una cuenta preparada y una credencial legible', async (t) => {
  const root = makeRoot(t);
  const { launcher, state, nativeClone } = makeHarness(root, { account: false });
  await assert.rejects(
    launcher.launch('profile-1', 'app-account', {}),
    (error) => error.code === 'clone_account_missing',
  );
  state.cloneAccounts.push({
    profileId: 'profile-1',
    username: accountName('profile-1'),
    sid: SID,
    passwordEnc: 'plain1:',
  });
  await assert.rejects(
    launcher.launch('profile-1', 'app-account', {}),
    (error) => error.code === 'clone_credential_missing',
  );
  state.cloneAccounts[0].passwordEnc = 'v1:invalido';
  await assert.rejects(
    launcher.launch('profile-1', 'app-account', {}),
    (error) => error.code === 'clone_credential_missing',
  );
  nativeClone.calls.start.length = 0;
  await assert.rejects(
    launcher.launch('profile-1', 'app-account', {}),
    (error) => error.code === 'clone_credential_missing',
  );
  assert.equal(nativeClone.calls.start.length, 0);
});

test('el modo datos redirige APPDATA, LOCALAPPDATA y TEMP a la carpeta del perfil', async (t) => {
  const root = makeRoot(t);
  const { launcher, calls } = makeHarness(root);
  const result = await launcher.launch('profile-1', 'app-data', {});
  assert.equal(result.isolation, 'data');
  assert.equal(result.isolated, true);

  const spawn = calls.spawn.at(-1);
  const isolated = path.join(root, 'profiles', 'profile-1', 'applications', 'app-data');
  assert.equal(spawn.args.length, 0);
  assert.equal(spawn.options.cwd, path.join(root, 'profiles', 'profile-1', 'applications'));
  assert.equal(spawn.options.env.APPDATA, path.join(isolated, 'Roaming'));
  assert.equal(spawn.options.env.LOCALAPPDATA, path.join(isolated, 'Local'));
  assert.equal(spawn.options.env.TEMP, path.join(isolated, 'Temp'));
  assert.equal(spawn.options.env.TMP, path.join(isolated, 'Temp'));
  assert.equal(spawn.options.env.PERFILLAB_PROFILE_ID, 'profile-1');
  assert.equal(spawn.options.env.PERFILLAB_APPLICATION_ID, 'app-data');
  assert.equal(spawn.options.env.USERPROFILE, process.env.USERPROFILE);
  assert.equal(fs.existsSync(isolated), true);

  await emitExit(launcher.running.values().next().value.child);
  assert.equal(launcher.listRunning().length, 0);
});

test('el modo sin aislamiento conserva el entorno del usuario', async (t) => {
  const root = makeRoot(t);
  const { launcher, calls } = makeHarness(root);
  const result = await launcher.launch('profile-1', 'app-none', { cwd: root });
  assert.equal(result.isolation, 'none');
  assert.equal(result.isolated, false);
  const spawn = calls.spawn.at(-1);
  assert.equal(spawn.options.cwd, root);
  assert.equal(spawn.options.env.APPDATA, process.env.APPDATA);
  assert.equal(spawn.options.env.TEMP, process.env.TEMP);
  await emitExit(launcher.running.values().next().value.child);
});

test('el modo cuenta propaga el fallo del motor nativo y limpia la instancia', async (t) => {
  const root = makeRoot(t);
  const { launcher, nativeClone } = makeHarness(root);
  nativeClone.startProcess = async () => {
    const { AppError } = require('../electron/errors');
    throw new AppError('Windows denegó el acceso al ejecutable.', 500, 'clone_launch_failed');
  };
  await assert.rejects(
    launcher.launch('profile-1', 'app-account', {}),
    (error) => error.code === 'clone_launch_failed',
  );
  assert.equal(launcher.listRunning().length, 0);
});

test('el lanzador de aplicaciones del menú Inicio no se puede supervisar', async (t) => {
  const root = makeRoot(t);
  const { launcher, calls } = makeHarness(root);
  const result = await launcher.launch('profile-1', 'app-start', {});
  assert.equal(result.tracked, false);
  assert.equal(result.isolation, 'none');
  assert.equal(calls.spawn.at(-1).file, 'explorer.exe');
  assert.deepEqual(calls.spawn.at(-1).args, ['shell:AppsFolder\\Microsoft.WindowsCalculator_8wekyb3d8bbwe!App']);
  assert.equal(launcher.listRunning().length, 0);
});

test('el modo máquina virtual enciende la VM del perfil sin validar el ejecutable en el host', async (t) => {
  const root = makeRoot(t);
  const hyperV = new EventEmitter();
  const calls = { ensure: [], window: [], stop: [], stopAll: [] };
  hyperV.run = async (profileId, task) => task();
  hyperV.ensure = async (profileId, settings, options) => {
    calls.ensure.push({ profileId, settings, options });
    return {
      vmName: vmName(profileId),
      diskPath: path.join(root, 'vms', `${vmName(profileId)}.vhdx`),
      state: 'Running',
      created: true,
    };
  };
  hyperV.openWindow = (profileId, profileName, name) => {
    calls.window.push({ profileId, profileName, vmName: name });
    return { pid: 4321, startedAt: '2026-10-25T00:00:00.000Z' };
  };
  hyperV.stop = async (profileId) => {
    calls.stop.push(profileId);
    return { state: 'Off' };
  };
  hyperV.stopAll = async (profileIds) => {
    calls.stopAll.push(profileIds);
    return { stopped: profileIds.length };
  };
  hyperV.closeWindow = () => {};
  const { launcher } = makeHarness(root, { hyperV });

  const result = await launcher.launch('profile-1', 'app-vm', {});
  assert.equal(result.isolation, 'vm');
  assert.equal(result.vmName, vmName('profile-1'));
  assert.match(result.message, /máquina virtual/i);
  assert.equal(calls.ensure.length, 1);
  assert.deepEqual(calls.ensure[0].options, { start: true });
  assert.deepEqual(calls.window, [{
    profileId: 'profile-1',
    profileName: 'Perfil 1',
    vmName: vmName('profile-1'),
  }]);

  const running = launcher.listRunning();
  assert.equal(running.length, 1);
  assert.equal(running[0].instanceId, 'vm:profile-1');
  assert.equal(running[0].isolation, 'vm');
  assert.equal(running[0].vmName, vmName('profile-1'));

  await assert.rejects(
    launcher.launch('profile-1', 'app-vm', {}),
    (error) => error.code === 'conflict',
  );

  hyperV.emit('window-exit', { profileId: 'profile-1', code: 0, signal: null });
  assert.equal(launcher.listRunning().length, 0);

  await launcher.launch('profile-1', 'app-vm', {});
  await launcher.stop('vm:profile-1');
  assert.deepEqual(calls.stop, ['profile-1']);
  assert.equal(launcher.listRunning().length, 0);

  await launcher.launch('profile-1', 'app-vm', {});
  const stopped = await launcher.stopAllVms();
  assert.deepEqual(stopped, { stopped: 1 });
  assert.deepEqual(calls.stopAll, [['profile-1']]);
  assert.equal(launcher.listRunning().length, 0);
});

test('validateAppDraft aplica el modo de clonación y bloquea el menú Inicio', (t) => {
  const root = makeRoot(t);
  const launcher = new AppLauncher({ getState: () => ({}) }, { nativeClone: {} });
  const exe = path.join(root, 'App.exe');
  const draft = launcher.validateAppDraft({ name: 'App', kind: 'executable', target: exe });
  assert.equal(draft.cloneMode, 'account');
  assert.equal(launcher.validateAppDraft({
    name: 'App', kind: 'executable', target: exe, cloneMode: 'account',
  }).cloneMode, 'account');
  assert.equal(launcher.validateAppDraft({
    name: 'App', kind: 'executable', target: exe, cloneMode: 'data',
  }).cloneMode, 'data');
  assert.equal(launcher.validateAppDraft({
    name: 'App', kind: 'executable', target: exe, cloneMode: 'vm',
  }).cloneMode, 'vm');
  assert.throws(
    () => launcher.validateAppDraft({
      name: 'Calc', kind: 'startapp', target: 'Microsoft.WindowsCalculator_8wekyb3d8bbwe!App', cloneMode: 'account',
    }),
    /menú Inicio/,
  );
  assert.throws(
    () => launcher.validateAppDraft({
      name: 'App', kind: 'executable', target: exe, cloneMode: 'sandbox',
    }),
    /none, data, account o vm/,
  );
  const existing = {
    id: 'a1', name: 'App', kind: 'executable', target: exe, args: '--old', cwd: '', cloneMode: 'data',
  };
  assert.deepEqual(
    launcher.validateAppDraft({ cloneMode: 'none' }, existing),
    { name: 'App', target: exe, kind: 'executable', args: '--old', cwd: '', cloneMode: 'none' },
  );
  assert.equal(
    launcher.validateAppDraft({ name: 'Calculadora', kind: 'startapp', target: 'Microsoft.WindowsCalculator_8wekyb3d8bbwe!App' }).cloneMode,
    'none',
  );
});
