'use strict';

const assert = require('node:assert/strict');
const Module = require('node:module');
const EventEmitter = require('node:events');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const test = require('node:test');

const fixtureRoot = fs.mkdtempSync(path.join(os.tmpdir(), 'perfillab-manage-fixture-'));

const electronStub = {
  app: { getPath: () => fixtureRoot, getVersion: () => '0.0.0-test' },
  safeStorage: { isEncryptionAvailable: () => false },
  shell: { openPath: async () => '' },
};
const originalLoad = Module._load;
Module._load = function load(request, ...rest) {
  if (request === 'electron') return electronStub;
  return originalLoad.call(this, request, ...rest);
};

const csv = require('../electron/csv');
const { Store } = require('../electron/store');
const { AppService } = require('../electron/app-service');
const { BUILTIN_BROWSER_ID } = require('../electron/browser-launch');

class FakeLauncher extends EventEmitter {
  constructor() {
    super();
    this.running = new Map();
    this.failIds = new Set();
    this.starts = [];
    this.stops = [];
  }

  isRunning(profileId) {
    return this.running.has(profileId);
  }

  listRunning() {
    return [...this.running.values()];
  }

  async start(profileId) {
    if (this.failIds.has(profileId)) throw new Error('Fallo simulado del navegador.');
    this.starts.push(profileId);
    const startedAt = new Date().toISOString();
    this.running.set(profileId, { profileId, startedAt, browserName: 'Fake', pid: 1 });
    return { profileId, startedAt, browserName: 'Fake', proxyMode: 'direct' };
  }

  async stop(profileId) {
    this.stops.push(profileId);
    this.running.delete(profileId);
    return { profileId };
  }
}

function createService(t) {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'perfillab-manage-'));
  process.env.PERFILLAB_DATA_DIR = dir;
  t.after(() => fs.rmSync(dir, { recursive: true, force: true }));
  const store = new Store();
  store.load();
  const launcher = new FakeLauncher();
  const service = new AppService({ store, launcher });
  return { store, launcher, service };
}

function createProfile(service, name) {
  return service.createProfile({
    name,
    workspaceId: service.state.workspaces[0].id,
  });
}

test('el parser CSV respeta RFC 4180, BOM, comillas y saltos de línea', () => {
  const text = '\uFEFFNombre,Notas\r\n"Perfil, uno","Línea 1\nLínea 2"\r\n"Dos ""comillas""",simple\r\n';
  const rows = csv.parseCsv(text);
  assert.equal(rows.length, 3);
  assert.deepEqual(rows[1].values, ['Perfil, uno', 'Línea 1\nLínea 2']);
  assert.equal(rows[1].line, 2);
  assert.deepEqual(rows[2].values, ['Dos "comillas"', 'simple']);
  assert.equal(rows[2].line, 4);

  const parsed = csv.parseProfilesCsv(text);
  assert.equal(parsed.rows.length, 2);
  assert.equal(parsed.rows[0].name, 'Perfil, uno');
  assert.equal(parsed.rows[0].notes, 'Línea 1\nLínea 2');
});

test('el parser rechaza comillas sin cerrar y encabezados obligatorios', () => {
  assert.throws(() => csv.parseCsv('a,b\n"sin cerrar,2'), /comillas sin cerrar/);
  assert.throws(() => csv.parseProfilesCsv('Espacio,Notas\nGeneral,texto'), /columna "Nombre"/);
  assert.throws(() => csv.parseProfilesCsv('Nombre,Nombre\nA,B'), /está repetida/);
  assert.throws(() => csv.parseProfilesCsv(''), /vacío/);
});

test('el CSV generado neutraliza fórmulas y vuelve a leerse sin cambios', () => {
  const text = csv.buildProfilesCsv([{
    name: '=HYPERLINK("http://mal")',
    workspace: 'General',
    browser: 'Navegador de prueba',
    proxy: '',
    startUrls: ['https://example.com/'],
    tags: ['uno', 'dos'],
    notes: '-5 grados',
    color: '#112233',
  }]);
  assert(text.startsWith('\uFEFFNombre,Espacio,Estado,Navegador,Proxy,URLs,Etiquetas,Notas,Color'));
  assert(text.includes("'=HYPERLINK"));
  const parsed = csv.parseProfilesCsv(text);
  assert.equal(parsed.rows[0].name, '=HYPERLINK("http://mal")');
  assert.equal(parsed.rows[0].notes, '-5 grados');
  assert.equal(parsed.rows[0].startUrls, 'https://example.com/');
});

test('la importación CSV crea espacios, enlaza proxies por nombre y reporta filas inválidas', (t) => {
  const { service } = createService(t);
  service.createProxy({ name: 'Proxy QA', protocol: 'http', host: '127.0.0.1', port: 8080, username: 'u', password: 'secreto' });
  const text = [
    'Nombre,Espacio,Navegador,Proxy,URLs,Etiquetas,Notas,Color',
    'Perfil CSV,Equipo Nuevo,PerfilLab Browser,Proxy QA,https://example.com/|https://example.org/,uno;dos,"nota, con coma",#112233',
    'Sin navegador,,Desconocido,,, ,,',
    ',General,PerfilLab Browser,,,,,',
    'Malo,General,PerfilLab Browser,,ftp://x,,,',
    'Sin proxy,Equipo Nuevo,PerfilLab Browser,NoExiste,,, ,,',
  ].join('\r\n');
  const result = service.importCsv(text);

  assert.equal(result.profiles, 3);
  assert.equal(result.workspaces, 1);
  assert.equal(result.skippedProxies, 1);
  assert.equal(result.errors.length, 2);
  assert(result.warnings.some((item) => item.includes('"Desconocido" no está disponible')));
  assert(result.warnings.some((item) => item.includes('"NoExiste" no existe')));

  const workspace = service.state.workspaces.find((item) => item.name === 'Equipo Nuevo');
  assert(workspace);
  const imported = service.state.profiles.find((profile) => profile.name === 'Perfil CSV');
  assert.equal(imported.workspaceId, workspace.id);
  assert.equal(imported.proxyId, service.state.proxies[0].id);
  assert.deepEqual(imported.tags, ['uno', 'dos']);
  assert.deepEqual(imported.startUrls, ['https://example.com/', 'https://example.org/']);
  assert.equal(imported.notes, 'nota, con coma');
  assert.equal(imported.color, '#112233');
  const fallback = service.state.profiles.find((profile) => profile.name === 'Sin navegador');
  assert.equal(fallback.browserId, BUILTIN_BROWSER_ID);
  const withoutProxy = service.state.profiles.find((profile) => profile.name === 'Sin proxy');
  assert.equal(withoutProxy.proxyId, null);
  assert.equal(service.state.proxies.length, 1);
  assert.equal(service.state.profiles.some((profile) => profile.name === 'Malo'), false);
});

test('la importación CSV omite un proxy cuyo nombre es ambiguo', (t) => {
  const { service } = createService(t);
  service.createProxy({ name: 'Proxy repetido', protocol: 'http', host: '127.0.0.1', port: 8080, password: 'uno' });
  service.createProxy({ name: 'proxy REPETIDO', protocol: 'http', host: '127.0.0.1', port: 8081, password: 'dos' });
  const result = service.importCsv([
    'Nombre,Proxy',
    'Perfil ambiguo,Proxy repetido',
  ].join('\r\n'));
  assert.equal(result.profiles, 1);
  assert.equal(result.skippedProxies, 1);
  assert(result.warnings.some((item) => item.includes('varios proxies')));
  assert.equal(service.state.profiles[0].proxyId, null);
});

test('la exportación CSV incluye nombres de proxy y estado pero nunca contraseñas', (t) => {
  const { service } = createService(t);
  const proxy = service.createProxy({ name: 'Proxy secreto', protocol: 'http', host: '127.0.0.1', port: 8080, username: 'u', password: 'clave-super-secreta' });
  const status = service.createStatus({ name: 'En prueba', color: '#f59e0b' });
  const profile = createProfile(service, 'Perfil visible');
  service.updateProfile(profile.id, { proxyId: proxy.id, statusId: status.id });

  const text = service.buildCsv([profile.id]);
  assert.equal(text.includes('clave-super-secreta'), false);
  assert.equal(text.includes('Proxy secreto'), true);
  assert.equal(text.includes('En prueba'), true);
  assert.equal(text.includes(proxy.id), false);
  assert.equal(text.includes(status.id), false);
  const parsed = csv.parseProfilesCsv(text);
  assert.equal(parsed.rows.length, 1);
  assert.equal(parsed.rows[0].proxy, 'Proxy secreto');
  assert.equal(parsed.rows[0].status, 'En prueba');
  assert.equal(parsed.rows[0].browser, 'PerfilLab Browser');
  assert.throws(() => service.buildCsv(['no-existe']), /No hay perfiles para exportar/);
});

test('las acciones masivas mueven, inician y detienen con resultados por perfil', async (t) => {
  const { service, launcher } = createService(t);
  const target = service.createWorkspace({ name: 'Lote', color: '#22c55e' });
  const first = createProfile(service, 'Lote uno');
  const second = createProfile(service, 'Lote dos');
  const third = createProfile(service, 'Lote tres');

  const moved = await service.batchProfiles({ action: 'move', profileIds: [first.id, second.id], workspaceId: target.id });
  assert.equal(moved.succeeded, 2);
  assert.equal(moved.failed, 0);
  assert.equal(service.state.profiles.find((item) => item.id === first.id).workspaceId, target.id);
  assert.equal(service.state.profiles.find((item) => item.id === second.id).workspaceId, target.id);

  const movedAgain = await service.batchProfiles({ action: 'move', profileIds: [first.id, second.id], workspaceId: target.id });
  assert.equal(movedAgain.succeeded, 0);
  assert.equal(movedAgain.skipped, 2);

  const started = await service.batchProfiles({ action: 'start', profileIds: [first.id, second.id] });
  assert.equal(started.succeeded, 2);
  assert.equal(launcher.starts.length, 2);
  assert(service.state.profiles.find((item) => item.id === first.id).lastStartedAt);

  const startedAgain = await service.batchProfiles({ action: 'start', profileIds: [first.id, second.id] });
  assert.equal(startedAgain.skipped, 2);
  assert.equal(launcher.starts.length, 2);

  const stopped = await service.batchProfiles({ action: 'stop', profileIds: [first.id] });
  assert.equal(stopped.succeeded, 1);
  assert.equal(launcher.stops.length, 1);

  const stoppedAgain = await service.batchProfiles({ action: 'stop', profileIds: [first.id] });
  assert.equal(stoppedAgain.skipped, 1);

  launcher.failIds.add(third.id);
  const partial = await service.batchProfiles({ action: 'start', profileIds: [first.id, third.id] });
  assert.equal(partial.succeeded, 1);
  assert.equal(partial.failed, 1);
  assert.equal(partial.results.find((item) => item.profileId === third.id).ok, false);

  const missing = await service.batchProfiles({ action: 'start', profileIds: ['fantasma'] });
  assert.equal(missing.failed, 1);
  assert.equal(missing.results[0].error, 'El perfil no existe.');

  await assert.rejects(() => service.batchProfiles({ action: 'archive', profileIds: [first.id] }), /La acción masiva no es válida/);
  await assert.rejects(() => service.batchProfiles({ action: 'start', profileIds: [] }), /al menos un elemento/);
  await assert.rejects(
    () => service.batchProfiles({ action: 'start', profileIds: Array.from({ length: 51 }, (_, index) => `p${index}`) }),
    /máximo de 50/,
  );
  await assert.rejects(() => service.batchProfiles({ action: 'move', profileIds: [first.id], workspaceId: 'no-existe' }), /espacio de trabajo no existe/);
});

test('la prueba masiva de proxies conserva el orden, limita la concurrencia y resume los fallos', async (t) => {
  const { service } = createService(t);
  const created = [];
  for (let index = 0; index < 6; index += 1) {
    created.push(service.createProxy({ name: `Proxy ${index}`, protocol: 'http', host: '127.0.0.1', port: 8000 + index }));
  }
  let active = 0;
  let maxActive = 0;
  service.testProxyConnection = async ({ id }) => {
    active += 1;
    maxActive = Math.max(maxActive, active);
    await new Promise((resolve) => setTimeout(resolve, 15));
    active -= 1;
    if (id === created[2].id) throw new Error('Fallo de red');
    if (id === created[3].id) return { ok: false, error: 'Sin salida' };
    return { ok: true, ip: `10.0.0.${id.slice(-1)}`, latencyMs: 12 };
  };
  const ids = [created[5].id, created[2].id, 'fantasma', created[3].id, created[4].id, created[0].id];
  const result = await service.testProxies({ ids });

  assert.equal(result.total, 6);
  assert.equal(result.ok, 3);
  assert.equal(result.failed, 3);
  assert.deepEqual(result.results.map((item) => item.proxyId), ids);
  assert.equal(result.results[1].ok, false);
  assert.equal(result.results[1].error, 'Fallo de red');
  assert.equal(result.results[2].error, 'El proxy no existe.');
  assert.equal(result.results[3].error, 'Sin salida');
  assert(maxActive <= 4);
  assert(maxActive >= 2);
  for (const item of result.results) {
    assert.equal(Object.hasOwn(item, 'password'), false);
    assert.equal(Object.hasOwn(item, 'passwordEnc'), false);
  }

  await assert.rejects(() => service.testProxies({ ids: [] }), /al menos un elemento/);
  await assert.rejects(
    () => service.testProxies({ ids: Array.from({ length: 51 }, (_, index) => `p${index}`) }),
    /máximo de 50/,
  );
  service.state.proxies = [];
  await assert.rejects(() => service.testProxies({}), /No hay proxies para probar/);
});

test('los estados de perfil se validan y se eliminan sin dejar referencias', (t) => {
  const { service } = createService(t);
  assert.equal(service.state.profileStatuses.length, 3);
  const status = service.createStatus({ name: '  En revisión  ', color: '#F59E0B' });
  assert.equal(status.name, 'En revisión');
  assert.equal(status.color, '#f59e0b');
  assert.throws(() => service.createStatus({ name: 'EN REVISIÓN' }), /Ya existe un estado/);
  assert.throws(() => service.createStatus({ name: '   ' }), /nombre del estado es obligatorio/i);
  assert.throws(() => service.updateStatus(status.id, { color: 'naranja' }), /formato hexadecimal/);

  const renamed = service.updateStatus(status.id, { name: 'Pendiente', color: '#22c55e' });
  assert.equal(renamed.name, 'Pendiente');
  assert.equal(renamed.color, '#22c55e');

  const profile = createProfile(service, 'Con estado');
  const updated = service.updateProfile(profile.id, { statusId: status.id });
  assert.equal(updated.statusId, status.id);
  assert.throws(() => service.updateProfile(profile.id, { statusId: 'fantasma' }), /El estado seleccionado no existe/);

  const removed = service.deleteStatus(status.id);
  assert.equal(removed.updatedProfiles, 1);
  assert.equal(service.state.profiles.find((item) => item.id === profile.id).statusId, null);
  assert.throws(() => service.updateStatus(status.id, { name: 'Otro' }), /El estado no existe/);

  while (service.state.profileStatuses.length < 30) {
    service.createStatus({ name: `Estado ${service.state.profileStatuses.length}` });
  }
  assert.throws(() => service.createStatus({ name: 'Uno más' }), /máximo de 30 estados/);
});

test('las acciones masivas de etiquetas, estado y proxy informan cambios y omisiones', async (t) => {
  const { service } = createService(t);
  const status = service.createStatus({ name: 'Cliente', color: '#22c55e' });
  const proxy = service.createProxy({ name: 'Proxy lote', protocol: 'http', host: '127.0.0.1', port: 9000 });
  const first = createProfile(service, 'Etiquetas uno');
  const second = createProfile(service, 'Etiquetas dos');

  const added = await service.batchProfiles({ action: 'add-tags', profileIds: [first.id, second.id], tags: 'cliente, vip' });
  assert.equal(added.succeeded, 2);
  assert.deepEqual(service.state.profiles.find((item) => item.id === first.id).tags, ['cliente', 'vip']);

  const repeated = await service.batchProfiles({ action: 'add-tags', profileIds: [first.id], tags: ['cliente'] });
  assert.equal(repeated.skipped, 1);
  assert.equal(repeated.results[0].reason, 'no_changes');

  const removed = await service.batchProfiles({ action: 'remove-tags', profileIds: [first.id], tags: ['vip'] });
  assert.equal(removed.succeeded, 1);
  assert.deepEqual(service.state.profiles.find((item) => item.id === first.id).tags, ['cliente']);

  const replaced = await service.batchProfiles({ action: 'set-tags', profileIds: [second.id], tags: ['uno', 'dos'] });
  assert.equal(replaced.succeeded, 1);
  assert.deepEqual(service.state.profiles.find((item) => item.id === second.id).tags, ['uno', 'dos']);

  const assigned = await service.batchProfiles({ action: 'set-status', profileIds: [first.id, second.id], statusId: status.id });
  assert.equal(assigned.succeeded, 2);
  assert.equal(service.state.profiles.find((item) => item.id === second.id).statusId, status.id);

  const cleared = await service.batchProfiles({ action: 'set-status', profileIds: [first.id], statusId: null });
  assert.equal(cleared.succeeded, 1);
  assert.equal(service.state.profiles.find((item) => item.id === first.id).statusId, null);

  const proxied = await service.batchProfiles({ action: 'set-proxy', profileIds: [first.id, second.id], proxyId: proxy.id });
  assert.equal(proxied.succeeded, 2);
  const proxyless = await service.batchProfiles({ action: 'set-proxy', profileIds: [second.id], proxyId: null });
  assert.equal(proxyless.succeeded, 1);
  assert.equal(service.state.profiles.find((item) => item.id === second.id).proxyId, null);

  await assert.rejects(() => service.batchProfiles({ action: 'set-status', profileIds: [first.id], statusId: 'fantasma' }), /El estado no existe/);
  await assert.rejects(() => service.batchProfiles({ action: 'set-proxy', profileIds: [first.id], proxyId: 'fantasma' }), /El proxy no existe/);
  await assert.rejects(() => service.batchProfiles({ action: 'add-tags', profileIds: [first.id], tags: '   ' }), /al menos una etiqueta/);
  await assert.rejects(() => service.batchProfiles({ action: 'set-status', profileIds: [first.id] }), /Indica el estado/);
});

test('las acciones masivas duplican y eliminan con salvaguardas de cuentas y máquinas', async (t) => {
  const { service } = createService(t);
  const first = createProfile(service, 'Clonar uno');
  const second = createProfile(service, 'Eliminar dos');

  const duplicated = await service.batchProfiles({ action: 'duplicate', profileIds: [first.id] });
  assert.equal(duplicated.succeeded, 1);
  assert.equal(service.state.profiles.length, 3);
  const copy = service.state.profiles.find((profile) => profile.id === duplicated.results[0].copyId);
  assert.match(copy.name, /^Copia de Clonar uno/);
  assert.equal(copy.workspaceId, first.workspaceId);

  const deleted = await service.batchProfiles({ action: 'delete', profileIds: [second.id] });
  assert.equal(deleted.succeeded, 1);
  assert.equal(deleted.results[0].deletedData, false);
  assert.equal(service.state.profiles.some((profile) => profile.id === second.id), false);

  const withAccount = createProfile(service, 'Con cuenta clon');
  service.state.cloneAccounts.push({ profileId: withAccount.id, username: 'PL-TEST', passwordEnc: 'plain1:QQ==' });
  service.nativeClone = {
    snapshot: () => ({ available: true, checked: true, platform: process.platform, error: null }),
    release: async ({ profileId }) => ({ profileId, released: true }),
  };
  const blocked = await service.batchProfiles({ action: 'delete', profileIds: [withAccount.id] });
  assert.equal(blocked.failed, 1);
  assert.match(blocked.results[0].error, /cuenta de Windows para clones/);
  assert.equal(service.state.profiles.some((profile) => profile.id === withAccount.id), true);

  const released = await service.batchProfiles({ action: 'delete', profileIds: [withAccount.id], releaseCloneAccount: true });
  assert.equal(released.succeeded, 1);
  assert.equal(service.state.cloneAccounts.some((item) => item.profileId === withAccount.id), false);

  const withVm = createProfile(service, 'Con máquina');
  service.state.virtualMachines.push({ profileId: withVm.id, vmName: 'PL-0123456789ab', diskPath: 'C:\\vms\\PL-0123456789ab.vhdx' });
  const vmBlocked = await service.batchProfiles({ action: 'delete', profileIds: [withVm.id] });
  assert.equal(vmBlocked.failed, 1);
  assert.match(vmBlocked.results[0].error, /máquina virtual/);
});

test('el CSV crea estados al importar y los reutiliza por nombre', (t) => {
  const { service } = createService(t);
  const status = service.createStatus({ name: 'Pendiente', color: '#f59e0b' });
  const result = service.importCsv([
    'Nombre,Estado',
    'Perfil pendiente,Pendiente',
    'Perfil nuevo,En revisión',
    'Perfil repetido,en revisión',
    'Perfil vacío,',
  ].join('\r\n'));
  assert.equal(result.profiles, 4);
  assert.equal(result.statuses, 1);
  const byName = Object.fromEntries(service.state.profiles.map((profile) => [profile.name, profile]));
  assert.equal(byName['Perfil pendiente'].statusId, status.id);
  const created = service.state.profileStatuses.find((item) => item.name === 'En revisión');
  assert.ok(created);
  assert.equal(byName['Perfil nuevo'].statusId, created.id);
  assert.equal(byName['Perfil repetido'].statusId, created.id);
  assert.equal(byName['Perfil vacío'].statusId, null);
});
