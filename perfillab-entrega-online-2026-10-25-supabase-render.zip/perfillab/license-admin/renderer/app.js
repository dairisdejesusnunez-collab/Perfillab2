'use strict';

const bridge = window.licenseAdmin;
const DEFAULT_SERVER_URL = 'http://127.0.0.1:45900/v1';
const BATCH_CLIENT_LIMIT = 1000;
const BATCH_CHUNK_SIZE = 20;

const STATUS_META = {
  pending: { label: 'Pendiente', tone: 'warn' },
  active: { label: 'Activa', tone: 'success' },
  expired: { label: 'Vencida', tone: 'muted' },
  revoked: { label: 'Revocada', tone: 'danger' },
  suspended: { label: 'Suspendida', tone: 'warn' },
};

const ORDER_META = {
  created: { label: 'Creado', tone: 'muted' },
  pending: { label: 'Pendiente', tone: 'warn' },
  paid: { label: 'Pagado', tone: 'success' },
  failed: { label: 'Fallido', tone: 'danger' },
  cancelled: { label: 'Cancelado', tone: 'muted' },
  refunded: { label: 'Reembolsado', tone: 'accent' },
  expired: { label: 'Expirado', tone: 'muted' },
};

const EMAIL_META = {
  queued: { label: 'En cola', tone: 'warn' },
  sending: { label: 'Enviando', tone: 'warn' },
  sent: { label: 'Enviado', tone: 'success' },
  failed: { label: 'Fallido', tone: 'danger' },
};

const PLAN_ORDER = ['monthly', 'semiannual', 'annual'];
const DEFAULT_PLAN = 'annual';
const PLAN_META = {
  monthly: { label: 'Mensual', months: 1, period: '1 mes' },
  semiannual: { label: 'Semestral', months: 6, period: '6 meses' },
  annual: { label: 'Anual', months: 12, period: '12 meses' },
};

function planMeta(code) {
  return PLAN_META[code] || { label: code || 'Anual', months: 12, period: '12 meses' };
}

function planDuration(code) {
  return planMeta(code).period;
}

function planLabel(code) {
  return planMeta(code).label;
}

function planCatalogue() {
  const source = state.server && Array.isArray(state.server.plans) ? state.server.plans : [];
  return PLAN_ORDER.map((code) => {
    const base = planMeta(code);
    const live = source.find((plan) => plan && plan.code === code);
    return {
      code,
      months: base.months,
      period: base.period,
      label: base.label,
      amountCents: live && Number.isFinite(Number(live.amountCents)) ? Number(live.amountCents) : null,
      currency: (live && live.currency) || 'USD',
    };
  });
}

function planSelectOptions(selected) {
  const value = PLAN_META[selected] ? selected : DEFAULT_PLAN;
  return planCatalogue().map((plan) => {
    const price = plan.amountCents === null ? '' : ` · ${fmtMoney(plan.amountCents, plan.currency)}`;
    return `<option value="${esc(plan.code)}" ${plan.code === value ? 'selected' : ''}>${esc(plan.label)} · ${esc(plan.period)}${esc(price)}</option>`;
  }).join('');
}

function planPriceText(plan) {
  return plan.amountCents === null ? 'Precio no configurado' : `${fmtMoney(plan.amountCents, plan.currency)} · ${plan.period}`;
}

const LICENSE_ACTION_META = {
  revoke: {
    title: 'Revocar licencia',
    description: 'La licencia dejará de ser válida de forma permanente. Esta acción no se puede deshacer.',
    confirm: 'Revocar definitivamente',
    danger: true,
    reason: true,
    reasonLabel: 'Motivo de la revocación',
  },
  suspend: {
    title: 'Suspender licencia',
    description: 'La licencia dejará de validar mientras esté suspendida. Podrás reactivarla más adelante.',
    confirm: 'Suspender licencia',
    danger: false,
    reason: true,
    reasonLabel: 'Motivo de la suspensión',
  },
  'reset-activation': {
    title: 'Liberar código de equipo',
    description: 'La licencia quedará pendiente y podrá vincularse a otro equipo.',
    confirm: 'Liberar equipo',
    danger: false,
    reason: true,
    reasonLabel: 'Motivo del cambio',
    warning: 'El archivo de licencia ya entregado al equipo anterior seguirá siendo válido sin conexión hasta su vencimiento. Revoca la licencia si necesitas invalidarlo.',
  },
  reactivate: {
    title: 'Reactivar licencia',
    description: 'La licencia volverá a validar si no ha vencido y su equipo sigue disponible.',
    confirm: 'Reactivar',
    danger: false,
    reason: false,
  },
  renew: {
    title: 'Renovar licencia',
    description: 'La licencia se extenderá el periodo del plan elegido desde su vencimiento actual o desde hoy si ya venció.',
    confirm: 'Renovar',
    danger: false,
    reason: false,
  },
};

const VIEWS = {
  dashboard: { title: 'Panel', subtitle: 'Estado del servidor de licencias' },
  licenses: { title: 'Licencias', subtitle: 'Inventario histórico y estado de cada equipo' },
  issue: { title: 'Emitir licencia', subtitle: 'Emisión firmada para un cliente o equipo' },
  batch: { title: 'Emitir lote', subtitle: 'Cargas controladas de hasta 1.000 licencias' },
  orders: { title: 'Pedidos', subtitle: 'Pagos, órdenes y transacciones verificadas' },
  payments: { title: 'Pagos', subtitle: 'Configuración de PayPal, precios y entrega automática' },
  audit: { title: 'Auditoría', subtitle: 'Registro de operaciones administrativas' },
  tools: { title: 'Herramientas', subtitle: 'Exportaciones, servidor y seguridad' },
};

const ICONS = {
  dashboard: '<rect x="3.5" y="3.5" width="7" height="7" rx="2"></rect><rect x="13.5" y="3.5" width="7" height="7" rx="2"></rect><rect x="3.5" y="13.5" width="7" height="7" rx="2"></rect><rect x="13.5" y="13.5" width="7" height="7" rx="2"></rect>',
  list: '<path d="M4 6h16M4 12h16M4 18h10"></path>',
  key: '<circle cx="8" cy="12" r="4"></circle><path d="M12 12h8M17 12v3M20 12v2"></path>',
  plus: '<path d="M12 5v14M5 12h14"></path>',
  batch: '<rect x="3.5" y="4.5" width="17" height="5" rx="1.6"></rect><rect x="3.5" y="12" width="17" height="5" rx="1.6"></rect><path d="M6.5 16.5h4M6.5 7.5h4M15.5 7.5h2M15.5 16.5h2"></path>',
  cart: '<path d="M3.5 4.5h2l2.2 10.5h10.6l2-7.5H6.2"></path><circle cx="9" cy="19" r="1.4"></circle><circle cx="17.5" cy="19" r="1.4"></circle>',
  payments: '<rect x="2.5" y="5" width="19" height="14" rx="2.5"></rect><path d="M2.5 9.5h19M6 14.5h4.5"></path>',
  audit: '<circle cx="12" cy="12" r="8.5"></circle><path d="M12 7.5V12l3 1.8"></path>',
  tools: '<path d="M4 7h9M17 7h3M4 17h3M11 17h9"></path><circle cx="15" cy="7" r="2.4"></circle><circle cx="9" cy="17" r="2.4"></circle>',
  plusCircle: '<circle cx="12" cy="12" r="8.5"></circle><path d="M12 8v8M8 12h8"></path>',
  check: '<path d="m5 12.5 4.5 4.5L19 7"></path>',
  checkCircle: '<circle cx="12" cy="12" r="8.5"></circle><path d="m8.5 12 2.5 2.5 4.5-5"></path>',
  warning: '<path d="M12 4 21 19.5H3L12 4Z"></path><path d="M12 9.5v4.5M12 17h.01"></path>',
  shield: '<path d="M12 3.5 19.5 6v6c0 4.4-3.2 7.5-7.5 9-4.3-1.5-7.5-4.6-7.5-9V6L12 3.5Z"></path><path d="m9 12 2 2 4-4"></path>',
  lock: '<rect x="4.5" y="10" width="15" height="10.5" rx="2"></rect><path d="M8 10V7.5a4 4 0 0 1 8 0V10"></path>',
  refresh: '<path d="M19.5 12a7.5 7.5 0 1 1-2.2-5.3"></path><path d="M19.5 5v5h-5"></path>',
  download: '<path d="M12 4v11m0 0 4-4m-4 4-4-4M5 19.5h14"></path>',
  search: '<circle cx="10.5" cy="10.5" r="6.5"></circle><path d="m15.5 15.5 4 4"></path>',
  copy: '<rect x="8.5" y="8.5" width="11" height="12" rx="2"></rect><path d="M15.5 8.5V6a1.5 1.5 0 0 0-1.5-1.5H6A1.5 1.5 0 0 0 4.5 6v9A1.5 1.5 0 0 0 6 16.5h2.5"></path>',
  save: '<path d="M5 4.5h11.5L19.5 8v11.5h-15v-15Z"></path><path d="M8 4.5v5h7v-5M8 19.5v-6h8v6"></path>',
  monitor: '<rect x="3" y="4.5" width="18" height="12" rx="2"></rect><path d="M9 20.5h6M12 16.5v4"></path>',
  x: '<path d="m6 6 12 12M18 6 6 18"></path>',
  chevronLeft: '<path d="m14.5 6-6 6 6 6"></path>',
  chevronRight: '<path d="m9.5 6 6 6-6 6"></path>',
  mail: '<rect x="3" y="5" width="18" height="14" rx="2.5"></rect><path d="m4 7 8 6 8-6"></path>',
  server: '<rect x="3" y="4" width="18" height="6" rx="2"></rect><rect x="3" y="14" width="18" height="6" rx="2"></rect><path d="M7 7h.01M7 17h.01"></path>',
  user: '<circle cx="12" cy="8" r="3.5"></circle><path d="M5 20c.5-4 3.3-6 7-6s6.5 2 7 6"></path>',
  logout: '<path d="M14 5h4.5v14H14M10 8l-4 4 4 4M6 12h10"></path>',
  clock: '<circle cx="12" cy="12" r="8.5"></circle><path d="M12 7.5V12l3 1.8"></path>',
  trash: '<path d="M4.5 7h15M9.5 7V4.5h5V7M6.5 7l1 13h9l1-13M10 11v5M14 11v5"></path>',
  play: '<path d="M8 5.5v13L19 12 8 5.5Z"></path>',
  external: '<path d="M14 4.5h5.5V10M19 5l-8 8"></path><path d="M19 13v6.5H5v-14h6.5"></path>',
  alertCircle: '<circle cx="12" cy="12" r="8.5"></circle><path d="M12 7.5v5M12 16.5h.01"></path>',
};

const els = {
  titlebarServer: document.getElementById('titlebar-server'),
  connectionDot: document.getElementById('connection-dot'),
  loginScreen: document.getElementById('login-screen'),
  loginForm: document.getElementById('login-form'),
  loginServer: document.getElementById('login-server'),
  loginUser: document.getElementById('login-user'),
  loginPassword: document.getElementById('login-password'),
  togglePassword: document.getElementById('toggle-password'),
  testServer: document.getElementById('test-server'),
  loginActionsNote: document.getElementById('login-actions-note'),
  loginError: document.getElementById('login-error'),
  loginButton: document.getElementById('login-button'),
  loginHint: document.getElementById('login-hint'),
  lockVersion: document.getElementById('lock-version'),
  admin: document.getElementById('admin'),
  content: document.getElementById('content'),
  pageTitle: document.getElementById('page-title'),
  pageSubtitle: document.getElementById('page-subtitle'),
  capacityChipLabel: document.getElementById('capacity-chip-label'),
  topbarIssue: document.getElementById('topbar-issue'),
  navIssued: document.getElementById('nav-issued'),
  navOrders: document.getElementById('nav-orders'),
  seatMiniValue: document.getElementById('seat-mini-value'),
  seatMiniBar: document.getElementById('seat-mini-bar'),
  sessionAvatar: document.getElementById('session-avatar'),
  sessionUsername: document.getElementById('session-username'),
  sessionRole: document.getElementById('session-role'),
  sessionServer: document.getElementById('session-server'),
  logoutButton: document.getElementById('logout-button'),
  appVersion: document.getElementById('app-version'),
  modalRoot: document.getElementById('modal-root'),
  toastRoot: document.getElementById('toast-root'),
};

const state = {
  authenticated: false,
  session: null,
  appInfo: null,
  serverUrl: DEFAULT_SERVER_URL,
  defaultServerUrl: DEFAULT_SERVER_URL,
  configWarning: '',
  appVersion: '1.0.0',
  platform: '',
  summary: null,
  server: null,
  view: 'dashboard',
  viewSeq: 0,
  loginBusy: false,
  healthBusy: false,
  issueBusy: false,
  exporting: false,
  sessionTimer: null,
  lastFocus: null,
  modalBusy: false,
  modalSeq: 0,
  modalReturn: null,
  modalDetail: null,
  modalOrder: null,
  modalAudit: null,
  lastIssued: null,
  licenses: {
    query: '',
    status: 'all',
    page: 1,
    pageSize: 25,
    data: null,
    loading: false,
    error: '',
    seq: 0,
    timer: null,
  },
  orders: {
    tab: 'orders',
    query: '',
    status: 'all',
    page: 1,
    pageSize: 25,
    data: null,
    loading: false,
    error: '',
    seq: 0,
    timer: null,
  },
  transactions: {
    page: 1,
    pageSize: 50,
    data: null,
    loading: false,
    error: '',
    seq: 0,
  },
  audit: {
    page: 1,
    pageSize: 50,
    data: null,
    loading: false,
    error: '',
    seq: 0,
  },
  batch: {
    text: '',
    rows: [],
    plan: DEFAULT_PLAN,
    parseError: '',
    running: false,
    progress: { done: 0, total: 0 },
    results: new Map(),
    seq: 0,
    completed: false,
    interrupted: false,
  },
  payments: {
    data: null,
    loading: false,
    error: '',
    busy: false,
    seq: 0,
  },
};

const DATE_FMT = new Intl.DateTimeFormat('es-ES', { day: '2-digit', month: 'short', year: 'numeric' });
const DATETIME_FMT = new Intl.DateTimeFormat('es-ES', {
  day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit',
});
const NUM_FMT = new Intl.NumberFormat('es-ES');
const MONEY_FMT = new Map();

function icon(name, className = '') {
  const body = ICONS[name] || ICONS.alertCircle;
  return `<svg${className ? ` class="${esc(className)}"` : ''} viewBox="0 0 24 24" aria-hidden="true">${body}</svg>`;
}

function esc(value) {
  return String(value === null || value === undefined ? '' : value).replace(/[&<>"']/g, (char) => ({
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    '"': '&quot;',
    "'": '&#39;',
  }[char]));
}

function fmtNum(value) {
  return NUM_FMT.format(Number(value) || 0);
}

function plural(count, one, many) {
  return `${fmtNum(count)} ${Number(count) === 1 ? one : many}`;
}

function fmtDate(value, empty = '—') {
  if (!value) return empty;
  const timestamp = Date.parse(value);
  return Number.isFinite(timestamp) ? DATE_FMT.format(new Date(timestamp)) : '—';
}

function fmtDateTime(value, empty = '—') {
  if (!value) return empty;
  const timestamp = Date.parse(value);
  return Number.isFinite(timestamp) ? DATETIME_FMT.format(new Date(timestamp)) : '—';
}

function fmtMoney(cents, currency = 'USD') {
  const amount = Number(cents) / 100;
  const code = String(currency || 'USD').toUpperCase() || 'USD';
  let formatter = MONEY_FMT.get(code);
  if (!formatter) {
    try {
      formatter = new Intl.NumberFormat('es-ES', { style: 'currency', currency: code });
    } catch {
      formatter = new Intl.NumberFormat('es-ES', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
    }
    MONEY_FMT.set(code, formatter);
  }
  return formatter.format(Number.isFinite(amount) ? amount : 0);
}

function fmtPercent(value, digits = 0) {
  return `${Number(value || 0).toFixed(digits)} %`;
}

function truncate(value, max = 64) {
  const text = String(value || '');
  return text.length > max ? `${text.slice(0, max - 1)}…` : text;
}

function initials(value) {
  const text = String(value || '').trim();
  if (!text) return 'A';
  const words = text.split(/\s+/).filter(Boolean);
  if (words.length === 1) return words[0].slice(0, 1).toUpperCase();
  return `${words[0][0]}${words[1][0]}`.toUpperCase();
}

function roleLabel(role) {
  if (role === 'admin') return 'Administrador';
  if (role === 'reader') return 'Solo lectura';
  return role || 'Sesión activa';
}

function statusMeta(status) {
  return STATUS_META[status] || { label: status || 'Desconocido', tone: 'muted' };
}

function orderMeta(status) {
  return ORDER_META[status] || { label: status || 'Desconocido', tone: 'muted' };
}

function statusChip(status) {
  const meta = statusMeta(status);
  const tone = meta.tone === 'muted' ? ' is-plain' : ` is-${meta.tone}`;
  return `<span class="chip${tone}">${esc(meta.label)}</span>`;
}

function orderChip(status) {
  const meta = orderMeta(status);
  const tone = meta.tone === 'muted' ? ' is-plain' : ` is-${meta.tone}`;
  return `<span class="chip${tone}">${esc(meta.label)}</span>`;
}

function emailChip(status) {
  const meta = EMAIL_META[status] || { label: status || 'Desconocido', tone: 'muted' };
  const tone = meta.tone === 'muted' ? ' is-plain' : ` is-${meta.tone}`;
  return `<span class="chip${tone}">${esc(meta.label)}</span>`;
}

function isAdmin() {
  return Boolean(state.session && state.session.role === 'admin');
}

function currentServerHost() {
  try {
    const url = new URL(state.serverUrl);
    return url.host;
  } catch {
    return state.serverUrl || 'Servidor central';
  }
}

function setText(element, text) {
  if (element) element.textContent = text === null || text === undefined ? '' : String(text);
}

function isNetworkError(error) {
  return Boolean(error && (error.code === 'network_error' || error.code === 'timeout'));
}

function setConnection(mode, label = '') {
  if (els.connectionDot) {
    els.connectionDot.classList.toggle('is-warn', mode === 'warn');
    els.connectionDot.classList.toggle('is-offline', mode === 'offline');
    els.connectionDot.classList.toggle('is-error', mode === 'error');
  }
  if (els.titlebarServer) {
    els.titlebarServer.textContent = label || (state.authenticated ? currentServerHost() : 'Servidor central');
    els.titlebarServer.title = state.serverUrl || '';
  }
}

function toast(message, type = 'info') {
  if (!els.toastRoot) return;
  while (els.toastRoot.children.length >= 4) els.toastRoot.firstElementChild.remove();
  const item = document.createElement('div');
  item.className = 'toast';
  if (type === 'success') item.classList.add('is-success');
  else if (type === 'error') item.classList.add('is-error');
  else if (type === 'warn') item.classList.add('is-warn');
  item.textContent = String(message || '');
  els.toastRoot.appendChild(item);
  setTimeout(() => {
    item.classList.add('is-leaving');
    setTimeout(() => item.remove(), 230);
  }, 5200);
}

async function run(action, payload = {}) {
  if (!bridge || typeof bridge.action !== 'function') {
    throw new Error('No se pudo comunicar con el proceso de administración.');
  }
  const result = await bridge.action(action, payload);
  if (!result || result.ok !== true) {
    const info = result && result.error ? result.error : {};
    const error = new Error(info.message || 'No se pudo completar la operación.');
    error.code = info.code || 'error';
    error.status = info.status;
    error.requiresLogin = Boolean(info.requiresLogin || info.status === 401);
    throw error;
  }
  return result.data;
}

async function api(action, payload = {}) {
  try {
    return await run(action, payload);
  } catch (error) {
    if (error.requiresLogin) expireSession(error.message);
    throw error;
  }
}

async function copyText(value, message = 'Copiado al portapapeles.') {
  try {
    await run('clipboard:write', { text: String(value || '') });
    toast(message, 'success');
  } catch (error) {
    toast(error.message || 'No se pudo copiar.', 'error');
  }
}

function setBusy(button, busy, label = 'Procesando…') {
  if (!button) return;
  if (busy) {
    if (!button.dataset.originalHtml) button.dataset.originalHtml = button.innerHTML;
    button.disabled = true;
    button.innerHTML = `<span class="spinner"></span>${esc(label)}`;
  } else {
    button.disabled = false;
    if (button.dataset.originalHtml) {
      button.innerHTML = button.dataset.originalHtml;
      delete button.dataset.originalHtml;
    }
  }
}

function loadingView(label = 'Cargando…') {
  return `<div class="loading-view"><span class="spinner"></span>${esc(label)}</div>`;
}

function loadingBlock(label = 'Cargando…') {
  return `<div class="loading-block"><span class="spinner"></span>${esc(label)}</div>`;
}

function emptyBlock(iconName, title, copy, actions = '') {
  return `
    <div class="empty-state">
      <span class="empty-icon">${icon(iconName)}</span>
      <strong>${esc(title)}</strong>
      <p>${esc(copy)}</p>
      ${actions}
    </div>
  `;
}

function errorPanel(message, action = 'refresh-view') {
  return `
    <div class="card">
      ${emptyBlock(
        'warning',
        'No se pudo cargar la información',
        message,
        `<button class="btn btn-ghost btn-sm" type="button" data-action="${esc(action)}">${icon('refresh')} Reintentar</button>`,
      )}
    </div>
  `;
}

function notice(tone, title, copy, iconName = 'alertCircle') {
  const toneClass = tone ? ` is-${tone}` : '';
  return `
    <div class="notice${toneClass}">
      ${icon(iconName)}
      <div>
        <strong>${esc(title)}</strong>
        <p>${esc(copy)}</p>
      </div>
    </div>
  `;
}

function copyButton(value, message, label = 'Copiar') {
  return `<button class="btn-icon" type="button" data-copy="${esc(value)}" data-copy-message="${esc(message)}" title="${esc(label)}" aria-label="${esc(label)}">${icon('copy')}</button>`;
}

function detailItem(label, value, options = {}) {
  return `
    <div class="detail-item${options.wide ? ' is-wide' : ''}">
      <small>${esc(label)}</small>
      <span class="value${options.mono ? ' mono' : ''}">${esc(value || '—')}</span>
    </div>
  `;
}

function detailCopyItem(label, value, options = {}) {
  return `
    <div class="detail-item${options.wide === false ? '' : ' is-wide'}">
      <small>${esc(label)}</small>
      <div class="key-row">
        <span class="value mono">${esc(value || '—')}</span>
        ${value ? copyButton(value, `${label} copiado.`, `Copiar ${label}`) : ''}
      </div>
    </div>
  `;
}

function modalCloseButton() {
  return `<button class="modal-close" type="button" data-close aria-label="Cerrar ventana">${icon('x')}</button>`;
}

function openModal(html, options = {}) {
  if (!els.modalRoot) return;
  const hasModal = Boolean(els.modalRoot.firstElementChild);
  if (!hasModal) {
    state.lastFocus = options.lastFocus || (document.activeElement instanceof HTMLElement ? document.activeElement : null);
  } else if (options.lastFocus) {
    state.lastFocus = options.lastFocus;
  }
  state.modalReturn = typeof options.returnModal === 'function' ? options.returnModal : null;
  els.modalRoot.innerHTML = `
    <div class="modal-backdrop">
      <div class="modal${options.className ? ` ${esc(options.className)}` : ''}" role="dialog" aria-modal="true" aria-label="${esc(options.label || 'Diálogo')}">
        ${html}
      </div>
    </div>
  `;
  const backdrop = els.modalRoot.firstElementChild;
  if (backdrop) {
    backdrop.addEventListener('mousedown', (event) => {
      if (event.target === backdrop) closeModal();
    });
  }
  const target = els.modalRoot.querySelector('[data-autofocus]')
    || els.modalRoot.querySelector('.modal-close')
    || els.modalRoot.querySelector('button, input, select, textarea');
  if (target) setTimeout(() => target.focus(), 35);
}

function closeModal(options = {}) {
  const { restoreFocus = true, force = false } = options;
  if (!els.modalRoot || !els.modalRoot.firstElementChild) return;
  if (state.modalBusy && !force) return;
  if (!force && typeof state.modalReturn === 'function') {
    const back = state.modalReturn;
    state.modalReturn = null;
    back();
    return;
  }
  state.modalSeq += 1;
  state.modalBusy = false;
  state.modalReturn = null;
  els.modalRoot.innerHTML = '';
  state.modalDetail = null;
  state.modalOrder = null;
  state.modalAudit = null;
  const last = state.lastFocus;
  state.lastFocus = null;
  if (restoreFocus && last instanceof HTMLElement && last.isConnected) last.focus();
}

function modalHead(kicker, title, chips = '') {
  return `
    <div class="modal-head">
      <div>
        <span class="modal-kicker">${esc(kicker)}</span>
        <h2 id="modal-title">${esc(title)}</h2>
        ${chips ? `<div class="modal-subhead" style="margin-top:8px">${chips}</div>` : ''}
      </div>
      ${modalCloseButton()}
    </div>
  `;
}

function modalLoading(label) {
  return `
    <div class="modal-body">
      <div class="loading-view" style="min-height:160px"><span class="spinner"></span>${esc(label)}</div>
    </div>
  `;
}

function updateSummary(summary) {
  if (!summary) return;
  state.summary = summary;
  setText(els.navIssued, fmtNum(summary.used));
  setText(els.navOrders, fmtNum(Object.values(summary.orders || {}).reduce((sum, value) => sum + (Number(value) || 0), 0)));
  setText(els.seatMiniValue, `${fmtNum(summary.used)} / ${fmtNum(summary.capacity)}`);
  if (els.seatMiniBar) {
    const percent = summary.capacity ? Math.min(100, (Number(summary.used) / summary.capacity) * 100) : 0;
    els.seatMiniBar.style.width = `${percent.toFixed(2)}%`;
  }
  setText(els.capacityChipLabel, `${fmtNum(summary.available)} disponibles`);
}

function updateChrome() {
  const version = state.appVersion || '1.0.0';
  setText(els.appVersion, `v${version}`);
  setText(els.lockVersion, `v${version}`);
  const role = state.session ? state.session.role : '';
  if (els.topbarIssue) els.topbarIssue.hidden = !isAdmin();
  document.querySelectorAll('.nav-item[data-nav="issue"], .nav-item[data-nav="batch"]').forEach((button) => {
    button.hidden = !isAdmin();
  });
  if (state.session) {
    setText(els.sessionUsername, state.session.username || 'Administrador');
    setText(els.sessionAvatar, initials(state.session.username));
    setText(els.sessionRole, roleLabel(role));
    setText(els.sessionServer, state.serverUrl || '—');
    if (els.sessionServer) els.sessionServer.title = state.serverUrl || '';
  }
  if (state.summary) updateSummary(state.summary);
}

function updateNav(view) {
  document.querySelectorAll('.nav-item[data-nav]').forEach((button) => {
    const active = button.dataset.nav === view;
    button.classList.toggle('is-active', active);
    if (active) button.setAttribute('aria-current', 'page');
    else button.removeAttribute('aria-current');
  });
  const meta = VIEWS[view] || VIEWS.dashboard;
  setText(els.pageTitle, meta.title);
  setText(els.pageSubtitle, meta.subtitle);
}

function setView(view) {
  if (!state.authenticated) return;
  if (!VIEWS[view]) view = 'dashboard';
  if ((view === 'issue' || view === 'batch') && !isAdmin()) {
    toast('Tu rol de solo lectura no permite emitir licencias.', 'warn');
    view = 'dashboard';
  }
  state.view = view;
  state.viewSeq += 1;
  updateNav(view);
  if (els.content) els.content.scrollTop = 0;
  if (view === 'dashboard') renderDashboard();
  else if (view === 'licenses') renderLicenses();
  else if (view === 'issue') renderIssue();
  else if (view === 'batch') renderBatch();
  else if (view === 'orders') renderOrders();
  else if (view === 'payments') renderPayments();
  else if (view === 'audit') renderAudit();
  else if (view === 'tools') renderTools();
}

function stopSessionTimer() {
  if (state.sessionTimer) {
    clearInterval(state.sessionTimer);
    state.sessionTimer = null;
  }
}

function startSessionTimer() {
  stopSessionTimer();
  if (!state.session || !state.session.expiresAt) return;
  const expiry = Date.parse(state.session.expiresAt);
  if (!Number.isFinite(expiry)) return;
  state.sessionTimer = setInterval(() => {
    if (!state.authenticated) return;
    if (Date.now() >= expiry) {
      expireSession('La sesión administrativa expiró. Vuelve a iniciar sesión.');
    }
  }, 15_000);
}

function expireSession(message) {
  if (!state.authenticated) return;
  state.authenticated = false;
  stopSessionTimer();
  closeModal({ restoreFocus: false, force: true });
  showLogin(message || 'La sesión expiró. Vuelve a iniciar sesión.');
}

function showLogin(message = '') {
  state.authenticated = false;
  state.session = null;
  state.summary = null;
  state.server = null;
  state.viewSeq += 1;
  state.licenses.seq += 1;
  state.orders.seq += 1;
  state.transactions.seq += 1;
  state.audit.seq += 1;
  state.batch.seq += 1;
  state.batch.running = false;
  state.payments.seq += 1;
  state.payments.data = null;
  state.payments.error = '';
  state.payments.busy = false;
  stopSessionTimer();
  closeModal({ restoreFocus: false, force: true });
  document.body.classList.remove('is-admin');
  if (els.admin) els.admin.hidden = true;
  if (els.loginScreen) els.loginScreen.hidden = false;
  if (els.content) els.content.innerHTML = '';
  if (els.loginPassword) els.loginPassword.value = '';
  setLoginError(message);
  setConnection('offline', 'Servidor central');
  updateChrome();
  if (els.loginServer && !els.loginServer.value) els.loginServer.value = state.serverUrl || state.defaultServerUrl;
  updateLoginNote();
  setTimeout(() => {
    if (!els.loginScreen || els.loginScreen.hidden) return;
    const target = els.loginUser && els.loginUser.value ? els.loginPassword : els.loginUser;
    if (target) target.focus();
  }, 40);
}

function showAdmin(info) {
  state.authenticated = true;
  state.session = {
    user: info.user,
    expiresAt: info.expiresAt || null,
    username: (info.user && info.user.username) || 'Administrador',
    role: (info.user && info.user.role) || 'reader',
  };
  state.serverUrl = info.serverUrl || state.serverUrl;
  state.appVersion = info.appVersion || state.appVersion;
  if (info.configWarning) state.configWarning = info.configWarning;
  document.body.classList.add('is-admin');
  if (els.loginScreen) els.loginScreen.hidden = true;
  if (els.admin) els.admin.hidden = false;
  updateChrome();
  setConnection('online', currentServerHost());
  startSessionTimer();
  setView('dashboard');
  if (state.configWarning) {
    toast(state.configWarning, 'warn');
  }
}

function setLoginError(message = '') {
  if (!els.loginError) return;
  els.loginError.textContent = String(message || '');
  els.loginError.hidden = !message;
}

function setLoginNote(message, tone = '') {
  if (!els.loginActionsNote) return;
  els.loginActionsNote.textContent = message;
  els.loginActionsNote.classList.toggle('is-success', tone === 'success');
  els.loginActionsNote.classList.toggle('is-warn', tone === 'warn');
  els.loginActionsNote.classList.toggle('is-error', tone === 'error');
}

function inspectLoginUrl(raw) {
  const text = String(raw || '').trim();
  if (!text) return { state: 'empty' };
  const candidate = /^[a-z][a-z0-9+.-]*:\/\//i.test(text) ? text : `http://${text}`;
  let url;
  try {
    url = new URL(candidate);
  } catch {
    return { state: 'invalid' };
  }
  if (url.protocol !== 'http:' && url.protocol !== 'https:') return { state: 'invalid' };
  const local = ['localhost', '127.0.0.1', '::1', '[::1]'].includes(url.hostname);
  const pathname = url.pathname.replace(/\/+$/, '');
  return {
    state: 'valid',
    https: url.protocol === 'https:',
    local,
    path: pathname === '/v1' ? '' : pathname,
  };
}

function updateLoginNote() {
  if (!els.loginServer) return;
  const info = inspectLoginUrl(els.loginServer.value);
  if (info.state === 'empty') {
    setLoginNote('Escribe la dirección del servidor');
    return;
  }
  if (info.state === 'invalid') {
    setLoginNote('Dirección no válida: usa http:// o https://', 'error');
    return;
  }
  if (info.path) {
    setLoginNote('La dirección debe apuntar a la raíz o a /v1, sin rutas adicionales', 'warn');
    return;
  }
  if (info.https) {
    setLoginNote('Sesión cifrada con TLS', 'success');
    return;
  }
  if (info.local) {
    setLoginNote('Servidor local · conexión directa');
    return;
  }
  setLoginNote('Conexión HTTP sin cifrado', 'warn');
}

function fillLogin(info) {
  if (!info) return;
  state.serverUrl = info.serverUrl || state.defaultServerUrl;
  state.defaultServerUrl = info.defaultServerUrl || DEFAULT_SERVER_URL;
  state.appVersion = info.appVersion || state.appVersion;
  state.platform = info.platform || '';
  if (els.loginServer) els.loginServer.value = state.serverUrl;
  if (els.loginHint) {
    els.loginHint.textContent = `Servidor predeterminado: ${state.defaultServerUrl}`;
    els.loginHint.classList.remove('is-error');
  }
  updateChrome();
  updateLoginNote();
  if (info.configWarning) setLoginError(info.configWarning);
}

async function handleLogin(event) {
  event.preventDefault();
  if (state.loginBusy) return;
  setLoginError('');
  const serverUrl = els.loginServer ? els.loginServer.value.trim() : '';
  const username = els.loginUser ? els.loginUser.value.trim() : '';
  const password = els.loginPassword ? els.loginPassword.value : '';
  if (!serverUrl) {
    setLoginError('Escribe la dirección del servidor de licencias.');
    if (els.loginServer) els.loginServer.focus();
    return;
  }
  if (!username) {
    setLoginError('Escribe el usuario administrador.');
    if (els.loginUser) els.loginUser.focus();
    return;
  }
  if (!password) {
    setLoginError('Escribe la contraseña.');
    if (els.loginPassword) els.loginPassword.focus();
    return;
  }
  state.loginBusy = true;
  setBusy(els.loginButton, true, 'Conectando…');
  if (els.testServer) els.testServer.disabled = true;
  try {
    const data = await run('auth:login', { serverUrl, username, password });
    if (els.loginPassword) els.loginPassword.value = '';
    showAdmin({ ...data, user: data.user, expiresAt: data.expiresAt });
    toast(`Sesión iniciada como ${data.user ? data.user.username : username}.`, 'success');
  } catch (error) {
    setLoginError(error.message);
    setConnection('error', 'Servidor central');
    if (error.code === 'invalid_credentials' || error.status === 401) {
      if (els.loginPassword) {
        els.loginPassword.select();
        els.loginPassword.focus();
      }
    }
  } finally {
    state.loginBusy = false;
    setBusy(els.loginButton, false);
    if (els.testServer) els.testServer.disabled = false;
  }
}

async function testServerConnection() {
  if (state.healthBusy) return;
  const serverUrl = els.loginServer ? els.loginServer.value.trim() : '';
  if (!serverUrl) {
    setLoginError('Escribe la dirección del servidor antes de probar.');
    return;
  }
  state.healthBusy = true;
  setLoginError('');
  setLoginNote('Probando conexión…');
  if (els.testServer) els.testServer.disabled = true;
  try {
    const data = await run('server:health', { serverUrl });
    setLoginNote(`Servidor disponible · v${data.version || 'desconocida'}`, 'success');
    setConnection('online', 'Servidor disponible');
  } catch (error) {
    setLoginNote(truncate(error.message, 110), 'error');
    setConnection('error', 'Sin conexión');
  } finally {
    state.healthBusy = false;
    if (els.testServer) els.testServer.disabled = false;
  }
}

async function logout() {
  if (els.logoutButton) els.logoutButton.disabled = true;
  try {
    await run('auth:logout');
  } catch {
    // El cierre local siempre debe completarse.
  } finally {
    if (els.logoutButton) els.logoutButton.disabled = false;
  }
  showLogin();
  toast('Sesión cerrada.', 'success');
}

async function refreshSummary() {
  if (!state.authenticated) return null;
  try {
    const data = await api('admin:overview');
    state.summary = data.summary;
    state.server = data.server;
    updateChrome();
    return data;
  } catch (error) {
    if (isNetworkError(error)) setConnection('error', 'Sin conexión');
    return null;
  }
}

/* ===== Dashboard ===== */

function statCard(tone, iconName, label, value, foot) {
  return `
    <article class="stat-card${tone ? ` is-${tone}` : ''}">
      <span class="stat-icon">${icon(iconName)}</span>
      <div>
        <span class="stat-label">${esc(label)}</span>
        <strong class="stat-value">${esc(value)}</strong>
        <span class="stat-foot">${esc(foot)}</span>
      </div>
    </article>
  `;
}

function latestRows(items) {
  return items.map((license) => `
    <tr class="is-clickable" data-open-license="${esc(license.id)}" tabindex="0">
      <td>
        <div class="cell-main mono">${esc(license.id)}</div>
        <span class="cell-sub mono">${esc(planLabel(license.plan))} · ${esc(license.keyMasked || '')}</span>
      </td>
      <td>
        <div class="cell-main">${esc(license.customerName || '—')}</div>
        <span class="cell-sub">${esc(license.email || 'Sin correo')}</span>
      </td>
      <td>${statusChip(license.status)}</td>
      <td class="cell-date">${fmtDate(license.issuedAt)}</td>
    </tr>
  `).join('');
}

function dashboardHtml() {
  const summary = state.summary || {};
  const server = state.server || {};
  const counts = summary.statusCounts || {};
  const capacity = Number(summary.capacity) || 50000;
  const used = Number(summary.used) || 0;
  const available = Number(summary.available) || 0;
  const percent = capacity ? Math.min(100, (used / capacity) * 100) : 0;
  const netRevenue = summary.revenue ? summary.revenue.netCents : 0;
  const orders = summary.orders || {};
  const latest = Array.isArray(summary.latest) ? summary.latest : [];
  const plans = planCatalogue();
  const planText = plans.map((plan) => `${plan.label} ${plan.amountCents === null ? '—' : fmtMoney(plan.amountCents, plan.currency)} · ${plan.period}`).join(' · ');
  const statusKeys = ['active', 'pending', 'suspended', 'expired', 'revoked'];
  const statusLegend = statusKeys.map((key) => {
    const meta = statusMeta(key);
    return `<span class="chip${meta.tone === 'muted' ? ' is-plain' : ` is-${meta.tone}`}">${esc(meta.label)} · ${fmtNum(counts[key] || 0)}</span>`;
  }).join('');
  const notices = [];
  if (!server.paymentsEnabled) {
    notices.push(notice(
      'warn',
      'PayPal no está operativo en este servidor',
      server.missingPayments && server.missingPayments.length
        ? `Faltan ${plural(server.missingPayments.length, 'dato de configuración', 'datos de configuración')} de pago. ${isAdmin() ? 'Configura PayPal y los precios en la sección Pagos.' : 'Pide a un administrador que configure la pasarela.'}`
        : 'La tienda no puede crear órdenes mientras la pasarela no esté configurada.',
      'warning',
    ));
  }
  if (!server.emailEnabled) {
    notices.push(notice(
      'warn',
      'El envío de correo no está configurado',
      'Las licencias se emiten igualmente, pero los correos permanecerán en cola.',
      'mail',
    ));
  }
  if (isAdmin() && (counts.pending || 0) > 0) {
    notices.push(notice(
      'warn',
      `${plural(counts.pending, 'licencia pendiente', 'licencias pendientes')} de activación`,
      'Entregadas sin código de equipo o pendientes de que el cliente las active. Puedes revisarlas en Licencias.',
      'warning',
    ));
  }

  return `
    <div class="view-head">
      <div>
        <h2>Resumen del servidor</h2>
        <p>Inventario histórico, activaciones y pagos verificados.</p>
      </div>
      <div class="view-actions">
        <button class="btn btn-ghost" type="button" data-action="dashboard-refresh">${icon('refresh')} Actualizar</button>
        ${isAdmin() ? `<button class="btn btn-ghost" type="button" data-nav-inline="payments">${icon('payments')} PayPal y precios</button>` : ''}
        <button class="btn btn-ghost" type="button" data-action="licenses-export">${icon('download')} Exportar CSV</button>
      </div>
    </div>

    ${notices.length ? `<div class="notice-stack">${notices.join('')}</div>` : ''}
    ${!isAdmin() ? `<div class="read-only-banner">${notice('', 'Sesión de solo lectura', 'Puedes consultar licencias, pedidos y auditoría. La emisión y las acciones sensibles requieren un usuario administrador.', 'lock')}</div>` : ''}

    <div class="stats">
      ${statCard('accent', 'key', 'Emitidas históricas', fmtNum(used), `${fmtPercent(percent, 2)} de ${fmtNum(capacity)}`)}
      ${statCard('success', 'checkCircle', 'Activas', fmtNum(counts.active || 0), 'Validan en sus equipos')}
      ${statCard('warn', 'clock', 'Pendientes', fmtNum(counts.pending || 0), 'Sin activar o sin equipo')}
      ${statCard('', 'shield', 'Disponibles', fmtNum(available), `${fmtNum(summary.reserved || 0)} reservadas en pedidos`)}
    </div>

    <div class="dash-grid">
      <section class="card capacity-card">
        <div class="card-head">
          <div><h3>Capacidad histórica</h3><p>Un asiento por licencia emitida, sin reutilización</p></div>
          <span class="chip is-accent">${esc(String(capacity ? fmtNum(capacity) : '50.000'))} total</span>
        </div>
        <div class="capacity-numbers">
          <strong>${fmtNum(used)}</strong>
          <span>asignadas de ${fmtNum(capacity)}</span>
        </div>
        <div class="progress"><span style="width:${percent.toFixed(2)}%"></span></div>
        <div class="capacity-legend">
          ${statusLegend}
        </div>
        <div class="capacity-foot">
          ${isAdmin() ? `<button class="btn btn-primary btn-sm" type="button" data-nav-inline="issue">${icon('plus')} Emitir licencia</button>` : ''}
          <button class="btn btn-ghost btn-sm" type="button" data-nav-inline="licenses">${icon('list')} Ver inventario</button>
        </div>
      </section>

      <section class="card">
        <div class="card-head">
          <div><h3>Operación y seguridad</h3><p>Estado del backend central</p></div>
          <span class="chip ${server.paymentsEnabled ? 'is-success' : 'is-warn'}">${server.paymentsEnabled ? 'Pagos activos' : 'Pagos inactivos'}</span>
        </div>
        <div class="card-pad">
          <dl class="data-list">
            <div><dt>Ingresos netos</dt><dd>${esc(fmtMoney(netRevenue, 'USD'))}</dd></div>
            <div><dt>Pedidos pagados</dt><dd>${fmtNum(orders.paid || 0)}</dd></div>
            <div><dt>Planes</dt><dd>${esc(planText)}</dd></div>
            <div><dt>PayPal</dt><dd>${esc(server.paypalMode || 'no configurado')}${isAdmin() ? ` · <button class="link-btn" type="button" data-nav-inline="payments">Configurar</button>` : ''}</dd></div>
            <div><dt>Correo</dt><dd>${server.emailEnabled ? 'Configurado' : 'No configurado'}${Number(server.pendingEmails) ? ` · ${plural(server.pendingEmails, 'en cola', 'en cola')}` : ''}</dd></div>
            <div><dt>Firma</dt><dd class="mono">${esc(server.keyId || '—')}</dd></div>
            <div><dt>Entorno</dt><dd>${esc(server.environment || '—')} · v${esc(server.version || '—')}</dd></div>
            ${server.publicBaseUrl ? `<div><dt>Sitio público</dt><dd>${esc(server.publicBaseUrl)}</dd></div>` : ''}
            ${server.supportEmail ? `<div><dt>Soporte</dt><dd>${esc(server.supportEmail)}</dd></div>` : ''}
          </dl>
        </div>
      </section>
    </div>

    <section class="card latest-card" style="margin-top:16px">
      <div class="card-head">
        <div><h3>Últimas licencias</h3><p>Emisiones más recientes del servidor</p></div>
        <button class="btn btn-ghost btn-sm" type="button" data-nav-inline="licenses">Ver todas ${icon('chevronRight')}</button>
      </div>
      ${latest.length
        ? `<div class="table-wrap"><table class="data-table">
            <thead><tr><th>Licencia</th><th>Cliente</th><th>Estado</th><th>Emitida</th></tr></thead>
            <tbody>${latestRows(latest)}</tbody>
          </table></div>`
        : `<div class="table-empty">Todavía no se ha emitido ninguna licencia.</div>`}
    </section>
  `;
}

async function renderDashboard() {
  const seq = ++state.viewSeq;
  if (els.content) els.content.innerHTML = loadingView('Cargando el panel…');
  try {
    const data = await api('admin:overview');
    if (!state.authenticated) return;
    if (state.view !== 'dashboard' || seq !== state.viewSeq) return;
    state.summary = data.summary;
    state.server = data.server;
    updateChrome();
    setConnection('online', currentServerHost());
    if (els.content) els.content.innerHTML = dashboardHtml();
  } catch (error) {
    if (!state.authenticated) return;
    if (state.view !== 'dashboard' || seq !== state.viewSeq) return;
    if (isNetworkError(error)) setConnection('error', 'Sin conexión');
    if (els.content) els.content.innerHTML = errorPanel(error.message, 'dashboard-refresh');
  }
}

/* ===== Licenses list ===== */

function licensesShell() {
  const filters = state.licenses;
  const statusButtons = ['all', 'pending', 'active', 'expired', 'revoked', 'suspended'].map((status) => {
    const label = status === 'all' ? 'Todas' : statusMeta(status).label;
    return `<button class="${filters.status === status ? 'is-active' : ''}" type="button" data-action="licenses-status" data-status="${esc(status)}">${esc(label)}</button>`;
  }).join('');
  return `
    <div class="view-head">
      <div>
        <h2>Inventario de licencias</h2>
        <p>El historial completo cuenta para el límite de 50.000 asientos.</p>
      </div>
      <div class="view-actions">
        <button class="btn btn-ghost" type="button" data-action="licenses-export">${icon('download')} Exportar CSV</button>
        ${isAdmin() ? `<button class="btn btn-primary" type="button" data-nav-inline="issue">${icon('plus')} Emitir</button>` : ''}
      </div>
    </div>
    <div class="toolbar">
      <div class="search-field">
        ${icon('search')}
        <input class="input" id="license-search" type="search" maxlength="120" value="${esc(filters.query)}" placeholder="Cliente, correo, equipo o ID…" autocomplete="off" spellcheck="false" aria-label="Buscar licencias">
      </div>
      <div class="segmented">${statusButtons}</div>
      <span class="toolbar-count" id="licenses-toolbar-count">${filters.data ? plural(filters.data.total, 'licencia', 'licencias') : 'Cargando…'}</span>
    </div>
    <div id="licenses-results">${loadingBlock('Cargando licencias…')}</div>
  `;
}

function licenseRows(items) {
  return items.map((license) => `
    <tr class="is-clickable" data-open-license="${esc(license.id)}" tabindex="0">
      <td>
        <div class="cell-main mono">${esc(license.id)}</div>
        <span class="cell-sub mono">${esc(planLabel(license.plan))} · ${esc(license.keyMasked || '')}</span>
      </td>
      <td>
        <div class="cell-main">${esc(license.customerName || '—')}</div>
        <span class="cell-sub">${esc(license.email || 'Sin correo')}</span>
      </td>
      <td class="status-cell">${statusChip(license.status)}</td>
      <td class="cell-machine">${license.machineCode ? esc(license.machineCode) : '<span class="cell-empty">Sin vincular</span>'}</td>
      <td class="cell-date">${fmtDate(license.issuedAt)}</td>
      <td class="cell-date">${fmtDate(license.expiresAt, '—')}</td>
      <td class="cell-actions">
        <button class="btn-icon" type="button" data-action="license-open" data-id="${esc(license.id)}" title="Ver licencia" aria-label="Ver licencia ${esc(license.id)}">${icon('chevronRight')}</button>
      </td>
    </tr>
  `).join('');
}

function licenseResultsHtml(data) {
  if (!data || !Array.isArray(data.items) || !data.items.length) {
    const query = state.licenses.query;
    const status = state.licenses.status;
    return `<div class="card table-card">${emptyBlock(
      'key',
      query || status !== 'all' ? 'No hay coincidencias' : 'Todavía no hay licencias emitidas',
      query || status !== 'all'
        ? 'Ajusta la búsqueda o el filtro de estado para ver otras licencias.'
        : 'Cuando emitas una licencia aparecerá aquí con su cliente, equipo y estado.',
      query || status !== 'all'
        ? `<button class="btn btn-ghost btn-sm" type="button" data-action="licenses-clear">${icon('x')} Limpiar filtros</button>`
        : (isAdmin() ? `<button class="btn btn-primary btn-sm" type="button" data-nav-inline="issue">${icon('plus')} Emitir primera licencia</button>` : ''),
    )}</div>`;
  }
  const page = Number(data.page) || 1;
  const pages = Number(data.pages) || 1;
  return `
    <section class="card table-card">
      <div class="table-wrap">
        <table class="data-table">
          <thead>
            <tr><th>Licencia</th><th>Cliente</th><th>Estado</th><th>Equipo</th><th>Emitida</th><th>Vence</th><th class="th-actions"></th></tr>
          </thead>
          <tbody>${licenseRows(data.items)}</tbody>
        </table>
      </div>
      <div class="table-foot">
        <span class="table-meta">${plural(data.total, 'licencia', 'licencias')} · página ${fmtNum(page)} de ${fmtNum(pages)}</span>
        <div class="pagination">
          <button class="btn btn-ghost btn-xs" type="button" data-action="licenses-page" data-page="${page - 1}" ${page <= 1 ? 'disabled' : ''} aria-label="Página anterior">${icon('chevronLeft')}</button>
          <span class="page-indicator">${fmtNum(page)} / ${fmtNum(pages)}</span>
          <button class="btn btn-ghost btn-xs" type="button" data-action="licenses-page" data-page="${page + 1}" ${page >= pages ? 'disabled' : ''} aria-label="Página siguiente">${icon('chevronRight')}</button>
        </div>
      </div>
    </section>
  `;
}

function renderLicenses() {
  if (!els.content) return;
  els.content.innerHTML = licensesShell();
  loadLicenses();
}

async function loadLicenses() {
  if (!state.authenticated) return;
  const filters = state.licenses;
  const seq = ++filters.seq;
  filters.loading = true;
  filters.error = '';
  const target = document.getElementById('licenses-results');
  if (target) target.innerHTML = loadingBlock('Cargando licencias…');
  try {
    const data = await api('admin:licenses:list', {
      query: filters.query,
      status: filters.status,
      page: filters.page,
      pageSize: filters.pageSize,
    });
    if (seq !== filters.seq || state.view !== 'licenses') return;
    filters.loading = false;
    filters.data = data;
    const result = document.getElementById('licenses-results');
    if (result) result.innerHTML = licenseResultsHtml(data);
    const count = document.getElementById('licenses-toolbar-count');
    if (count) count.textContent = plural(data.total, 'licencia', 'licencias');
    setConnection('online', currentServerHost());
  } catch (error) {
    if (seq !== filters.seq || state.view !== 'licenses') return;
    filters.loading = false;
    filters.error = error.message;
    if (isNetworkError(error)) setConnection('error', 'Sin conexión');
    const result = document.getElementById('licenses-results');
    if (result) result.innerHTML = errorPanel(error.message, 'licenses-retry');
  }
}

function licenseSearchChanged(value) {
  state.licenses.query = value;
  state.licenses.page = 1;
  clearTimeout(state.licenses.timer);
  state.licenses.timer = setTimeout(() => {
    if (state.view === 'licenses') loadLicenses();
  }, 280);
}

function setLicenseStatus(status) {
  if (!['all', 'pending', 'active', 'expired', 'revoked', 'suspended'].includes(status)) return;
  state.licenses.status = status;
  state.licenses.page = 1;
  document.querySelectorAll('[data-action="licenses-status"]').forEach((button) => {
    button.classList.toggle('is-active', button.dataset.status === status);
  });
  loadLicenses();
}

function clearLicenseFilters() {
  state.licenses.query = '';
  state.licenses.status = 'all';
  state.licenses.page = 1;
  renderLicenses();
}

async function exportLicensesCsv() {
  try {
    const result = await api('admin:licenses:export-csv', {
      status: state.licenses.status,
      query: state.licenses.query,
    });
    if (result.canceled) return;
    toast(`Inventario guardado en ${result.path}`, 'success');
  } catch (error) {
    toast(error.message, 'error');
  }
}

/* ===== License detail ===== */

function detailSectionTitle(title, action = '') {
  return `<div class="section-head-inline"><h3>${esc(title)}</h3>${action}</div>`;
}

function licenseEmailRows(emails) {
  return emails.map((email) => `
    <tr>
      <td>${emailChip(email.status)}</td>
      <td class="cell-date">${fmtDateTime(email.createdAt)}</td>
      <td class="cell-date">${fmtDateTime(email.sentAt, '—')}</td>
      <td class="cell-date">${fmtNum(email.attempts || 0)}</td>
      <td>${esc(email.lastError ? truncate(email.lastError, 90) : '—')}</td>
    </tr>
  `).join('');
}

function licenseOrderRows(orders) {
  return orders.map((order) => `
    <tr class="is-clickable" data-open-order="${esc(order.id)}" tabindex="0">
      <td class="mono">${esc(order.id)}</td>
      <td>${orderChip(order.status)}</td>
      <td>${esc(fmtMoney(order.amountCents, order.currency))}</td>
      <td class="cell-date">${fmtDate(order.createdAt)}</td>
    </tr>
  `).join('');
}

function licenseTransactionRows(transactions) {
  return transactions.map((transaction) => `
    <tr>
      <td class="mono">${esc(transaction.id)}</td>
      <td>${esc(transaction.kind === 'refund' ? 'Reembolso' : 'Pago')}</td>
      <td>${esc(fmtMoney(transaction.amountCents, transaction.currency))}</td>
      <td>${esc(transaction.status)}</td>
      <td class="cell-date">${fmtDateTime(transaction.createdAt)}</td>
    </tr>
  `).join('');
}

function licenseActionButtons(license) {
  if (!isAdmin()) return '';
  const actions = [];
  if (license.status !== 'revoked') {
    actions.push(`<button class="btn btn-danger btn-sm" type="button" data-action="license-revoke" data-id="${esc(license.id)}">${icon('trash')} Revocar</button>`);
  }
  if (license.status === 'active' || license.status === 'pending') {
    actions.push(`<button class="btn btn-ghost btn-sm" type="button" data-action="license-suspend" data-id="${esc(license.id)}">${icon('lock')} Suspender</button>`);
  }
  if (license.status === 'suspended') {
    actions.push(`<button class="btn btn-soft btn-sm" type="button" data-action="license-reactivate" data-id="${esc(license.id)}">${icon('refresh')} Reactivar</button>`);
  }
  if (license.status !== 'revoked' && license.status !== 'suspended') {
    actions.push(`<button class="btn btn-soft btn-sm" type="button" data-action="license-renew" data-id="${esc(license.id)}">${icon('clock')} Renovar</button>`);
  }
  if (license.machineCode && license.status !== 'revoked') {
    actions.push(`<button class="btn btn-ghost btn-sm" type="button" data-action="license-reset" data-id="${esc(license.id)}">${icon('monitor')} Liberar equipo</button>`);
  }
  return actions.join('');
}

function envelopeSection(envelope) {
  if (!envelope) {
    return notice(
      'warn',
      'Archivo de licencia todavía no generado',
      'La licencia está pendiente de activación. El archivo firmado se creará cuando se vincule a un código de equipo.',
      'key',
    );
  }
  return `
    <div class="license-preview-head">
      <span>Archivo firmado</span>
      <div class="mini-actions">
        <button class="link-btn" type="button" data-action="license-copy-envelope">Copiar JSON</button>
        <button class="link-btn" type="button" data-action="license-save-envelope" data-id="${esc(state.modalDetail.license.id)}">Guardar archivo</button>
      </div>
    </div>
    <pre class="license-preview">${esc(JSON.stringify(envelope, null, 2))}</pre>
  `;
}

function licenseDetailHtml(detail) {
  const license = detail.license;
  const emails = Array.isArray(detail.emails) ? detail.emails : [];
  const orders = Array.isArray(detail.orders) ? detail.orders : [];
  const transactions = Array.isArray(detail.transactions) ? detail.transactions : [];
  const notes = license.notes ? `<div class="detail-item is-wide"><small>Notas internas</small><span class="value">${esc(license.notes)}</span></div>` : '';
  const revokeInfo = license.revokedAt
    ? `<div class="detail-item is-wide"><small>Revocación</small><span class="value">${esc(fmtDateTime(license.revokedAt))}${license.revokedReason ? ` · ${esc(license.revokedReason)}` : ''}</span></div>`
    : '';
  const suspendInfo = license.suspendedAt
    ? `<div class="detail-item is-wide"><small>Suspensión</small><span class="value">${esc(fmtDateTime(license.suspendedAt))}${license.suspendedReason ? ` · ${esc(license.suspendedReason)}` : ''}</span></div>`
    : '';
  return `
    ${modalHead('Detalle de licencia', license.id, `${statusChip(license.status)}<span class="chip">${esc(license.product || 'perfillab')}</span><span class="chip is-plain">v${esc(license.licenseVersion || 1)}</span>`)}
    <div class="modal-body">
      <div class="detail-grid">
        ${detailItem('Cliente', license.customerName || '—')}
        ${detailItem('Correo', license.email || 'Sin correo')}
        ${detailItem('Asiento', `#${license.seat}`, { mono: true })}
        ${detailItem('Plan', `${planLabel(license.plan)} · ${planDuration(license.plan)}`)}
        ${detailItem('Emitida', fmtDateTime(license.issuedAt))}
        ${detailItem('Vence', fmtDateTime(license.expiresAt))}
        ${detailItem('Activada', fmtDateTime(license.activatedAt, 'Sin activar'))}
        ${detailItem('Transacción', license.transactionId || 'Sin transacción')}
        ${detailCopyItem('Código de equipo', license.machineCode || '')}
        ${detailItem('Nombre del equipo', license.machineName || '—')}
        ${notes}
        ${revokeInfo}
        ${suspendInfo}
      </div>

      <div class="modal-section">
        <h3>Clave de licencia</h3>
        <div class="key-row">
          <code class="key-box">${esc(detail.licenseKey)}</code>
          ${copyButton(detail.licenseKey, 'Clave de licencia copiada.', 'Copiar clave de licencia')}
        </div>
        <p class="detail-note">La clave se descifra únicamente en esta sesión administrativa. Cada consulta queda registrada en auditoría.</p>
      </div>

      <div class="modal-section">
        ${envelopeSection(detail.envelope)}
      </div>

      ${emails.length ? `
        <div class="modal-section">
          ${detailSectionTitle('Correos')}
          <div class="table-wrap">
            <table class="data-table">
              <thead><tr><th>Estado</th><th>Creado</th><th>Enviado</th><th>Intentos</th><th>Último error</th></tr></thead>
              <tbody>${licenseEmailRows(emails)}</tbody>
            </table>
          </div>
        </div>
      ` : ''}

      ${orders.length ? `
        <div class="modal-section">
          ${detailSectionTitle('Pedidos vinculados')}
          <div class="table-wrap">
            <table class="data-table">
              <thead><tr><th>Pedido</th><th>Estado</th><th>Importe</th><th>Creado</th></tr></thead>
              <tbody>${licenseOrderRows(orders)}</tbody>
            </table>
          </div>
        </div>
      ` : ''}

      ${transactions.length ? `
        <div class="modal-section">
          ${detailSectionTitle('Transacciones')}
          <div class="table-wrap">
            <table class="data-table">
              <thead><tr><th>ID</th><th>Tipo</th><th>Importe</th><th>Estado</th><th>Fecha</th></tr></thead>
              <tbody>${licenseTransactionRows(transactions)}</tbody>
            </table>
          </div>
        </div>
      ` : ''}
    </div>
    <div class="modal-actions license-detail-actions">
      <div class="group">
        ${license.email ? `<button class="btn btn-ghost btn-sm" type="button" data-action="license-resend" data-id="${esc(license.id)}">${icon('mail')} Reenviar correo</button>` : ''}
        ${licenseActionButtons(license)}
      </div>
      <div class="group">
        <button class="btn btn-ghost" type="button" data-close>Cerrar</button>
        ${detail.envelope ? `<button class="btn btn-primary" type="button" data-action="license-save-envelope" data-id="${esc(license.id)}">${icon('save')} Guardar archivo</button>` : ''}
      </div>
    </div>
  `;
}

async function openLicenseDetail(id) {
  if (!id || !state.authenticated) return;
  const seq = ++state.modalSeq;
  state.modalDetail = null;
  state.modalOrder = null;
  state.modalAudit = null;
  state.modalReturn = null;
  openModal(modalLoading('Descifrando la licencia…'), { className: 'is-lg', label: `Licencia ${id}` });
  try {
    const detail = await api('admin:licenses:get', { id });
    if (seq !== state.modalSeq) return;
    state.modalDetail = detail;
    renderLicenseDetailModal();
    setConnection('online', currentServerHost());
  } catch (error) {
    if (seq !== state.modalSeq) return;
    closeModal({ restoreFocus: false, force: true });
    if (isNetworkError(error)) setConnection('error', 'Sin conexión');
    if (!error.requiresLogin) toast(error.message, 'error');
  }
}

function renderLicenseDetailModal() {
  if (!state.modalDetail) return;
  openModal(licenseDetailHtml(state.modalDetail), {
    className: 'is-lg',
    label: `Licencia ${state.modalDetail.license.id}`,
    lastFocus: state.lastFocus,
  });
}

async function saveEnvelope(id) {
  if (!id) return;
  try {
    const result = await api('admin:licenses:save-envelope', { id });
    if (result.canceled) return;
    toast(`Archivo de licencia guardado en ${result.path}`, 'success');
  } catch (error) {
    toast(error.message, 'error');
  }
}

function openLicenseAction(action, id) {
  const meta = LICENSE_ACTION_META[action];
  if (!meta || !state.modalDetail || state.modalDetail.license.id !== id) return;
  const license = state.modalDetail.license;
  openModal(`
    ${modalHead(meta.title, license.id, statusChip(license.status))}
    <form id="license-action-form" data-operation="${esc(action)}" data-id="${esc(id)}" novalidate>
      <div class="modal-body">
        <p>${esc(meta.description)}</p>
        ${meta.warning ? `<div class="notice is-warn" style="margin-top:14px">${icon('warning')}<div><strong>Importante</strong><p>${esc(meta.warning)}</p></div></div>` : ''}
        ${action === 'renew' ? `
          <div class="field" style="margin-top:16px">
            <label class="field-label" for="license-action-plan">Plan de renovación *</label>
            <select class="select" id="license-action-plan">${planSelectOptions(license.plan)}</select>
            <span class="field-hint">El nuevo vencimiento se calcula desde hoy o desde el vencimiento vigente, el que sea posterior.</span>
          </div>
        ` : ''}
        <div class="form-error" id="license-action-error" role="alert" hidden></div>
        ${meta.reason ? `
          <div class="field" style="margin-top:16px">
            <label class="field-label" for="license-action-reason">${esc(meta.reasonLabel)} *</label>
            <textarea class="textarea" id="license-action-reason" maxlength="300" placeholder="Obligatorio, mínimo 3 caracteres. Queda registrado en auditoría."></textarea>
            <span class="field-hint">Visible en el historial de auditoría.</span>
          </div>
        ` : ''}
      </div>
      <div class="modal-actions">
        <button class="btn btn-ghost" type="button" data-close>Cancelar</button>
        <button class="btn ${meta.danger ? 'btn-danger' : 'btn-primary'}" type="submit">${icon(meta.danger ? 'trash' : 'check')} ${esc(meta.confirm)}</button>
      </div>
    </form>
  `, {
    className: 'is-sm',
    label: meta.title,
    lastFocus: state.lastFocus,
    returnModal: renderLicenseDetailModal,
  });
}

async function submitLicenseAction(action, id, button) {
  const meta = LICENSE_ACTION_META[action];
  if (!meta) return;
  const errorBox = document.getElementById('license-action-error');
  const reasonField = document.getElementById('license-action-reason');
  const planField = document.getElementById('license-action-plan');
  const reason = reasonField ? reasonField.value.trim() : '';
  const plan = action === 'renew' && planField ? planField.value : '';
  const showError = (message) => {
    if (errorBox) {
      errorBox.textContent = message;
      errorBox.hidden = false;
    } else {
      toast(message, 'error');
    }
  };
  if (meta.reason && reason.length < 3) {
    showError('Indica un motivo de al menos 3 caracteres.');
    if (reasonField) reasonField.focus();
    return;
  }
  if (action === 'renew' && !PLAN_META[plan]) {
    showError('Selecciona un plan de renovación válido.');
    if (planField) planField.focus();
    return;
  }
  state.modalBusy = true;
  setBusy(button, true, 'Aplicando…');
  if (errorBox) {
    errorBox.textContent = '';
    errorBox.hidden = true;
  }
  try {
    const result = await api('admin:licenses:action', { id, action, reason, plan });
    state.modalBusy = false;
    if (result.already) toast('La licencia ya se encontraba en ese estado.', 'info');
    else toast(`Acción aplicada a ${id}.`, 'success');
    if (result.warning) toast(result.warning, 'warn');
    await refreshSummary();
    await refreshCurrentView();
    await openLicenseDetail(id);
  } catch (error) {
    state.modalBusy = false;
    if (error.requiresLogin) return;
    setBusy(button, false);
    showError(error.message);
  }
}

async function resendLicenseEmail(id) {
  try {
    const result = await api('admin:licenses:action', { id, action: 'resend-email', reason: '' });
    toast(result.queued ? 'Correo añadido a la cola de envío.' : 'El correo ya estaba en cola.', 'success');
    await refreshSummary();
    await openLicenseDetail(id);
  } catch (error) {
    if (!error.requiresLogin) toast(error.message, 'error');
  }
}

async function refreshCurrentView() {
  if (!state.authenticated) return;
  if (state.view === 'dashboard') await renderDashboard();
  else if (state.view === 'licenses') await loadLicenses();
  else if (state.view === 'orders') {
    if (state.orders.tab === 'transactions') await loadTransactions();
    else await loadOrders();
  } else if (state.view === 'audit') await loadAudit();
  else if (state.view === 'payments') await loadPayments();
  else if (state.view === 'tools') await renderTools();
}

/* ===== Issue view ===== */

const CROCKFORD_ALPHABET = '0123456789ABCDEFGHJKMNPQRSTVWXYZ';
const TRANSACTION_RE = /^[A-Za-z0-9._:@-]+$/;

function normalizeMachineInput(value) {
  return String(value || '')
    .toUpperCase()
    .replace(/[^0-9A-Z]/g, '')
    .replace(/[IL]/g, '1')
    .replace(/O/g, '0')
    .replace(/U/g, 'V')
    .slice(0, 16);
}

function groupMachine(value) {
  const groups = String(value || '').match(/.{1,4}/g);
  return groups ? groups.join('-') : '';
}

function machineInputValid(value) {
  const clean = normalizeMachineInput(value);
  if (clean.length !== 16) return false;
  return [...clean].every((char) => CROCKFORD_ALPHABET.includes(char));
}

function formatMachineInput(input) {
  if (!input) return;
  const formatted = groupMachine(normalizeMachineInput(input.value));
  if (input.value !== formatted) input.value = formatted;
  input.classList.remove('is-error');
  updateMachineCounter(input);
}

function updateMachineCounter(input) {
  const counter = document.getElementById('issue-machine-counter');
  if (!counter) return;
  const clean = normalizeMachineInput(input.value);
  counter.classList.remove('is-valid');
  if (!clean.length) {
    counter.textContent = 'Opcional · 16 caracteres si vinculase un equipo';
  } else if (clean.length === 16) {
    counter.textContent = 'Código completo · 16/16';
    counter.classList.add('is-valid');
  } else {
    counter.textContent = `${clean.length}/16 caracteres`;
  }
}

function emailIsValid(value) {
  const email = String(value || '').trim();
  if (!email || email.length > 254 || /\s/.test(email)) return false;
  const at = email.lastIndexOf('@');
  if (at < 1 || at > 64) return false;
  const local = email.slice(0, at);
  const domain = email.slice(at + 1);
  if (local.length > 64 || domain.length > 253) return false;
  if (!/^[A-Za-z0-9.!#$%&'*+/=?^_`{|}~-]+$/.test(local)) return false;
  if (local.startsWith('.') || local.endsWith('.') || local.includes('..')) return false;
  const labels = domain.split('.');
  if (labels.length < 2) return false;
  return labels.every((label) => (
    Boolean(label)
    && label.length <= 63
    && /^[A-Za-z0-9](?:[A-Za-z0-9-]*[A-Za-z0-9])?$/.test(label)
  ));
}

function issueHtml() {
  return `
    <div class="view-head">
      <div>
        <h2>Emitir una licencia</h2>
        <p>El servidor asigna la clave, la firma y la vincula a un único equipo.</p>
      </div>
      <div class="view-actions">
        <button class="btn btn-ghost" type="button" data-nav-inline="batch">${icon('batch')} Emitir por lote</button>
        <button class="btn btn-ghost" type="button" data-nav-inline="licenses">${icon('list')} Ver inventario</button>
      </div>
    </div>

    <div class="issue-layout">
      <section class="card form-card">
        <form id="issue-form" class="issue-form" novalidate>
          <div class="form-section">
            <h3>Cliente</h3>
            <p>El nombre aparece en el inventario y en el correo de entrega.</p>
            <div class="field">
              <label class="field-label" for="issue-customer">Nombre del cliente o empresa *</label>
              <input class="input" id="issue-customer" type="text" maxlength="160" autocomplete="off" placeholder="Ej. Estudio Norte SRL" autofocus>
              <span class="field-hint">Máximo 160 caracteres.</span>
            </div>
            <div class="field">
              <label class="field-label" for="issue-email">Correo electrónico</label>
              <input class="input" id="issue-email" type="email" maxlength="254" autocomplete="off" spellcheck="false" placeholder="cliente@ejemplo.com">
              <span class="field-hint">Si el servidor tiene SMTP, la licencia se envía a esta dirección.</span>
            </div>
          </div>

          <div class="form-section">
            <h3>Equipo de destino</h3>
            <p>Déjalo vacío para emitir una licencia pendiente que el cliente activará después.</p>
            <div class="form-grid">
              <div class="field">
                <label class="field-label" for="issue-machine">Código de equipo</label>
                <input class="input is-mono" id="issue-machine" type="text" maxlength="19" autocomplete="off" spellcheck="false" placeholder="XXXX-XXXX-XXXX-XXXX">
                <span class="field-hint" id="issue-machine-counter">Opcional · 16 caracteres si vinculase un equipo</span>
              </div>
              <div class="field">
                <label class="field-label" for="issue-machine-name">Nombre del equipo</label>
                <input class="input" id="issue-machine-name" type="text" maxlength="80" autocomplete="off" placeholder="Ej. PC-Recepción">
                <span class="field-hint">Solo informativo; no se incluye en la firma.</span>
              </div>
            </div>
          </div>

          <div class="form-section">
            <h3>Vigencia y control</h3>
            <p id="issue-plan-copy">La licencia dura 12 meses desde su emisión y no se renueva automáticamente.</p>
            <div class="form-grid">
              <div class="field">
                <label class="field-label" for="issue-plan">Plan *</label>
                <select class="select" id="issue-plan">${planSelectOptions(DEFAULT_PLAN)}</select>
                <span class="field-hint">Precio configurado en la sección Pagos.</span>
              </div>
              <div class="field">
                <label class="field-label" for="issue-transaction">Referencia de pago</label>
                <input class="input is-mono" id="issue-transaction" type="text" maxlength="100" autocomplete="off" spellcheck="false" placeholder="Opcional · PayPal, transferencia…">
                <span class="field-hint">Impide emitir dos licencias con la misma referencia.</span>
              </div>
            </div>
            <div class="field">
              <label class="field-label" for="issue-duration">Duración</label>
              <input class="input" id="issue-duration" type="text" value="Anual · 12 meses" disabled>
              <span class="field-hint">Fecha de vencimiento calculada por el servidor. Un plan mensual no se renueva solo.</span>
            </div>
            <div class="field">
              <label class="field-label" for="issue-notes">Notas internas</label>
              <textarea class="textarea" id="issue-notes" maxlength="500" placeholder="Opcional. Solo visible en esta consola."></textarea>
            </div>
          </div>

          <div class="form-error" id="issue-error" role="alert" hidden></div>

          <div class="form-actions">
            <button class="btn btn-ghost" type="button" data-nav-inline="licenses">Cancelar</button>
            <button class="btn btn-primary" id="issue-submit" type="submit">${icon('key')} Firmar y emitir</button>
          </div>
        </form>
      </section>

      <aside class="issue-aside">
        <section class="card info-card">
          <h3>Cómo se emite</h3>
          <div class="mini-steps">
            <div class="mini-step">
              <span>01</span>
              <div><strong>El servidor reserva un asiento</strong><small>La clave se genera con aleatoriedad criptográfica y se cifra en el inventario.</small></div>
            </div>
            <div class="mini-step">
              <span>02</span>
              <div><strong>Firma Ed25519</strong><small>La clave privada nunca sale del servidor ni se incluye en esta aplicación.</small></div>
            </div>
            <div class="mini-step">
              <span>03</span>
              <div><strong>Entrega controlada</strong><small>Con código de equipo, el archivo firmado queda listo. Sin código, la licencia queda pendiente.</small></div>
            </div>
          </div>
          <div class="aside-note">La emisión queda registrada en auditoría. El límite histórico es de 50.000 licencias y no se reutilizan asientos.</div>
        </section>

        <section class="card rule-card">
          ${icon('warning')}
          <div>
            <strong>Una licencia por ordenador</strong>
            <p>Un mismo código de equipo no puede tener dos licencias activas al mismo tiempo.</p>
          </div>
        </section>
      </aside>
    </div>
  `;
}

function renderIssue() {
  if (!isAdmin()) {
    setView('dashboard');
    return;
  }
  if (!els.content) return;
  els.content.innerHTML = issueHtml();
  refreshIssuePlan();
  const customer = document.getElementById('issue-customer');
  if (customer) setTimeout(() => customer.focus(), 40);
}

function refreshIssuePlan() {
  const select = document.getElementById('issue-plan');
  const plan = select ? select.value : DEFAULT_PLAN;
  const duration = document.getElementById('issue-duration');
  if (duration) duration.value = `${planLabel(plan)} · ${planDuration(plan)}`;
  const copy = document.getElementById('issue-plan-copy');
  if (copy) copy.textContent = `La licencia dura ${planDuration(plan)} desde su emisión y no se renueva automáticamente.`;
}

function setIssueError(message = '') {
  const box = document.getElementById('issue-error');
  if (!box) return;
  box.textContent = String(message || '');
  box.hidden = !message;
}

function issueResultHtml(result) {
  const license = result.license || {};
  const key = result.licenseKey || '';
  const envelope = result.envelope || null;
  const pending = !license.machineCode;
  const envelopeJson = envelope ? JSON.stringify(envelope, null, 2) : '';
  return `
    ${modalHead('Licencia emitida', license.id || 'Nueva licencia', statusChip(license.status))}
    <div class="modal-body">
      <div class="result-hero">
        <span class="result-icon">${icon('checkCircle')}</span>
        <div>
          <strong>${pending ? 'Licencia pendiente de activación' : 'Licencia activa y firmada'}</strong>
          <p>${pending
            ? 'La clave ya es válida. El archivo firmado se generará cuando el cliente la active con su código de equipo.'
            : 'El archivo firmado está listo para entregar al cliente.'}</p>
        </div>
      </div>

      <div class="detail-grid">
        ${detailItem('Cliente', license.customerName || '—')}
        ${detailItem('Correo', license.email || 'Sin correo')}
        ${detailItem('Asiento', license.seat ? `#${license.seat}` : '—', { mono: true })}
        ${detailItem('Plan', `${planLabel(license.plan)} · ${planDuration(license.plan)}`)}
        ${detailItem('Vence', fmtDateTime(license.expiresAt))}
        ${detailItem('Equipo', license.machineCode || 'Sin vincular', { mono: true, wide: Boolean(license.machineCode) })}
        ${license.machineName ? detailItem('Nombre del equipo', license.machineName) : ''}
      </div>

      <div class="modal-section">
        <h3>Clave de licencia</h3>
        <div class="key-row">
          <code class="key-box">${esc(key)}</code>
          ${copyButton(key, 'Clave de licencia copiada.', 'Copiar clave de licencia')}
        </div>
        <p class="detail-note">Entrega la clave por un canal seguro. También puedes volver a consultarla desde el inventario; cada consulta queda auditada.</p>
      </div>

      <div class="modal-section">
        ${envelope ? `
          <div class="license-preview-head">
            <span>Archivo firmado</span>
            <div class="mini-actions">
              ${copyButton(envelopeJson, 'Archivo de licencia copiado.', 'Copiar JSON')}
              <button class="link-btn" type="button" data-action="license-save-envelope" data-id="${esc(license.id)}">Guardar archivo</button>
            </div>
          </div>
          <pre class="license-preview">${esc(envelopeJson)}</pre>
        ` : notice(
          'warn',
          'Archivo firmado pendiente',
          'La licencia todavía no está vinculada a un equipo. Cuando el cliente la active, el servidor generará el archivo firmado.',
          'key',
        )}
      </div>
    </div>
    <div class="modal-actions">
      <button class="btn btn-ghost" type="button" data-action="issue-another">Emitir otra</button>
      <button class="btn btn-ghost" type="button" data-close>Cerrar</button>
      <button class="btn btn-soft" type="button" data-action="issue-view-detail" data-id="${esc(license.id)}">${icon('list')} Ver detalle</button>
      ${envelope ? `<button class="btn btn-primary" type="button" data-action="license-save-envelope" data-id="${esc(license.id)}">${icon('save')} Guardar archivo</button>` : ''}
    </div>
  `;
}

async function handleIssueSubmit(event) {
  event.preventDefault();
  if (state.issueBusy || !isAdmin()) return;
  setIssueError('');
  const customerField = document.getElementById('issue-customer');
  const emailField = document.getElementById('issue-email');
  const machineField = document.getElementById('issue-machine');
  const machineNameField = document.getElementById('issue-machine-name');
  const transactionField = document.getElementById('issue-transaction');
  const notesField = document.getElementById('issue-notes');
  const planField = document.getElementById('issue-plan');
  const submit = document.getElementById('issue-submit');
  if (!customerField || !submit) return;

  const customerName = customerField.value.trim();
  const email = emailField ? emailField.value.trim() : '';
  const machineCode = machineField ? machineField.value.trim() : '';
  const machineName = machineNameField ? machineNameField.value.trim() : '';
  const transactionId = transactionField ? transactionField.value.trim() : '';
  const notes = notesField ? notesField.value.trim() : '';
  const plan = planField ? planField.value : DEFAULT_PLAN;

  if (!customerName) {
    setIssueError('Escribe el nombre del cliente.');
    customerField.focus();
    return;
  }
  if (!PLAN_META[plan]) {
    setIssueError('Selecciona un plan de licencia válido.');
    if (planField) planField.focus();
    return;
  }
  if (customerName.length > 160) {
    setIssueError('El nombre del cliente supera los 160 caracteres.');
    customerField.focus();
    return;
  }
  if (email && !emailIsValid(email)) {
    setIssueError('El correo electrónico no es válido.');
    if (emailField) emailField.focus();
    return;
  }
  if (machineCode && !machineInputValid(machineCode)) {
    setIssueError('El código de equipo debe tener 16 caracteres válidos.');
    if (machineField) {
      machineField.classList.add('is-error');
      machineField.focus();
    }
    return;
  }
  if (machineName.length > 80) {
    setIssueError('El nombre del equipo supera los 80 caracteres.');
    return;
  }
  if (transactionId && (transactionId.length > 100 || !TRANSACTION_RE.test(transactionId))) {
    setIssueError('La referencia de pago no es válida. Usa letras, números y . _ : @ -');
    if (transactionField) transactionField.focus();
    return;
  }
  if (notes.length > 500) {
    setIssueError('Las notas superan los 500 caracteres.');
    return;
  }

  state.issueBusy = true;
  setBusy(submit, true, 'Emitiendo…');
  try {
    const result = await api('admin:licenses:issue', {
      customerName,
      email,
      machineCode: machineCode ? groupMachine(normalizeMachineInput(machineCode)) : '',
      machineName: machineCode ? machineName : '',
      transactionId,
      notes,
      plan,
    });
    state.lastIssued = result;
    await refreshSummary();
    toast(`Licencia ${result.license.id} emitida.`, 'success');
    openModal(issueResultHtml(result), {
      className: 'is-lg',
      label: `Licencia ${result.license.id} emitida`,
    });
  } catch (error) {
    if (error.requiresLogin) return;
    setIssueError(error.message);
    if (error.code === 'machine_in_use' && machineField) {
      machineField.classList.add('is-error');
      machineField.focus();
    } else if (error.code === 'invalid_email' && emailField) {
      emailField.focus();
    } else if (error.code === 'transaction_already_used' && transactionField) {
      transactionField.focus();
    }
  } finally {
    state.issueBusy = false;
    setBusy(submit, false);
  }
}

async function openIssueDetail(id) {
  closeModal({ force: true, restoreFocus: false });
  await openLicenseDetail(id);
}

/* ===== Batch view ===== */

let batchParseTimer = null;

const BATCH_HEADER_ALIASES = {
  customerName: ['cliente', 'nombre', 'nombre del cliente', 'nombre cliente', 'customer', 'customer name', 'name'],
  email: ['correo', 'correo electronico', 'email', 'e mail', 'e-mail', 'mail'],
  machineCode: ['equipo', 'codigo de equipo', 'codigo equipo', 'codigo', 'machine', 'machine code', 'machinecode', 'machine_code'],
  machineName: ['nombre del equipo', 'nombre equipo', 'nombre de equipo', 'machine name', 'machinename'],
  notes: ['notas', 'nota', 'notes', 'observaciones'],
  plan: ['plan', 'planes', 'plan de licencia', 'tipo de plan', 'periodo', 'duracion', 'licencia', 'tipo de licencia'],
  transactionId: ['referencia', 'referencia de pago', 'transaccion', 'transaction', 'transaction id', 'transactionid', 'transaction_id', 'pago', 'pedido'],
};

const BATCH_EXAMPLE = [
  'cliente,correo,equipo,nombre del equipo,notas,plan,referencia',
  'Ana Torres,ana@ejemplo.com,K7M2-9Q4T-X8RB-3N6V,PC-Ana,Venta directa,anual,MANUAL-001',
  'Estudio Norte SRL,compras@estudionorte.com,H5P8-2W7C-Y4KM-6T9B,PC-Recepcion,,semestral,MANUAL-002',
  'Carlos Pérez,carlos@ejemplo.com,,,,mensual,PEDIDO-8842',
].join('\n');

function normalizePlanInput(value) {
  const clean = String(value || '')
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/\s+/g, ' ')
    .trim();
  if (!clean) return '';
  if (['mensual', 'monthly', 'mes', '1', '1 mes', '30 dias'].includes(clean)) return 'monthly';
  if (['semestral', 'semianual', 'semi anual', '6', '6 meses', 'medio ano'].includes(clean)) return 'semiannual';
  if (['anual', 'annual', 'ano', '12', '12 meses', 'year'].includes(clean)) return 'annual';
  return null;
}

function batchHtml() {
  const text = state.batch.text || '';
  return `
    <div class="view-head">
      <div>
        <h2>Emisión por lote</h2>
        <p>Hasta 1.000 filas por carga. El servidor procesa bloques de 20 y registra cada resultado.</p>
      </div>
      <div class="view-actions">
        <button class="btn btn-ghost" type="button" data-nav-inline="licenses">${icon('list')} Ver inventario</button>
        <button class="btn btn-ghost" type="button" data-nav-inline="issue">${icon('plus')} Emisión individual</button>
      </div>
    </div>

    <div class="batch-layout">
      <section class="card form-card">
        <div class="form-section">
          <h3>Datos de las licencias</h3>
          <p>Pega filas separadas por comas, punto y coma o tabulaciones, o carga un archivo CSV.</p>
          <div class="form-grid">
            <div class="field">
              <label class="field-label" for="batch-plan">Plan predeterminado *</label>
              <select class="select" id="batch-plan" ${state.batch.running ? 'disabled' : ''}>${planSelectOptions(state.batch.plan)}</select>
              <span class="field-hint">Se aplica a las filas que no incluyan una columna «plan».</span>
            </div>
          </div>
          <div class="field">
            <label class="field-label" for="batch-input">Filas del lote</label>
            <textarea class="textarea batch-input" id="batch-input" spellcheck="false" placeholder="cliente,correo,equipo,nombre del equipo,notas,plan,referencia&#10;Ana Torres,ana@ejemplo.com,K7M2-9Q4T-X8RB-3N6V,PC-Ana,Venta directa,anual,MANUAL-001" ${state.batch.running ? 'disabled' : ''}>${esc(text)}</textarea>
            <span class="field-hint">La primera fila puede ser una cabecera. El equipo es opcional: sin código, la licencia queda pendiente. Plan: mensual, semestral o anual.</span>
          </div>
          <div class="batch-toolbar">
            <label class="btn btn-ghost btn-sm file-button">
              ${icon('download')} Cargar archivo
              <input type="file" id="batch-file" accept=".csv,.tsv,.txt,text/csv,text/plain" ${state.batch.running ? 'disabled' : ''}>
            </label>
            <button class="btn btn-ghost btn-sm" type="button" data-action="batch-example" ${state.batch.running ? 'disabled' : ''}>Usar ejemplo</button>
            <button class="btn btn-ghost btn-sm" type="button" data-action="batch-parse" ${state.batch.running ? 'disabled' : ''}>${icon('refresh')} Analizar</button>
            <button class="btn btn-ghost btn-sm" type="button" data-action="batch-clear" ${state.batch.running ? 'disabled' : ''}>${icon('x')} Limpiar</button>
            <span class="tool-meta" id="batch-row-count"></span>
          </div>
          <div class="form-error" id="batch-error" role="alert" hidden></div>
        </div>
        <div id="batch-preview"></div>
      </section>

      <aside class="issue-aside">
        <section class="card batch-progress-card" id="batch-progress"></section>

        <section class="card info-card">
          <h3>Columnas admitidas</h3>
          <div class="mini-steps">
            <div class="mini-step">
              <span>01</span>
              <div><strong>cliente</strong><small>Obligatorio. Nombre del cliente o empresa.</small></div>
            </div>
            <div class="mini-step">
              <span>02</span>
              <div><strong>correo</strong><small>Opcional. La licencia se encola para entrega si el SMTP está configurado.</small></div>
            </div>
            <div class="mini-step">
              <span>03</span>
              <div><strong>equipo</strong><small>Opcional. Código de 16 caracteres; vincula la licencia a ese ordenador.</small></div>
            </div>
            <div class="mini-step">
              <span>04</span>
              <div><strong>plan</strong><small>Opcional. mensual, semestral o anual; si falta se usa el plan predeterminado.</small></div>
            </div>
            <div class="mini-step">
              <span>05</span>
              <div><strong>notas y referencia</strong><small>Opcionales. La referencia de pago no puede repetirse.</small></div>
            </div>
          </div>
          <div class="aside-note">Las filas con errores no se envían. Si una petición falla por red, esas filas se marcan como inciertas y no se reintentan automáticamente.</div>
        </section>

        <section class="card rule-card">
          ${icon('warning')}
          <div>
            <strong>Sin duplicados por equipo</strong>
            <p>Si un equipo ya tiene una licencia activa, esa fila fallará. Corrige el código o libera el equipo antes de reintentar.</p>
          </div>
        </section>
      </aside>
    </div>
  `;
}

function batchStats() {
  const stats = {
    rows: state.batch.rows.length,
    valid: 0,
    invalid: 0,
    success: 0,
    failed: 0,
    uncertain: 0,
    pending: 0,
  };
  for (const row of state.batch.rows) {
    if (row.error) {
      stats.invalid += 1;
      continue;
    }
    stats.valid += 1;
    const result = state.batch.results.get(row.index);
    if (!result) stats.pending += 1;
    else if (result.status === 'success') stats.success += 1;
    else if (result.status === 'uncertain') stats.uncertain += 1;
    else stats.failed += 1;
  }
  return stats;
}

function batchStatusChip(row) {
  if (row.error) return '<span class="chip is-danger">Revisar</span>';
  const result = state.batch.results.get(row.index);
  if (!result) return '<span class="chip is-plain">Lista</span>';
  if (result.status === 'success') return '<span class="chip is-success">Emitida</span>';
  if (result.status === 'uncertain') return '<span class="chip is-warn">Sin confirmar</span>';
  return '<span class="chip is-danger">Falló</span>';
}

function batchPreviewHtml() {
  if (state.batch.parseError) return '';
  if (!state.batch.rows.length) {
    return emptyBlock(
      'batch',
      'Sin filas analizadas',
      'Pega los datos del lote y pulsa Analizar, o carga un archivo CSV. También puedes empezar con el ejemplo.',
      '<button class="btn btn-ghost btn-sm" type="button" data-action="batch-example">Usar ejemplo</button>',
    );
  }
  const visible = state.batch.rows.slice(0, 100);
  const body = visible.map((row) => {
    const result = state.batch.results.get(row.index);
    const detail = row.error
      || (result && result.status !== 'success' ? result.message : '')
      || (result && result.status === 'success' ? 'Clave emitida y guardada' : '');
    const success = result && result.status === 'success' && result.licenseKey;
    return `
      <tr>
        <td class="cell-date">${fmtNum(row.index + 1)}</td>
        <td>
          <div class="cell-main">${esc(row.values.customerName || '—')}</div>
          <span class="cell-sub">${esc(row.values.email || 'Sin correo')}</span>
          ${detail ? `<span class="cell-sub">${esc(truncate(detail, 70))}</span>` : ''}
        </td>
        <td class="cell-machine">${row.values.machineCode ? esc(row.values.machineCode) : '<span class="cell-empty">Sin equipo</span>'}</td>
        <td><span class="chip is-plain">${esc(planLabel(row.values.plan))}</span></td>
        <td class="status-cell">${batchStatusChip(row)}</td>
        <td class="cell-actions">${success
          ? copyButton(result.licenseKey, 'Clave copiada.', `Copiar clave de la fila ${row.index + 1}`)
          : ''}</td>
      </tr>
    `;
  }).join('');
  const more = state.batch.rows.length > visible.length
    ? `<div class="table-empty">Mostrando las primeras ${fmtNum(visible.length)} de ${plural(state.batch.rows.length, 'fila', 'filas')}.</div>`
    : '';
  return `
    <div class="batch-preview">
      <div class="table-wrap">
        <table class="data-table">
          <thead><tr><th>Fila</th><th>Cliente</th><th>Equipo</th><th>Plan</th><th>Estado</th><th class="th-actions"></th></tr></thead>
          <tbody>${body}</tbody>
        </table>
      </div>
      ${more}
    </div>
  `;
}

function batchProgressHtml() {
  const stats = batchStats();
  const { done, total } = state.batch.progress;
  const percent = total ? Math.min(100, (done / total) * 100) : 0;
  const attemptable = state.batch.rows.filter((row) => {
    if (row.error) return false;
    const result = state.batch.results.get(row.index);
    return !result || result.status === 'failed';
  }).length;
  const errors = [];
  for (const row of state.batch.rows) {
    if (row.error) {
      if (errors.length < 9) errors.push(`Fila ${row.index + 1}: ${row.error}`);
      continue;
    }
    const result = state.batch.results.get(row.index);
    if (result && result.status !== 'success' && errors.length < 9) {
      errors.push(`Fila ${row.index + 1}: ${result.message || 'No se pudo emitir.'}`);
    }
  }
  const hasOutcome = stats.success || stats.failed || stats.uncertain;
  return `
    <div class="batch-progress-meta">
      <strong>${total ? `${fmtNum(done)} de ${fmtNum(total)} procesadas` : 'Progreso del lote'}</strong>
      <span>${state.batch.running ? 'Procesando…' : (hasOutcome ? 'Finalizado' : 'Sin procesar')}</span>
    </div>
    <div class="progress"><span style="width:${percent.toFixed(2)}%"></span></div>
    <div class="batch-legend">
      <span class="chip is-plain">${plural(stats.valid, 'válida', 'válidas')}</span>
      ${stats.invalid ? `<span class="chip is-danger">${plural(stats.invalid, 'con error', 'con error')}</span>` : ''}
      ${stats.success ? `<span class="chip is-success">${plural(stats.success, 'emitida', 'emitidas')}</span>` : ''}
      ${stats.failed ? `<span class="chip is-danger">${plural(stats.failed, 'fallida', 'fallidas')}</span>` : ''}
      ${stats.uncertain ? `<span class="chip is-warn">${plural(stats.uncertain, 'sin confirmar', 'sin confirmar')}</span>` : ''}
      ${stats.pending ? `<span class="chip is-plain">${plural(stats.pending, 'pendiente', 'pendientes')}</span>` : ''}
    </div>
    ${state.batch.interrupted ? `<p class="user-note" style="margin-top:10px">La ejecución se detuvo. Las filas «sin confirmar» podrían haberse emitido: revisa el inventario antes de repetirlas. Las pendientes no llegaron a enviarse.</p>` : ''}
    ${errors.length ? `<ul class="batch-error-list">${errors.map((line) => `<li>${esc(line)}</li>`).join('')}</ul>` : ''}
    <div class="batch-actions">
      ${state.batch.running
        ? `<button class="btn btn-primary btn-sm" type="button" disabled><span class="spinner"></span>Emitiendo lote…</button>`
        : `<button class="btn btn-primary btn-sm" type="button" data-action="batch-start" ${attemptable ? '' : 'disabled'}>${icon('play')} ${hasOutcome ? `Reintentar ${fmtNum(attemptable)}` : `Emitir ${fmtNum(attemptable)} licencias`}</button>`}
      <button class="btn btn-ghost btn-sm" type="button" data-action="batch-copy-keys" ${stats.success ? '' : 'disabled'}>${icon('copy')} Copiar claves</button>
    </div>
    <p>${stats.valid
      ? 'Cada bloque se confirma en el servidor. Las filas con error no consumen asiento.'
      : 'Analiza el lote para habilitar la emisión.'}</p>
  `;
}

function renderBatchDynamic() {
  if (state.view !== 'batch') return;
  const input = document.getElementById('batch-input');
  if (input) {
    input.disabled = state.batch.running;
    if (input.value !== state.batch.text) input.value = state.batch.text;
  }
  const fileInput = document.getElementById('batch-file');
  if (fileInput) fileInput.disabled = state.batch.running;
  const planSelect = document.getElementById('batch-plan');
  if (planSelect) planSelect.disabled = state.batch.running;
  for (const action of ['batch-example', 'batch-parse', 'batch-clear']) {
    const button = els.content.querySelector(`[data-action="${action}"]`);
    if (button) button.disabled = state.batch.running;
  }
  const count = document.getElementById('batch-row-count');
  if (count) {
    count.textContent = state.batch.rows.length
      ? `${plural(state.batch.rows.length, 'fila', 'filas')} · ${plural(batchStats().invalid, 'error', 'errores')}`
      : '';
  }
  const errorBox = document.getElementById('batch-error');
  if (errorBox) {
    errorBox.textContent = state.batch.parseError || '';
    errorBox.hidden = !state.batch.parseError;
  }
  const preview = document.getElementById('batch-preview');
  if (preview) preview.innerHTML = batchPreviewHtml();
  const progress = document.getElementById('batch-progress');
  if (progress) progress.innerHTML = batchProgressHtml();
}

function renderBatch() {
  if (!isAdmin()) {
    setView('dashboard');
    return;
  }
  if (!els.content) return;
  els.content.innerHTML = batchHtml();
  renderBatchDynamic();
}

function detectDelimiter(text) {
  const line = String(text || '').split(/\r?\n/).find((item) => item.trim()) || '';
  let best = ',';
  let bestCount = 0;
  for (const delimiter of ['\t', ';', ',']) {
    let count = 0;
    let quoted = false;
    for (let i = 0; i < line.length; i += 1) {
      const char = line[i];
      if (char === '"') quoted = !quoted;
      else if (!quoted && char === delimiter) count += 1;
    }
    if (count > bestCount) {
      best = delimiter;
      bestCount = count;
    }
  }
  return best;
}

function parseDelimited(text, delimiter) {
  const records = [];
  let row = [];
  let field = '';
  let quoted = false;
  const source = String(text || '').replace(/^\uFEFF/, '');
  for (let i = 0; i < source.length; i += 1) {
    const char = source[i];
    if (quoted) {
      if (char === '"') {
        if (source[i + 1] === '"') {
          field += '"';
          i += 1;
        } else {
          quoted = false;
        }
      } else {
        field += char;
      }
    } else if (char === '"') {
      quoted = true;
    } else if (char === delimiter) {
      row.push(field.trim());
      field = '';
    } else if (char === '\n' || char === '\r') {
      if (char === '\r' && source[i + 1] === '\n') i += 1;
      row.push(field.trim());
      field = '';
      if (row.some((value) => value !== '')) records.push(row);
      row = [];
    } else {
      field += char;
    }
  }
  row.push(field.trim());
  if (row.some((value) => value !== '')) records.push(row);
  return records;
}

function normalizeHeader(value) {
  return String(value || '')
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9]+/g, ' ')
    .trim();
}

function headerField(value) {
  const header = normalizeHeader(value);
  if (!header) return null;
  for (const [field, aliases] of Object.entries(BATCH_HEADER_ALIASES)) {
    if (aliases.includes(header)) return field;
  }
  return null;
}

function parseBatchRecord(values, index) {
  const row = { index, values, error: '' };
  const customerName = String(values.customerName || '').trim();
  const email = String(values.email || '').trim().toLowerCase();
  const machineCode = String(values.machineCode || '').trim();
  const machineName = String(values.machineName || '').trim();
  const notes = String(values.notes || '').trim();
  const planInput = String(values.plan || '').trim();
  const plan = normalizePlanInput(planInput);
  const transactionId = String(values.transactionId || '').trim();
  row.explicitPlan = Boolean(planInput);
  row.values = {
    customerName,
    email,
    machineCode: '',
    machineName,
    notes,
    plan: plan || state.batch.plan,
    transactionId,
  };

  if (!customerName) row.error = 'Falta el nombre del cliente.';
  else if (customerName.length > 160) row.error = 'El nombre del cliente supera 160 caracteres.';
  else if (email && !emailIsValid(email)) row.error = 'El correo electrónico no es válido.';
  else if (machineCode && !machineInputValid(machineCode)) row.error = 'El código de equipo debe tener 16 caracteres válidos.';
  else if (machineName && machineName.length > 80) row.error = 'El nombre del equipo supera 80 caracteres.';
  else if (notes.length > 500) row.error = 'Las notas superan 500 caracteres.';
  else if (planInput && plan === null) row.error = 'El plan debe ser mensual, semestral o anual.';
  else if (transactionId && (transactionId.length > 100 || !TRANSACTION_RE.test(transactionId))) {
    row.error = 'La referencia de pago no es válida.';
  }

  if (!row.error) {
    row.values.machineCode = machineCode ? groupMachine(normalizeMachineInput(machineCode)) : '';
  }
  return row;
}

function parseBatchText(raw) {
  const text = String(raw || '');
  state.batch.text = text;
  state.batch.rows = [];
  state.batch.parseError = '';
  state.batch.results = new Map();
  state.batch.completed = false;
  state.batch.interrupted = false;
  state.batch.progress = { done: 0, total: 0 };
  state.batch.seq += 1;
  if (!text.trim()) {
    renderBatchDynamic();
    return;
  }
  const delimiter = detectDelimiter(text);
  const records = parseDelimited(text, delimiter);
  if (!records.length) {
    state.batch.parseError = 'No se encontraron filas con datos.';
    renderBatchDynamic();
    return;
  }

  let fields = null;
  let start = 0;
  const first = records[0];
  const mapped = first.map(headerField);
  const headerMatches = mapped.filter(Boolean).length;
  if (headerMatches >= 2 || (first.length === 1 && headerMatches === 1)) {
    fields = mapped;
    start = 1;
    if (!fields.includes('customerName')) {
      state.batch.parseError = 'La cabecera debe incluir una columna «cliente» o «nombre».';
      renderBatchDynamic();
      return;
    }
  } else {
    fields = ['customerName', 'email', 'machineCode', 'machineName', 'notes', 'plan', 'transactionId'];
  }

  const dataRecords = records.slice(start);
  if (!dataRecords.length) {
    state.batch.parseError = 'La cabecera está presente, pero no hay filas de datos debajo.';
    renderBatchDynamic();
    return;
  }
  if (dataRecords.length > BATCH_CLIENT_LIMIT) {
    state.batch.parseError = `El lote tiene ${fmtNum(dataRecords.length)} filas y el máximo es ${fmtNum(BATCH_CLIENT_LIMIT)}. Divídelo en varias cargas.`;
    renderBatchDynamic();
    return;
  }

  state.batch.rows = dataRecords.map((record, index) => {
    const values = {};
    if (!start && record.length > fields.length) {
      return {
        index,
        values: { customerName: record[0] || '' },
        error: 'La fila tiene más columnas de las esperadas. Revisa el separador o usa una cabecera.',
      };
    }
    for (let column = 0; column < fields.length; column += 1) {
      if (fields[column]) values[fields[column]] = record[column] || '';
    }
    return parseBatchRecord(values, index);
  });

  const machines = new Map();
  const transactions = new Map();
  for (const row of state.batch.rows) {
    if (row.error) continue;
    if (row.values.machineCode) {
      if (machines.has(row.values.machineCode)) {
        row.error = `Equipo repetido en el lote (fila ${machines.get(row.values.machineCode) + 1}).`;
        continue;
      }
      machines.set(row.values.machineCode, row.index);
    }
    if (row.values.transactionId) {
      if (transactions.has(row.values.transactionId)) {
        row.error = `Referencia repetida en el lote (fila ${transactions.get(row.values.transactionId) + 1}).`;
        continue;
      }
      transactions.set(row.values.transactionId, row.index);
    }
  }
  renderBatchDynamic();
}

function runBatchParse() {
  if (state.batch.running) return;
  const input = document.getElementById('batch-input');
  parseBatchText(input ? input.value : state.batch.text);
  const errorBox = document.getElementById('batch-error');
  if (errorBox && !state.batch.parseError) errorBox.hidden = true;
}

function scheduleBatchParse() {
  clearTimeout(batchParseTimer);
  const input = document.getElementById('batch-input');
  if (!input || state.batch.running) return;
  state.batch.text = input.value;
  batchParseTimer = setTimeout(() => {
    if (state.view !== 'batch' || state.batch.running) return;
    const field = document.getElementById('batch-input');
    if (!field || field.value !== state.batch.text) return;
    parseBatchText(field.value);
  }, 380);
}

function useBatchExample() {
  if (state.batch.running) return;
  parseBatchText(BATCH_EXAMPLE);
}

function clearBatch() {
  if (state.batch.running) return;
  state.batch.seq += 1;
  state.batch.text = '';
  state.batch.rows = [];
  state.batch.parseError = '';
  state.batch.results = new Map();
  state.batch.progress = { done: 0, total: 0 };
  state.batch.completed = false;
  state.batch.interrupted = false;
  const input = document.getElementById('batch-input');
  if (input) input.value = '';
  renderBatchDynamic();
}

function setBatchPlan(value) {
  const plan = PLAN_META[value] ? value : DEFAULT_PLAN;
  state.batch.plan = plan;
  for (const row of state.batch.rows) {
    if (!row.explicitPlan) row.values.plan = plan;
  }
  renderBatchDynamic();
}

async function loadBatchFile(file) {
  if (!file || state.batch.running) return;
  if (file.size > 2 * 1024 * 1024) {
    state.batch.parseError = 'El archivo supera 2 MB. Divide el lote en archivos más pequeños.';
    renderBatchDynamic();
    return;
  }
  try {
    const text = await file.text();
    parseBatchText(text);
  } catch {
    state.batch.parseError = 'No se pudo leer el archivo seleccionado.';
    renderBatchDynamic();
  }
}

async function startBatch() {
  if (state.batch.running || !isAdmin()) return;
  const targets = state.batch.rows.filter((row) => {
    if (row.error) return false;
    const result = state.batch.results.get(row.index);
    return !result || result.status === 'failed';
  });
  if (!targets.length) {
    toast('No hay filas pendientes por emitir.', 'warn');
    return;
  }
  const seq = ++state.batch.seq;
  state.batch.running = true;
  state.batch.completed = false;
  state.batch.interrupted = false;
  state.batch.progress = { done: 0, total: targets.length };
  renderBatchDynamic();

  let stopped = '';
  let issued = 0;

  for (let offset = 0; offset < targets.length; offset += BATCH_CHUNK_SIZE) {
    if (seq !== state.batch.seq || !state.authenticated) return;
    const chunk = targets.slice(offset, offset + BATCH_CHUNK_SIZE);
    const items = chunk.map((row) => ({
      customerName: row.values.customerName,
      email: row.values.email,
      machineCode: row.values.machineCode,
      machineName: row.values.machineCode ? row.values.machineName : '',
      notes: row.values.notes,
      plan: row.values.plan || state.batch.plan,
      transactionId: row.values.transactionId,
    }));
    try {
      const response = await api('admin:licenses:batch', { items });
      if (seq !== state.batch.seq) return;
      const returned = new Map((Array.isArray(response.results) ? response.results : [])
        .map((item) => [Number(item.index), item]));
      chunk.forEach((row, position) => {
        const item = returned.get(position);
        if (!item) {
          state.batch.results.set(row.index, {
            status: 'uncertain',
            message: 'El servidor no devolvió un resultado para esta fila.',
          });
        } else if (item.ok) {
          state.batch.results.set(row.index, {
            status: 'success',
            licenseId: item.licenseId,
            licenseKey: item.licenseKey,
          });
          issued += 1;
        } else {
          state.batch.results.set(row.index, {
            status: 'failed',
            code: item.code || 'error',
            message: item.message || 'No se pudo emitir la licencia.',
          });
        }
      });
      state.batch.progress.done = Math.min(targets.length, state.batch.progress.done + chunk.length);
      renderBatchDynamic();
    } catch (error) {
      if (seq !== state.batch.seq) return;
      if (error.requiresLogin) {
        state.batch.running = false;
        return;
      }
      const uncertain = isNetworkError(error) || !error.status || error.status >= 500;
      chunk.forEach((row) => {
        state.batch.results.set(row.index, {
          status: uncertain ? 'uncertain' : 'failed',
          code: error.code,
          message: uncertain
            ? 'No se pudo confirmar si la licencia fue emitida. Revisa el inventario antes de repetirla.'
            : error.message,
        });
      });
      state.batch.progress.done = Math.min(targets.length, state.batch.progress.done + chunk.length);
      state.batch.interrupted = true;
      stopped = error.message;
      break;
    }
  }

  if (seq !== state.batch.seq) return;
  const stats = batchStats();
  state.batch.running = false;
  state.batch.completed = stats.pending === 0 && stats.uncertain === 0;
  renderBatchDynamic();
  if (issued) {
    await refreshSummary();
    toast(`${plural(issued, 'licencia emitida', 'licencias emitidas')} en este lote.`, 'success');
  }
  if (stopped) {
    toast(`Lote detenido: ${stopped}`, 'error');
  } else if (!issued && stats.failed) {
    toast('Ninguna fila se pudo emitir. Revisa los errores del lote.', 'error');
  }
}

function copyBatchKeys() {
  const keys = [];
  for (const row of state.batch.rows) {
    const result = state.batch.results.get(row.index);
    if (result && result.status === 'success' && result.licenseKey) keys.push(result.licenseKey);
  }
  if (!keys.length) {
    toast('Todavía no hay claves emitidas en este lote.', 'warn');
    return;
  }
  copyText(keys.join('\n'), `${plural(keys.length, 'clave copiada', 'claves copiadas')}.`);
}

/* ===== Orders and transactions ===== */

const ORDER_STATUS_FILTERS = ['all', 'pending', 'paid', 'failed', 'refunded', 'cancelled', 'expired'];

function ordersShell() {
  const filters = state.orders;
  const tab = filters.tab;
  const statusOptions = ORDER_STATUS_FILTERS.map((status) => `
    <option value="${esc(status)}" ${filters.status === status ? 'selected' : ''}>${esc(status === 'all' ? 'Todos los estados' : orderMeta(status).label)}</option>
  `).join('');
  return `
    <div class="view-head">
      <div>
        <h2>Pedidos y pagos</h2>
        <p>Órdenes de PayPal verificadas en el servidor y transacciones asociadas.</p>
      </div>
      <div class="view-actions">
        <div class="segmented">
          <button class="${tab === 'orders' ? 'is-active' : ''}" type="button" data-action="orders-tab" data-tab="orders">Pedidos</button>
          <button class="${tab === 'transactions' ? 'is-active' : ''}" type="button" data-action="orders-tab" data-tab="transactions">Transacciones</button>
        </div>
        <button class="btn btn-ghost" type="button" data-action="orders-refresh">${icon('refresh')} Actualizar</button>
      </div>
    </div>
    ${tab === 'orders' ? `
      <div class="toolbar">
        <div class="search-field">
          ${icon('search')}
          <input class="input" id="order-search" type="search" maxlength="120" value="${esc(filters.query)}" placeholder="Pedido, correo o ID de PayPal…" autocomplete="off" spellcheck="false" aria-label="Buscar pedidos">
        </div>
        <select class="select" id="order-status" aria-label="Filtrar pedidos por estado">${statusOptions}</select>
        <span class="toolbar-count" id="orders-toolbar-count">${filters.data ? plural(filters.data.total, 'pedido', 'pedidos') : 'Cargando…'}</span>
      </div>
      <div id="orders-results">${loadingBlock('Cargando pedidos…')}</div>
    ` : `
      <div class="notice" style="margin-bottom:14px">${icon('shield')}<div><strong>Transacciones verificadas</strong><p>Solo aparecen cobros y reembolsos confirmados por PayPal o registrados por el servidor.</p></div></div>
      <div id="transactions-results">${loadingBlock('Cargando transacciones…')}</div>
    `}
  `;
}

function renderOrders() {
  if (!els.content) return;
  els.content.innerHTML = ordersShell();
  if (state.orders.tab === 'transactions') loadTransactions();
  else loadOrders();
}

function orderRows(items) {
  return items.map((order) => `
    <tr class="is-clickable" data-open-order="${esc(order.id)}" tabindex="0">
      <td>
        <div class="cell-main mono">${esc(order.id)}</div>
        <span class="cell-sub mono">${esc(order.paypalOrderId || 'Sin ID de PayPal')}</span>
      </td>
      <td>
        <div class="cell-main">${esc(order.customerName || order.email || '—')}</div>
        <span class="cell-sub">${esc(order.email || 'Sin correo')}</span>
      </td>
      <td class="status-cell">${orderChip(order.status)}</td>
      <td>
        <div class="cell-main">${esc(order.planLabel || planLabel(order.plan))}</div>
        <span class="cell-sub">${esc(`${Number(order.durationMonths) || planMeta(order.plan).months} ${(Number(order.durationMonths) || planMeta(order.plan).months) === 1 ? 'mes' : 'meses'}`)}</span>
      </td>
      <td class="cell-date">${esc(fmtMoney(order.amountCents, order.currency))}</td>
      <td class="cell-date">${fmtDateTime(order.createdAt)}</td>
      <td class="cell-actions"><span class="btn-icon" aria-hidden="true">${icon('chevronRight')}</span></td>
    </tr>
  `).join('');
}

function ordersResultsHtml(data) {
  if (!data || !Array.isArray(data.items) || !data.items.length) {
    const filtered = state.orders.query || state.orders.status !== 'all';
    return `<div class="card table-card">${emptyBlock(
      'cart',
      filtered ? 'No hay pedidos con ese filtro' : 'Todavía no hay pedidos',
      filtered
        ? 'Cambia la búsqueda o el estado para ver otros pedidos.'
        : 'Los pedidos creados desde la tienda aparecerán aquí cuando PayPal los confirme.',
      filtered
        ? `<button class="btn btn-ghost btn-sm" type="button" data-action="orders-clear">${icon('x')} Limpiar filtros</button>`
        : '',
    )}</div>`;
  }
  const page = Number(data.page) || 1;
  const pages = Number(data.pages) || 1;
  return `
    <section class="card table-card">
      <div class="table-wrap">
        <table class="data-table">
          <thead><tr><th>Pedido</th><th>Cliente</th><th>Estado</th><th>Plan</th><th>Importe</th><th>Creado</th><th class="th-actions"></th></tr></thead>
          <tbody>${orderRows(data.items)}</tbody>
        </table>
      </div>
      <div class="table-foot">
        <span class="table-meta">${plural(data.total, 'pedido', 'pedidos')} · página ${fmtNum(page)} de ${fmtNum(pages)}</span>
        <div class="pagination">
          <button class="btn btn-ghost btn-xs" type="button" data-action="orders-page" data-page="${page - 1}" ${page <= 1 ? 'disabled' : ''} aria-label="Página anterior">${icon('chevronLeft')}</button>
          <span class="page-indicator">${fmtNum(page)} / ${fmtNum(pages)}</span>
          <button class="btn btn-ghost btn-xs" type="button" data-action="orders-page" data-page="${page + 1}" ${page >= pages ? 'disabled' : ''} aria-label="Página siguiente">${icon('chevronRight')}</button>
        </div>
      </div>
    </section>
  `;
}

async function loadOrders() {
  if (!state.authenticated) return;
  const filters = state.orders;
  const seq = ++filters.seq;
  filters.loading = true;
  const target = document.getElementById('orders-results');
  if (target) target.innerHTML = loadingBlock('Cargando pedidos…');
  try {
    const data = await api('admin:orders:list', {
      query: filters.query,
      status: filters.status,
      page: filters.page,
      pageSize: filters.pageSize,
    });
    if (seq !== filters.seq || state.view !== 'orders' || filters.tab !== 'orders') return;
    filters.loading = false;
    filters.data = data;
    const result = document.getElementById('orders-results');
    if (result) result.innerHTML = ordersResultsHtml(data);
    const count = document.getElementById('orders-toolbar-count');
    if (count) count.textContent = plural(data.total, 'pedido', 'pedidos');
    setConnection('online', currentServerHost());
  } catch (error) {
    if (seq !== filters.seq || state.view !== 'orders' || filters.tab !== 'orders') return;
    filters.loading = false;
    if (isNetworkError(error)) setConnection('error', 'Sin conexión');
    if (error.requiresLogin) return;
    const result = document.getElementById('orders-results');
    if (result) result.innerHTML = errorPanel(error.message, 'orders-refresh');
  }
}

function orderSearchChanged(value) {
  state.orders.query = value;
  state.orders.page = 1;
  clearTimeout(state.orders.timer);
  state.orders.timer = setTimeout(() => {
    if (state.view === 'orders' && state.orders.tab === 'orders') loadOrders();
  }, 280);
}

function setOrderStatus(status) {
  if (!ORDER_STATUS_FILTERS.includes(status)) return;
  state.orders.status = status;
  state.orders.page = 1;
  loadOrders();
}

function setOrdersTab(tab) {
  if (!['orders', 'transactions'].includes(tab) || state.orders.tab === tab) return;
  state.orders.tab = tab;
  state.orders.seq += 1;
  state.transactions.seq += 1;
  renderOrders();
}

function transactionRows(items) {
  return items.map((transaction) => `
    <tr>
      <td class="mono">${esc(transaction.id)}</td>
      <td>
        <div class="cell-main">${esc(transaction.kind === 'refund' ? 'Reembolso' : 'Pago')}</div>
        <span class="cell-sub">${esc(transaction.provider || 'paypal')}</span>
      </td>
      <td class="cell-date">${esc(fmtMoney(transaction.amountCents, transaction.currency))}</td>
      <td><span class="chip is-plain">${esc(transaction.status || '—')}</span></td>
      <td>
        <div class="cell-main mono">${esc(transaction.orderId || '—')}</div>
        <span class="cell-sub mono">${esc(transaction.licenseId || 'Sin licencia')}</span>
      </td>
      <td class="cell-date">${fmtDateTime(transaction.createdAt)}</td>
    </tr>
  `).join('');
}

function transactionsResultsHtml(data) {
  if (!data || !Array.isArray(data.items) || !data.items.length) {
    return `<div class="card table-card">${emptyBlock(
      'cart',
      'Todavía no hay transacciones',
      'Cuando PayPal confirme un pago o un reembolso, la transacción quedará registrada aquí.',
    )}</div>`;
  }
  const page = Number(data.page) || 1;
  const pages = Number(data.pages) || 1;
  return `
    <section class="card table-card">
      <div class="table-wrap">
        <table class="data-table">
          <thead><tr><th>ID</th><th>Tipo</th><th>Importe</th><th>Estado</th><th>Pedido / licencia</th><th>Fecha</th></tr></thead>
          <tbody>${transactionRows(data.items)}</tbody>
        </table>
      </div>
      <div class="table-foot">
        <span class="table-meta">${plural(data.total, 'transacción', 'transacciones')} · página ${fmtNum(page)} de ${fmtNum(pages)}</span>
        <div class="pagination">
          <button class="btn btn-ghost btn-xs" type="button" data-action="transactions-page" data-page="${page - 1}" ${page <= 1 ? 'disabled' : ''} aria-label="Página anterior">${icon('chevronLeft')}</button>
          <span class="page-indicator">${fmtNum(page)} / ${fmtNum(pages)}</span>
          <button class="btn btn-ghost btn-xs" type="button" data-action="transactions-page" data-page="${page + 1}" ${page >= pages ? 'disabled' : ''} aria-label="Página siguiente">${icon('chevronRight')}</button>
        </div>
      </div>
    </section>
  `;
}

async function loadTransactions() {
  if (!state.authenticated) return;
  const filters = state.transactions;
  const seq = ++filters.seq;
  const target = document.getElementById('transactions-results');
  if (target) target.innerHTML = loadingBlock('Cargando transacciones…');
  try {
    const data = await api('admin:transactions:list', { page: filters.page, pageSize: filters.pageSize });
    if (seq !== filters.seq || state.view !== 'orders' || state.orders.tab !== 'transactions') return;
    filters.data = data;
    const result = document.getElementById('transactions-results');
    if (result) result.innerHTML = transactionsResultsHtml(data);
    setConnection('online', currentServerHost());
  } catch (error) {
    if (seq !== filters.seq || state.view !== 'orders' || state.orders.tab !== 'transactions') return;
    if (isNetworkError(error)) setConnection('error', 'Sin conexión');
    if (error.requiresLogin) return;
    const result = document.getElementById('transactions-results');
    if (result) result.innerHTML = errorPanel(error.message, 'orders-refresh');
  }
}

function orderTransactionRows(transactions) {
  return transactions.map((transaction) => `
    <tr>
      <td class="mono">${esc(transaction.id)}</td>
      <td>${esc(transaction.kind === 'refund' ? 'Reembolso' : 'Pago')}</td>
      <td>${esc(fmtMoney(transaction.amountCents, transaction.currency))}</td>
      <td><span class="chip is-plain">${esc(transaction.status || '—')}</span></td>
      <td class="cell-date">${fmtDateTime(transaction.createdAt)}</td>
    </tr>
  `).join('');
}

function orderDetailHtml(order) {
  const transactions = Array.isArray(order.transactions) ? order.transactions : [];
  const license = order.license;
  const approval = order.approvalUrl
    ? `<div class="detail-item is-wide"><small>Enlace de aprobación</small><div class="key-row"><span class="value mono">${esc(order.approvalUrl)}</span>${copyButton(order.approvalUrl, 'Enlace de aprobación copiado.', 'Copiar enlace')}</div></div>`
    : '';
  return `
    ${modalHead('Pedido', order.id, `${orderChip(order.status)}<span class="chip is-plain">${esc(fmtMoney(order.amountCents, order.currency))}</span>`)}
    <div class="modal-body">
      ${order.failureReason ? notice('danger', 'Incidencia del pedido', order.failureReason, 'warning') : ''}
      <div class="detail-grid">
        ${detailItem('Cliente', order.customerName || '—')}
        ${detailItem('Correo', order.email || 'Sin correo')}
        ${detailItem('Pagador', order.payerEmail || '—')}
        ${detailItem('Plan', `${order.planLabel || planLabel(order.plan)} · ${Number(order.durationMonths) || planMeta(order.plan).months} ${(Number(order.durationMonths) || planMeta(order.plan).months) === 1 ? 'mes' : 'meses'}`)}
        ${detailItem('Importe', fmtMoney(order.amountCents, order.currency))}
        ${detailItem('ID de PayPal', order.paypalOrderId || '—', { mono: true, wide: true })}
        ${detailCopyItem('ID del pedido', order.id)}
        ${detailItem('Creado', fmtDateTime(order.createdAt))}
        ${detailItem('Actualizado', fmtDateTime(order.updatedAt))}
        ${detailItem('Pagado', fmtDateTime(order.paidAt, '—'))}
        ${detailItem('Reembolsado', fmtDateTime(order.refundedAt, '—'))}
        ${detailItem('Completado', fmtDateTime(order.completedAt, '—'))}
        ${approval}
      </div>

      <div class="modal-section">
        ${detailSectionTitle('Licencia vinculada')}
        ${license || order.licenseId ? `
          <div class="sub-row">
            <div class="sub-row-copy">
              <strong class="mono">${esc(license ? license.id : order.licenseId)}</strong>
              <small>${license ? `${esc(license.customerName || 'Sin cliente')} · ${esc(statusMeta(license.status).label)}${license.keyMasked ? ` · ${esc(license.keyMasked)}` : ''}` : 'Licencia no disponible en el inventario.'}</small>
            </div>
            <button class="btn btn-ghost btn-sm" type="button" data-action="order-license" data-id="${esc(license ? license.id : order.licenseId)}">Ver licencia</button>
          </div>
        ` : notice('', 'Sin licencia vinculada', 'El pedido todavía no ha generado una licencia, o el pago no se ha confirmado.', 'key')}
      </div>

      ${transactions.length ? `
        <div class="modal-section">
          ${detailSectionTitle('Transacciones')}
          <div class="table-wrap">
            <table class="data-table">
              <thead><tr><th>ID</th><th>Tipo</th><th>Importe</th><th>Estado</th><th>Fecha</th></tr></thead>
              <tbody>${orderTransactionRows(transactions)}</tbody>
            </table>
          </div>
        </div>
      ` : ''}
    </div>
    <div class="modal-actions">
      ${isAdmin() && !['paid', 'refunded'].includes(order.status)
        ? `<button class="btn btn-soft" type="button" data-action="order-sync" data-id="${esc(order.id)}">${icon('refresh')} Sincronizar con PayPal</button>`
        : ''}
      <button class="btn btn-ghost" type="button" data-close>Cerrar</button>
    </div>
  `;
}

async function openOrderDetail(id) {
  if (!id || !state.authenticated) return;
  const seq = ++state.modalSeq;
  state.modalDetail = null;
  state.modalOrder = null;
  state.modalAudit = null;
  state.modalReturn = null;
  openModal(modalLoading('Cargando el pedido…'), { className: 'is-lg', label: `Pedido ${id}` });
  try {
    const detail = await api('admin:orders:get', { id });
    if (seq !== state.modalSeq) return;
    state.modalOrder = detail;
    renderOrderDetailModal();
    setConnection('online', currentServerHost());
  } catch (error) {
    if (seq !== state.modalSeq) return;
    closeModal({ restoreFocus: false, force: true });
    if (isNetworkError(error)) setConnection('error', 'Sin conexión');
    if (!error.requiresLogin) toast(error.message, 'error');
  }
}

function renderOrderDetailModal() {
  if (!state.modalOrder) return;
  openModal(orderDetailHtml(state.modalOrder), {
    className: 'is-lg',
    label: `Pedido ${state.modalOrder.id}`,
    lastFocus: state.lastFocus,
  });
}

async function syncOrder(id, button) {
  if (!isAdmin() || state.modalBusy) return;
  state.modalBusy = true;
  setBusy(button, true, 'Consultando PayPal…');
  try {
    const detail = await api('admin:orders:sync', { id });
    state.modalBusy = false;
    state.modalOrder = detail;
    renderOrderDetailModal();
    toast(`Pedido sincronizado: ${orderMeta(detail.status).label}.`, 'success');
    await refreshSummary();
    if (state.view === 'orders') await loadOrders();
  } catch (error) {
    state.modalBusy = false;
    if (error.requiresLogin) return;
    setBusy(button, false);
    toast(error.message, 'error');
  }
}

async function openOrderLicense(id) {
  if (!id) return;
  await openLicenseDetail(id);
}

/* ===== Audit ===== */

const AUDIT_ACTIONS = {
  'admin.login': 'Inicio de sesión',
  'admin.login_failed': 'Intento de acceso fallido',
  'license.issued': 'Licencia emitida',
  'license.activated': 'Licencia activada',
  'license.revoked': 'Licencia revocada',
  'license.suspended': 'Licencia suspendida',
  'license.reactivated': 'Licencia reactivada',
  'license.activation_reset': 'Equipo liberado',
  'license.renewed': 'Licencia renovada',
  'license.email_queued': 'Correo en cola',
  'license.revealed': 'Clave consultada',
  'licenses.exported': 'Inventario exportado',
  'email.sent': 'Correo enviado',
  'email.failed': 'Error de correo',
  'order.created': 'Pedido creado',
  'order.seat_reserved': 'Asiento reservado',
  'order.pending': 'Pago pendiente',
  'order.paid': 'Pedido pagado',
  'order.synced': 'Pedido sincronizado',
  'order.capture_pending': 'Captura pendiente',
  'order.fulfillment_failed': 'Fallo de entrega',
  'order.manual_review': 'Revisión manual',
  'order.refunded': 'Pedido reembolsado',
  'order.partially_refunded': 'Reembolso parcial',
  'order.return_token_mismatch': 'Regreso de PayPal no válido',
  'webhook.processed': 'Webhook procesado',
  'payments.updated': 'PayPal actualizado',
  'payments.cleared': 'PayPal eliminado',
  'payments.tested': 'PayPal verificado',
  'payments.test_failed': 'Fallo al verificar PayPal',
};

function auditActionLabel(action) {
  if (AUDIT_ACTIONS[action]) return AUDIT_ACTIONS[action];
  return String(action || '')
    .replace(/[._]/g, ' ')
    .replace(/^./, (char) => char.toUpperCase()) || 'Evento';
}

function auditActor(row) {
  const type = row.actorType === 'admin' ? 'Administrador'
    : row.actorType === 'paypal' ? 'PayPal'
      : row.actorType === 'system' ? 'Sistema'
        : (row.actorType || 'Sistema');
  return { type, id: row.actorId || '' };
}

function auditTarget(row) {
  if (!row.targetType && !row.targetId) return '—';
  const type = row.targetType === 'license' ? 'Licencia'
    : row.targetType === 'order' ? 'Pedido'
      : row.targetType === 'webhook' ? 'Webhook'
        : row.targetType || 'Registro';
  return `${type}${row.targetId ? ` · ${row.targetId}` : ''}`;
}

function auditRows(items) {
  return items.map((row) => {
    const actor = auditActor(row);
    return `
      <tr class="is-clickable" data-open-audit="${esc(row.id)}" tabindex="0">
        <td class="cell-date">${fmtDateTime(row.createdAt)}</td>
        <td>
          <div class="cell-main">${esc(actor.type)}</div>
          <span class="cell-sub">${esc(actor.id || '—')}</span>
        </td>
        <td>
          <div class="cell-main">${esc(auditActionLabel(row.action))}</div>
          <span class="cell-sub mono">${esc(row.action)}</span>
        </td>
        <td class="cell-machine">${esc(truncate(auditTarget(row), 52))}</td>
        <td class="cell-date mono">${esc(row.ip || '—')}</td>
        <td class="cell-actions"><span class="btn-icon" aria-hidden="true">${icon('chevronRight')}</span></td>
      </tr>
    `;
  }).join('');
}

function auditResultsHtml(data) {
  if (!data || !Array.isArray(data.items) || !data.items.length) {
    return `<div class="card table-card">${emptyBlock(
      'audit',
      'Todavía no hay eventos',
      'Las emisiones, activaciones, cambios de estado, pagos y accesos administrativos quedarán registrados aquí.',
    )}</div>`;
  }
  const page = Number(data.page) || 1;
  const pages = Number(data.pages) || 1;
  return `
    <section class="card table-card">
      <div class="table-wrap">
        <table class="data-table">
          <thead><tr><th>Fecha</th><th>Actor</th><th>Acción</th><th>Objetivo</th><th>IP</th><th class="th-actions"></th></tr></thead>
          <tbody>${auditRows(data.items)}</tbody>
        </table>
      </div>
      <div class="table-foot">
        <span class="table-meta">${plural(data.total, 'evento', 'eventos')} · página ${fmtNum(page)} de ${fmtNum(pages)}</span>
        <div class="pagination">
          <button class="btn btn-ghost btn-xs" type="button" data-action="audit-page" data-page="${page - 1}" ${page <= 1 ? 'disabled' : ''} aria-label="Página anterior">${icon('chevronLeft')}</button>
          <span class="page-indicator">${fmtNum(page)} / ${fmtNum(pages)}</span>
          <button class="btn btn-ghost btn-xs" type="button" data-action="audit-page" data-page="${page + 1}" ${page >= pages ? 'disabled' : ''} aria-label="Página siguiente">${icon('chevronRight')}</button>
        </div>
      </div>
    </section>
  `;
}

function renderAudit() {
  if (!els.content) return;
  els.content.innerHTML = `
    <div class="view-head">
      <div>
        <h2>Auditoría administrativa</h2>
        <p>Registro cronológico de accesos, emisiones, acciones sensibles y eventos de pago.</p>
      </div>
      <div class="view-actions">
        <button class="btn btn-ghost" type="button" data-action="audit-refresh">${icon('refresh')} Actualizar</button>
      </div>
    </div>
    <div id="audit-results">${loadingBlock('Cargando auditoría…')}</div>
  `;
  loadAudit();
}

async function loadAudit() {
  if (!state.authenticated) return;
  const filters = state.audit;
  const seq = ++filters.seq;
  const target = document.getElementById('audit-results');
  if (target) target.innerHTML = loadingBlock('Cargando auditoría…');
  try {
    const data = await api('admin:audit:list', { page: filters.page, pageSize: filters.pageSize });
    if (seq !== filters.seq || state.view !== 'audit') return;
    filters.data = data;
    const result = document.getElementById('audit-results');
    if (result) result.innerHTML = auditResultsHtml(data);
    setConnection('online', currentServerHost());
  } catch (error) {
    if (seq !== filters.seq || state.view !== 'audit') return;
    if (isNetworkError(error)) setConnection('error', 'Sin conexión');
    if (error.requiresLogin) return;
    const result = document.getElementById('audit-results');
    if (result) result.innerHTML = errorPanel(error.message, 'audit-refresh');
  }
}

function openAuditDetail(id) {
  const data = state.audit.data;
  const row = data && Array.isArray(data.items) ? data.items.find((item) => item.id === id) : null;
  if (!row) {
    toast('El evento ya no está disponible. Actualiza la auditoría.', 'warn');
    return;
  }
  state.modalAudit = row;
  state.modalDetail = null;
  state.modalOrder = null;
  state.modalReturn = null;
  const actor = auditActor(row);
  const details = row.details ? JSON.stringify(row.details, null, 2) : '';
  openModal(`
    ${modalHead('Evento de auditoría', auditActionLabel(row.action), `<span class="chip is-plain">${esc(row.actorType || 'system')}</span>`)}
    <div class="modal-body">
      <div class="detail-grid">
        ${detailItem('Fecha', fmtDateTime(row.createdAt))}
        ${detailItem('Acción', row.action, { mono: true })}
        ${detailItem('Actor', `${actor.type}${actor.id ? ` · ${actor.id}` : ''}`)}
        ${detailItem('IP', row.ip || '—', { mono: true })}
        ${detailItem('Objetivo', auditTarget(row), { wide: true })}
        ${detailItem('ID del evento', row.id, { mono: true, wide: true })}
      </div>
      <div class="modal-section">
        <div class="section-head-inline">
          <h3>Detalles</h3>
          ${details ? copyButton(details, 'Detalles copiados.', 'Copiar detalles') : ''}
        </div>
        ${details
          ? `<pre class="license-preview audit-json">${esc(details)}</pre>`
          : '<p class="user-note">Este evento no incluye datos adicionales.</p>'}
      </div>
    </div>
    <div class="modal-actions">
      <button class="btn btn-ghost" type="button" data-close>Cerrar</button>
    </div>
  `, { className: 'is-lg', label: `Evento ${row.action}` });
}

/* ===== Tools ===== */

function toolsHtml() {
  const server = state.server || {};
  const paymentsLabel = server.paymentsEnabled ? 'Activos' : 'Inactivos';
  const emailLabel = server.emailEnabled ? 'Configurado' : 'No configurado';
  return `
    <div class="view-head">
      <div>
        <h2>Herramientas</h2>
        <p>Exportaciones firmadas, configuración visible del servidor y controles de seguridad.</p>
      </div>
      <div class="view-actions">
        <button class="btn btn-ghost" type="button" data-action="tools-refresh">${icon('refresh')} Actualizar estado</button>
      </div>
    </div>

    <div class="tools-grid">
      <section class="card tool-card">
        <div class="tool-head">
          <span class="tool-icon">${icon('download')}</span>
          <div>
            <h3>Inventario de licencias</h3>
            <p>Descarga un CSV con el historial completo o los filtros que tengas activos.</p>
          </div>
        </div>
        <p>Incluye cliente, correo, asiento, equipo, fechas, estado y motivo de revocación. La exportación queda registrada en auditoría.</p>
        <div class="tool-actions">
          <button class="btn btn-soft btn-sm" type="button" data-action="tools-export-licenses">${icon('download')} Exportar todo</button>
          <button class="btn btn-ghost btn-sm" type="button" data-action="tools-export-filtered">${icon('list')} Exportar filtros actuales</button>
        </div>
      </section>

      <section class="card tool-card">
        <div class="tool-head">
          <span class="tool-icon is-warn">${icon('shield')}</span>
          <div>
            <h3>Lista de revocaciones firmada</h3>
            <p>Archivo JSON firmado con las licencias revocadas y sus motivos.</p>
          </div>
        </div>
        <p>Los clientes pueden consultar esta lista cuando están en línea. Las licencias revocadas siguen bloqueadas aunque el cliente no tenga conexión, gracias a su estado local.</p>
        <div class="tool-actions">
          <button class="btn btn-ghost btn-sm" type="button" data-action="tools-export-revocations">${icon('download')} Guardar lista firmada</button>
        </div>
      </section>

      <section class="card tool-card is-wide">
        <div class="tool-head">
          <span class="tool-icon">${icon('server')}</span>
          <div>
            <h3>Servidor central</h3>
            <p>Datos de la instancia que atiende esta consola.</p>
          </div>
          <span class="chip ${server.paymentsEnabled ? 'is-success' : 'is-warn'}" style="margin-left:auto">Pagos ${esc(paymentsLabel.toLowerCase())}</span>
        </div>
        <dl class="tool-kv">
          <dt>Dirección</dt><dd>${esc(state.serverUrl)}</dd>
          <dt>Sitio público</dt><dd>${server.publicBaseUrl ? esc(server.publicBaseUrl) : 'No configurado'}</dd>
          <dt>Versión</dt><dd>${esc(server.version || '—')} · ${esc(server.environment || '—')}</dd>
          <dt>Clave de firma</dt><dd class="mono">${esc(server.keyId || '—')}</dd>
          <dt>PayPal</dt><dd>${esc(server.paypalMode || 'No configurado')}${isAdmin() ? ` · <button class="link-btn" type="button" data-nav-inline="payments">Configurar PayPal y precios</button>` : ''}</dd>
          <dt>Correo</dt><dd>${esc(emailLabel)}${Number(server.pendingEmails) ? ` · ${plural(server.pendingEmails, 'mensaje en cola', 'mensajes en cola')}` : ''}</dd>
          <dt>Soporte</dt><dd>${esc(server.supportEmail || 'No configurado')}</dd>
          <dt>Planes</dt><dd>${planCatalogue().map((plan) => `${plan.label}: ${plan.amountCents === null ? '—' : fmtMoney(plan.amountCents, plan.currency)} (${plan.period})`).join(' · ')}</dd>
          <dt>Límite histórico</dt><dd>${fmtNum(state.summary ? state.summary.capacity : 50000)} licencias · un equipo cada una</dd>
          ${isAdmin() && server.dataDir ? `<dt>Ruta de datos</dt><dd class="mono">${esc(server.dataDir)}</dd>` : ''}
        </dl>
        ${!server.paymentsEnabled ? notice(
          'warn',
          'PayPal no está configurado',
          'La tienda no puede crear órdenes hasta que el servidor reciba las credenciales oficiales.',
          'warning',
        ) : ''}
        ${!server.emailEnabled ? notice(
          'warn',
          'SMTP no está configurado',
          'Las licencias se emiten, pero los correos quedan en cola hasta configurar el servidor de salida.',
          'mail',
        ) : ''}
      </section>

      <section class="card tool-card">
        <div class="tool-head">
          <span class="tool-icon is-success">${icon('lock')}</span>
          <div>
            <h3>Sesión y firma</h3>
            <p>Esta consola nunca contiene la clave privada.</p>
          </div>
        </div>
        <div class="mini-steps">
          <div class="mini-step">
            <span>01</span>
            <div><strong>Token en memoria</strong><small>La sesión administrativa se pierde al cerrar la aplicación.</small></div>
          </div>
          <div class="mini-step">
            <span>02</span>
            <div><strong>Firma en el servidor</strong><small>Ed25519 y cifrado AES-256-GCM viven únicamente en el backend.</small></div>
          </div>
          <div class="mini-step">
            <span>03</span>
            <div><strong>Acciones auditadas</strong><small>Consultar una clave, revocar o exportar deja un evento con actor e IP.</small></div>
          </div>
        </div>
      </section>

      <section class="card tool-card">
        <div class="tool-head">
          <span class="tool-icon">${icon('user')}</span>
          <div>
            <h3>Tu sesión</h3>
            <p>Permisos efectivos en esta consola.</p>
          </div>
        </div>
        <dl class="tool-kv">
          <dt>Usuario</dt><dd>${esc(state.session ? state.session.username : '—')}</dd>
          <dt>Rol</dt><dd>${esc(roleLabel(state.session ? state.session.role : ''))}</dd>
          <dt>Servidor</dt><dd class="mono">${esc(state.serverUrl)}</dd>
          <dt>Expira</dt><dd>${fmtDateTime(state.session ? state.session.expiresAt : null)}</dd>
          <dt>Versión de la consola</dt><dd>v${esc(state.appVersion)}</dd>
        </dl>
        <p class="user-note" style="margin-top:14px">${isAdmin()
          ? 'Puedes emitir, suspender, revocar y sincronizar pedidos.'
          : 'El rol de solo lectura puede consultar licencias, pedidos y auditoría; no puede emitir ni modificar licencias.'}</p>
      </section>
    </div>
  `;
}

async function renderTools() {
  if (!els.content) return;
  const seq = ++state.viewSeq;
  els.content.innerHTML = loadingView('Consultando el servidor…');
  try {
    const data = await api('admin:overview');
    if (!state.authenticated || state.view !== 'tools' || seq !== state.viewSeq) return;
    state.summary = data.summary;
    state.server = data.server;
    updateChrome();
    setConnection('online', currentServerHost());
    if (els.content) els.content.innerHTML = toolsHtml();
  } catch (error) {
    if (!state.authenticated || state.view !== 'tools' || seq !== state.viewSeq) return;
    if (isNetworkError(error)) setConnection('error', 'Sin conexión');
    if (error.requiresLogin) return;
    if (els.content) els.content.innerHTML = errorPanel(error.message, 'tools-refresh');
  }
}

async function exportLicensesCsv(button, filters = state.licenses) {
  if (state.exporting) return;
  state.exporting = true;
  setBusy(button, true, 'Exportando…');
  try {
    const result = await api('admin:licenses:export-csv', {
      status: filters.status || 'all',
      query: filters.query || '',
    });
    if (!result.canceled) toast(`Inventario guardado en ${result.path}`, 'success');
  } catch (error) {
    if (!error.requiresLogin) toast(error.message, 'error');
  } finally {
    state.exporting = false;
    setBusy(button, false);
  }
}

async function exportRevocations(button) {
  if (state.exporting) return;
  state.exporting = true;
  setBusy(button, true, 'Preparando…');
  try {
    const result = await api('admin:revocations:export');
    if (!result.canceled) toast(`Lista firmada guardada en ${result.path}`, 'success');
  } catch (error) {
    if (!error.requiresLogin) toast(error.message, 'error');
  } finally {
    state.exporting = false;
    setBusy(button, false);
  }
}

/* ===== Payments ===== */

function paymentsSourceLabel(source) {
  if (source === 'db') return 'Guardado en el servidor';
  if (source === 'env') return 'Variables de entorno';
  return 'Sin configurar';
}

function paymentsStatusText(data) {
  if (data.local) return 'Servidor local';
  if (data.enabled) return 'Operativo';
  if (data.configured) return 'Incompleto';
  return 'Sin configurar';
}

function paymentsPlanRows(plans) {
  const list = Array.isArray(plans) && plans.length ? plans : planCatalogue();
  return list.map((plan) => {
    const months = Number(plan.months) || planMeta(plan.code).months;
    const label = plan.label || planLabel(plan.code);
    return detailItem(
      `${label} · ${months} ${months === 1 ? 'mes' : 'meses'}`,
      `${fmtMoney(plan.amountCents, plan.currency || 'USD')} · pago único`,
    );
  }).join('');
}

function paymentPriceInput(plan, amountCents) {
  return `
    <div class="field">
      <label class="field-label" for="payments-price-${esc(plan.code)}">${esc(plan.label)} · ${esc(plan.period)} (USD) *</label>
      <input class="input is-mono" id="payments-price-${esc(plan.code)}" type="text" inputmode="decimal" maxlength="12" value="${esc(amountCents === null ? '' : (Number(amountCents) / 100).toFixed(2))}" placeholder="0.00">
    </div>
  `;
}

function paymentsFormHtml(data) {
  const plans = planCatalogue();
  const current = {};
  for (const plan of Array.isArray(data.plans) ? data.plans : []) {
    if (plan && PLAN_META[plan.code]) current[plan.code] = plan.amountCents;
  }
  return `
    <section class="card" style="margin-top:16px">
      <div class="card-head">
        <div><h3>Credenciales de PayPal</h3><p>El servidor cifra el Client Secret y nunca lo devuelve a esta consola.</p></div>
        <span class="chip ${data.enabled ? 'is-success' : 'is-warn'}">${esc(paymentsStatusText(data))}</span>
      </div>
      <div class="card-pad">
        <form id="payments-form" novalidate>
          <div class="form-grid">
            <div class="field">
              <label class="field-label" for="payments-mode">Modo *</label>
              <select class="select" id="payments-mode">
                <option value="sandbox" ${data.mode !== 'live' ? 'selected' : ''}>Sandbox · pruebas</option>
                <option value="live" ${data.mode === 'live' ? 'selected' : ''}>Live · pagos reales</option>
              </select>
              <span class="field-hint">Live exige una URL pública HTTPS y un webhook accesible.</span>
            </div>
            <div class="field">
              <label class="field-label" for="payments-client-id">Client ID *</label>
              <input class="input is-mono" id="payments-client-id" type="text" maxlength="200" autocomplete="off" spellcheck="false" value="${esc(data.clientId || '')}" placeholder="Client ID de la app de PayPal">
            </div>
          </div>
          <div class="form-grid">
            <div class="field">
              <label class="field-label" for="payments-secret">Client Secret ${data.secretConfigured ? '(sin cambios)' : '*'}</label>
              <input class="input is-mono" id="payments-secret" type="password" maxlength="200" autocomplete="new-password" placeholder="${data.secretConfigured ? 'Déjalo vacío para conservar el secreto actual' : 'Client Secret de PayPal'}">
              <span class="field-hint">${data.secretConfigured ? `Secreto ${esc(paymentsSourceLabel(data.secretSource).toLowerCase())}. Escribe uno nuevo solo si lo rotas.` : 'Obligatorio la primera vez. Se guarda cifrado con AES-256-GCM.'}</span>
            </div>
            <div class="field">
              <label class="field-label" for="payments-webhook-id">ID del webhook *</label>
              <input class="input is-mono" id="payments-webhook-id" type="text" maxlength="100" autocomplete="off" spellcheck="false" value="${esc(data.webhookId || '')}" placeholder="ID del webhook de PayPal">
              <span class="field-hint">El servidor lo usa para verificar la firma de cada notificación.</span>
            </div>
          </div>

          <div class="form-section">
            <h3>Precios de venta</h3>
            <p>Cada plan es un pago único. El plan mensual no se renueva automáticamente.</p>
            <div class="form-grid payment-prices">
              ${plans.map((plan) => paymentPriceInput(plan, current[plan.code] === undefined ? null : current[plan.code])).join('')}
            </div>
          </div>

          <div class="form-error" id="payments-error" role="alert" hidden></div>

          <div class="form-actions">
            <button class="btn btn-danger btn-sm" type="button" data-action="payments-clear">${icon('trash')} Quitar configuración</button>
            <button class="btn btn-ghost" type="button" data-action="payments-test">${icon('play')} Probar credenciales</button>
            <button class="btn btn-primary" id="payments-save" type="submit">${icon('save')} Guardar configuración</button>
          </div>
        </form>
      </div>
    </section>
    <p class="user-note" style="margin-top:12px">Los cambios de precio se aplican a los nuevos pedidos de la tienda. Las licencias ya emitidas conservan su vencimiento.</p>
  `;
}

function paymentsReadOnlyHtml(data) {
  return `
    <section class="card" style="margin-top:16px">
      <div class="card-pad">
        ${notice(
          '',
          'Configuración de solo lectura',
          data.local
            ? 'El servidor local no procesa pagos. Configura PayPal en el servidor central para habilitar la tienda.'
            : 'Tu rol no permite modificar las credenciales de PayPal. Puedes consultar el estado y los precios.',
          'lock',
        )}
      </div>
    </section>
  `;
}

function paymentsHtml() {
  const data = state.payments.data || {};
  const webhookUrl = data.webhookUrl
    || (data.publicBaseUrl ? `${data.publicBaseUrl}${data.webhookPath || '/api/paypal/webhook'}` : '');
  const editable = isAdmin() && !data.local && data.editable !== false;
  const missing = Array.isArray(data.missing) ? data.missing : [];
  const missingText = {
    publicBaseUrl: 'URL pública del servidor',
    clientId: 'Client ID',
    clientSecret: 'Client Secret',
    webhookId: 'ID del webhook',
  };
  return `
    <div class="view-head">
      <div>
        <h2>PayPal y precios</h2>
        <p>Configura la cuenta que recibe los pagos. La licencia se emite solo tras verificar la captura en el servidor.</p>
      </div>
      <div class="view-actions">
        <button class="btn btn-ghost" type="button" data-action="payments-refresh">${icon('refresh')} Actualizar</button>
      </div>
    </div>

    ${data.local ? notice('warn', 'Servidor local sin pagos', data.message || 'El servidor local no procesa pagos. Usa el servidor central para vender licencias.', 'server') : ''}
    ${!data.local && missing.length ? notice(
      'warn',
      'Configuración incompleta',
      `Falta: ${missing.map((key) => missingText[key] || key).join(', ')}. La tienda no puede crear órdenes hasta completarla.`,
      'warning',
    ) : ''}
    ${!isAdmin() ? `<div class="read-only-banner">${notice('', 'Sesión de solo lectura', 'Puedes consultar la pasarela y los precios. Solo un administrador puede modificarlos.', 'lock')}</div>` : ''}

    <div class="stats">
      ${statCard(data.enabled ? 'success' : 'warn', 'payments', 'Pasarela', paymentsStatusText(data), data.enabled ? 'Cobros verificados en el servidor' : 'La tienda no puede cobrar')}
      ${statCard('accent', 'server', 'Modo', data.mode === 'live' ? 'Live' : 'Sandbox', data.mode === 'live' ? 'Pagos reales' : 'Pagos de prueba')}
      ${statCard('', 'key', 'Client ID', data.clientId ? truncate(data.clientId, 16) : 'No configurado', paymentsSourceLabel(data.source))}
      ${statCard('', 'lock', 'Client Secret', data.secretConfigured ? 'Configurado' : 'No configurado', paymentsSourceLabel(data.secretSource))}
    </div>

    <div class="dash-grid">
      <section class="card">
        <div class="card-head">
          <div><h3>Precios por plan</h3><p>Importes que PayPal cobrará en la tienda</p></div>
          <span class="chip is-plain">${esc(paymentsSourceLabel(data.pricesSource))}</span>
        </div>
        <div class="card-pad">
          <div class="detail-grid">${paymentsPlanRows(data.plans)}</div>
        </div>
      </section>

      <section class="card">
        <div class="card-head">
          <div><h3>Webhook de pagos</h3><p>Notificaciones firmadas de PayPal</p></div>
          <span class="chip ${webhookUrl ? 'is-success' : 'is-warn'}">${webhookUrl ? 'URL disponible' : 'Sin URL pública'}</span>
        </div>
        <div class="card-pad">
          ${webhookUrl
            ? `<div class="key-row"><code class="key-box">${esc(webhookUrl)}</code>${copyButton(webhookUrl, 'URL del webhook copiada.', 'Copiar URL del webhook')}</div>
               <p class="detail-note">Registra esta URL en PayPal para los eventos de captura, reembolso y disputa.</p>`
            : notice('warn', 'URL pública no configurada', 'El servidor necesita publicBaseUrl con HTTPS para recibir webhooks. Sin webhook, los pagos no se confirman automáticamente.', 'warning')}
          <dl class="data-list" style="margin-top:14px">
            <div><dt>Webhook ID</dt><dd class="mono">${esc(data.webhookId || 'No configurado')}</dd></div>
            <div><dt>Ruta</dt><dd class="mono">${esc(data.webhookPath || '/api/paypal/webhook')}</dd></div>
            <div><dt>Última actualización</dt><dd>${fmtDateTime(data.updatedAt, 'Sin cambios guardados')}</dd></div>
            <div><dt>Entorno</dt><dd>${esc(data.environment || '—')}</dd></div>
          </dl>
        </div>
      </section>
    </div>

    ${editable ? paymentsFormHtml(data) : paymentsReadOnlyHtml(data)}
  `;
}

function renderPayments() {
  if (!els.content) return;
  els.content.innerHTML = `<div id="payments-results">${loadingBlock('Cargando la configuración de PayPal…')}</div>`;
  loadPayments();
}

async function loadPayments() {
  if (!state.authenticated) return;
  const seq = ++state.payments.seq;
  state.payments.loading = true;
  const target = document.getElementById('payments-results');
  if (target) target.innerHTML = loadingBlock('Cargando la configuración de PayPal…');
  try {
    const data = await api('admin:payments:get');
    if (seq !== state.payments.seq || state.view !== 'payments') return;
    state.payments.loading = false;
    state.payments.error = '';
    state.payments.data = data;
    const result = document.getElementById('payments-results');
    if (result) result.innerHTML = paymentsHtml();
    setConnection('online', currentServerHost());
  } catch (error) {
    if (seq !== state.payments.seq || state.view !== 'payments') return;
    state.payments.loading = false;
    state.payments.error = error.message;
    if (isNetworkError(error)) setConnection('error', 'Sin conexión');
    if (error.requiresLogin) return;
    const result = document.getElementById('payments-results');
    if (result) result.innerHTML = errorPanel(error.message, 'payments-refresh');
  }
}

function paymentsError(message = '') {
  const box = document.getElementById('payments-error');
  if (!box) {
    if (message) toast(message, 'error');
    return;
  }
  box.textContent = String(message || '');
  box.hidden = !message;
}

function readPaymentsForm() {
  const data = state.payments.data || {};
  const modeField = document.getElementById('payments-mode');
  const clientField = document.getElementById('payments-client-id');
  const secretField = document.getElementById('payments-secret');
  const webhookField = document.getElementById('payments-webhook-id');
  const mode = modeField ? modeField.value : 'sandbox';
  const clientId = clientField ? clientField.value.trim() : '';
  const clientSecret = secretField ? secretField.value.trim() : '';
  const webhookId = webhookField ? webhookField.value.trim() : '';

  if (!['sandbox', 'live'].includes(mode)) return { error: 'Selecciona el modo de PayPal.' };
  if (!clientId) return { error: 'Escribe el Client ID de PayPal.' };
  if (!/^[A-Za-z0-9._-]{8,200}$/.test(clientId)) return { error: 'El Client ID de PayPal no tiene un formato válido.' };
  if (!webhookId) return { error: 'Escribe el ID del webhook de PayPal.' };
  if (!/^[A-Za-z0-9_-]{6,100}$/.test(webhookId)) return { error: 'El ID del webhook no tiene un formato válido.' };
  if (!clientSecret && !data.secretConfigured) return { error: 'Escribe el Client Secret de PayPal.' };
  if (clientSecret && !/^[\x21-\x7E]{8,200}$/.test(clientSecret)) {
    return { error: 'El Client Secret de PayPal no tiene un formato válido.' };
  }

  const prices = {};
  for (const code of PLAN_ORDER) {
    const field = document.getElementById(`payments-price-${code}`);
    const raw = field ? field.value.trim().replace(',', '.') : '';
    if (!/^\d+(?:\.\d{1,2})?$/.test(raw)) {
      return { error: `Indica un precio válido para el plan ${planLabel(code)}.` };
    }
    const cents = Math.round(Number(raw) * 100);
    if (!Number.isInteger(cents) || cents < 50 || cents > 10_000_000) {
      return { error: `El precio ${planLabel(code)} debe estar entre 0,50 y 100.000 USD.` };
    }
    prices[code] = cents;
  }

  return { values: { mode, clientId, clientSecret, webhookId, prices } };
}

async function handlePaymentsSubmit(event) {
  event.preventDefault();
  if (!isAdmin() || state.payments.busy) return;
  paymentsError('');
  const parsed = readPaymentsForm();
  if (parsed.error) {
    paymentsError(parsed.error);
    return;
  }
  const save = document.getElementById('payments-save');
  state.payments.busy = true;
  setBusy(save, true, 'Guardando…');
  try {
    const data = await api('admin:payments:save', parsed.values);
    state.payments.data = data;
    state.payments.busy = false;
    await refreshSummary();
    toast('PayPal y los precios se guardaron en el servidor.', 'success');
    if (state.view === 'payments' && els.content) els.content.innerHTML = paymentsHtml();
  } catch (error) {
    state.payments.busy = false;
    setBusy(save, false);
    if (!error.requiresLogin) paymentsError(error.message);
  }
}

async function testPayments(button) {
  if (!isAdmin() || state.payments.busy) return;
  paymentsError('');
  const parsed = readPaymentsForm();
  if (parsed.error) {
    paymentsError(parsed.error);
    return;
  }
  state.payments.busy = true;
  setBusy(button, true, 'Consultando PayPal…');
  try {
    const result = await api('admin:payments:test', parsed.values);
    toast(result.message || 'PayPal aceptó las credenciales.', 'success');
  } catch (error) {
    if (!error.requiresLogin) paymentsError(error.message);
  } finally {
    state.payments.busy = false;
    setBusy(button, false);
  }
}

function confirmClearPayments() {
  if (!isAdmin() || state.payments.busy) return;
  openModal(`
    ${modalHead('Quitar configuración', 'PayPal y precios')}
    <div class="modal-body">
      ${notice(
        'danger',
        'Se eliminarán las credenciales guardadas',
        'La tienda dejará de crear órdenes hasta que vuelvas a configurar PayPal. Las licencias ya emitidas siguen vigentes y los pedidos existentes se conservan.',
        'warning',
      )}
    </div>
    <div class="modal-actions">
      <button class="btn btn-ghost" type="button" data-close>Cancelar</button>
      <button class="btn btn-danger" id="payments-clear-confirm" type="button">${icon('trash')} Quitar configuración</button>
    </div>
  `, { className: 'is-sm', label: 'Quitar configuración de PayPal' });
  const confirm = document.getElementById('payments-clear-confirm');
  if (confirm) confirm.addEventListener('click', () => clearPayments(confirm));
}

async function clearPayments(button) {
  if (!isAdmin() || state.payments.busy) return;
  state.payments.busy = true;
  setBusy(button, true, 'Quitando…');
  try {
    const data = await api('admin:payments:clear');
    state.payments.busy = false;
    state.payments.data = data;
    closeModal({ force: true, restoreFocus: false });
    await refreshSummary();
    toast('Configuración de PayPal eliminada.', 'success');
    if (state.view === 'payments' && els.content) els.content.innerHTML = paymentsHtml();
  } catch (error) {
    state.payments.busy = false;
    setBusy(button, false);
    if (!error.requiresLogin) toast(error.message, 'error');
  }
}

/* ===== Events ===== */

function togglePasswordVisibility() {
  if (!els.loginPassword || !els.togglePassword) return;
  const visible = els.loginPassword.type === 'text';
  els.loginPassword.type = visible ? 'password' : 'text';
  els.togglePassword.setAttribute('aria-label', visible ? 'Mostrar contraseña' : 'Ocultar contraseña');
  els.togglePassword.title = visible ? 'Mostrar contraseña' : 'Ocultar contraseña';
  els.loginPassword.focus();
}

function trapModalFocus(event) {
  const modal = els.modalRoot ? els.modalRoot.querySelector('.modal') : null;
  if (!modal) return;
  const focusable = Array.from(modal.querySelectorAll(
    'a[href], button:not([disabled]), input:not([disabled]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])',
  )).filter((element) => element.offsetParent !== null);
  if (!focusable.length) {
    event.preventDefault();
    return;
  }
  const first = focusable[0];
  const last = focusable[focusable.length - 1];
  const active = document.activeElement;
  if (event.shiftKey && (active === first || !modal.contains(active))) {
    event.preventDefault();
    last.focus();
  } else if (!event.shiftKey && (active === last || !modal.contains(active))) {
    event.preventDefault();
    first.focus();
  }
}

async function handleAction(name, element) {
  const id = element.dataset.id || '';
  switch (name) {
    case 'dashboard-refresh':
      await renderDashboard();
      break;
    case 'licenses-export':
      await exportLicensesCsv(element, state.view === 'licenses' ? state.licenses : { status: 'all', query: '' });
      break;
    case 'licenses-retry':
      await loadLicenses();
      break;
    case 'licenses-status':
      setLicenseStatus(element.dataset.status);
      break;
    case 'licenses-page': {
      const page = Number(element.dataset.page);
      if (!Number.isFinite(page) || page < 1) return;
      state.licenses.page = page;
      await loadLicenses();
      break;
    }
    case 'licenses-clear':
      clearLicenseFilters();
      break;
    case 'license-open':
      await openLicenseDetail(id);
      break;
    case 'license-renew':
    case 'license-revoke':
    case 'license-suspend':
    case 'license-reactivate':
    case 'license-reset':
      openLicenseAction(
        name === 'license-renew' ? 'renew'
          : name === 'license-revoke' ? 'revoke'
            : name === 'license-suspend' ? 'suspend'
              : name === 'license-reactivate' ? 'reactivate' : 'reset-activation',
        id,
      );
      break;
    case 'license-resend':
      await resendLicenseEmail(id);
      break;
    case 'license-copy-envelope': {
      const envelope = state.modalDetail && state.modalDetail.envelope
        ? state.modalDetail.envelope
        : (state.lastIssued && state.lastIssued.envelope ? state.lastIssued.envelope : null);
      if (!envelope) {
        toast('La licencia todavía no tiene un archivo firmado.', 'warn');
        break;
      }
      await copyText(JSON.stringify(envelope, null, 2), 'Archivo de licencia copiado.');
      break;
    }
    case 'license-save-envelope':
      await saveEnvelope(id);
      break;
    case 'issue-another':
      closeModal({ force: true, restoreFocus: false });
      setView('issue');
      break;
    case 'issue-view-detail':
      await openIssueDetail(id);
      break;
    case 'batch-parse':
      runBatchParse();
      break;
    case 'batch-example':
      useBatchExample();
      break;
    case 'batch-clear':
      clearBatch();
      break;
    case 'batch-start':
      await startBatch();
      break;
    case 'batch-copy-keys':
      copyBatchKeys();
      break;
    case 'orders-tab':
      setOrdersTab(element.dataset.tab);
      break;
    case 'orders-refresh':
    case 'orders-retry':
      if (state.orders.tab === 'transactions') await loadTransactions();
      else await loadOrders();
      break;
    case 'orders-page': {
      const page = Number(element.dataset.page);
      if (!Number.isFinite(page) || page < 1) return;
      state.orders.page = page;
      await loadOrders();
      break;
    }
    case 'orders-clear':
      state.orders.query = '';
      state.orders.status = 'all';
      state.orders.page = 1;
      renderOrders();
      break;
    case 'order-license':
      await openOrderLicense(id);
      break;
    case 'order-sync':
      await syncOrder(id, element);
      break;
    case 'transactions-page': {
      const page = Number(element.dataset.page);
      if (!Number.isFinite(page) || page < 1) return;
      state.transactions.page = page;
      await loadTransactions();
      break;
    }
    case 'audit-refresh':
      await loadAudit();
      break;
    case 'audit-page': {
      const page = Number(element.dataset.page);
      if (!Number.isFinite(page) || page < 1) return;
      state.audit.page = page;
      await loadAudit();
      break;
    }
    case 'payments-refresh':
      await loadPayments();
      break;
    case 'payments-test':
      await testPayments(element);
      break;
    case 'payments-clear':
      confirmClearPayments();
      break;
    case 'tools-refresh':
      await renderTools();
      break;
    case 'tools-export-licenses':
      await exportLicensesCsv(element, { status: 'all', query: '' });
      break;
    case 'tools-export-filtered':
      await exportLicensesCsv(element, state.licenses);
      break;
    case 'tools-export-revocations':
      await exportRevocations(element);
      break;
    default:
      break;
  }
}

function bindEvents() {
  document.addEventListener('click', async (event) => {
    const target = event.target;
    if (!(target instanceof Element)) return;

    const close = target.closest('[data-close]');
    if (close) {
      event.preventDefault();
      closeModal();
      return;
    }

    const copy = target.closest('[data-copy]');
    if (copy) {
      event.preventDefault();
      if (!copy.disabled) {
        await copyText(copy.dataset.copy || '', copy.dataset.copyMessage || 'Copiado al portapapeles.');
      }
      return;
    }

    const inlineNav = target.closest('[data-nav-inline]');
    if (inlineNav) {
      event.preventDefault();
      setView(inlineNav.dataset.navInline);
      return;
    }

    const action = target.closest('[data-action]');
    if (action) {
      if (action.disabled) return;
      event.preventDefault();
      try {
        await handleAction(action.dataset.action, action);
      } catch (error) {
        if (!error || !error.requiresLogin) {
          toast(error && error.message ? error.message : 'No se pudo completar la acción.', 'error');
        }
      }
      return;
    }

    if (target.closest('button, a, input, select, textarea, label')) return;

    const licenseRow = target.closest('[data-open-license]');
    if (licenseRow) {
      await openLicenseDetail(licenseRow.dataset.openLicense);
      return;
    }
    const orderRow = target.closest('[data-open-order]');
    if (orderRow) {
      await openOrderDetail(orderRow.dataset.openOrder);
      return;
    }
    const auditRow = target.closest('[data-open-audit]');
    if (auditRow) {
      openAuditDetail(auditRow.dataset.openAudit);
    }
  });

  document.addEventListener('submit', async (event) => {
    const form = event.target;
    if (!(form instanceof HTMLFormElement)) return;
    if (form.id === 'login-form') {
      await handleLogin(event);
      return;
    }
    if (form.id === 'issue-form') {
      await handleIssueSubmit(event);
      return;
    }
    if (form.id === 'license-action-form') {
      event.preventDefault();
      const submit = form.querySelector('button[type="submit"]');
      await submitLicenseAction(form.dataset.operation, form.dataset.id, submit);
      return;
    }
    if (form.id === 'payments-form') {
      await handlePaymentsSubmit(event);
    }
  });

  document.addEventListener('input', (event) => {
    const target = event.target;
    if (!(target instanceof HTMLElement)) return;
    if (target.id === 'license-search') {
      licenseSearchChanged(target.value);
      return;
    }
    if (target.id === 'order-search') {
      orderSearchChanged(target.value);
      return;
    }
    if (target.id === 'batch-input') {
      scheduleBatchParse();
      return;
    }
    if (target.id === 'issue-machine') {
      formatMachineInput(target);
      return;
    }
    if (target.id === 'login-server') {
      setLoginError('');
      updateLoginNote();
      return;
    }
    if (target.id === 'login-user' || target.id === 'login-password') {
      setLoginError('');
    }
  });

  document.addEventListener('change', async (event) => {
    const target = event.target;
    if (!(target instanceof HTMLElement)) return;
    if (target.id === 'order-status') {
      setOrderStatus(target.value);
      return;
    }
    if (target.id === 'batch-plan') {
      setBatchPlan(target.value);
      return;
    }
    if (target.id === 'issue-plan') {
      refreshIssuePlan();
      return;
    }
    if (target.id === 'batch-file' && target instanceof HTMLInputElement) {
      const file = target.files && target.files[0];
      target.value = '';
      if (file) await loadBatchFile(file);
    }
  });

  document.addEventListener('keydown', (event) => {
    if (event.key === 'Escape' && els.modalRoot && els.modalRoot.firstElementChild) {
      event.preventDefault();
      closeModal();
      return;
    }
    if (event.key === 'Tab' && els.modalRoot && els.modalRoot.firstElementChild) {
      trapModalFocus(event);
      return;
    }
    if ((event.key === 'Enter' || event.key === ' ') && event.target instanceof Element) {
      const row = event.target.closest('[data-open-license], [data-open-order], [data-open-audit]');
      if (row && !event.target.closest('button, a, input, select, textarea')) {
        event.preventDefault();
        if (row.dataset.openLicense) openLicenseDetail(row.dataset.openLicense);
        else if (row.dataset.openOrder) openOrderDetail(row.dataset.openOrder);
        else openAuditDetail(row.dataset.openAudit);
      }
    }
  });

  document.querySelectorAll('.nav-item[data-nav]').forEach((button) => {
    button.addEventListener('click', () => setView(button.dataset.nav));
  });
  if (els.topbarIssue) {
    els.topbarIssue.addEventListener('click', () => setView('issue'));
  }
  if (els.logoutButton) {
    els.logoutButton.addEventListener('click', logout);
  }
  if (els.testServer) {
    els.testServer.addEventListener('click', testServerConnection);
  }
  if (els.togglePassword) {
    els.togglePassword.addEventListener('click', togglePasswordVisibility);
  }

  window.addEventListener('offline', () => setConnection('error', 'Sin conexión'));
  window.addEventListener('online', () => {
    if (state.authenticated && state.server) setConnection('online', currentServerHost());
  });
}

/* ===== Boot ===== */

async function boot() {
  bindEvents();
  updateChrome();
  if (!bridge || typeof bridge.action !== 'function') {
    showLogin('No se pudo cargar el puente de la aplicación. Reinstala PerfilLab Licencias.');
    setLoginNote('El proceso de administración no está disponible', 'error');
    return;
  }
  try {
    const info = await run('server:info');
    fillLogin(info);
    if (info.authenticated) {
      showAdmin(info);
    } else {
      showLogin(info.expired ? 'La sesión administrativa anterior expiró. Vuelve a iniciar sesión.' : (info.configWarning || ''));
    }
  } catch (error) {
    showLogin(error.message || 'No se pudo iniciar la consola de administración.');
    setConnection('error', 'Sin conexión');
  }
}

boot();

