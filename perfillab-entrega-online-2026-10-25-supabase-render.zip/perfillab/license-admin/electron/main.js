'use strict';

const fs = require('node:fs');
const path = require('node:path');
const {
  app,
  BrowserWindow,
  dialog,
  ipcMain,
  clipboard,
  Menu,
  session,
} = require('electron');

const {
  AdminApiClient,
  AdminApiError,
  DEFAULT_SERVER_URL,
  normalizeServerUrl,
} = require('./server-client');

app.setName('PerfilLab Licencias');

const DEFAULT_DATA_DIR = path.join(app.getPath('appData'), 'PerfilLab Licencias');
const DATA_DIR = process.env.PERFILLAB_ADMIN_DATA_DIR
  ? path.resolve(process.env.PERFILLAB_ADMIN_DATA_DIR)
  : DEFAULT_DATA_DIR;
app.setPath('userData', DATA_DIR);
fs.mkdirSync(DATA_DIR, { recursive: true });

const CONFIG_FILE = path.join(DATA_DIR, 'admin-config.json');
const MAX_CONFIG_BYTES = 64 * 1024;
const ASSETS = path.join(__dirname, '..', 'assets');
const RENDERER = path.join(__dirname, '..', 'renderer', 'index.html');
const LICENSE_ID_RE = /^[A-Za-z0-9._-]{3,100}$/;
const ORDER_ID_RE = /^[A-Za-z0-9-]{8,100}$/;
const LICENSE_STATUSES = new Set(['all', 'pending', 'active', 'expired', 'revoked', 'suspended']);
const ORDER_STATUSES = new Set(['all', 'created', 'pending', 'paid', 'failed', 'cancelled', 'refunded', 'expired']);
const LICENSE_ACTIONS = new Set(['revoke', 'suspend', 'reactivate', 'reset-activation', 'resend-email', 'renew']);
const PLAN_CODES = new Set(['monthly', 'semiannual', 'annual']);
const PAYMENT_MODES = new Set(['sandbox', 'live']);
const MIN_PRICE_CENTS = 50;
const MAX_PRICE_CENTS = 10_000_000;

let mainWindow = null;
let api = null;
let configured = loadConfig();

class AdminError extends Error {
  constructor(message, status = 400, code = 'admin_error', extra = {}) {
    super(message);
    this.name = 'AdminError';
    this.status = status;
    this.code = code;
    this.requiresLogin = Boolean(extra.requiresLogin);
  }
}

function loadConfig() {
  let serverUrl = process.env.PERFILLAB_LICENSE_SERVER || DEFAULT_SERVER_URL;
  let warning = null;
  if (fs.existsSync(CONFIG_FILE)) {
    try {
      const stat = fs.statSync(CONFIG_FILE);
      if (stat.size > MAX_CONFIG_BYTES) throw new Error('archivo demasiado grande');
      const raw = JSON.parse(fs.readFileSync(CONFIG_FILE, 'utf8'));
      if (raw && typeof raw.serverUrl === 'string' && raw.serverUrl.trim()) {
        serverUrl = raw.serverUrl;
      }
    } catch {
      warning = 'La configuración local del servidor no se pudo leer. Se usó la dirección predeterminada.';
    }
  }
  try {
    serverUrl = normalizeServerUrl(serverUrl);
  } catch {
    warning = 'La dirección guardada del servidor no es válida. Se usó la dirección predeterminada.';
    serverUrl = DEFAULT_SERVER_URL;
  }
  return { serverUrl, warning };
}

function persistConfig(serverUrl) {
  const temp = `${CONFIG_FILE}.tmp`;
  try {
    fs.writeFileSync(temp, `${JSON.stringify({ version: 1, serverUrl }, null, 2)}\n`, {
      encoding: 'utf8',
      mode: 0o600,
    });
    fs.renameSync(temp, CONFIG_FILE);
  } catch (error) {
    throw new AdminError(`No se pudo guardar la configuración local: ${error.message}`, 500, 'config_save_failed');
  }
}

function client() {
  if (!api || api.serverUrl !== configured.serverUrl) {
    api = new AdminApiClient({ serverUrl: configured.serverUrl });
  }
  return api;
}

function sessionInfo() {
  const active = client();
  if (!active.hasSession) {
    return {
      authenticated: false,
      user: null,
      expiresAt: null,
      serverUrl: configured.serverUrl,
      defaultServerUrl: DEFAULT_SERVER_URL,
      configWarning: configured.warning,
      appVersion: app.getVersion(),
      platform: process.platform,
    };
  }
  if (active.sessionLocallyExpired()) {
    active.clearSession();
    return {
      authenticated: false,
      user: null,
      expiresAt: null,
      serverUrl: configured.serverUrl,
      defaultServerUrl: DEFAULT_SERVER_URL,
      configWarning: configured.warning,
      appVersion: app.getVersion(),
      platform: process.platform,
      expired: true,
    };
  }
  return {
    authenticated: true,
    user: active.user,
    expiresAt: active.expiresAt,
    serverUrl: configured.serverUrl,
    defaultServerUrl: DEFAULT_SERVER_URL,
    configWarning: configured.warning,
    appVersion: app.getVersion(),
    platform: process.platform,
  };
}

function payloadObject(payload) {
  if (!payload || typeof payload !== 'object' || Array.isArray(payload)) {
    throw new AdminError('Datos de acción no válidos.', 400, 'invalid_payload');
  }
  return payload;
}

function text(value, max, label = 'El campo') {
  if (value === undefined || value === null) return '';
  if (typeof value !== 'string') throw new AdminError('Uno de los campos no es válido.', 400, 'invalid_field');
  const clean = value.trim();
  if (clean.length > max) throw new AdminError(`${label} supera el máximo de ${max} caracteres.`, 400, 'invalid_field');
  return clean;
}

function identifier(value) {
  const id = text(value, 100, 'El identificador');
  if (!LICENSE_ID_RE.test(id)) throw new AdminError('El identificador de licencia no es válido.', 400, 'invalid_id');
  return id;
}

function orderIdentifier(value) {
  const id = text(value, 100, 'El identificador de orden');
  if (!ORDER_ID_RE.test(id)) throw new AdminError('El identificador de orden no es válido.', 400, 'invalid_id');
  return id;
}

function integer(value, fallback, min, max) {
  const parsed = Number.parseInt(value, 10);
  if (!Number.isFinite(parsed)) return fallback;
  return Math.min(Math.max(parsed, min), max);
}

function statusFilter(value, allowed) {
  const clean = String(value || 'all');
  return allowed.has(clean) ? clean : 'all';
}

function planCode(value, { required = false } = {}) {
  const plan = text(value, 20, 'El plan').toLowerCase();
  if (!plan) {
    if (required) throw new AdminError('Selecciona un plan de licencia.', 400, 'invalid_plan');
    return '';
  }
  if (!PLAN_CODES.has(plan)) throw new AdminError('El plan de licencia no es válido.', 400, 'invalid_plan');
  return plan;
}

function issuePayload(payload) {
  const data = payloadObject(payload);
  return {
    customerName: text(data.customerName, 160, 'El nombre del cliente'),
    email: text(data.email, 254, 'El correo electrónico'),
    machineCode: text(data.machineCode, 32, 'El código de equipo'),
    machineName: text(data.machineName, 80, 'El nombre del equipo'),
    notes: text(data.notes, 500, 'Las notas'),
    plan: planCode(data.plan),
    transactionId: text(data.transactionId, 100, 'La transacción'),
  };
}

function priceCents(value, label) {
  const parsed = typeof value === 'string' && value.trim() !== '' ? Number(value) : value;
  if (!Number.isInteger(parsed) || parsed < MIN_PRICE_CENTS || parsed > MAX_PRICE_CENTS) {
    throw new AdminError(`El precio ${label} debe estar entre 0,50 y 100.000 USD.`, 400, 'invalid_price');
  }
  return parsed;
}

function paymentsPayload(payload) {
  const data = payloadObject(payload);
  const mode = text(data.mode, 16, 'El modo').toLowerCase() || 'sandbox';
  if (!PAYMENT_MODES.has(mode)) {
    throw new AdminError('El modo de PayPal debe ser sandbox o live.', 400, 'invalid_mode');
  }
  const clientId = text(data.clientId, 200, 'El Client ID');
  if (clientId && !/^[A-Za-z0-9._-]{8,200}$/.test(clientId)) {
    throw new AdminError('El Client ID de PayPal no tiene un formato válido.', 400, 'invalid_client_id');
  }
  const webhookId = text(data.webhookId, 100, 'El ID del webhook');
  if (webhookId && !/^[A-Za-z0-9_-]{6,100}$/.test(webhookId)) {
    throw new AdminError('El ID del webhook no tiene un formato válido.', 400, 'invalid_webhook_id');
  }
  let clientSecret = '';
  if (data.clientSecret !== undefined && data.clientSecret !== null) {
    if (typeof data.clientSecret !== 'string') {
      throw new AdminError('El Client Secret no es válido.', 400, 'invalid_client_secret');
    }
    clientSecret = data.clientSecret.trim();
    if (clientSecret.length > 200 || (clientSecret && !/^[\x21-\x7E]{8,200}$/.test(clientSecret))) {
      throw new AdminError('El Client Secret de PayPal no tiene un formato válido.', 400, 'invalid_client_secret');
    }
  }
  const prices = {};
  if (data.prices !== undefined) {
    if (!data.prices || typeof data.prices !== 'object' || Array.isArray(data.prices)) {
      throw new AdminError('Los precios no tienen un formato válido.', 400, 'invalid_price');
    }
    for (const code of PLAN_CODES) {
      if (data.prices[code] !== undefined) prices[code] = priceCents(data.prices[code], code);
    }
  }
  return { mode, clientId, clientSecret, webhookId, prices };
}

function listPayload(payload, allowedStatuses) {
  const data = payloadObject(payload);
  return {
    query: text(data.query, 120, 'La búsqueda'),
    status: statusFilter(data.status, allowedStatuses),
    page: integer(data.page, 1, 1, 1_000_000),
    pageSize: integer(data.pageSize, 25, 10, 100),
  };
}

function pagePayload(payload, pageSize, maxPageSize) {
  const data = payloadObject(payload);
  return {
    page: integer(data.page, 1, 1, 1_000_000),
    pageSize: integer(data.pageSize, pageSize, 10, maxPageSize),
  };
}

function mapApiError(error, extra = {}) {
  if (error instanceof AdminApiError) {
    const requiresLogin = error.status === 401;
    if (requiresLogin) client().clearSession();
    return new AdminError(error.message, error.status || 502, error.code, {
      requiresLogin,
      ...extra,
    });
  }
  return error;
}

function plainApiError(error) {
  if (error instanceof AdminApiError) {
    return new AdminError(error.message, error.status || 502, error.code);
  }
  return error;
}

function normalizedServerUrl(value) {
  try {
    return normalizeServerUrl(value);
  } catch (error) {
    throw new AdminError(error.message, 400, error.code || 'invalid_server_url');
  }
}

async function withSession(operation) {
  const active = client();
  if (!active.hasSession) {
    throw new AdminError('Inicia sesión para continuar.', 401, 'invalid_session', { requiresLogin: true });
  }
  if (active.sessionLocallyExpired()) {
    active.clearSession();
    throw new AdminError('La sesión expiró. Vuelve a iniciar sesión.', 401, 'invalid_session', { requiresLogin: true });
  }
  try {
    return await operation(active);
  } catch (error) {
    throw mapApiError(error);
  }
}

async function login(payload) {
  const data = payloadObject(payload);
  const username = text(data.username, 64, 'El usuario');
  if (typeof data.password !== 'string' || !data.password.length) {
    throw new AdminError('Escribe la contraseña.', 400, 'missing_field');
  }
  if (data.password.length > 200) {
    throw new AdminError('La contraseña supera el máximo de 200 caracteres.', 400, 'invalid_field');
  }
  const password = data.password;
  if (!username) throw new AdminError('Escribe el usuario administrador.', 400, 'missing_field');
  const serverUrl = normalizedServerUrl(data.serverUrl || configured.serverUrl);

  const previous = api;
  if (previous && previous.hasSession && previous.serverUrl !== serverUrl) {
    previous.logout().catch(() => {});
  }
  const next = new AdminApiClient({ serverUrl });
  try {
    const result = await next.login({ username, password });
    api = next;
    configured = { serverUrl, warning: null };
    try {
      persistConfig(serverUrl);
    } catch (error) {
      configured.warning = error.message;
    }
    return {
      user: result.user,
      expiresAt: result.expiresAt,
      serverUrl,
      appVersion: app.getVersion(),
      configWarning: configured.warning,
    };
  } catch (error) {
    throw plainApiError(error);
  }
}

async function logout() {
  const active = client();
  await active.logout();
  return { ok: true, serverUrl: configured.serverUrl };
}

async function testConnection(payload) {
  const data = payloadObject(payload);
  const serverUrl = normalizedServerUrl(data.serverUrl || configured.serverUrl);
  const probe = new AdminApiClient({ serverUrl, timeoutMs: 8000 });
  try {
    const health = await probe.health();
    return { serverUrl, ...health };
  } catch (error) {
    throw plainApiError(error);
  }
}

function safeFilename(value, fallback) {
  const base = path.basename(String(value || '')).replace(/[<>:"/\\|?*\u0000-\u001f]/g, '-').trim();
  const name = base && base !== '.' && base !== '..' ? base : fallback;
  return name.slice(0, 140);
}

function dateForFile(date = new Date()) {
  const pad = (value) => String(value).padStart(2, '0');
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}`;
}

async function askSavePath(parent, { title, defaultName, filters }) {
  const options = {
    title,
    defaultPath: path.join(app.getPath('documents'), defaultName),
    filters,
  };
  const result = parent
    ? await dialog.showSaveDialog(parent, options)
    : await dialog.showSaveDialog(options);
  if (result.canceled || !result.filePath) return null;
  return result.filePath;
}

function writeFile(filePath, content) {
  try {
    fs.writeFileSync(filePath, content, 'utf8');
  } catch (error) {
    throw new AdminError(`No se pudo guardar el archivo: ${error.message}`, 500, 'file_save_failed');
  }
}

async function exportCsv(payload, event) {
  const data = payloadObject(payload);
  const status = statusFilter(data.status, LICENSE_STATUSES);
  const query = text(data.query, 120, 'La búsqueda');
  return withSession(async (active) => {
    const download = await active.downloadLicensesCsv({ status, query });
    const parent = BrowserWindow.fromWebContents(event.sender);
    const filePath = await askSavePath(parent, {
      title: 'Exportar inventario de licencias',
      defaultName: safeFilename(download.filename, `perfillab-licencias-${dateForFile()}.csv`),
      filters: [{ name: 'CSV', extensions: ['csv'] }],
    });
    if (!filePath) return { canceled: true };
    writeFile(filePath, download.text);
    return { canceled: false, path: filePath, bytes: Buffer.byteLength(download.text, 'utf8') };
  });
}

async function exportRevocations(payload, event) {
  return withSession(async (active) => {
    const download = await active.downloadRevocations();
    const parent = BrowserWindow.fromWebContents(event.sender);
    const filePath = await askSavePath(parent, {
      title: 'Guardar lista firmada de revocaciones',
      defaultName: safeFilename(download.filename, `perfillab-revocaciones-${dateForFile()}.json`),
      filters: [{ name: 'Lista firmada', extensions: ['json'] }],
    });
    if (!filePath) return { canceled: true };
    writeFile(filePath, download.text);
    return { canceled: false, path: filePath, bytes: Buffer.byteLength(download.text, 'utf8') };
  });
}

async function saveEnvelope(payload, event) {
  const id = identifier(payloadObject(payload).id);
  return withSession(async (active) => {
    const detail = await active.getLicense(id);
    if (!detail.envelope) {
      throw new AdminError(
        'La licencia todavía no está vinculada a un equipo. El archivo firmado se genera cuando la licencia se activa.',
        409,
        'license_not_activated',
      );
    }
    const parent = BrowserWindow.fromWebContents(event.sender);
    const filePath = await askSavePath(parent, {
      title: 'Guardar archivo de licencia',
      defaultName: safeFilename(`perfillab-licencia-${detail.license.id}.perfillab-license`, 'perfillab-license.json'),
      filters: [{ name: 'Licencia de PerfilLab', extensions: ['perfillab-license', 'json'] }],
    });
    if (!filePath) return { canceled: true };
    writeFile(filePath, `${JSON.stringify(detail.envelope, null, 2)}\n`);
    return { canceled: false, path: filePath, licenseId: detail.license.id };
  });
}

function buildActions() {
  return {
    'app:info': () => ({
      version: app.getVersion(),
      platform: process.platform,
      serverUrl: configured.serverUrl,
      defaultServerUrl: DEFAULT_SERVER_URL,
      dataDir: DATA_DIR,
      configFile: CONFIG_FILE,
      configWarning: configured.warning,
    }),
    'server:info': () => sessionInfo(),
    'server:health': (payload) => testConnection(payload),
    'auth:login': (payload) => login(payload),
    'auth:logout': () => logout(),
    'auth:state': () => sessionInfo(),
    'admin:overview': () => withSession((active) => active.overview()),
    'admin:payments:get': () => withSession((active) => active.getPayments()),
    'admin:payments:save': (payload) => {
      const input = paymentsPayload(payload);
      return withSession((active) => active.updatePayments(input));
    },
    'admin:payments:test': (payload) => {
      const input = paymentsPayload(payload);
      return withSession((active) => active.testPayments(input));
    },
    'admin:payments:clear': () => withSession((active) => active.clearPayments()),
    'admin:licenses:list': (payload) => {
      const params = listPayload(payload, LICENSE_STATUSES);
      return withSession((active) => active.listLicenses(params));
    },
    'admin:licenses:get': (payload) => {
      const id = identifier(payloadObject(payload).id);
      return withSession((active) => active.getLicense(id));
    },
    'admin:licenses:issue': (payload) => {
      const input = issuePayload(payload);
      return withSession((active) => active.issueLicense(input));
    },
    'admin:licenses:batch': (payload) => {
      const data = payloadObject(payload);
      if (!Array.isArray(data.items) || !data.items.length) {
        throw new AdminError('El lote no contiene licencias para emitir.', 400, 'batch_empty');
      }
      if (data.items.length > 100) {
        throw new AdminError('El lote supera el máximo de 100 licencias por petición.', 400, 'batch_too_large');
      }
      const items = data.items.map((item) => issuePayload(item));
      return withSession((active) => active.issueBatch(items));
    },
    'admin:licenses:action': (payload) => {
      const data = payloadObject(payload);
      const id = identifier(data.id);
      const action = String(data.action || '');
      if (!LICENSE_ACTIONS.has(action)) {
        throw new AdminError('Acción de licencia no permitida.', 400, 'unknown_action');
      }
      const reason = text(data.reason, 300, 'El motivo');
      const plan = action === 'renew' ? planCode(data.plan, { required: true }) : '';
      return withSession((active) => active.licenseAction(id, action, { reason, plan }));
    },
    'admin:licenses:export-csv': (payload, event) => exportCsv(payload, event),
    'admin:licenses:save-envelope': (payload, event) => saveEnvelope(payload, event),
    'admin:orders:list': (payload) => {
      const params = listPayload(payload, ORDER_STATUSES);
      return withSession((active) => active.listOrders(params));
    },
    'admin:orders:get': (payload) => {
      const id = orderIdentifier(payloadObject(payload).id);
      return withSession((active) => active.getOrder(id));
    },
    'admin:orders:sync': (payload) => {
      const id = orderIdentifier(payloadObject(payload).id);
      return withSession((active) => active.syncOrder(id));
    },
    'admin:transactions:list': (payload) => {
      const params = pagePayload(payload, 50, 200);
      return withSession((active) => active.listTransactions(params));
    },
    'admin:audit:list': (payload) => {
      const params = pagePayload(payload, 50, 200);
      return withSession((active) => active.listAudit(params));
    },
    'admin:revocations:export': (payload, event) => exportRevocations(payload, event),
    'clipboard:write': (payload) => {
      const value = payloadObject(payload).text;
      if (typeof value !== 'string') throw new AdminError('El texto no es válido.', 400, 'invalid_payload');
      if (value.length > 262_144) throw new AdminError('El texto es demasiado grande para el portapapeles.', 400, 'too_large');
      clipboard.writeText(value);
      return { copied: true };
    },
  };
}

function registerIpc() {
  const actions = buildActions();
  ipcMain.handle('license-admin:action', async (event, name, payload) => {
    try {
      if (!mainWindow || mainWindow.isDestroyed() || event.sender !== mainWindow.webContents) {
        throw new AdminError('Origen no permitido.', 403, 'forbidden');
      }
      if (typeof name !== 'string' || !Object.prototype.hasOwnProperty.call(actions, name)) {
        throw new AdminError('Acción no permitida.', 400, 'unknown_action');
      }
      if (payload !== undefined && payload !== null && (typeof payload !== 'object' || Array.isArray(payload))) {
        throw new AdminError('Datos de acción no válidos.', 400, 'invalid_payload');
      }
      const data = await actions[name](payload || {}, event);
      return { ok: true, data };
    } catch (error) {
      const adminError = error instanceof AdminError ? error : mapApiError(error);
      const status = adminError instanceof AdminError ? adminError.status : 500;
      if (!(adminError instanceof AdminError)) {
        console.error('[admin]', name, error);
      }
      return {
        ok: false,
        error: {
          message: adminError && adminError.message ? adminError.message : 'Ocurrió un error inesperado.',
          code: adminError && adminError.code ? adminError.code : 'error',
          status,
          requiresLogin: Boolean(adminError && adminError.requiresLogin),
        },
      };
    }
  });
}

function protectSession() {
  const ses = session.defaultSession;
  ses.setPermissionRequestHandler((_contents, _permission, callback) => callback(false));
  ses.setPermissionCheckHandler(() => false);
  ses.setDevicePermissionHandler(() => false);
  ses.setBluetoothPairingHandler((_details, callback) => callback({ confirmed: false }));
  ses.webRequest.onHeadersReceived((details, callback) => {
    callback({
      responseHeaders: {
        ...details.responseHeaders,
        'X-Content-Type-Options': ['nosniff'],
      },
    });
  });
}

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1320,
    height: 860,
    minWidth: 1040,
    minHeight: 700,
    show: false,
    backgroundColor: '#080c14',
    title: 'PerfilLab Licencias',
    icon: path.join(ASSETS, 'icon.png'),
    autoHideMenuBar: true,
    ...(process.platform === 'win32'
      ? {
        titleBarStyle: 'hidden',
        titleBarOverlay: {
          color: '#080c14',
          symbolColor: '#dfe7f8',
          height: 70,
        },
      }
      : {}),
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      sandbox: true,
      nodeIntegration: false,
      webSecurity: true,
      spellcheck: false,
      devTools: process.env.PERFILLAB_ADMIN_DEV === '1',
    },
  });

  Menu.setApplicationMenu(null);
  mainWindow.loadFile(RENDERER);
  mainWindow.once('ready-to-show', () => mainWindow.show());
  mainWindow.on('closed', () => {
    mainWindow = null;
  });
  mainWindow.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));
  mainWindow.webContents.on('will-navigate', (event) => event.preventDefault());
  mainWindow.webContents.on('will-attach-webview', (event) => event.preventDefault());
  mainWindow.webContents.on('render-process-gone', (_event, details) => {
    console.error('[renderer]', details.reason);
  });
}

app.setAppUserModelId('com.perfillab.licencias');

if (process.env.PERFILLAB_DEBUG_PORT) {
  app.commandLine.appendSwitch('remote-debugging-port', process.env.PERFILLAB_DEBUG_PORT);
}

const gotLock = app.requestSingleInstanceLock();
if (!gotLock) {
  app.quit();
} else {
  app.on('second-instance', () => {
    if (!mainWindow) return;
    if (mainWindow.isMinimized()) mainWindow.restore();
    mainWindow.show();
    mainWindow.focus();
  });

  app.whenReady().then(() => {
    protectSession();
    registerIpc();
    createWindow();
  }).catch((error) => {
    dialog.showErrorBox('PerfilLab Licencias no pudo iniciar', error.stack || error.message);
    app.quit();
  });

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
    else if (mainWindow) {
      mainWindow.show();
      mainWindow.focus();
    }
  });

  app.on('window-all-closed', () => {
    if (process.platform !== 'darwin') app.quit();
  });

  app.on('before-quit', () => {
    if (api && api.hasSession) api.clearSession();
  });
}
