'use strict';

const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('licenseAdmin', {
  action: (name, payload) => ipcRenderer.invoke('license-admin:action', name, payload),
  platform: process.platform,
});
