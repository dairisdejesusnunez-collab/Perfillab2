'use strict';

const DEFAULT_SERVER_URL = 'http://127.0.0.1:45900/v1';
const DEFAULT_TIMEOUT_MS = 15_000;
const MAX_JSON_BYTES = 4 * 1024 * 1024;
const MAX_TEXT_BYTES = 32 * 1024 * 1024;
const MAX_BATCH_ITEMS = 100;

class AdminApiError extends Error {
  constructor(message, { status = 0, code = 'api_error', details = null, cause } = {}) {
    super(message);
    this.name = 'AdminApiError';
    this.status = status;
    this.code = code;
    this.details = details;
    this.cause = cause;
  }
}

function isLoopbackHostname(hostname) {
  const raw = String(hostname || '').trim().toLowerCase()
    .replace(/^\[/, '')
    .replace(/\]$/, '')
    .replace(/\.$/, '');
  if (!raw) return false;
  if (raw === 'localhost' || raw === '::1') return true;
  const match = /^127\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/.exec(raw);
  return Boolean(match) && match.slice(1).every((part) => Number(part) <= 255);
}

function normalizeServerUrl(input) {
  const raw = String(input === undefined || input === null ? '' : input).trim();
  if (!raw) {
    throw new AdminApiError('Escribe la dirección del servidor de licencias.', {
      code: 'invalid_server_url',
    });
  }
  const candidate = /^[a-z][a-z0-9+.-]*:\/\//i.test(raw) ? raw : `http://${raw}`;
  let url;
  try {
    url = new URL(candidate);
  } catch {
    throw new AdminApiError('La dirección del servidor no es válida.', { code: 'invalid_server_url' });
  }
  if (url.protocol !== 'http:' && url.protocol !== 'https:') {
    throw new AdminApiError('El servidor debe usar http:// o https://.', { code: 'invalid_server_url' });
  }
  if (url.username || url.password) {
    throw new AdminApiError('No incluyas credenciales dentro de la dirección del servidor.', {
      code: 'invalid_server_url',
    });
  }
  if (url.protocol === 'http:' && !isLoopbackHostname(url.hostname)) {
    throw new AdminApiError(
      'Usa HTTPS para un servidor remoto. HTTP solo se permite en localhost o 127.0.0.1.',
      { code: 'invalid_server_url' },
    );
  }
  if (!url.hostname) {
    throw new AdminApiError('La dirección del servidor no incluye un host.', { code: 'invalid_server_url' });
  }
  if (url.search || url.hash) {
    throw new AdminApiError('La dirección del servidor no debe incluir parámetros ni fragmentos.', {
      code: 'invalid_server_url',
    });
  }
  const pathname = url.pathname.replace(/\/+$/, '');
  if (pathname !== '' && pathname !== '/v1') {
    throw new AdminApiError('La dirección debe apuntar a la raíz del servidor o a /v1, sin rutas adicionales.', {
      code: 'invalid_server_url',
    });
  }
  return pathname === '/v1' ? `${url.origin}/v1` : url.origin;
}

function localApiPath(path) {
  if (path === '/api/health') return '/health';
  if (path === '/api/admin/login') return '/auth/login';
  if (path === '/api/admin/logout') return '/auth/logout';
  if (path === '/api/admin/session') return '/auth/me';
  if (path.startsWith('/api/admin/')) return `/admin/${path.slice('/api/admin/'.length)}`;
  if (path.startsWith('/api/license/')) return `/license/${path.slice('/api/license/'.length)}`;
  return path;
}

function filenameFromDisposition(value, fallback) {
  const header = String(value || '');
  const encoded = /filename\*\s*=\s*UTF-8''([^;]+)/i.exec(header);
  if (encoded) {
    try {
      return decodeURIComponent(encoded[1].trim().replace(/^"|"$/g, ''));
    } catch {
      // Se usa el nombre alternativo.
    }
  }
  const plain = /filename\s*=\s*"([^"]+)"/i.exec(header) || /filename\s*=\s*([^;]+)/i.exec(header);
  if (plain) {
    const name = plain[1].trim().replace(/^"|"$/g, '');
    if (name) return name;
  }
  return fallback;
}

function requestPath(base, path, query) {
  if (!query) return `${base}${path}`;
  const params = new URLSearchParams();
  for (const [key, value] of Object.entries(query)) {
    if (value === undefined || value === null || value === '') continue;
    params.set(key, String(value));
  }
  const suffix = params.toString();
  return suffix ? `${base}${path}?${suffix}` : `${base}${path}`;
}

class AdminApiClient {
  constructor({ serverUrl = DEFAULT_SERVER_URL, timeoutMs = DEFAULT_TIMEOUT_MS } = {}) {
    this.serverUrl = normalizeServerUrl(serverUrl);
    this.basePath = new URL(this.serverUrl).pathname === '/v1' ? '/v1' : '';
    this.timeoutMs = Number(timeoutMs) > 0 ? Number(timeoutMs) : DEFAULT_TIMEOUT_MS;
    this.token = null;
    this.user = null;
    this.expiresAt = null;
  }

  get hasSession() {
    return Boolean(this.token);
  }

  setServerUrl(serverUrl) {
    const normalized = normalizeServerUrl(serverUrl);
    if (normalized !== this.serverUrl && this.token) this.clearSession();
    this.serverUrl = normalized;
    this.basePath = new URL(normalized).pathname === '/v1' ? '/v1' : '';
    return normalized;
  }

  clearSession() {
    this.token = null;
    this.user = null;
    this.expiresAt = null;
  }

  sessionLocallyExpired(now = Date.now()) {
    return Boolean(this.expiresAt) && Date.parse(this.expiresAt) <= now;
  }

  sessionInfo() {
    return {
      authenticated: Boolean(this.token),
      user: this.user,
      expiresAt: this.expiresAt,
      serverUrl: this.serverUrl,
    };
  }

  async request(method, path, options = {}) {
    const {
      body,
      auth = true,
      raw = false,
      timeoutMs = this.timeoutMs,
      query = null,
      accept = raw ? 'text/csv, text/plain;q=0.9, */*;q=0.1' : 'application/json',
    } = options;
    if (auth && !this.token) {
      throw new AdminApiError('Inicia sesión para continuar.', {
        status: 401,
        code: 'invalid_session',
      });
    }
    const headers = { Accept: accept };
    if (auth) headers.Authorization = `Bearer ${this.token}`;
    let payload;
    if (body !== undefined) {
      headers['Content-Type'] = 'application/json';
      payload = JSON.stringify(body);
    }
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeoutMs);
    const target = this.basePath ? localApiPath(path) : path;
    let response;
    try {
      response = await fetch(requestPath(this.serverUrl, target, query), {
        method,
        headers,
        body: payload,
        redirect: 'error',
        cache: 'no-store',
        signal: controller.signal,
      });
    } catch (error) {
      if (error && error.name === 'AbortError') {
        throw new AdminApiError('El servidor tardó demasiado en responder. Inténtalo de nuevo.', {
          code: 'timeout',
          cause: error,
        });
      }
      throw new AdminApiError(
        'No se pudo conectar con el servidor de licencias. Revisa la dirección y que el servidor esté en marcha.',
        { code: 'network_error', cause: error },
      );
    } finally {
      clearTimeout(timer);
    }

    const maxBytes = raw ? MAX_TEXT_BYTES : MAX_JSON_BYTES;
    const declared = Number(response.headers.get('content-length'));
    if (Number.isFinite(declared) && declared > maxBytes) {
      throw new AdminApiError('La respuesta del servidor es demasiado grande.', {
        status: response.status,
        code: 'response_too_large',
      });
    }
    let buffer;
    try {
      buffer = Buffer.from(await response.arrayBuffer());
    } catch (error) {
      throw new AdminApiError('La respuesta del servidor se interrumpió.', {
        code: 'response_interrupted',
        cause: error,
      });
    }
    if (buffer.length > maxBytes) {
      throw new AdminApiError('La respuesta del servidor es demasiado grande.', {
        status: response.status,
        code: 'response_too_large',
      });
    }
    const text = buffer.toString('utf8');

    if (!response.ok) {
      let info = null;
      try {
        info = JSON.parse(text);
      } catch {
        info = null;
      }
      const detail = info && info.error && typeof info.error === 'object' ? info.error : {};
      throw new AdminApiError(
        detail.message || `El servidor respondió con HTTP ${response.status}.`,
        {
          status: response.status,
          code: detail.code || 'http_error',
          details: detail.details || null,
        },
      );
    }

    if (raw) {
      return {
        text,
        filename: filenameFromDisposition(
          response.headers.get('content-disposition'),
          options.fallbackFilename || 'perfillab-export.csv',
        ),
        contentType: response.headers.get('content-type') || '',
      };
    }
    if (!text.trim()) return {};
    try {
      return JSON.parse(text);
    } catch {
      throw new AdminApiError('El servidor envió una respuesta que no es JSON válido.', {
        status: response.status,
        code: 'invalid_response',
      });
    }
  }

  async health() {
    const data = await this.request('GET', '/api/health', {
      auth: false,
      timeoutMs: Math.min(this.timeoutMs, 8000),
    });
    return {
      ok: data.ok === true,
      service: data.service || '',
      version: data.version || '',
      time: data.time || null,
    };
  }

  async login({ username, password } = {}) {
    const data = await this.request('POST', '/api/admin/login', {
      auth: false,
      body: { username: String(username || ''), password: String(password || '') },
      timeoutMs: 20_000,
    });
    if (!data || typeof data.token !== 'string' || !data.token) {
      throw new AdminApiError('El servidor no devolvió una sesión válida.', {
        code: 'invalid_response',
      });
    }
    this.token = data.token;
    this.user = data.user || null;
    this.expiresAt = data.expiresAt || null;
    return { user: this.user, expiresAt: this.expiresAt };
  }

  async logout() {
    if (this.token) {
      try {
        await this.request('POST', '/api/admin/logout', { body: {} });
      } catch {
        // El cierre de sesión local nunca queda bloqueado por la red.
      }
    }
    this.clearSession();
    return { ok: true };
  }

  async session() {
    const data = await this.request('GET', '/api/admin/session');
    this.user = data.user || this.user;
    if (this.user && this.user.expiresAt) this.expiresAt = this.user.expiresAt;
    return { user: this.user, expiresAt: this.expiresAt };
  }

  overview() {
    return this.request('GET', '/api/admin/overview');
  }

  getPayments() {
    return this.request('GET', '/api/admin/payments');
  }

  updatePayments(input) {
    return this.request('POST', '/api/admin/payments', { body: input, timeoutMs: 30_000 });
  }

  testPayments(input) {
    return this.request('POST', '/api/admin/payments/test', { body: input, timeoutMs: 30_000 });
  }

  clearPayments() {
    return this.request('POST', '/api/admin/payments/clear', { body: {} });
  }

  listLicenses({ query = '', status = 'all', page = 1, pageSize = 25 } = {}) {
    return this.request('GET', '/api/admin/licenses', {
      query: { query, status, page, pageSize },
    });
  }

  getLicense(id) {
    return this.request('GET', `/api/admin/licenses/${encodeURIComponent(String(id))}`);
  }

  issueLicense(input) {
    return this.request('POST', '/api/admin/licenses', { body: input });
  }

  async issueBatch(items) {
    if (!Array.isArray(items) || !items.length) {
      throw new AdminApiError('El lote no contiene licencias para emitir.', {
        code: 'batch_empty',
      });
    }
    if (items.length > MAX_BATCH_ITEMS) {
      throw new AdminApiError(`El lote supera el máximo de ${MAX_BATCH_ITEMS} licencias por petición.`, {
        code: 'batch_too_large',
      });
    }
    return this.request('POST', '/api/admin/licenses/batch', { body: { items } });
  }

  async licenseAction(id, action, payload = {}) {
    const allowed = new Set(['revoke', 'suspend', 'reactivate', 'reset-activation', 'resend-email', 'renew']);
    if (!allowed.has(action)) {
      throw new AdminApiError('Acción de licencia no permitida.', { code: 'unknown_action' });
    }
    return this.request('POST', `/api/admin/licenses/${encodeURIComponent(String(id))}/${action}`, {
      body: payload,
    });
  }

  downloadLicensesCsv({ status = 'all', query = '' } = {}) {
    return this.request('GET', '/api/admin/licenses.csv', {
      raw: true,
      query: { status, query },
      timeoutMs: 60_000,
      accept: 'text/csv',
      fallbackFilename: 'perfillab-licencias.csv',
    });
  }

  listOrders({ status = 'all', query = '', page = 1, pageSize = 25 } = {}) {
    return this.request('GET', '/api/admin/orders', {
      query: { status, query, page, pageSize },
    });
  }

  getOrder(id) {
    return this.request('GET', `/api/admin/orders/${encodeURIComponent(String(id))}`);
  }

  syncOrder(id) {
    return this.request('POST', `/api/admin/orders/${encodeURIComponent(String(id))}/sync`, {
      body: {},
      timeoutMs: 45_000,
    });
  }

  listTransactions({ page = 1, pageSize = 50 } = {}) {
    return this.request('GET', '/api/admin/transactions', { query: { page, pageSize } });
  }

  listAudit({ page = 1, pageSize = 50 } = {}) {
    return this.request('GET', '/api/admin/audit', { query: { page, pageSize } });
  }

  downloadRevocations() {
    return this.request('GET', '/api/admin/revocations', {
      raw: true,
      timeoutMs: 60_000,
      accept: 'application/json',
      fallbackFilename: 'perfillab-revocaciones.json',
    });
  }
}

module.exports = {
  AdminApiClient,
  AdminApiError,
  DEFAULT_SERVER_URL,
  MAX_BATCH_ITEMS,
  isLoopbackHostname,
  normalizeServerUrl,
};
