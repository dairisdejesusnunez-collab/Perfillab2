'use strict';

const http = require('node:http');
const { test } = require('node:test');
const assert = require('node:assert/strict');

const {
  AdminApiClient,
  AdminApiError,
  normalizeServerUrl,
} = require('../electron/server-client');

const TOKEN = 'token-de-prueba-1234567890';

function send(res, status, payload, headers = {}) {
  const body = typeof payload === 'string' ? payload : JSON.stringify(payload);
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', ...headers });
  res.end(body);
}

function startFakeAdminServer({ delayMs = 0 } = {}) {
  const state = { logins: [], authenticated: 0, batchSizes: [] };
  const server = http.createServer((req, res) => {
    const chunks = [];
    req.on('data', (chunk) => chunks.push(chunk));
    req.on('end', () => {
      const respond = () => route(req, res, Buffer.concat(chunks).toString('utf8'), state);
      if (delayMs) setTimeout(respond, delayMs);
      else respond();
    });
  });
  return new Promise((resolve) => {
    server.listen(0, '127.0.0.1', () => {
      const { port } = server.address();
      resolve({
        state,
        url: `http://127.0.0.1:${port}`,
        close: () => new Promise((done) => server.close(done)),
      });
    });
  });
}

function route(req, res, raw, state) {
  const url = new URL(req.url, 'http://localhost');
  const authorized = req.headers.authorization === `Bearer ${TOKEN}`;
  if (req.method === 'GET' && url.pathname === '/api/health') {
    return send(res, 200, { ok: true, service: 'perfillab-license-server', version: '1.0.0' });
  }
  if (req.method === 'POST' && url.pathname === '/api/admin/login') {
    const body = JSON.parse(raw || '{}');
    state.logins.push(body.username);
    if (body.username === 'admin' && body.password === 'correcta') {
      return send(res, 200, {
        token: TOKEN,
        expiresAt: new Date(Date.now() + 3600_000).toISOString(),
        user: { id: 1, username: 'admin', role: 'admin' },
      });
    }
    return send(res, 401, { error: { message: 'Usuario o contraseña incorrectos.', code: 'invalid_credentials' } });
  }
  if (!authorized) {
    return send(res, 401, { error: { message: 'Sesión no válida o expirada.', code: 'invalid_session' } });
  }
  state.authenticated += 1;
  if (req.method === 'GET' && url.pathname === '/api/admin/overview') {
    return send(res, 200, { summary: { capacity: 50000, used: 2 } });
  }
  if (req.method === 'POST' && url.pathname === '/api/admin/licenses/batch') {
    const body = JSON.parse(raw || '{}');
    state.batchSizes.push(body.items.length);
    return send(res, 200, { issued: body.items.length, failed: 0, results: [] });
  }
  if (req.method === 'GET' && url.pathname === '/api/admin/licenses.csv') {
    const body = 'ID,Asiento\r\nPL-0001,1\r\n';
    res.writeHead(200, {
      'Content-Type': 'text/csv; charset=utf-8',
      'Content-Disposition': 'attachment; filename="perfillab-licencias-2026-10-24.csv"',
    });
    return res.end(body);
  }
  if (req.method === 'POST' && url.pathname === '/api/admin/logout') {
    return send(res, 200, { ok: true });
  }
  if (req.method === 'GET' && url.pathname === '/api/admin/broken-json') {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    return res.end('{no es json');
  }
  return send(res, 404, { error: { message: 'Recurso no encontrado.', code: 'not_found' } });
}

function startFakeLocalServer() {
  const paths = [];
  const server = http.createServer((req, res) => {
    const chunks = [];
    req.on('data', (chunk) => chunks.push(chunk));
    req.on('end', () => {
      const url = new URL(req.url, 'http://localhost');
      paths.push(`${req.method} ${url.pathname}`);
      const authorized = req.headers.authorization === `Bearer ${TOKEN}`;
      if (req.method === 'GET' && url.pathname === '/v1/health') {
        return send(res, 200, { ok: true, service: 'perfillab-license-server-local', version: '1.0.0' });
      }
      if (req.method === 'POST' && url.pathname === '/v1/auth/login') {
        return send(res, 200, {
          token: TOKEN,
          expiresAt: new Date(Date.now() + 3600_000).toISOString(),
          user: { id: 'admin-1', username: 'admin', role: 'admin' },
        });
      }
      if (!authorized) {
        return send(res, 401, { error: { message: 'Sesión no válida o expirada.', code: 'invalid_session' } });
      }
      if (req.method === 'GET' && url.pathname === '/v1/auth/me') {
        return send(res, 200, { user: { id: 'admin-1', username: 'admin', role: 'admin' } });
      }
      if (req.method === 'GET' && url.pathname === '/v1/admin/overview') {
        return send(res, 200, { summary: { capacity: 50000, used: 3 }, server: { environment: 'local' } });
      }
      if (req.method === 'POST' && url.pathname === '/v1/admin/licenses/PL-0001/renew') {
        return send(res, 200, { renewed: true, expiresAt: new Date().toISOString() });
      }
      if (req.method === 'POST' && url.pathname === '/v1/auth/logout') {
        return send(res, 200, { ok: true });
      }
      return send(res, 404, { error: { message: 'Recurso no encontrado.', code: 'not_found' } });
    });
  });
  return new Promise((resolve) => {
    server.listen(0, '127.0.0.1', () => {
      resolve({
        paths,
        url: `http://127.0.0.1:${server.address().port}/v1`,
        close: () => new Promise((done) => server.close(done)),
      });
    });
  });
}

test('el cliente usa /v1 cuando la dirección incluye la ruta', async () => {
  const fake = await startFakeLocalServer();
  try {
    const client = new AdminApiClient({ serverUrl: fake.url });
    const health = await client.health();
    assert.equal(health.ok, true);

    await client.login({ username: 'admin', password: 'correcta' });
    const session = await client.session();
    assert.equal(session.user.username, 'admin');

    const overview = await client.overview();
    assert.equal(overview.summary.used, 3);

    const renewed = await client.licenseAction('PL-0001', 'renew', {});
    assert.equal(renewed.renewed, true);

    await client.logout();
    assert.deepEqual(fake.paths, [
      'GET /v1/health',
      'POST /v1/auth/login',
      'GET /v1/auth/me',
      'GET /v1/admin/overview',
      'POST /v1/admin/licenses/PL-0001/renew',
      'POST /v1/auth/logout',
    ]);
  } finally {
    await fake.close();
  }
});

test('normalizeServerUrl acepta hosts y rechaza direcciones inseguras', () => {
  assert.equal(normalizeServerUrl('127.0.0.1:45900'), 'http://127.0.0.1:45900');
  assert.equal(normalizeServerUrl(' http://127.0.0.1:45900/ '), 'http://127.0.0.1:45900');
  assert.equal(normalizeServerUrl('https://licencias.example.com'), 'https://licencias.example.com');
  assert.equal(normalizeServerUrl('https://licencias.example.com/'), 'https://licencias.example.com');
  assert.equal(normalizeServerUrl('http://[::1]:45900'), 'http://[::1]:45900');
  assert.equal(normalizeServerUrl('http://127.0.0.1:45900/v1'), 'http://127.0.0.1:45900/v1');
  assert.equal(normalizeServerUrl('http://127.0.0.1:45900/v1/'), 'http://127.0.0.1:45900/v1');
  assert.equal(normalizeServerUrl('http://localhost:45900'), 'http://localhost:45900');

  assert.throws(() => normalizeServerUrl('http://licencias.example.com'), /HTTPS/);
  assert.throws(() => normalizeServerUrl('http://192.168.1.20:45900'), /HTTPS/);
  assert.throws(() => normalizeServerUrl(''), AdminApiError);
  assert.throws(() => normalizeServerUrl('ftp://licencias.example.com'), /http/);
  assert.throws(() => normalizeServerUrl('file:///etc/passwd'), /http/);
  assert.throws(() => normalizeServerUrl('http://user:secret@licencias.example.com'), /credenciales/);
  assert.throws(() => normalizeServerUrl('https://licencias.example.com/admin'), /raíz/);
  assert.throws(() => normalizeServerUrl('https://licencias.example.com?x=1'), /parámetros/);
  assert.throws(() => normalizeServerUrl('https://licencias.example.com#frag'), /parámetros/);
});

test('login, sesión, errores y descargas usan el servidor configurado', async () => {
  const fake = await startFakeAdminServer();
  try {
    const client = new AdminApiClient({ serverUrl: fake.url });
    assert.equal(client.hasSession, false);
    await assert.rejects(client.overview(), (error) => error.code === 'invalid_session' && error.status === 401);

    const login = await client.login({ username: 'admin', password: 'correcta' });
    assert.equal(login.user.username, 'admin');
    assert.equal(login.token, undefined);
    assert.equal(client.hasSession, true);
    assert.equal(fake.state.logins[0], 'admin');

    const overview = await client.overview();
    assert.equal(overview.summary.capacity, 50000);

    const csv = await client.downloadLicensesCsv({ status: 'active', query: 'ana' });
    assert.match(csv.text, /PL-0001/);
    assert.equal(csv.filename, 'perfillab-licencias-2026-10-24.csv');
    assert.equal(csv.contentType.startsWith('text/csv'), true);

    await assert.rejects(
      client.login({ username: 'admin', password: 'incorrecta' }),
      (error) => error.status === 401 && error.code === 'invalid_credentials' && /incorrectos/.test(error.message),
    );
    await assert.rejects(
      client.issueBatch(Array.from({ length: 101 }, () => ({}))),
      (error) => error.code === 'batch_too_large',
    );
    await assert.rejects(client.licenseAction('PL-0001', 'drop-table'), /no permitida/);

    const batch = await client.issueBatch([{}, {}]);
    assert.equal(batch.issued, 2);
    assert.deepEqual(fake.state.batchSizes, [2]);

    const logout = await client.logout();
    assert.equal(logout.ok, true);
    assert.equal(client.hasSession, false);
    await assert.rejects(client.overview(), (error) => error.code === 'invalid_session');
  } finally {
    await fake.close();
  }
});

test('detecta errores de red, tiempos de espera y respuestas inválidas', async () => {
  const slow = await startFakeAdminServer({ delayMs: 150 });
  try {
    const client = new AdminApiClient({ serverUrl: slow.url, timeoutMs: 30 });
    await assert.rejects(client.health(), (error) => error.code === 'timeout');
  } finally {
    await slow.close();
  }

  const unreachable = await startFakeAdminServer();
  const deadUrl = unreachable.url;
  await unreachable.close();
  const offline = new AdminApiClient({ serverUrl: deadUrl, timeoutMs: 1000 });
  await assert.rejects(offline.health(), (error) => error.code === 'network_error');

  const fake = await startFakeAdminServer();
  try {
    const client = new AdminApiClient({ serverUrl: fake.url });
    await client.login({ username: 'admin', password: 'correcta' });
    client.request = client.request.bind(client);
    await assert.rejects(
      client.request('GET', '/api/admin/broken-json'),
      (error) => error.code === 'invalid_response',
    );
    await assert.rejects(
      client.request('GET', '/api/no-existe'),
      (error) => error.status === 404 && error.code === 'not_found',
    );
  } finally {
    await fake.close();
  }
});

test('una sesión expirada localmente se puede identificar sin red', () => {
  const client = new AdminApiClient();
  client.token = 'x'.repeat(30);
  client.user = { id: 1, username: 'admin', role: 'admin' };
  client.expiresAt = new Date(Date.now() - 1000).toISOString();
  assert.equal(client.sessionLocallyExpired(), true);
  assert.deepEqual(client.sessionInfo(), {
    authenticated: true,
    user: { id: 1, username: 'admin', role: 'admin' },
    expiresAt: client.expiresAt,
    serverUrl: 'http://127.0.0.1:45900/v1',
  });
  client.clearSession();
  assert.equal(client.sessionInfo().authenticated, false);
});
