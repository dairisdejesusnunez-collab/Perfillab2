'use strict';

const fs = require('node:fs');
const path = require('node:path');
const { test } = require('node:test');
const assert = require('node:assert/strict');

const source = fs.readFileSync(path.join(__dirname, '..', 'renderer', 'app.js'), 'utf8');

test('la consola conecta el botón Renovar con la acción de renovación', () => {
  assert.match(source, /data-action="license-renew"/);
  assert.match(source, /case 'license-renew':[\s\S]*?name === 'license-renew' \? 'renew'/);
});

test('el formulario de acciones no choca con el despachador global de clics', () => {
  assert.doesNotMatch(source, /<form id="license-action-form" data-action=/);
  assert.match(source, /<form id="license-action-form" data-operation=/);
  assert.match(source, /submitLicenseAction\(form\.dataset\.operation, form\.dataset\.id, submit\)/);
});

test('la consola expone la configuración de PayPal sin devolver el secreto', () => {
  const html = fs.readFileSync(path.join(__dirname, '..', 'renderer', 'index.html'), 'utf8');
  assert.match(html, /data-nav="payments"/);
  assert.match(source, /admin:payments:get/);
  assert.match(source, /admin:payments:save/);
  assert.match(source, /id="payments-secret"[^>]*type="password"/);
  assert.doesNotMatch(source, /value="\$\{esc\(data\.clientSecret/);
  assert.match(source, /id="payments-price-\$\{esc\(plan\.code\)\}"/);
});

test('emisión, renovación y lotes envían el plan elegido', () => {
  assert.match(source, /id="issue-plan"/);
  assert.match(source, /const plan = planField \? planField\.value : DEFAULT_PLAN/);
  assert.match(source, /id="license-action-plan"/);
  assert.match(source, /action === 'renew' && !PLAN_META\[plan\]/);
  assert.match(source, /api\('admin:licenses:action', \{ id, action, reason, plan \}\)/);
  assert.match(source, /id="batch-plan"/);
  assert.match(source, /plan: row\.values\.plan \|\| state\.batch\.plan/);
});
