'use strict';

const crypto = require('node:crypto');

const LICENSE_FORMAT = 'perfillab-license';
const LICENSE_VERSION_V1 = 1;
const LICENSE_VERSION = 2;
const CROCKFORD_ALPHABET = '0123456789ABCDEFGHJKMNPQRSTVWXYZ';
const LICENSE_KEY_RE = /^[A-Z0-9]{4}(?:-[A-Z0-9]{4}){3}$/;
const PRODUCT = 'perfillab';
const PLAN = 'annual';
const PLAN_CODES = new Set(['monthly', 'semiannual', 'annual']);
const HISTORICAL_LICENSE_LIMIT = 50000;
const REVOCATION_FORMAT = 'perfillab-revocation-list';
const REVOCATION_VERSION = 1;

class LicenseFormatError extends Error {
  constructor(message) {
    super(message);
    this.name = 'LicenseFormatError';
    this.code = 'invalid_license';
  }
}

function nowIso() {
  return new Date().toISOString();
}

function groupCode(value, size = 4) {
  const matches = String(value).match(new RegExp(`.{1,${size}}`, 'g'));
  return matches ? matches.join('-') : '';
}

function normalizeMachineCode(input) {
  const cleaned = String(input || '')
    .toUpperCase()
    .replace(/[^0-9A-Z]/g, '')
    .replace(/[IL]/g, '1')
    .replace(/O/g, '0')
    .replace(/U/g, 'V');
  if (cleaned.length !== 16) return '';
  for (const char of cleaned) {
    if (!CROCKFORD_ALPHABET.includes(char)) return '';
  }
  return groupCode(cleaned);
}

function normalizeLicenseKeyV1(input) {
  const cleaned = String(input || '')
    .toUpperCase()
    .replace(/[^0-9A-Z]/g, '')
    .replace(/[IL]/g, '1')
    .replace(/O/g, '0')
    .replace(/U/g, 'V');
  if (cleaned.length !== 16) return '';
  for (const char of cleaned) {
    if (!CROCKFORD_ALPHABET.includes(char)) return '';
  }
  return groupCode(cleaned);
}

function normalizeLicenseKey(input) {
  const cleaned = String(input || '')
    .toUpperCase()
    .replace(/[^0-9A-Z]/g, '');
  if (cleaned.length !== 16) return '';
  const grouped = groupCode(cleaned);
  return LICENSE_KEY_RE.test(grouped) ? grouped : '';
}

function licenseKeyIsValid(value) {
  return typeof value === 'string' && LICENSE_KEY_RE.test(value);
}

function canonicalPayloadV1(payload) {
  return JSON.stringify([
    'perfillab-license-v1',
    String(payload.licenseId || ''),
    String(payload.licenseKey || ''),
    Number(payload.seat || 0),
    String(payload.machineCode || ''),
    String(payload.customer || ''),
    String(payload.issuedAt || ''),
    payload.expiresAt ? String(payload.expiresAt) : null,
  ]);
}

function canonicalPayloadV2(payload) {
  return JSON.stringify([
    'perfillab-license-v2',
    String(payload.keyId || ''),
    String(payload.licenseId || ''),
    String(payload.licenseKey || ''),
    Number(payload.seat || 0),
    String(payload.machineCode || ''),
    String(payload.customer || ''),
    String(payload.product || ''),
    String(payload.plan || ''),
    String(payload.transactionId || ''),
    String(payload.issuedAt || ''),
    String(payload.startsAt || ''),
    String(payload.expiresAt || ''),
  ]);
}

function canonicalPayload(payload, version = LICENSE_VERSION) {
  return version === LICENSE_VERSION_V1 ? canonicalPayloadV1(payload) : canonicalPayloadV2(payload);
}

function publicKeyFromB64(publicKeyB64) {
  return crypto.createPublicKey({
    key: Buffer.from(publicKeyB64, 'base64'),
    format: 'der',
    type: 'spki',
  });
}

function keyIdFor(publicKeyB64) {
  return crypto.createHash('sha256').update(Buffer.from(publicKeyB64, 'base64')).digest('hex').slice(0, 16);
}

function requireDate(value, label) {
  if (typeof value !== 'string' || !value || !Number.isFinite(Date.parse(value))) {
    throw new LicenseFormatError(`${label} no es válida.`);
  }
}

function validatePayload(payload, version) {
  if (!payload || typeof payload !== 'object' || Array.isArray(payload)) {
    throw new LicenseFormatError('La licencia no contiene datos válidos.');
  }
  if (payload.machineCode !== normalizeMachineCode(payload.machineCode)) {
    throw new LicenseFormatError('El código de equipo de la licencia no es válido.');
  }
  if (!Number.isInteger(payload.seat) || payload.seat < 1 || payload.seat > HISTORICAL_LICENSE_LIMIT) {
    throw new LicenseFormatError('El número de asiento de la licencia no es válido.');
  }
  if (typeof payload.licenseId !== 'string' || !payload.licenseId || payload.licenseId.length > 80) {
    throw new LicenseFormatError('La licencia no contiene un identificador válido.');
  }
  const normalizedKey = version === LICENSE_VERSION_V1
    ? normalizeLicenseKeyV1(payload.licenseKey)
    : normalizeLicenseKey(payload.licenseKey);
  if (!normalizedKey || normalizedKey !== payload.licenseKey) {
    throw new LicenseFormatError('La clave de la licencia no es válida.');
  }
  if (typeof payload.customer !== 'string' || !payload.customer.trim() || payload.customer.length > 160) {
    throw new LicenseFormatError('La licencia no contiene un cliente válido.');
  }
  requireDate(payload.issuedAt, 'La fecha de emisión');
  if (version === LICENSE_VERSION_V1) {
    if (payload.expiresAt !== null && payload.expiresAt !== undefined) {
      requireDate(payload.expiresAt, 'La fecha de vencimiento');
    }
    return;
  }
  if (payload.product !== PRODUCT) throw new LicenseFormatError('El producto de la licencia no es válido.');
  if (!PLAN_CODES.has(payload.plan)) throw new LicenseFormatError('El plan de la licencia no es válido.');
  if (typeof payload.transactionId !== 'string' || payload.transactionId.length > 100
    || (payload.transactionId && !/^[A-Za-z0-9._:@-]+$/.test(payload.transactionId))) {
    throw new LicenseFormatError('La transacción de la licencia no es válida.');
  }
  if (typeof payload.keyId !== 'string' || !/^[a-f0-9]{16}$/.test(payload.keyId)) {
    throw new LicenseFormatError('La clave de firma de la licencia no es válida.');
  }
  requireDate(payload.startsAt, 'La fecha de inicio');
  requireDate(payload.expiresAt, 'La fecha de vencimiento');
  if (Date.parse(payload.expiresAt) <= Date.parse(payload.startsAt)) {
    throw new LicenseFormatError('El periodo de la licencia no es válido.');
  }
}

function verifyLicense(license, publicKeyB64, options = {}) {
  if (!license || typeof license !== 'object' || Array.isArray(license)) {
    throw new LicenseFormatError('El archivo no contiene una licencia válida.');
  }
  if (license.format !== LICENSE_FORMAT) {
    throw new LicenseFormatError('El formato de la licencia no es compatible.');
  }
  const version = Number(license.version);
  if (version !== LICENSE_VERSION && version !== LICENSE_VERSION_V1) {
    throw new LicenseFormatError('La versión de la licencia no es compatible.');
  }
  validatePayload(license.payload, version);
  const expectedKeyId = keyIdFor(publicKeyB64);
  if (options.keyId && options.keyId !== expectedKeyId) {
    throw new LicenseFormatError('La clave pública configurada no coincide con la esperada.');
  }
  if (version === LICENSE_VERSION && license.payload.keyId !== expectedKeyId) {
    throw new LicenseFormatError('La licencia fue firmada con otra clave.');
  }
  const signature = Buffer.from(String(license.signature || ''), 'base64');
  if (!signature.length || signature.length > 256) throw new LicenseFormatError('La licencia no está firmada.');
  let valid = false;
  try {
    valid = crypto.verify(
      null,
      Buffer.from(canonicalPayload(license.payload, version), 'utf8'),
      publicKeyFromB64(publicKeyB64),
      signature,
    );
  } catch {
    valid = false;
  }
  if (!valid) throw new LicenseFormatError('La firma de la licencia no es válida.');
  return { version, payload: license.payload };
}

function canonicalRevocationList(list) {
  const revoked = Array.isArray(list.revoked)
    ? list.revoked.slice().sort((a, b) => String(a.licenseId).localeCompare(String(b.licenseId)))
    : [];
  return JSON.stringify([
    'perfillab-revocation-list-v1',
    String(list.keyId || ''),
    String(list.issuedAt || ''),
    revoked.map((item) => [
      String(item.licenseId || ''),
      String(item.revokedAt || ''),
      String(item.reason || '').slice(0, 300),
    ]),
  ]);
}

function verifyRevocationList(list, publicKeyB64) {
  if (!list || typeof list !== 'object' || Array.isArray(list)) {
    throw new LicenseFormatError('La lista de revocación no es válida.');
  }
  if (list.format !== REVOCATION_FORMAT || Number(list.version) !== REVOCATION_VERSION) {
    throw new LicenseFormatError('La lista de revocación no tiene un formato compatible.');
  }
  const expectedKeyId = keyIdFor(publicKeyB64);
  if (list.keyId !== expectedKeyId) throw new LicenseFormatError('La lista de revocación usa otra clave.');
  requireDate(list.issuedAt, 'La fecha de la lista de revocación');
  if (!Array.isArray(list.revoked) || list.revoked.length > HISTORICAL_LICENSE_LIMIT) {
    throw new LicenseFormatError('Las revocaciones de la lista no son válidas.');
  }
  const seen = new Set();
  for (const item of list.revoked) {
    if (!item || typeof item !== 'object') throw new LicenseFormatError('La lista de revocación contiene datos no válidos.');
    if (typeof item.licenseId !== 'string' || !item.licenseId || item.licenseId.length > 80) {
      throw new LicenseFormatError('La lista de revocación contiene un identificador no válido.');
    }
    if (seen.has(item.licenseId)) throw new LicenseFormatError('La lista de revocación contiene duplicados.');
    seen.add(item.licenseId);
    requireDate(item.revokedAt, 'La fecha de revocación');
    if (item.reason !== undefined && (typeof item.reason !== 'string' || item.reason.length > 300)) {
      throw new LicenseFormatError('El motivo de revocación no es válido.');
    }
  }
  const signature = Buffer.from(String(list.signature || ''), 'base64');
  if (!signature.length || signature.length > 256) throw new LicenseFormatError('La lista de revocación no está firmada.');
  let valid = false;
  try {
    valid = crypto.verify(
      null,
      Buffer.from(canonicalRevocationList(list), 'utf8'),
      publicKeyFromB64(publicKeyB64),
      signature,
    );
  } catch {
    valid = false;
  }
  if (!valid) throw new LicenseFormatError('La firma de la lista de revocación no es válida.');
  return list;
}

module.exports = {
  LICENSE_FORMAT,
  LICENSE_VERSION,
  LICENSE_VERSION_V1,
  LICENSE_KEY_RE,
  PRODUCT,
  PLAN,
  PLAN_CODES,
  HISTORICAL_LICENSE_LIMIT,
  REVOCATION_FORMAT,
  REVOCATION_VERSION,
  LicenseFormatError,
  nowIso,
  groupCode,
  normalizeMachineCode,
  normalizeLicenseKey,
  normalizeLicenseKeyV1,
  licenseKeyIsValid,
  canonicalPayload,
  canonicalPayloadV1,
  canonicalPayloadV2,
  canonicalRevocationList,
  keyIdFor,
  verifyLicense,
  verifyRevocationList,
};
