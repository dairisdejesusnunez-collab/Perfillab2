# PerfilLab

Gestor local de perfiles de navegador aislados para Windows, construido con Electron. Cada perfil usa su propia carpeta de datos de Chromium, de modo que cookies, sesiones e historial no se mezclan entre identidades. Incluye además clonación nativa de aplicaciones de Windows: la misma aplicación abierta en dos perfiles se ejecuta como dos instancias simultáneas e independientes, cada una con su propia cuenta local de Windows, de modo que cada perfil actúa como un dispositivo nuevo, sin instalar Sandboxie ni ningún otro software de terceros. Completa el producto un proxy por perfil, espacios de trabajo, etiquetas, estados de perfil personalizables, importación/exportación JSON y CSV, operaciones masivas sobre perfiles (iniciar, detener, mover, etiquetar, asignar estado o proxy, duplicar y eliminar), comprobación masiva de proxies, una API HTTP local para automatizar tareas desde scripts y licencias firmadas vinculadas al equipo mediante un servidor central.

El proyecto incluye tres piezas independientes:

- **PerfilLab**: la aplicación que usa el cliente final. Sin una licencia válida para ese ordenador solo muestra la pantalla de activación.
- **PerfilLab Licencias**: la consola de administración. Se conecta al servidor central para iniciar sesión, emitir licencias por clave, gestionar lotes, revocaciones y pagos. No contiene la clave privada ni la base de datos de licencias y no debe entregarse a los clientes.
- **Servidor de licencias** (`license-server/`): API Node que guarda el inventario histórico de 50.000 licencias, firma con Ed25519, valida activaciones, aplica revocaciones y procesa PayPal en el despliegue central. Incluye además un **modo local Express** en `http://127.0.0.1:45900/v1` para probar y operar la consola sin Internet, PayPal ni SMTP.

PerfilLab es una implementación original. No contiene código, recursos, marcas ni binarios de Multilogin, AdsPower ni Dolphin Anty. Se inspira en el flujo de trabajo observado al analizar esas aplicaciones, pero se limita a la gestión legítima de perfiles y proxies del navegador.

## Alcance y límites

- No implementa suplantación de huellas digitales (canvas, WebGL, fuentes, audio, WebRTC, etc.).
- No incluye evasión de detección, saltos de licencias ni manipulación de sistemas de terceros.
- No modifica Windows Defender, el firewall ni crea exclusiones de seguridad.
- El aislamiento de los perfiles de navegador es el que ofrece Chromium mediante `--user-data-dir`; los perfiles comparten el sistema operativo y la red del equipo. Para que una aplicación de Windows se duplique de verdad —cada perfil como un dispositivo nuevo— PerfilLab la abre con una cuenta local exclusiva por perfil (modo **Cuenta Windows**), que separa archivos, registro (`HKCU`) y perfil de usuario; el modo **Datos aislados** solo redirige variables de entorno y no duplica la mayoría de aplicaciones. Ese aislamiento no es una barrera de seguridad frente a código malicioso ni cambia la red del equipo.
- La API local está pensada para automatización en el mismo equipo. Escucha solo en `127.0.0.1`, exige un token Bearer y rechaza peticiones con cabecera `Origin`.
- Esta herramienta no está afiliada a Multilogin ni a ningún otro producto de gestión de perfiles.

## Funciones

- Perfiles independientes con nombre, color, notas, etiquetas, URLs de inicio, espacio de trabajo y estado personalizado.
- Estados de perfil con nombre y color (hasta 30), filtro por estado y asignación individual o masiva. Al eliminar un estado, sus perfiles quedan «Sin estado».
- Navegador **PerfilLab Browser** incluido y exclusivo: el mismo ejecutable abre un navegador Chromium propio por perfil, con pestañas, barra de direcciones, historial, búsqueda en página, descargas, zoom y pantalla completa, y datos aislados en la carpeta del perfil. Todos los perfiles se abren siempre en este navegador integrado; no se detectan ni se lanzan Chrome, Edge, Brave, Chromium, Vivaldi ni ejecutables personalizados.
- Un proxy reutilizable por perfil (`http`, `https` o `socks5`) con autenticación opcional.
- Relay local para proxies autenticados: el navegador se conecta a un proxy local efímero y las credenciales no se escriben en los argumentos del proceso.
- Inicio, detención, duplicado y apertura de la carpeta de datos de cada perfil.
- Espacios de trabajo, filtros, búsqueda y ordenación de perfiles.
- Importación y exportación JSON sin contraseñas ni tokens.
- Importación y exportación CSV con BOM, comillas RFC 4180, detección de columnas por encabezado (incluidas variantes en español), creación automática de espacios de trabajo y de estados a partir de la columna **Estado**. El CSV exporta el nombre del proxy y del estado, nunca sus identificadores ni credenciales; al importar, un proxy desconocido se omite con un aviso. Los valores que empiezan por `=`, `+`, `-` o `@` se neutralizan al exportar para evitar inyección de fórmulas.
- Selección múltiple de perfiles con barra de acciones en lote: iniciar, detener, mover a un espacio, añadir/quitar/reemplazar etiquetas, asignar estado, asignar o quitar proxy, duplicar, exportar, probar los proxies usados y eliminar con confirmación. Cada operación devuelve el resultado por perfil, omite los que ya estaban en ese estado y continúa aunque uno falle. La eliminación masiva exige confirmar por separado las cuentas de Windows clon y las máquinas virtuales Hyper-V afectadas, y los datos del navegador solo se borran si se marca esa casilla.
- Comprobación masiva de proxies con hasta 50 elementos por lote y 4 comprobaciones simultáneas, conservando el orden y resumiendo aciertos y fallos.
- Historial de actividad local.
- API HTTP local con token, para crear y operar perfiles y proxies.
- Temas claro, oscuro y del sistema; bandeja del sistema y cierre opcional a la bandeja.
- Almacenamiento de contraseñas de proxy y token de la API con `safeStorage` de Electron cuando el sistema lo permite.
- Biblioteca de aplicaciones de Windows: detección del menú Inicio, ejecutables supervisados, favoritos y apertura con los datos del perfil elegido.
- Clonación nativa de aplicaciones de Windows por perfil, sin software de terceros: cada perfil abre la aplicación con su propia cuenta local de Windows (predeterminado) y se comporta como un dispositivo nuevo; también admite máquina virtual Hyper-V por perfil, datos redirigidos o sin aislamiento, con proceso supervisado y cierre de todo el árbol de procesos. Las máquinas virtuales se crean en Hyper-V con un disco diferencial por perfil; PerfilLab no incluye ni descarga imágenes de Windows.
- Licencias firmadas con Ed25519, vinculadas al código de equipo, con activación en línea, comprobación periódica y caché firmada de revocaciones.
- Inventario histórico de **50.000 licencias únicas** (las 2.000 heredadas se migran sin perder claves emitidas); las licencias revocadas o vencidas siguen contando para el límite y nunca se reutilizan.
- Consola de administración conectada al servidor de licencias: emisión individual y por lotes con progreso, búsqueda, detalle, renovación, revocación, suspensión, reactivación, reinicio de activación, exportación CSV y auditoría.
- Tienda con PayPal y tres planes (mensual, semestral y anual): el servidor crea la orden con el importe del plan elegido, verifica el pago con la API oficial de PayPal (webhook firmado o conciliación directa de la captura) y solo entonces emite la licencia. Ningún dato del navegador autoriza la emisión.

## Requisitos

- Windows 10 u 11 de 64 bits.
- No hace falta instalar Chrome, Edge, Brave, Chromium, Vivaldi ni ningún otro navegador: PerfilLab Browser viene incluido.
- Windows 10 u 11 de 64 bits con Windows PowerShell 5.1 (`Get-LocalUser`/`New-LocalUser`). No hace falta instalar Sandboxie ni ningún software de terceros.
- Las aplicaciones `.exe` se abren en modo **Cuenta Windows** de forma predeterminada, para que cada perfil sea un dispositivo nuevo. Ese modo pide una aprobación de UAC por cada cuenta de perfil nueva (una sola vez). El modo **Datos aislados** no pide UAC pero no duplica la mayoría de aplicaciones.
- **Máquina virtual (opcional)**: requiere Hyper-V habilitado (Windows 10/11 Pro, Enterprise o Education), el servicio `vmms` en ejecución y una imagen base `.vhdx` propia instalada por el usuario. PerfilLab no crea, descarga ni activa imágenes de Windows; sin una `.vhdx` válida el modo no se puede usar. Hyper-V no está pensado para evadir controles antifraude ni sustituye una licencia de Windows por máquina virtual.
- Node.js 24 o superior para el servidor central. Para el cliente y la consola basta Node.js 20 o superior.
- Para producción: PostgreSQL gestionado (o un servidor propio), HTTPS, una cuenta de PayPal con credenciales del panel de desarrolladores y un lugar seguro para el keystore (secreto base64 o disco persistente). SQLite queda para el modo local y desarrollo.

Probado con Electron 40 y Node.js 24/26 en Windows 10/11. El servidor se probó en Windows; en Linux requiere Node.js 24 o posterior.

## Puesta en marcha

Cliente:

```bash
npm install
npm start
```

En desarrollo la licencia no es obligatoria. Para probar el bloqueo igual que en la versión empaquetada, inicia con `PERFILLAB_REQUIRE_LICENSE=1` (PowerShell: `$env:PERFILLAB_REQUIRE_LICENSE='1'; npm start`). Las versiones empaquetadas siempre exigen licencia y ignoran los atajos de desarrollo.

Servidor local de licencias (primera vez, sin Internet ni pagos):

```bash
cd license-server
npm install
npm run init
npm run admin -- create --username admin
npm run local
```

`npm run init` recibe la bóveda heredada con las 2.000 licencias, la migra a un inventario de 50.000 asientos y crea el keystore cifrado con la clave de firma. La contraseña de la bóveda heredada se pasa por `PERFILLAB_VAULT_PASSWORD_FILE` o se solicita de forma oculta; no se escribe en el código. No hay usuario ni contraseña universales: crea el primer administrador con `npm run admin -- create`. El servidor local escucha únicamente en `http://127.0.0.1:45900/v1`, desactiva PayPal/SMTP y conserva firmas Ed25519 reales. Guía completa: [`license-server/docs/SERVIDOR_LOCAL.md`](license-server/docs/SERVIDOR_LOCAL.md).

> El servidor local de licencias y la consola administrativa usan el puerto **45900**. La API de perfiles del cliente PerfilLab usa **45800** y no se solapan. El backend de licencias permite cambiarlo con `PERFILLAB_LOCAL_PORT`.

Servidor central (producción):

```bash
cd license-server
npm install
cp .env.example .env
# Completa la URL de PostgreSQL, la frase del keystore, PayPal y SMTP.
npm run init
npm start
```

En producción se exige `PERFILLAB_DATABASE_URL` (PostgreSQL); SQLite solo sigue disponible con `PERFILLAB_ALLOW_SQLITE=true` para desarrollo o hosts con disco persistente. El keystore se puede cargar desde `PERFILLAB_KEYSTORE_BASE64`, pensado para servicios cuyo disco se borra al reiniciar. La tienda sirve el instalador configurado con `PERFILLAB_INSTALLER_URL` o `PERFILLAB_INSTALLER_PATH`; el cliente lo descarga en `/descargar` y la licencia se sigue comprando aparte.

La ruta recomendada para publicarlo es **Supabase + Render**: Supabase aporta PostgreSQL gestionado y Render ejecuta el contenedor con HTTPS. El blueprint [`render.yaml`](render.yaml) crea el servicio, fija el health check en `/api/health` y deja los secretos fuera del repositorio. La base remota se puede crear clonando la base local completa con `scripts/clone-to-postgres.js` (50.000 asientos, administrador, licencias y pedidos, sin bóveda) o inicializándola desde la bóveda con `scripts/init.js`. En Supabase el servidor activa RLS automáticamente para que la Data API no lea las tablas. La guía paso a paso, incluida la inicialización remota, el keystore como secreto y el endpoint del cliente, está en [`license-server/docs/DESPLIEGUE_SUPABASE_RENDER.md`](license-server/docs/DESPLIEGUE_SUPABASE_RENDER.md).

El procedimiento general, incluido HTTPS, PayPal Sandbox y restauración, está en [`license-server/docs/OPERACIONES.md`](license-server/docs/OPERACIONES.md). Para otros proveedores con PostgreSQL gestionado y secretos por entorno, sigue [`license-server/docs/DESPLIEGUE_ONLINE.md`](license-server/docs/DESPLIEGUE_ONLINE.md). Después de iniciar sesión como administrador, abre **Pagos** en la consola para configurar la cuenta de PayPal que recibe los cobros, el webhook y los precios de los tres planes; las variables de entorno siguen disponibles como respaldo.

Antes de compilar los instaladores que verán los clientes, fija el endpoint remoto con `npm run license:endpoint -- --server-url=https://<tu-servicio>` y vuelve a ejecutar `npm run installers`. Sin ese paso, el cliente cae en `http://127.0.0.1:45900` y la activación en línea falla; la importación de un archivo de licencia firmado sigue funcionando.

Consola de administración:

```bash
npm run admin
```

Al abrirla, la dirección predeterminada es `http://127.0.0.1:45900/v1` y **Probar conexión** solo consulta `/v1/health`, sin iniciar sesión. Para el servidor central escribe su URL HTTPS (raíz). Las credenciales son las de un administrador creado con `license-server/scripts/admin.js`.

Para pruebas automatizadas:

```bash
npm run smoke
npm run smoke -- --browser
npm run test:license
npm run test:clone
npm run test:manage
npm run test:browser
npm run test:ui-clone
npm run test:ui-browser
npm run verify:installers
cd license-server && npm test
cd license-admin && npm test
```

`npm run smoke` ejecuta 26 comprobaciones de almacenamiento, CRUD, estados de perfil, import/export JSON y CSV, operaciones masivas, prueba masiva de proxies, validación y API local sin abrir navegadores; con `--browser` añade el inicio y la detención reales de un navegador (27 comprobaciones). `npm run test:license` ejecuta 18 comprobaciones del código de equipo, licencias v1/v2, firmas, caducidad, límite de asientos, revocaciones, endpoint HTTPS y persistencia. `npm run test:clone` ejecuta 43 comprobaciones del motor nativo, la generación de credenciales, los scripts elevados, el lanzamiento por cuenta, datos y máquina virtual, el redireccionamiento de entorno, las ACL, los conflictos de instancia, la migración al esquema v5/v6/v7 y los estados de perfil, el proveedor Hyper-V (nombres deterministas, capacidades, límites, cancelación de UAC y parada de todas las VM) y la compilación real del lanzador C# con el error de inicio de sesión de Windows. `npm run test:manage` ejecuta 12 comprobaciones del parser CSV (RFC 4180, BOM, comillas, fórmulas), la importación con espacios, proxies y estados por nombre, nombres ambiguos, la exportación sin credenciales, el CRUD de estados, las acciones masivas de etiquetas, estado, proxy, duplicado y eliminación con salvaguardas, y la prueba masiva de proxies con concurrencia limitada. `npm run test:ui-clone` abre PerfilLab por CDP, comprueba los cuatro modos de clonación y la tarjeta de Hyper-V, el diagnóstico del sistema, el estado de la cuenta preparada, lanza una aplicación en modo datos y verifica que `%APPDATA%` se escribe dentro de la carpeta del perfil, prueba los ajustes y el bloqueo de borrado de un perfil con cuenta, y verifica la selección múltiple, los modales de movimiento, etiquetas, estado, proxy, duplicado y eliminación, el filtro y la tarjeta de estados, los selectores de formato JSON/CSV, la prueba masiva de proxies y los endpoints de lote y de estados en la vista de API; guarda capturas en `build/`. `npm run test:ui-browser` abre PerfilLab Browser por CDP y verifica el cromo propio, navegación, atrás/adelante, búsqueda (con respaldo DOM), zoom, descarga, pestaña emergente, página de error, pantalla completa, aislamiento y persistencia de datos por perfil, y la pantalla de bloqueo sin licencia. `npm run verify:installers` instala y desinstala ambos instaladores en silencio, audita el contenido y comprueba el arranque real del cliente y de la consola. `npm test` del servidor ejecuta 45 pruebas de migración, emisión, activación, renovación, revocación, lotes, planes, configuración cifrada de PayPal, PayPal simulado, correo, API local `/v1` (autenticación, permisos, operaciones, auditoría y respuestas uniformes), validación de PostgreSQL/entorno y HTTPS, keystore base64 y descarga verificada del instalador. La consola administrativa se prueba con `cd license-admin && npm test` (9 comprobaciones del cliente HTTP y de las acciones de la interfaz).

> Las pruebas del clonador no crean cuentas reales ni máquinas virtuales: la creación de una cuenta local o de una VM requiere aprobar el aviso de UAC del escritorio seguro, que no se puede automatizar sin reducir la seguridad del equipo. La suite sí compila el lanzador C# con Windows PowerShell y comprueba contra Windows el error real de inicio de sesión (1326) con una cuenta inexistente; el proveedor Hyper-V se prueba con PowerShell simulado y nunca toca `vmms`. El arnés UI verifica una cuenta ya preparada y el modo datos de extremo a extremo. En un equipo con Windows, crea una cuenta desde la interfaz y confirma que el diálogo de UAC aparece una sola vez; luego abre y cierra la aplicación para validar el modo cuenta. Para el modo VM, instala Hyper-V, prepara una imagen base `.vhdx` apagada, elígela en **Ajustes → Máquinas virtuales** y confirma que la primera operación pide UAC y que `vmconnect` abre la ventana del invitado.

Para empaquetar sin instalador (desarrollo y depuración):

```bash
npm run pack
npm run pack:admin
```

Los resultados quedan en `build/PerfilLab-win32-x64/PerfilLab.exe` y `build/PerfilLab Licencias-win32-x64/PerfilLab Licencias.exe`. Si una instancia empaquetada bloquea la carpeta, usa `PERFILLAB_PACK_OUT=<ruta>`. El comando heredado `npm run pack:installer` sigue generando un ZIP del cliente, pero los entregables recomendados son los instaladores siguientes.

### Instaladores de Windows (cliente y consola)

Los instaladores reales se compilan con [Inno Setup 6](https://jrsoftware.org/isinfo.php). `ISCC.exe` debe estar en `Program Files (x86)\Inno Setup 6` o indicarse con `PERFILLAB_ISCC`.

```bash
npm run installers
npm run verify:installers
```

`npm run installers` empaqueta y audita ambos productos y genera:

- `dist/PerfilLab-Setup-<versión>.exe`: cliente PerfilLab. No incluye la consola, el servidor, `.env`, la bóveda, el keystore, pruebas, scripts ni secretos.
- `dist/PerfilLab-Licencias-Setup-<versión>.exe`: consola administrativa. No incluye el cliente, el servidor, PostgreSQL, `.env`, la bóveda, el keystore ni secretos.
- `dist/installers.json` y `dist/SHA256SUMS.txt`: versión, tamaño y SHA-256 de cada artefacto.

Ambos son instaladores por usuario (`PrivilegesRequired=lowest`), x64, con accesos directos opcionales y desinstalador. Aceptan instalación y desinstalación silenciosa:

```powershell
.\PerfilLab-Setup-1.1.1.exe /VERYSILENT /SUPPRESSMSGBOXES /NORESTART /NOCANCEL /LOG=C:\ruta\cliente.log /DIR=C:\ruta\PerfilLab
```

`npm run verify:installers` instala ambos en silencio en una carpeta temporal, audita el contenido instalado, abre el cliente en modo activación, abre la consola y comprueba que apunta a `http://127.0.0.1:45900/v1`, y los desinstala. Los registros y una captura quedan en `build/installer-check/`.

Los instaladores no están firmados digitalmente: Windows SmartScreen puede mostrar una advertencia hasta que se firmen con un certificado de código. Ningún instalador contiene la clave privada ni apunta a un dominio inventado.

### Endpoint de licencias configurable

El cliente y la consola apuntan por defecto al servidor local `http://127.0.0.1:45900` (la consola usa `http://127.0.0.1:45900/v1`). Para un servidor remoto se exige HTTPS; HTTP solo se acepta en `localhost`, `127.0.0.0/8` y `::1`.

Cliente PerfilLab, por orden de prioridad:

1. `PERFILLAB_LICENSE_SERVER=https://licencias.<tu-dominio>` en el proceso; no se guarda.
2. La dirección guardada en `%LOCALAPPDATA%\PerfilLab\license-config.json`, escrita desde la pantalla de activación.
3. El valor compilado en `electron/license-public.js` (`serverUrl`), vacío hoy para usar el servidor local.

Para grabar el endpoint en el ejecutable antes de empaquetar:

```bash
npm run license:endpoint -- --server-url=https://licencias.<tu-dominio>
npm run installers
```

`--clear` borra el valor compilado. El comando conserva la clave pública y el límite de asientos; cambiar la clave pública invalida las licencias emitidas y no forma parte de esta operación.

Consola PerfilLab Licencias, por orden de prioridad:

1. La dirección guardada en `%APPDATA%\PerfilLab Licencias\admin-config.json` (solo se persiste la URL).
2. `PERFILLAB_LICENSE_SERVER=https://licencias.<tu-dominio>` al arrancar.
3. El valor predeterminado `http://127.0.0.1:45900/v1`.

El token administrativo vive solo en memoria. El proyecto no incluye ningún dominio, credencial ni despliegue real; los requisitos de producción están en [`license-server/docs/DESPLIEGUE_ONLINE.md`](license-server/docs/DESPLIEGUE_ONLINE.md).

## Dónde se guardan los datos

Por defecto, la base local y los perfiles se guardan en:

```text
%LOCALAPPDATA%\PerfilLab\
  data.json
  profiles\<id-del-perfil>\
    applications\<id-de-aplicación>\   APPDATA/LOCALAPPDATA/TEMP del modo datos
  native-clone\                        Solicitudes temporales del proceso elevado
  hyperv-operations\                   Solicitudes temporales de Hyper-V (se eliminan al terminar)
  vms\                                 Discos diferenciales y carpetas de VM (ruta configurable)
```

Se puede cambiar la ubicación de la base con la variable de entorno `PERFILLAB_DATA_DIR` o la carpeta de perfiles desde Ajustes. Las carpetas de perfiles existentes conservan su ruta. Las cuentas de clon y sus credenciales cifradas se guardan en `data.json`; los archivos temporales de `native-clone\` y `hyperv-operations\` se crean solo durante una operación y se eliminan al terminar. Los discos de las máquinas virtuales se guardan en `vms\` o en la carpeta elegida en Ajustes, nunca dentro del paquete de la aplicación.

Las contraseñas de proxy se guardan cifradas con el almacén seguro del sistema. Si `safeStorage` no está disponible, PerfilLab avisa en Actividad y usa un formato ofuscado en base64, no cifrado. Las exportaciones nunca incluyen contraseñas ni el token de la API.

La licencia activada se guarda en `%LOCALAPPDATA%\PerfilLab\license.json`; la caché firmada de revocaciones en `license-revocations.json` y la dirección elegida del servidor en `license-config.json`. Si se elimina `license.json`, la aplicación vuelve a la pantalla de activación.

## Clonación de aplicaciones de Windows

PerfilLab puede abrir una aplicación `.exe` como un clon separado por perfil. No usa Sandboxie ni controladores de terceros: aprovecha cuentas locales, variables de entorno de Windows o Hyper-V. Cada aplicación elige uno de cuatro modos desde su editor; el predeterminado es **Cuenta Windows**, que duplica la aplicación sin crear máquinas virtuales.

### Modos

- **Cuenta Windows (predeterminado, aislamiento real por perfil)**: crea una cuenta local estándar exclusiva para el perfil y abre la aplicación con `CreateProcessWithLogonW` y `LOGON_WITH_PROFILE`. Al tener su propio usuario de Windows, la misma aplicación abierta en dos perfiles se ejecuta como dos instancias simultáneas: cada perfil es un dispositivo nuevo. La aplicación usa su propio `HKCU`, `%USERPROFILE%`, `%APPDATA%`, `%LOCALAPPDATA%` y `%TEMP%`. Se pide UAC una vez al preparar la cuenta; después se abre sin elevar. Requiere que `safeStorage` pueda cifrar la credencial.
- **Datos aislados (limitado)**: sin UAC ni cuentas. Redirige `APPDATA`, `LOCALAPPDATA`, `TEMP` y `TMP` a `profiles/<perfil>/applications/<aplicación>/` y ejecuta con el usuario actual. No separa `HKCU`, así que la mayoría de aplicaciones (Electron, Chromium, ofimática, etc.) siguen leyendo su carpeta de datos del registro y **no se duplican**: solo sirve para programas que respetan las variables de entorno. Para que cada perfil sea un dispositivo nuevo, usa **Cuenta Windows**.
- **Sin aislamiento**: abre con el usuario actual y su entorno, solo con supervisión de procesos.
- **Máquina virtual Hyper-V (aislamiento máximo)**: enciende una VM de Hyper-V exclusiva del perfil y abre su ventana con `vmconnect.exe`. Cada VM tiene su propia sesión de Windows, su propio disco y su propio entorno de red, así que también separa aplicaciones de instancia única que la cuenta local no puede duplicar (por ejemplo, Spotify). La identidad concreta del sistema (nombre de equipo, SID, licencia) depende de cómo se haya preparado la imagen base; PerfilLab no la generaliza ni la activa. Requiere Hyper-V habilitado, una imagen base `.vhdx` y UAC para cada operación de Hyper-V. La aplicación se abre **dentro de la VM**, no en el equipo anfitrión.

Las entradas del menú Inicio no se pueden aislar: Windows controla el proceso y PerfilLab no puede supervisarlo ni detenerlo. Se abren en modo sin aislamiento.

Al actualizar desde una versión anterior al esquema v5, las aplicaciones que estaban en **Datos aislados** pasan a **Cuenta Windows** para que se dupliquen de verdad; solo se conserva **Datos aislados** si el usuario lo vuelve a elegir a propósito. El esquema v6 añade el modo **Máquina virtual**, conserva los modos `data` y `account` ya elegidos y registra las VM creadas por perfil. El esquema v7 añade los estados de perfil personalizados (`profileStatuses`) y el campo `statusId` de cada perfil; los perfiles existentes quedan sin estado y se crean tres estados de ejemplo («Nuevo», «En uso», «Pausado») la primera vez. El esquema v4 y anteriores ya habían descartado la configuración de cajas y la ruta de Sandboxie. No se borra ninguna carpeta de Sandboxie del equipo.

### Máquinas virtuales Hyper-V

- La configuración vive en **Ajustes → Máquinas virtuales**: imagen base `.vhdx` (obligatoria), conmutador virtual, memoria (1–32 GB, 4 GB por defecto), CPUs (1–16, 2 por defecto), generación (1 o 2) y carpeta de discos. La imagen base debe ser una instalación de Windows apagada y preparada por el usuario; PerfilLab no crea ni descarga imágenes, ISO ni claves de Windows.
- Cada perfil recibe un nombre determinista `PL-<12 hex>` y un disco diferencial `.vhdx` cuyo padre es la imagen base. La primera vez se crea la VM con `New-VM`, se configura la memoria dinámica, la CPU, el conmutador y se desactivan los puntos de control; las siguientes veces se reutiliza la misma VM. Solo puede existir una VM por perfil.
- **Encender** combina la creación o comprobación de la VM y su arranque en una sola solicitud elevada, y abre la ventana con `vmconnect.exe`. Si se cancela UAC no se crea, arranca ni detiene nada.
- Cerrar la ventana de `vmconnect` no apaga la VM: la sesión de PerfilLab termina, la actividad lo indica y la máquina sigue encendida en Hyper-V. Puedes volver a pulsar **Encender** para reconectarte. **Detener** guarda el estado de la VM (`Stop-VM -Save`) y usa apagado forzado solo si Windows no puede guardarlo.
- Al salir de PerfilLab se detienen las VM cuya ventana de conexión sigue abierta (con confirmación y UAC). Las VM cuya ventana se cerró antes dejan de supervisarse y siguen encendidas hasta que las apagues desde Hyper-V o vuelvas a PerfilLab; si falla la detención, la aplicación ofrece salir de todos modos y avisa de que seguirán encendidas.
- Eliminar un perfil con VM exige marcar la casilla del diálogo de borrado; se elimina la VM y su disco diferencial. La imagen base nunca se modifica ni se borra.
- **Límites**: cada VM necesita su propia licencia de Windows, consume RAM y disco reales y no tiene aceleración gráfica. PerfilLab no instala ni abre la aplicación dentro de la VM, no comparte archivos con el invitado y no oculta el uso de Hyper-V: algunas aplicaciones y sistemas antifraude pueden detectar que se ejecutan en una máquina virtual. Hyper-V requiere edición Pro o superior y no está disponible en Windows Home de forma oficial.
- **Estado de verificación**: el proveedor, el esquema, el lanzador, el IPC y la interfaz están implementados y cubiertos por pruebas con PowerShell simulado. En este equipo no hay ninguna imagen `.vhdx`, así que la creación, el arranque y la conexión reales **no se verificaron de extremo a extremo**; la primera prueba real requiere que el usuario instale Hyper-V, prepare una imagen base y apruebe UAC.

### Lanzamiento y cierre

### Cuentas por perfil

- Nombre determinista `PL_<12 hex>` derivado del ID del perfil; descripción `PerfilLab clon <8 hex>`. La cuenta es estándar, nunca administradora.
- Al abrir una aplicación en modo cuenta sin tener la cuenta preparada, PerfilLab la crea automáticamente antes de lanzar (una sola aprobación de UAC); después, la misma aplicación en otro perfil se abre como una instancia nueva, sin UAC adicional.
- Contraseña aleatoria de 24 caracteres generada en el proceso principal y cifrada con `safeStorage` (formato `enc1:`; `plain1:` solo si el sistema no ofrece cifrado). Nunca aparece en el estado público, las exportaciones, los registros ni los resultados IPC, y no se escribe en la línea de comandos.
- La preparación exige Windows PowerShell 5.1 con los cmdlets `Get-LocalUser`/`New-LocalUser`. **Ajustes → Clonador nativo** y la vista Aplicaciones muestran el diagnóstico (PowerShell, cuentas locales, UAC y si el proceso es elevado).
- La creación y la eliminación se ejecutan en un proceso elevado con `Start-Process -Verb RunAs`. La contraseña viaja por un archivo temporal de solicitud y por la entrada estándar del proceso elevado, nunca por `argv`. Si se cancela UAC no se crea ni se modifica nada; los archivos temporales se eliminan.
- Antes de lanzar, PerfilLab concede a la cuenta del clon lectura y ejecución (`icacls`) sobre el ejecutable y la carpeta de trabajo cuando están dentro de la carpeta del usuario. Las rutas de `Program Files` se omiten porque ya son legibles y la carpeta personal raíz se rechaza para no conceder acceso a todo el perfil.
- Eliminar un perfil con cuenta exige confirmar la liberación de la cuenta en el diálogo de borrado. La liberación elimina la cuenta local y su carpeta de perfil; si Windows no puede borrar la carpeta, se conserva el aviso para limpiarla manualmente.

### Lanzamiento y cierre

- Cada combinación perfil+aplicación admite una sola instancia en modo cuenta; la segunda se rechaza con un aviso.
- La aplicación se inicia heredando el escritorio interactivo del usuario (no se fija `winsta0\default`, que provoca el error `0xc0000142`) dentro de un trabajo (job object) configurado para terminar sus procesos al cerrar la sesión. PerfilLab supervisa el proceso y, al pulsar **Detener**, cierra el árbol completo.
- El editor de la aplicación muestra el modo elegido y, en modo cuenta, si la cuenta está preparada, su nombre y si la credencial es legible. El historial de Actividad registra el lanzamiento sin secretos.
- Si la aplicación necesita elevación dentro de la cuenta (por ejemplo, un instalador), el modo cuenta no la eleva automáticamente: usa **Sin aislamiento** o ejecútala manualmente. PerfilLab no desactiva UAC, Defender, el firewall ni crea exclusiones.

### Límite de seguridad

La cuenta local separa archivos, registro (`HKCU`) y carpetas de usuario entre perfiles; el modo **Datos aislados** solo redirige variables de entorno y no separa el registro. Ninguno de los dos es un sandbox de seguridad: la aplicación sigue ejecutándose en el mismo equipo, comparte la red y puede leer los archivos a los que su cuenta tenga acceso. No uses este aislamiento para ejecutar software no confiable. PerfilLab no promete ocultar la identidad del equipo ni evadir controles de seguridad.

## Licencias y servidor central

El servidor genera un par **Ed25519** al inicializarse. La clave privada queda cifrada en un keystore AES-256-GCM con derivación scrypt y nunca se incluye en los ejecutables, en la consola de administración ni en el cliente. El cliente fija la clave pública y su `keyId`; rechaza cualquier licencia firmada con otra clave, aunque el usuario cambie la dirección del servidor.

### Identificadores y límite

- El código de equipo es un valor estable de 16 caracteres derivado de `MachineGuid` y un hash SHA-256, con formato `XXXX-XXXX-XXXX-XXXX`.
- Las claves siguen `^[A-Z0-9]{4}(-[A-Z0-9]{4}){3}$` y se generan con aleatoriedad criptográfica en el servidor. El formato se valida antes de la firma, pero la firma, la fecha y el estado son los que autorizan la licencia.
- El inventario tiene **50.000 asientos históricos únicos**. Las 2.000 licencias heredadas se migran conservando sus claves; las revocadas y vencidas siguen ocupando su asiento y no se reutilizan. Al agotar el cupo no se emite ninguna licencia nueva.
- Cada licencia incluye ID único, clave, asiento, producto, plan (mensual, semestral o anual), fechas de emisión, inicio y vencimiento, estado, cliente, transacción, equipo vinculado, versión y firma. La vigencia es de **1, 6 o 12 meses** según el plan y no se renueva automáticamente.
- Estados: `pending` (sin equipo), `active`, `expired`, `revoked` y `suspended`. Una licencia pendiente pasa a activa cuando el cliente la activa con su código de equipo. Un equipo no puede tener dos licencias activas.

### Activación y comprobación

1. El cliente abre PerfilLab y copia **Tu código de equipo**.
2. En **PerfilLab Licencias**, el administrador emite una licencia. Puede vincularla ya a ese código o dejarla pendiente para que se vincule al activarla. La clave se muestra una vez y queda auditada.
3. El cliente escribe la clave completa en la pantalla de activación y pulsa **Activar licencia**. El servidor comprueba clave, estado, equipo y fechas; devuelve un sobre v2 firmado que el cliente verifica con la clave pública fijada y guarda de forma atómica.
4. Si el servidor no está disponible, se puede importar un archivo o texto de licencia firmado. La licencia guardada sigue vigente hasta su vencimiento y el cliente avisa del estado sin conexión.
5. Con conexión, el cliente consulta el servidor al arrancar y cada 15 minutos mientras permanece abierto. La caché de revocaciones también está firmada. Una licencia revocada o suspendida deja de estar activa en la siguiente comprobación; si el equipo está permanentemente sin conexión, la revocación no puede aplicarse hasta que vuelva a estarlo.
6. La app se bloquea si la licencia vence, se revoca, se suspende, pertenece a otro equipo o la firma no es válida. Al recuperar el servidor puede reactivarse desde el panel de administración o reiniciarse la activación para vincular otro equipo.

La verificación offline reduce la dependencia del servidor, pero no es una garantía antimanipulación: un usuario con control total del equipo puede alterar el reloj o el sistema. La licencia evita el uso casual en otro ordenador y permite revocar accesos, no protege frente a un atacante con control administrativo del equipo.

### Consola de administración

La consola no guarda la bóveda ni la clave privada. Se conecta al servidor de licencias (por defecto `http://127.0.0.1:45900/v1`, o la URL HTTPS del servidor central), inicia sesión con un usuario administrador y mantiene el token Bearer solo en memoria; al cerrar la consola hay que volver a iniciar sesión. Solo persiste la dirección del servidor en `%APPDATA%\PerfilLab Licencias\admin-config.json`.

Operaciones disponibles: emisión individual, emisión por lotes con progreso y reintentos, búsqueda y filtros, detalle con clave y archivo firmado, renovación según plan, revocación, suspensión, reactivación, reinicio de activación, reenvío de correo, exportación CSV, pedidos, auditoría, configuración de PayPal y precios, y copia de seguridad del servidor. Los administradores se crean y gestionan con `license-server/scripts/admin.js`; cada acción queda registrada en auditoría.

### Planes, PayPal y entrega

- La tienda ofrece tres planes de pago único: **Mensual (10 USD / 1 mes)**, **Semestral (50 USD / 6 meses)** y **Anual (100 USD / 12 meses)**. Ninguno se renueva automáticamente.
- En **PerfilLab Licencias → Pagos**, un administrador configura la cuenta de PayPal que recibe los cobros (Client ID, Client Secret y Webhook ID), el modo Sandbox/Live y el precio de cada plan. El precio se valida y se aplica solo en el servidor; nunca se acepta desde el navegador.
- El Client Secret se guarda cifrado con AES-256-GCM en la base del servidor y no se devuelve a la consola ni se escribe en registros. Si no hay configuración guardada, se usan las variables de entorno como respaldo.
- El servidor crea la orden de PayPal con el importe del plan elegido. El modo **Sandbox** es el valor predeterminado; para producción se activa el modo **live** con HTTPS obligatorio.
- La licencia solo se emite después de verificar el pago con PayPal: autenticidad del webhook, importe, moneda, producto, plan, orden y ausencia de duplicados, o la misma conciliación directa de la captura. El regreso del navegador a la página de éxito solo consulta el estado; no autoriza la emisión.
- La entrega se encola por SMTP si está configurado. La clave también queda disponible en la consola para entrega manual por un canal seguro.
- No se inventan credenciales, identificadores de aplicación ni secretos. Las credenciales de PayPal y SMTP viven solo en el servidor.

### Secretos y datos sensibles

- No se guardan claves privadas en el código fuente, en el cliente, en la consola de administración, en los instaladores, en archivos de configuración del cliente ni en registros.
- La frase de paso del keystore se entrega por variable de entorno o archivo con permisos restringidos; no se registra. La contraseña inicial de la bóveda heredada está en `perfillab-admin-password.txt`, fuera del proyecto y de los paquetes, y debe custodiarse por separado.
- `license-admin/seed/vault.json` es la bóveda heredada de 2.000 asientos y solo se usa una vez al inicializar el servidor. Está excluida de ambos paquetes; no la distribuyas ni la confirmes en un repositorio público.
- La base del servidor cifra las claves de licencia con una clave de datos del keystore. El Client Secret de PayPal configurado desde la consola se guarda cifrado con AES-256-GCM y nunca se devuelve al cliente administrativo. Las copias de seguridad contienen datos personales y deben cifrarse y almacenarse por separado de la frase de paso.

### Copia, restauración, rotación y compromiso

El procedimiento operativo completo está en [`license-server/docs/OPERACIONES.md`](license-server/docs/OPERACIONES.md). Resumen:

- **Copia**: `npm run backup` crea una copia consistente de la base (volcado `pg_dump` con PostgreSQL o `VACUUM INTO` con SQLite) y del keystore con hashes SHA-256. En un plan gratuito descarga la copia fuera del servicio. Guarda la frase de paso del keystore en un medio distinto.
- **Restauración**: detén el servidor, restaura la base y el keystore del mismo periodo, arranca y verifica `/api/health`, el `keyId` y una activación de prueba.
- **Rotación del keystore**: `npm run rotate-keystore` re-cifra el keystore conservando la clave privada y la clave de datos, con una copia previa verificable. La rotación de la clave de firma requiere publicar un cliente nuevo con la nueva clave pública fijada y reemitir las licencias; no se puede hacer solo en el servidor sin romper a los clientes existentes.
- **Compromiso**: si se sospecha que la clave privada quedó expuesta, revoca las licencias afectadas, rota la clave de firma en una instalación nueva, publica un cliente con la nueva clave pública y comunica el cambio. La lista de revocaciones firmada por la clave comprometida no basta por sí sola: hay que actualizar la clave fijada en el cliente.

Advertencias adicionales:

- No distribuyas **PerfilLab Licencias**, la frase de paso del keystore, `keystore.json`, la base de datos ni la clave privada. Quien los tenga puede emitir licencias y comprometer el inventario.
- Si pierdes la frase de paso, el keystore y las copias no permiten firmar; no hay recuperación. Custodia ambos por separado.
- Regenerar claves con `node scripts/provision-license.js --force` invalida todas las licencias ya emitidas y cambia la clave pública del cliente.

## API local (cliente)

Actívala en **API local**, elige el puerto (45800 por defecto) y copia el token. La dirección base es:

```text
http://127.0.0.1:45800/v1
```

Todas las peticiones deben incluir:

```http
Authorization: Bearer <token>
```

Ejemplos:

```bash
# Estado de la API
curl -H "Authorization: Bearer $TOKEN" http://127.0.0.1:45800/v1/health

# Crear un perfil
curl -X POST http://127.0.0.1:45800/v1/profiles \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"name":"Cuenta demo","startUrls":["https://example.com"]}'

# Iniciar y detener un perfil
curl -X POST http://127.0.0.1:45800/v1/profiles/<id>/start \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" -d '{}'

# Operar varios perfiles a la vez (máximo 50)
curl -X POST http://127.0.0.1:45800/v1/profiles/batch \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"action":"move","profileIds":["<id1>","<id2>"],"workspaceId":"<workspace>"}'

# Crear un estado y asignarlo en lote
curl -X POST http://127.0.0.1:45800/v1/statuses \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"name":"En revisión","color":"#f59e0b"}'

curl -X POST http://127.0.0.1:45800/v1/profiles/batch \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"action":"set-status","profileIds":["<id1>","<id2>"],"statusId":"<status>"}'

# Probar todos los proxies, o solo los indicados
curl -X POST http://127.0.0.1:45800/v1/proxies/test \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" -d '{}'
```

Endpoints principales:

| Método | Ruta | Uso |
| --- | --- | --- |
| GET | `/v1/health` | Comprobar que la API responde |
| GET | `/v1/state` | Estado público (sin secretos) |
| GET | `/v1/profiles` | Listar perfiles y sesiones |
| POST | `/v1/profiles` | Crear perfil |
| GET | `/v1/profiles/:id` | Consultar un perfil |
| PATCH | `/v1/profiles/:id` | Editar un perfil |
| DELETE | `/v1/profiles/:id` | Eliminar un perfil; `?releaseCloneAccount=true` libera la cuenta del clon y `?removeVirtualMachine=true` elimina su máquina virtual y su disco |
| POST | `/v1/profiles/:id/start` | Abrir el navegador del perfil |
| POST | `/v1/profiles/:id/stop` | Detener el perfil |
| POST | `/v1/profiles/:id/duplicate` | Duplicar el perfil |
| POST | `/v1/profiles/batch` | Operar varios perfiles; `action`: `start`, `stop`, `move` (`workspaceId`), `add-tags`, `remove-tags`, `set-tags` (`tags`), `set-status` (`statusId`, vacío para quitarlo), `set-proxy` (`proxyId`, vacío para quitarlo), `duplicate` o `delete` (con `deleteData`, `releaseCloneAccount` y `removeVirtualMachine` opcionales) |
| GET | `/v1/statuses` | Listar estados de perfil |
| POST | `/v1/statuses` | Crear un estado (`name`, `color`) |
| PATCH | `/v1/statuses/:id` | Editar un estado |
| DELETE | `/v1/statuses/:id` | Eliminar un estado; sus perfiles quedan sin estado |
| GET | `/v1/proxies` | Listar proxies sin secretos |
| POST | `/v1/proxies` | Crear proxy |
| PATCH | `/v1/proxies/:id` | Editar proxy |
| DELETE | `/v1/proxies/:id` | Eliminar proxy |
| POST | `/v1/proxies/:id/test` | Probar conectividad del proxy |
| POST | `/v1/proxies/test` | Probar varios proxies; `ids` opcional (sin `ids`, todos) |
| GET | `/v1/workspaces` | Listar espacios |
| POST | `/v1/workspaces` | Crear espacio |
| PATCH | `/v1/workspaces/:id` | Editar espacio |
| DELETE | `/v1/workspaces/:id` | Eliminar espacio sin perfiles |
| GET | `/v1/status` | Sesiones activas y estado de la API |
| GET | `/v1/activity` | Historial (`?limit=50`) |

La API se detiene al cerrar PerfilLab. Si el puerto está ocupado, el error se muestra en la interfaz. Regenerar el token invalida los scripts que usaban el anterior.

> Esta API de perfiles no es el servidor de licencias. Usa `45800/v1` por defecto, mientras que el backend de licencias usa `45900/v1`, de modo que ambos pueden convivir en el mismo equipo. El backend de licencias se describe en [`license-server/docs/SERVIDOR_LOCAL.md`](license-server/docs/SERVIDOR_LOCAL.md).

## Arquitectura

```text
electron/
  main.js             Ventana, bandeja, diálogos, IPC, ciclo de vida y puerta de licencia
  preload.js          Puente mínimo y aislado para el renderer
  app-service.js      Lógica de perfiles, proxies, espacios, ajustes, import/export
  app-launcher.js     Detección del menú Inicio y lanzamiento supervisado de aplicaciones
  native-clone.js     Motor de clones: cuentas locales, credenciales, ACL, scripts elevados y proceso supervisado
  hyperv.js           Proveedor Hyper-V: discos diferenciales, VM por perfil, ventana vmconnect y operaciones elevadas
  store.js            Estado JSON, normalización, migración y escritura atómica
  launcher.js         Arranque del navegador, relay de proxy y detención de procesos
  api-server.js       Servidor HTTP local y autenticación Bearer
  browsers.js         Detección de navegadores instalados
  proxy-test.js       Prueba de conectividad del proxy
  validation.js       Validación y normalización de entradas
  secrets.js          Cifrado con safeStorage
  paths.js            Rutas de datos y perfiles
  license.js          Código de equipo, activación en línea/offline, revocaciones y estado
  license-public.js   Clave pública, keyId, límite de 50.000 asientos y servidor configurado
renderer/
  index.html          Estructura de la interfaz
  styles.css          Temas y estilos
  app.js              Renderizado, formularios, modales y eventos
  license.html        Pantalla de activación
  license.css         Estilos de la activación
  license.js          Activación por clave, archivo, texto y comprobación en línea
shared/
  license-format.js   Formato canónico, firmas v1/v2 y listas de revocación
license-admin/
  electron/main.js    IPC, sesión y diálogos de la consola
  electron/server-client.js  Cliente HTTPS del servidor central
  renderer/           Panel, inventario, emisión, lotes, pedidos, auditoría y herramientas
  lib/core.js         Código heredado de la bóveda local (excluido del paquete)
  seed/vault.json     Bóveda heredada de 2.000 asientos (excluida del paquete)
license-server/
  src/                API HTTP, PostgreSQL/SQLite, keystore, licencias, PayPal, SMTP y auditoría
  scripts/            Inicialización, administradores, exportación del keystore y copias
  public/             Tienda, páginas de pago y descarga del instalador
  test/               Pruebas del backend, del correo, del instalador y de configuración
  docs/OPERACIONES.md Despliegue, copias, restauración, rotación y compromiso
  docs/DESPLIEGUE_ONLINE.md  Hosting gratuito con PostgreSQL y secretos por entorno
  docs/DESPLIEGUE_SUPABASE_RENDER.md  Ruta concreta con Supabase y Render
render.yaml          Blueprint de Render para el servidor de licencias
installer/
  client.iss          Instalador Inno Setup del cliente
  admin.iss           Instalador Inno Setup de la consola administrativa
scripts/
  smoke.js            Pruebas de extremo a extremo de la aplicación
  license-test.js     Pruebas del sistema de licencias del cliente
  ui-clone-check.js  Verificación de la interfaz de clones por CDP con capturas
  provision-license.js  Genera claves, bóveda heredada y clave pública del cliente
  pack.js             Empaquetado del cliente
  pack-admin.js       Empaquetado de la consola de administración
  pack-audit.js       Auditoría del contenido y de secretos en los paquetes
  build-installers.js Compila ambos instaladores Inno y el manifiesto SHA-256
  verify-installers.js Instala, audita, abre y desinstala ambos instaladores
  pack-installer.js   ZIP heredado del cliente con SHA-256 y tamaño
  set-license-endpoint.js  Graba o borra el endpoint compilado del cliente
test/
  native-clone.test.js           Motor, credenciales, scripts elevados y ACL
  app-launcher-clone.test.js     Lanzamiento por cuenta/datos/VM, conflictos y modos
  clone-store.test.js            Migración al esquema v5/v6/v7, cuentas y máquinas virtuales
  hyperv.test.js                 Nombres, script elevado, capacidades, límites y parada de VM
```

Seguridad aplicada en la ventana: `contextIsolation`, `sandbox`, sin `nodeIntegration`, preload con acciones permitidas, CSP estricta, bloqueo de navegación y ventanas nuevas, denegación de permisos y DevTools desactivadas en producción. Las contraseñas de las cuentas de clon se generan con aleatoriedad criptográfica, se cifran con `safeStorage` y nunca se incluyen en el estado público, las exportaciones, la actividad, los registros ni la línea de comandos; los scripts elevados validan el nombre y la descripción de la cuenta antes de crear o eliminar nada. El servidor local no emite CORS, rechaza cabeceras `Origin` y no expone el token ni las contraseñas en sus respuestas. En la versión empaquetada, todas las acciones IPC distintas de las de licencia y la propia API local exigen una licencia activa; si la licencia caduca, la aplicación vuelve a la pantalla de activación y detiene los perfiles.

La consola de administración aplica el mismo aislamiento, valida el remitente IPC, bloquea navegación y ventanas nuevas, no incluye la bóveda ni la clave privada y solo persiste la dirección del servidor. El cliente empaquetado ignora las variables de desarrollo que permiten sustituir la clave pública: `PERFILLAB_DEV` y `PERFILLAB_DEBUG_PORT` solo tienen efecto fuera de un paquete. El servidor central se ejecuta aparte, nunca dentro de los ejecutables distribuidos, y sus pruebas y código fuente quedan excluidos de ambos paquetes.

## Origen del proyecto

El punto de partida fue el análisis estático de instaladores comerciales de gestión de perfiles (Multilogin, AdsPower y Dolphin Anty). Se documentaron sus flujos visibles (perfiles, proxies, espacios, estados, acciones masivas, importación/exportación, API local, bandeja) y se reimplementaron con un enfoque propio en Electron. Los instaladores originales no se ejecutaron durante el análisis y no se reutilizaron sus claves, certificados, binarios, kernels, recursos ni cuentas. Las funciones de evasión o suplantación de huellas, la importación/exportación de cookies y el scripting RPA propietario quedaron fuera del alcance por diseño.
